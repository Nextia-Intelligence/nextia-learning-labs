"""Tests of the rules for Indonesian receipts (rules_id.py): the words of the dev receipts."""

from cord_eval import rules_id
from doc_extract.pages import Line, Page


def line(text, x0, top, x1, bottom):
    return Line(text, (x0, top, x1, bottom), 0.99, bottom - top)


def test_rules_pair_label_and_amount_on_the_same_row():
    lines = [line("2 Nasi Goreng", 10, 100, 200, 120), line("50.000", 300, 101, 380, 121),
             line("Sub Total", 10, 140, 120, 160), line("50.000", 300, 141, 380, 161),
             line("PB1 (10%)", 10, 170, 120, 190), line("5.000", 310, 171, 380, 191),
             line("TOTAL", 10, 200, 120, 230), line("55.000", 290, 200, 380, 230)]
    ex = rules_id.extract([Page("r.jpg", 1, 400, 300, "px", "ocr", lines)])
    got = {n: ex.fields[n].value for n in ("total", "subtotal", "tax", "currency")}
    assert got == {"total": "55000", "subtotal": "50000", "tax": "5000", "currency": "IDR"}
    assert ex.fields["currency"].status == "inferred"
    assert [ln.text for ln in ex.fields["total"].lines] == ["TOTAL", "55.000"]
    assert [(i["quantity"], i["line_total"]) for i in ex.items] == [(2, "50000")]


def test_grand_total_wins_and_a_total_item_count_is_not_a_total():
    lines = [line("TOTAL ITEMS 3", 10, 80, 200, 100), line("TOTAL", 10, 100, 100, 120),
             line("56,181", 300, 100, 380, 120), line("GRAND TOTAL", 10, 130, 150, 150),
             line("61,799", 300, 130, 380, 150)]
    ex = rules_id.extract([Page("r.jpg", 1, 400, 300, "px", "ocr", lines)])
    assert ex.fields["total"].value == "61799"
    assert ex.fields["subtotal"].value == "56181"


def test_the_course_words_miss_pb1_and_grand_total():
    lines = [line("PB1 (10%)", 10, 170, 120, 190), line("5.000", 310, 171, 380, 191),
             line("GRAND TOTAL", 10, 200, 150, 230), line("55.000", 290, 200, 380, 230)]
    ex = rules_id.extract([Page("r.jpg", 1, 400, 300, "px", "ocr", lines)], labels=rules_id.COURSE_LABELS)
    assert ex.fields["tax"].value is None and ex.fields["total"].value is None
