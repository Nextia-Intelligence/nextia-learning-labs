"""Rules for Indonesian receipts: the course's rules (doc_extract/fields.py), adapted.

The course's rules know Larkfield's words and money with cents. On CORD's receipts they meet three
new things, and this module changes exactly those:

1. Money: rupiah have no cents, and the thousands are grouped with a point or a comma (idr.py).
2. Words: "Sub Total", "SUBTTL", "PB1" and "Pajak" (restaurant tax), "PPN", "VAT", "Service",
   "Grand Total", "TL", "Diskon". Every word here was seen on the 40 dev receipts, never on the
   60 test receipts.
3. Where the amount is: a label and its amount are often two OCR lines on one printed row, and on a
   crooked photo the amount at the right edge sits higher or lower than its label. The rules pair a
   label with the amount whose centre is closest along the page's slope (as the course's rows() does),
   so a large "Total" next to a small "Pajak" line does not mix the two.

Every value keeps the lines it came from (its evidence), as in the course.
"""

from __future__ import annotations

import math
import re

from cord_eval import idr
from doc_extract import fields
from doc_extract.fields import Extraction, Found
from doc_extract.pages import Line, Page, row_text, rows

# The course's words (doc_extract/fields.py): Larkfield's receipts, in English and French.
COURSE_LABELS = (
    ("subtotal", fields.SUBTOTAL),
    ("tax", fields.TAX),
    ("total", fields.TOTAL),
)

# The words of the 40 dev receipts. The first pattern that matches the start of a line wins
# (plain lower-case text).
LABELS = (
    ("subtotal", re.compile(r"^sub\W*t")),  # Sub Total, SUBTOTAL, SUB-TOTAL, SUBTTL, Sub, Total
    ("tax", re.compile(r"^(tax|vat|ppn|pb\W*1|pajak|restaurant tax)")),
    ("service", re.compile(r"^(service|svc|serv\b)")),
    ("discount", re.compile(r"^(discount|diskon|disc\b)")),
    ("total", re.compile(r"^(grand\W*total|total|tl\b)")),
    ("cash", re.compile(r"^(cash|tunai)")),
    ("change", re.compile(r"^(change|kembali)")),
)
NOT_A_TOTAL = re.compile(r"(item|qty|disc|tax|pajak)")  # "TOTAL ITEMS 3", "TOTAL DISC"
FIELDS = ("total", "subtotal", "tax", "currency")  # the contract fields CORD can score
EXTRA = ("service", "discount")  # CORD-only amounts, for the adds-up check


def _plain(text: str) -> str:
    return fields._plain(text).lstrip("*#:-. ")


def label_of(text: str, labels=LABELS) -> tuple[str | None, str]:
    """The label at the start of a line, and the rest of the line after it."""
    p = re.sub(r"^\d{1,3}\s+(?=total)", "", _plain(text))  # "14 Total": 14 items, then the total
    for name, pattern in labels:
        m = pattern.match(p)
        if m:
            if name == "total" and NOT_A_TOTAL.search(p):
                return None, text
            return name, p[m.end():]
        if name == "total" and re.search(r"\d.*\btotal\W*$", p):  # "41,000 Total." (amount first)
            return name, p[: p.rfind("total")]
    return None, text


def _amount_after_label(rest: str) -> str | None:
    rest = re.sub(r"\(?\d+(?:[.,]\d+)?\s*[%z]\)?", " ", rest, flags=re.IGNORECASE)  # (10%), 10Z (an OCR'd %)
    rest = re.sub(r"^\W*\d\b", " ", rest)  # the "1" of "PB 1"
    return idr.amount(rest)


def _same_row(a: Line, b: Line, slope: float = 0.0) -> float:
    """How far apart two lines are in height, measured along the page's slope (degrees), in units of
    the smaller line's height. On a crooked photo, the amount at the right edge of a row sits higher
    or lower than its label at the left edge; turning the centres back by the slope lines them up."""
    t = math.radians(slope)

    def y(ln: Line) -> float:
        return -ln.cx * math.sin(t) + ln.cy * math.cos(t)

    return abs(y(a) - y(b)) / max(min(a.height, b.height), 1.0)


def local_slope(label_line: Line, lines: list[Line]) -> float:
    """The median slope (degrees) of the lines around a label: a photo of curved paper bends
    differently in each part, so one slope for the whole page is not enough."""
    near = sorted(ln.angle for ln in lines if abs(ln.cy - label_line.cy) < 4 * label_line.height
                  and ln.box[2] - ln.box[0] > 1.5 * ln.height)
    return near[len(near) // 2] if near else 0.0


def amount_for(label_line: Line, rest: str, lines: list[Line], labels=LABELS) -> tuple[str | None, list[Line]]:
    """The amount of a label: on its own line, or on the line closest in height on the same row."""
    v = _amount_after_label(rest)
    if v is not None:
        return v, [label_line]
    best = None
    slope = local_slope(label_line, lines)
    for ln in lines:
        if ln is label_line or label_of(ln.text, labels)[0] is not None:
            continue
        if re.search(r"[a-z]{3}", fields._plain(ln.text).replace("rp", "")):  # another line of words
            continue
        a = idr.amount(ln.text)
        d = _same_row(label_line, ln, slope)
        if a is not None and d < 0.7 and (best is None or d < best[0]):
            best = (d, a, ln)
    return (best[1], [label_line, best[2]]) if best else (None, [])


def extract(pages: list[Page], path: str = "rules-id", labels=LABELS) -> Extraction:
    """Fill the fields CORD can score (and the CORD-only amounts) from the pages' lines."""
    out = Extraction(pages[0].file if pages else "", path, pages=pages,
                     seconds=round(sum(p.seconds for p in pages), 3))
    found: dict[str, Found] = {}
    grand = None
    for page in pages:
        ordered = sorted(page.lines, key=lambda ln: (ln.cy, ln.cx))
        for ln in ordered:
            name, rest = label_of(ln.text, labels)
            if name is None:
                continue
            value, evidence = amount_for(ln, rest, page.lines, labels)
            if value is None:
                continue
            if name == "total" and re.match(r"grand", _plain(ln.text)):
                grand = Found("total", value, "found", "", ln.text, evidence, page.page)
            elif name not in found:
                found[name] = Found(name, value, "found", "", " ".join(x.text for x in evidence), evidence, page.page)
    if grand is not None:  # "GRAND TOTAL" wins over a plain "TOTAL" (which is then the subtotal)
        plain_total = found.get("total")
        if plain_total is not None and "subtotal" not in found and plain_total.value != grand.value:
            found["subtotal"] = Found("subtotal", plain_total.value, "found", "a TOTAL above the GRAND TOTAL",
                                      plain_total.raw, plain_total.lines, plain_total.page)
        found["total"] = grand
    rp = next(((p, ln) for p in pages for ln in p.lines if re.search(r"(?i)\brp\.?\s*\d", ln.text)), None)
    if rp:
        found["currency"] = Found("currency", "IDR", "found", "", rp[1].text, [rp[1]], rp[0].page)
    elif any(f.value for f in found.values()):
        found["currency"] = Found("currency", "IDR", "inferred", "rupiah amounts: thousands groups, no cents")
    for name in FIELDS + EXTRA:
        found.setdefault(name, Found(name, None, "absent", "not_found"))
    out.fields = {name: found[name] for name in FIELDS + EXTRA}
    out.items = items(pages, labels)
    return out


QTY_FIRST = re.compile(r"^(\d{1,2})\s*[xX×]?\s+(?=\D)")  # "3 Nasi Putih", "2x Teh"
QTY_TIMES = re.compile(r"\b(\d{1,2})\s*[xX×@]\s*\d")  # "2 x 24,000", "1 @ 10.000"


def items(pages: list[Page], labels=LABELS) -> list[dict]:
    """The item lines above the first summary line (subtotal, tax, total): a description with
    letters and an amount at the end of the row, with a quantity when one is printed first."""
    out = []
    for page in pages:
        for row in rows(page.lines):
            text = row_text(row)
            if label_of(row[0].text, labels)[0] is not None:
                break  # the summary starts: no more items on this page
            values = idr.amounts(text)
            words = re.sub(r"[\d.,x×@:\-()%]+", " ", text).strip()
            if not values or len(re.sub(r"[^A-Za-z]", "", words)) < 2:
                continue
            q = QTY_FIRST.match(text.strip()) or QTY_TIMES.search(text)
            quantity = int(q[1]) if q else None
            out.append({"description": words, "quantity": quantity, "unit_price": None,
                        "line_total": values[-1], "page": page.page, "lines": row})
    return out
