# CORD v2 test sample (for the case study "Read real receipts")

Source: CORD v2, NAVER CLOVA, https://huggingface.co/datasets/naver-clova-ix/cord-v2
(revision 7f0115a4b758a71d6473b8d085751692da2fef98, file data/test-00000-of-00001-9c204eb3f4e11791.parquet,
SHA-256 51c65f1788faff392abe2a0b55b023eb23e9be551c509138eaa3a832514224e7).
Licence: Creative Commons Attribution 4.0 International (CC BY 4.0), https://creativecommons.org/licenses/by/4.0/

Attribution: "CORD: A Consolidated Receipt Dataset for Post-OCR Parsing", Seunghyun Park, Seung Shin,
Bado Lee, Junyeop Lee, Jaeheung Surh, Minjoon Seo and Hwalsuk Lee, Workshop on Document Intelligence
at NeurIPS 2019. Data by NAVER CLOVA, CC BY 4.0.

Changes made by Nextia Learning: the 100 receipts of the test split only; each picture converted from
PNG to JPEG (quality 90) and, when its longer side was over 2,000 pixels, made smaller to 2,000 pixels
(labels.jsonl gives the scale; CORD's coordinates are unchanged, in the original picture's pixels);
our own IDs (cord-test-000 = CORD image_id 0) and a dev/test split (seed 13). The labels are unchanged.
