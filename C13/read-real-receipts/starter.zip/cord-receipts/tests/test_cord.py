"""Tests of the case study's own code (they need no OCR and no data download)."""

import json

import pytest

from cord_eval import check, idr, sample, score
from doc_extract import contract


@pytest.mark.parametrize("text, want", [
    ("60.000", "60000"), ("24,000", "24000"), ("Rp.118.000", "118000"), ("91000", "91000"),
    ("9.500,00", "9500"), ("63,000.00", "63000"), ("1,565,938", "1565938"), ("PB1 (10%) 10,091", "10091"),
    ("TAX 10.00 % 4.664", "4664"), ("Pajak -", None),
])
def test_rupiah_amounts(text, want):
    assert idr.amount(text) == want


def test_the_course_money_reader_does_not_read_rupiah():
    # the reason the course's rules miss these receipts: they expect cents
    assert contract.money("100,909") is None
    assert contract.money("60.000") is None
    assert contract.money("TAX 10.00 % 4.664") == "10.00"  # the tax rate, read as an amount


def test_truth_maps_cord_labels():
    gt = {"gt_parse": {"menu": [{"nm": "TEH", "cnt": "2", "price": "10.000"}, {"nm": "NASI", "price": "8.000"}],
                       "sub_total": {"subtotal_price": "18.000", "tax_price": ["1.000", "800"]},
                       "total": {"total_price": "Rp 19.800", "cashprice": "20.000"}}}
    t = sample.truth(gt)
    assert (t["total"], t["subtotal"], t["tax"], t["currency"]) == ("19800", "18000", "1800", "IDR")
    assert t["items"] == [{"description": "TEH", "quantity": 2, "line_total": "10000"},
                          {"description": "NASI", "quantity": None, "line_total": "8000"}]


def test_adds_up_with_tax_on_top_or_included():
    assert check.indonesian_rule({"subtotal": "100909", "tax": "10091", "total": "111000"}) == "adds up"
    assert check.indonesian_rule({"subtotal": "60000", "tax": "5455", "total": "60000"}) == "adds up"  # included
    assert check.indonesian_rule({"subtotal": "238000", "tax": "25585", "service": "17850", "total": "281435"}) == "adds up"
    assert check.course_rule({"subtotal": "238000", "tax": "25585", "total": "281435"}) == "does not add up"
    assert check.indonesian_rule({"subtotal": "50000", "tax": "5000", "total": "65000"}) == "does not add up"


def test_score_outcomes():
    assert score.outcome("total", "91000.00", "91000") == "correct"
    assert score.outcome("total", None, "91000") == "missing"
    assert score.outcome("tax", "10", "4664") == "wrong"
    assert score.outcome("tax", "4664", None) == "unlabelled"
    assert score.outcome("currency", "CAD", "IDR") == "wrong"


def test_the_sample_reads_its_labels(tmp_path, monkeypatch):
    folder = tmp_path / "cord-v2-test-sample"
    folder.mkdir()
    gt = json.dumps({"gt_parse": {"total": {"total_price": "1.000"}}, "valid_line": []})
    (folder / "labels.jsonl").write_text(json.dumps({"id": "cord-test-000", "file": "images/cord-test-000.jpg",
        "cord_image_id": 0, "split": "test", "original_size": [10, 10], "size": [10, 10], "scale": 1.0,
        "ground_truth": gt}) + "\n")
    monkeypatch.setenv("CORD_DIR", str(folder))
    sample.load.cache_clear()
    assert sample.get("000").truth["total"] == "1000"
    sample.load.cache_clear()
