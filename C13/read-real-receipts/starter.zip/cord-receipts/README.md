# cord-receipts

Run the course's `doc-extract` pipeline on **real receipts** from another country, and measure it
honestly against the receipts' own labels. A case study of the course *Document and Multimodal AI* on
Nextia Learning.

The receipts are 100 photos of Indonesian receipts from **CORD v2** (NAVER CLOVA, CC BY 4.0): see
`DATASET.md`. Shop names and card numbers are blurred in the pictures by the dataset's creators.

## Set up (once)

You need Python 3.12 or later. macOS or Linux:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m cord_eval.data
python -m pytest -q
```

Windows (PowerShell):

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m cord_eval.data
python -m pytest -q
```

`cord_eval.data` downloads the sample (19.7 MB) from the course's labs repository and checks its SHA-256
and every file in it. You need no account, no key and no money: OCR runs on your CPU, and the vision
model's answers were recorded by the course team (`recordings/`).

## Use it

```sh
python -m cord_eval.sample                     # the sample: 40 dev receipts, 60 test receipts
python -m cord_eval.sample cord-test-007       # one receipt and its labels, as the course's contract
python -m cord_eval.run --system as_is         # the course's pipeline, unchanged (OCR: about 2 minutes)
python -m cord_eval.run --system all           # every system (OCR results are kept in out/cache/ocr/)
python -m cord_eval.score --split dev          # field accuracy on the dev receipts
python -m cord_eval.score --split test         # ... and on the test receipts, once, at the end
python -m cord_eval.vision_id cord-test-005    # a recorded vision-model answer
```

The systems:

| System | What it is |
|---|---|
| `as_is` | the course's rules (`doc_extract/fields.py`) on prepared OCR: the pipeline unchanged |
| `money_only` | rupiah amounts (`cord_eval/idr.py`) and same-row pairing, with the course's words only |
| `adapted_raw` | the rules for Indonesian receipts (`cord_eval/rules_id.py`) on OCR of the raw picture |
| `adapted` | the same rules on prepared OCR |
| `vision` | the vision model alone (recorded answers, prompt `v2-idr`; only the receipts that were recorded) |
| `combined` | the adapted rules first; the model when the total is missing, unclear or does not add up |

`notebooks/evaluate-cord.ipynb` reads the runs in `out/cord/` (or the author's runs in
`results-author/`, if you have not run them yet) and makes the comparison tables and charts.

A live model call is optional: set `VISION_BASE_URL`, `VISION_API_KEY` and `VISION_MODEL` (any
OpenAI-compatible endpoint whose model reads pictures), then
`python -m cord_eval.vision_id cord-test-005 --live`. It costs about one US cent per receipt.

## Licence

The code is MIT (`LICENSE`). The receipts and their labels are CORD v2 by NAVER CLOVA, CC BY 4.0
(`DATASET.md`, and `data/cord-v2-test-sample/NOTICE.md` for the changes we made).
