"""The case study's sample of CORD v2 receipts, and CORD's labels mapped onto the course's contract.

    python -m cord_eval.sample                  # the sample in numbers
    python -m cord_eval.sample cord-test-007    # one receipt: CORD's labels and the mapped truth

CORD labels a receipt with its own classes (menu, sub_total, total). Only some of them mean the same
as a field of the course's contract `receipt-v1`. The mapping, field by field:

  contract field   CORD label                    note
  total            total.total_price             the amount to pay
  subtotal         sub_total.subtotal_price      before tax and service
  tax              sub_total.tax_price           several values: added up (as the contract says)
  currency         (none)                        every receipt is Indonesian: IDR, from the dataset card
  items            menu: nm, cnt, price          price is the line's total; sub-items are left out
  vendor, date, order_number, payment_method     CORD removed these labels (store_info, payment_info):
                                                 they cannot be scored
  (no field)       service_price, discount_price kept for the adds-up check only

A label of "-" or with no digit (e.g. "Pajak -") is not an amount: the field counts as not labelled.
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass
from decimal import Decimal
from functools import lru_cache
from pathlib import Path

from cord_eval import idr

ROOT = Path(__file__).resolve().parents[1]
SCORED = ("total", "subtotal", "tax", "currency")
CORD_LABEL = {"total": ("total", "total_price"), "subtotal": ("sub_total", "subtotal_price"),
              "tax": ("sub_total", "tax_price"), "service": ("sub_total", "service_price"),
              "discount": ("sub_total", "discount_price")}
CATEGORY = {"total": "total.total_price", "subtotal": "sub_total.subtotal_price", "tax": "sub_total.tax_price"}


def data_dir() -> Path:
    return Path(os.environ.get("CORD_DIR", ROOT / "data" / "cord-v2-test-sample"))


def shown(path: Path) -> str:
    """A path as it is printed: relative to the current folder when it is inside it."""
    try:
        return path.resolve().relative_to(Path.cwd().resolve()).as_posix()
    except ValueError:
        return str(path)


@dataclass
class Receipt:
    id: str
    file: str
    cord_image_id: int
    split: str  # dev | test
    original_size: list
    size: list
    scale: float  # the sample's picture = CORD's picture x scale
    ground_truth: str  # CORD's label, unchanged (a JSON string)

    @property
    def path(self) -> Path:
        return data_dir() / self.file

    @property
    def gt(self) -> dict:
        return json.loads(self.ground_truth)

    @property
    def truth(self) -> dict:
        return truth(self.gt)

    def label_box(self, field: str) -> tuple[float, float, float, float] | None:
        """The box of the amount CORD labelled for this field, in the sample picture's pixels:
        the last word of the first line with that label (the word that holds the amount)."""
        cat = CATEGORY.get(field)
        for line in self.gt.get("valid_line", []):
            if line["category"] == cat and line["words"]:
                w = line["words"][-1]["quad"]
                xs = [w[k] * self.scale for k in ("x1", "x2", "x3", "x4")]
                ys = [w[k] * self.scale for k in ("y1", "y2", "y3", "y4")]
                return (min(xs), min(ys), max(xs), max(ys))
        return None


def _value(raw) -> str | None:
    """A CORD label value -> rupiah, normalised; a list (two tax lines) -> the sum; None if no amount."""
    if raw is None:
        return None
    if isinstance(raw, list):
        values = [_value(r) for r in raw]
        values = [v for v in values if v is not None]
        if not values:
            return None
        if len(set(values)) == 1:  # the same amount labelled twice
            return values[0]
        return idr.normalise_decimal(sum(Decimal(v) for v in values))
    return idr.amount(str(raw))


def _menu(gt_parse: dict) -> list[dict]:
    menu = gt_parse.get("menu") or []
    return [menu] if isinstance(menu, dict) else list(menu)


def truth(gt: dict) -> dict:
    """CORD's labels as the course's contract: {field: value or None}, plus items and CORD-only amounts."""
    p = gt.get("gt_parse", {})
    out: dict = {}
    for field, (group, key) in CORD_LABEL.items():
        g = p.get(group)
        out[field] = _value(g.get(key)) if isinstance(g, dict) else None
    out["currency"] = "IDR"
    items = []
    for m in _menu(p):
        price = _value(m.get("price"))
        if price is None:
            continue
        cnt = m.get("cnt")
        qty = idr.amount(str(cnt)) if cnt is not None else None
        items.append({"description": m.get("nm") if isinstance(m.get("nm"), str) else " ".join(m.get("nm") or []),
                      "quantity": int(Decimal(qty)) if qty and Decimal(qty) == int(Decimal(qty)) else None,
                      "line_total": price})
    out["items"] = items
    return out


@lru_cache(maxsize=1)
def load() -> tuple[Receipt, ...]:
    p = data_dir() / "labels.jsonl"
    if not p.exists():
        raise SystemExit(f"{p} does not exist. Get the sample first: python -m cord_eval.data")
    return tuple(Receipt(**json.loads(line)) for line in p.read_text(encoding="utf-8").splitlines() if line.strip())


def receipts(split: str = "all") -> list[Receipt]:
    return [r for r in load() if split in ("all", r.split)]


def get(receipt_id: str) -> Receipt:
    for r in load():
        if r.id == receipt_id or r.id == f"cord-test-{receipt_id}":
            return r
    raise SystemExit(f"No receipt {receipt_id} in the sample.")


def main(argv: list[str] | None = None) -> None:
    argv = sys.argv[1:] if argv is None else argv
    if argv:
        r = get(argv[0])
        print(f"{r.id}  {r.file}  (CORD test image {r.cord_image_id}, our split: {r.split})")
        print(f"  picture {r.size[0]} x {r.size[1]} px (CORD's original {r.original_size[0]} x {r.original_size[1]})")
        t = r.truth
        for f in ("total", "subtotal", "tax", "service", "discount", "currency"):
            print(f"  {f:<10} {t[f] if t[f] is not None else '(not labelled)'}")
        for it in t["items"]:
            q = it["quantity"] if it["quantity"] is not None else "?"
            print(f"    item: {q} x {it['description']} = {it['line_total']}")
        return
    rs = receipts()
    print(f"{len(rs)} receipts in {shown(data_dir())}: dev {len(receipts('dev'))}, test {len(receipts('test'))}")
    for f in ("total", "subtotal", "tax", "service", "discount"):
        n = {s: sum(r.truth[f] is not None for r in receipts(s)) for s in ("dev", "test")}
        print(f"  {f:<10} labelled on {n['dev'] + n['test']:>3}  (dev {n['dev']}, test {n['test']})")
    n_items = {s: sum(len(r.truth["items"]) for r in receipts(s)) for s in ("dev", "test")}
    print(f"  item lines {n_items['dev'] + n_items['test']:>5}  (dev {n_items['dev']}, test {n_items['test']})")


if __name__ == "__main__":
    main()
