"""Score the runs against CORD's labels, field by field, as the course's evaluate.py does.

    python -m cord_eval.score                         # every system in out/cord/, the test receipts
    python -m cord_eval.score --split dev             # the dev receipts (to adapt the rules)
    python -m cord_eval.score --systems as_is,adapted --json out/cord/score.json

For every scored field of every receipt, one outcome:
  correct      the value is the labelled amount (rupiah, compared as numbers)
  missing      CORD labels an amount, the system gives none
  wrong        the system gives another amount
  unlabelled   CORD has no label for this field: not scored (the field may still be printed;
               CORD's labels miss some, and blurred or cut-off parts have none)
Currency is IDR on every receipt (the dataset is Indonesian), so it is always scored.
A receipt is complete when its labelled total, subtotal and tax are all correct.

Boxes: for a correct total, the box is "on the label" when the centre of the word CORD labelled as
the total lies inside the system's evidence box (both on the sample picture).
Items: a labelled item line is found when a found line has the same amount (and the same quantity,
when both give one).
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

from cord_eval import check, idr, sample
from cord_eval.run import OUT, SYSTEMS

FIELDS = ("total", "subtotal", "tax", "currency")


def outcome(name: str, got, want) -> str:
    if want is None:
        return "unlabelled"
    if got is None:
        return "missing"
    if name == "currency":
        return "correct" if str(got).upper() == want else "wrong"
    return "correct" if idr.amount(str(got)) is not None and idr.same(idr.amount(str(got)), want) else "wrong"


def inside(point, box) -> bool:
    return box is not None and box[0] - 3 <= point[0] <= box[2] + 3 and box[1] - 3 <= point[1] <= box[3] + 3


def load_run(system: str) -> dict[str, dict]:
    p = OUT / f"{system}.jsonl"
    if not p.exists():
        return {}
    return {r["id"]: r for r in (json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip())}


def score(system: str, split: str = "test", only: set[str] | None = None) -> dict | None:
    run = load_run(system)
    if not run:
        return None
    cells: dict = defaultdict(Counter)
    per: dict = {}
    complete = boxes_ok = boxes_n = items_found = items_true = 0
    receipts = [r for r in sample.receipts(split) if (only is None or r.id in only) and r.id in run]
    adds = Counter()
    routed = Counter()
    for r in receipts:
        rec, t = run[r.id], r.truth
        row = {}
        for name in FIELDS:
            got = rec["fields"].get(name, {}).get("value") if rec["read"] else None
            o = outcome(name, got, t[name])
            row[name] = o
            cells[name][o] += 1
            if name != "currency" and o == "unlabelled" and got is not None:
                cells[name]["value_where_unlabelled"] += 1
        ok = all(row[n] in ("correct", "unlabelled") for n in ("total", "subtotal", "tax")) and row["total"] == "correct"
        complete += ok
        if row["total"] == "correct":
            lb = r.label_box("total")
            if lb is not None:
                boxes_n += 1
                centre = ((lb[0] + lb[2]) / 2, (lb[1] + lb[3]) / 2)
                boxes_ok += inside(centre, rec["fields"]["total"].get("box"))
        got_items = rec.get("items", [])
        for w in t["items"]:
            items_true += 1
            items_found += any(g.get("line_total") is not None and idr.same(g["line_total"], w["line_total"])
                               and (w["quantity"] is None or g.get("quantity") is None or g["quantity"] == w["quantity"])
                               for g in got_items)
        vals = {k: (rec["fields"].get(k, {}).get("value") if rec["read"] else None)
                for k in ("total", "subtotal", "tax", "service", "discount")}
        adds[check.indonesian_rule(vals)] += 1
        review = rec["model"].get("review")
        if review is not None:  # the combined path routes each receipt: review or straight through
            routed["review" if review else "straight"] += 1
            if row["total"] == "wrong":
                routed["wrong_total_caught" if review else "wrong_total_to_agents"] += 1
        per[r.id] = {"fields": row, "complete": ok, "model": bool(rec["model"].get("used")),
                     "review": review}
    labelled = {n: sum(v for k, v in cells[n].items() if k in ("correct", "missing", "wrong")) for n in FIELDS}
    return {"system": system, "split": split, "receipts": len(receipts),
            "fields": {n: dict(cells[n]) | {"labelled": labelled[n]} for n in FIELDS},
            "correct": sum(cells[n]["correct"] for n in FIELDS), "labelled": sum(labelled.values()),
            "complete": complete, "total_box_on_label": [boxes_ok, boxes_n],
            "items": [items_found, items_true], "adds_up": dict(adds), "routing": dict(routed),
            "model_calls": sum(p["model"] for p in per.values()), "per_receipt": per}


def print_table(results: list[dict]) -> None:
    head = f"{'system':<12}" + "".join(f"{n:>13}" for n in FIELDS) + f"{'all':>12}{'complete':>10}{'items':>10}"
    print(head)
    for s in results:
        row = f"{s['system']:<12}"
        for n in FIELDS:
            c = s["fields"][n]
            row += f"{str(c.get('correct', 0)) + '/' + str(c['labelled']):>13}"
        row += f"{str(s['correct']) + '/' + str(s['labelled']):>12}{str(s['complete']) + '/' + str(s['receipts']):>10}"
        row += f"{str(s['items'][0]) + '/' + str(s['items'][1]):>10}"
        print(row)
    print("\nwrong / missing per field (w/m):")
    for s in results:
        print(f"  {s['system']:<12}" + "  ".join(
            f"{n} {s['fields'][n].get('wrong', 0)}/{s['fields'][n].get('missing', 0)}" for n in FIELDS)
            + f"   total's box on CORD's label: {s['total_box_on_label'][0]} of {s['total_box_on_label'][1]}")
    for s in results:
        if s["routing"]:
            r = s["routing"]
            print(f"  {s['system']}: model called for {s['model_calls']} receipts; to review {r.get('review', 0)}, "
                  f"straight through {r.get('straight', 0)}; wrong totals caught by review "
                  f"{r.get('wrong_total_caught', 0)}, sent on {r.get('wrong_total_to_agents', 0)}")


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser(description="Score the CORD runs against CORD's labels.")
    ap.add_argument("--systems", default=",".join(s for s in SYSTEMS if s != "vision"),
                    help="default: every system but vision (the model alone has answers for 21 receipts only)")
    ap.add_argument("--split", default="test", choices=("all", "dev", "test"))
    ap.add_argument("--only", default="", help="score only these receipts (comma-separated IDs)")
    ap.add_argument("--json", help="also write the full result to this file")
    args = ap.parse_args(argv)
    only = {x.strip() for x in args.only.split(",") if x.strip()} or None
    results = [x for x in (score(s.strip(), args.split, only) for s in args.systems.split(",")) if x]
    if not results:
        raise SystemExit("No runs in out/cord/. Run them first: python -m cord_eval.run --system all")
    n = results[0]["receipts"]
    print(f"{args.split} receipts: {n}. Correct values of the values CORD labels (rupiah compared as numbers).")
    print_table(results)
    if args.json:
        Path(args.json).parent.mkdir(parents=True, exist_ok=True)
        Path(args.json).write_text(json.dumps(results, indent=1, ensure_ascii=False), encoding="utf-8")
        print(f"written to {args.json}")


if __name__ == "__main__":
    main()
