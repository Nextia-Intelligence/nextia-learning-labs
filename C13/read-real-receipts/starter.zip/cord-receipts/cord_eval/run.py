"""Run the course's pipeline, and its adapted versions, on the CORD sample.

    python -m cord_eval.run --system as_is                 # the course's rules on prepared OCR, unchanged
    python -m cord_eval.run --system money_only            # rupiah amounts, but only the course's words
    python -m cord_eval.run --system adapted               # the rupiah rules (rules_id.py) on prepared OCR
    python -m cord_eval.run --system adapted_raw           # the same rules on OCR of the raw picture
    python -m cord_eval.run --system vision                # the model alone (recorded answers only)
    python -m cord_eval.run --system combined              # rupiah rules on raw OCR first, the model when needed
    python -m cord_eval.run --system all --split test      # every system on the 60 test receipts

Each run writes out/cord/<system>.jsonl: one line per receipt with every value, its status, its box on
the original picture and where it came from. OCR results are kept in out/cache/ocr/ (as in the course),
so the second run is fast. OCR is the heavy part: about 1 second per receipt, and about 1.5 GB of memory.
"""

from __future__ import annotations

import argparse
import json
import re
import time
from pathlib import Path

from cord_eval import check, idr, rules_id, sample, vision_id
from doc_extract import fields, ocr, prices
from doc_extract.fields import Extraction, Found
from doc_extract.pages import Page

OUT = Path("out/cord")
SYSTEMS = ("as_is", "money_only", "adapted_raw", "adapted", "vision", "combined")
LOW_SCORE = 0.80
SCORED = ("total", "subtotal", "tax", "currency")


def box_of(lines) -> list[float] | None:
    if not lines:
        return None
    return [round(min(ln.box[0] for ln in lines), 1), round(min(ln.box[1] for ln in lines), 1),
            round(max(ln.box[2] for ln in lines), 1), round(max(ln.box[3] for ln in lines), 1)]


def values(ex: Extraction | None) -> dict:
    """{field: rupiah value or None} for the adds-up check (the course's money -> rupiah)."""
    out = {}
    for name in ("total", "subtotal", "tax", "service", "discount"):
        f = ex.fields.get(name) if ex else None
        out[name] = idr.amount(str(f.value)) if f is not None and f.value is not None else None
    return out


def why_model(rules: Extraction) -> list[str]:
    """When the combined path asks the model (as the course's combine.why_model, for this contract)."""
    why = []
    total = rules.fields["total"]
    if total.value is None:
        why.append("required field missing: total")
    elif total.score < LOW_SCORE:
        why.append(f"low reading score: total {total.score:.2f}")
    if check.indonesian_rule(values(rules)) == "does not add up":
        why.append("the amounts do not add up")
    return why


def ground(value: str, pages: list[Page]):
    """The OCR line that shows this amount, or None: the model's value cannot be found on the page."""
    for page in pages:
        for ln in page.lines:
            if value in idr.amounts(ln.text):
                return ln
    return None


def combined(r: sample.Receipt, pages: list[Page]) -> tuple[Extraction, dict]:
    rules = rules_id.extract(pages, "combined")
    why = why_model(rules)
    info: dict = {"used": False, "why": why, "flags": {}, "source": {}}
    model = vision_id.read(Path(r.file).name) if why else None
    if why and model is None:
        info["why"] = why + ["no recorded model answer for this receipt: rules only"]
    if model is not None:
        info["used"] = True
        info["usage"] = model.usage | {"seconds": model.seconds}
    for name in SCORED:
        rv = rules.fields[name]
        mv = model.fields.get(name) if model else None
        flags = []
        src = "rules"
        if mv is not None and name == "currency":
            if rv.value is None and mv.value is not None:  # the model's currency: no line to ground it on
                rules.fields[name] = Found(name, mv.value, "inferred", mv.reason or "from the model", mv.raw, [], 1,
                                           mv.confidence)
                src = "model"
        elif mv is not None:
            mval = mv.value
            if rv.value is not None and mval is not None and not idr.same(rv.value, mval):
                flags.append(f"conflict: the rules read {rv.value}, the model read {mval}")
            elif rv.value is None and mval is not None:
                line = ground(mval, pages)
                if line is not None:
                    rules.fields[name] = Found(name, mval, "found", "", mv.raw, [line], 1, mv.confidence)
                else:
                    rules.fields[name] = Found(name, mval, "unverified", "", mv.raw, [], 1, mv.confidence)
                    flags.append("unverified: the model's value cannot be found on the page")
                src = "model"
            elif rv.value is not None and mval is not None:
                src = "both"
            elif rv.value is not None and mval is None:
                flags.append(f"the model says absent ({mv.reason or 'no reason'})")
        info["source"][name] = src
        if flags:
            info["flags"][name] = flags
    info["review"] = review_reasons(rules, info)
    return rules, info


def review_reasons(ex: Extraction, info: dict) -> list[str]:
    """Why a person must check this receipt before anyone uses it (empty: straight through)."""
    why = []
    if ex.fields["total"].value is None:
        why.append("no total")
    if check.indonesian_rule(values(ex)) == "does not add up":
        why.append("the amounts do not add up")
    for name, flags in info.get("flags", {}).items():
        if any(f.startswith(("conflict", "unverified")) for f in flags):
            why.append(f"{name}: {flags[0]}")
    return why


def run_one(system: str, r: sample.Receipt) -> dict:
    t0 = time.perf_counter()
    info: dict = {}
    pages: list[Page] = []
    if system == "vision":
        ex = vision_id.read(Path(r.file).name)
        if ex is not None:
            info = {"used": True, "usage": ex.usage | {"seconds": ex.seconds}}
    else:
        # The course prepares every picture. On the dev receipts, OCR of the raw photo read more values
        # (preparation cropped some receipts badly), so the combined path reads the raw photo.
        pages = ocr.read(r.path, prepare=system not in ("adapted_raw", "combined"))
        if system == "as_is":
            ex = fields.extract(pages, "as_is")
        elif system == "combined":
            ex, info = combined(r, pages)
        elif system == "money_only":
            ex = rules_id.extract(pages, system, rules_id.COURSE_LABELS)
        else:
            ex = rules_id.extract(pages, system)
    rec: dict = {"id": r.id, "split": r.split, "system": system, "read": ex is not None, "fields": {},
                 "items": [], "seconds": round(sum(p.seconds for p in pages), 3) if pages else None,
                 "prepared": pages[0].prepared if pages else {}, "model": info,
                 "wall_seconds": round(time.perf_counter() - t0, 3)}
    if ex is None:
        return rec
    for name in ("total", "subtotal", "tax", "currency", "service", "discount"):
        f = ex.fields.get(name)
        if f is None:
            continue
        v = f.value
        if v is not None and name != "currency":
            v = idr.amount(str(v)) if re.search(r"\d", str(v)) else v  # the course's 91000.00 -> 91000
        rec["fields"][name] = {"value": v, "printed_as": f.raw, "status": f.status, "reason": f.reason,
                               "box": box_of(f.lines), "score": round(f.score, 4) if f.lines else None,
                               "confidence": f.confidence}
    for it in ex.items:
        lt = it.get("line_total")
        rec["items"].append({"description": it.get("description"), "quantity": it.get("quantity"),
                             "line_total": idr.amount(str(lt)) if lt is not None else None,
                             "box": box_of(it.get("lines") or [])})
    return rec


def run(system: str, split: str = "all", quiet: bool = False) -> Path:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"{system}.jsonl"
    receipts = sample.receipts(split)
    lines = []
    for i, r in enumerate(receipts, 1):
        rec = run_one(system, r)
        lines.append(json.dumps(rec, ensure_ascii=False))
        if not quiet:
            total = rec["fields"].get("total", {}).get("value")
            note = f"  model: {'; '.join(rec['model'].get('why', []))}" if rec["model"].get("why") else ""
            print(f"[{i:>3}/{len(receipts)}] {r.id} ({r.split}) total {total if total is not None else '-'}{note}")
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    cost = sum(prices.cost(json.loads(x)["model"].get("usage", {}).get("tokens_in"),
                           json.loads(x)["model"].get("usage", {}).get("tokens_out")) for x in lines)
    used = sum(bool(json.loads(x)["model"].get("used")) for x in lines)
    print(f"{system}: {len(lines)} receipts -> {target}" + (f"; model answers used {used} (US${cost:.3f} when recorded)"
                                                             if system in ("vision", "combined") else ""))
    return target


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser(description="Run doc-extract on the CORD sample.")
    ap.add_argument("--system", default="adapted", choices=SYSTEMS + ("all",))
    ap.add_argument("--split", default="all", choices=("all", "dev", "test"))
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args(argv)
    for s in SYSTEMS if args.system == "all" else (args.system,):
        run(s, args.split, args.quiet)


if __name__ == "__main__":
    main()
