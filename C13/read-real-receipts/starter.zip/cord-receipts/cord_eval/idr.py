"""Amounts in Indonesian rupiah (IDR), as receipts in Indonesia print them.

The course's contract writes money with two decimals (1011.78), and its reader expects them. Rupiah
amounts have no cents, and the thousands are grouped with a point or a comma:

    60.000  ->  60000        24,000  ->  24000        Rp.118.000  ->  118000
    91000   ->  91000        9.500,00  ->  9500       63,000.00   ->  63000

A last group of exactly two digits is cents (".00" or ",00"); a group of three digits is thousands.
"""

from __future__ import annotations

import re
from decimal import Decimal

# A number, with optional thousands groups and optional cents, that is not a percentage ("10%",
# "10.00 %") and not glued to other digits.
AMOUNT = re.compile(r"(?<![\d.,])(\d{1,3}(?:[.,]\d{3})+|\d+)(?:[.,](\d{2}))?(?![\d.,]*\d)(?!\s*%)")


def amounts(text: str) -> list[str]:
    """Every amount on a line, in order, normalised: '2 x 24,000 48,000' -> ['2', '24000', '48000']."""
    out = []
    text = re.sub(r"(?i)\brp\.?", " ", text or "")  # the currency sign: Rp 38.000, Rp.118.000
    for m in AMOUNT.finditer(text):
        whole = re.sub(r"[.,]", "", m[1])
        cents = m[2]
        value = Decimal(whole) + (Decimal(cents) / 100 if cents else 0)
        out.append(normalise_decimal(value))
    return out


def amount(text: str | None) -> str | None:
    """The last amount on a line, normalised, or None: 'PB1 (10%) 10,091' -> '10091'."""
    found = amounts(text or "")
    return found[-1] if found else None


def normalise_decimal(value: Decimal) -> str:
    """60000 -> '60000'; 48982.68 -> '48982.68' (no '.00' for whole rupiah)."""
    value = value.quantize(Decimal("0.01"))
    return str(value.to_integral()) if value == value.to_integral() else str(value)


def same(a: str | None, b: str | None) -> bool:
    """Two amounts are the same number of rupiah (both normalised)."""
    if a is None or b is None:
        return a is b
    return Decimal(a) == Decimal(b)
