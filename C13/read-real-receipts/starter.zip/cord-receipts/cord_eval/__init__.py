"""cord_eval: run the course's doc-extract pipeline on real receipts (CORD v2) and measure it
against the dataset's own labels."""
