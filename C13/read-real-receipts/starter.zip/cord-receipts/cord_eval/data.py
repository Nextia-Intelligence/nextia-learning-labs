"""Get the case study's sample of CORD v2 receipts and check it.

    python -m cord_eval.data                       # download (19.7 MB) and check every file
    python -m cord_eval.data --zip PATH            # use a zip you already downloaded
    python -m cord_eval.data --check               # check the files you have

The sample is the 100 receipts of CORD v2's test split (NAVER CLOVA, CC BY 4.0), kept in the course's
labs repository as one zip with a fixed SHA-256. data/cord-v2-test-sample/NOTICE.md says what was changed.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import os
import urllib.request
import zipfile
from pathlib import Path

from cord_eval import sample

URL = os.environ.get("CORD_SAMPLE_URL", "https://github.com/usmanahmed99/nextia-learning-labs/raw/main/"
                     "C13/read-real-receipts/data/cord-v2-test-sample.zip")  # CORD_SAMPLE_URL: a mirror
SHA256 = "2dd48e2cc1412d4cdcb41314f1ccad70901fc0c3f8126f7cf1554ed3fab3a900"


def check(folder: Path) -> list[str]:
    """The files that are missing or differ from SHA256SUMS."""
    bad = []
    for line in (folder / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        p = folder / name
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != digest:
            bad.append(name)
    return bad


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser(description="Get and check the CORD sample.")
    ap.add_argument("--zip", help="a downloaded cord-v2-test-sample.zip")
    ap.add_argument("--check", action="store_true", help="only check the files you have")
    args = ap.parse_args(argv)
    folder = sample.data_dir()
    if not args.check:
        if args.zip:
            blob = Path(args.zip).read_bytes()
        else:
            print(f"Downloading {URL}")
            with urllib.request.urlopen(URL, timeout=120) as r:
                blob = r.read()
        digest = hashlib.sha256(blob).hexdigest()
        if digest != SHA256:
            raise SystemExit(f"SHA-256 {digest} is not the expected {SHA256}: the download is damaged or changed.")
        print(f"Checked cord-v2-test-sample.zip: SHA-256 {digest[:12]}... is correct")
        with zipfile.ZipFile(io.BytesIO(blob)) as z:
            z.extractall(folder.parent)
    bad = check(folder)
    if bad:
        raise SystemExit(f"{len(bad)} files are missing or differ: {', '.join(bad[:5])}")
    n = len(sample.load())
    print(f"{sample.shown(folder)}: {n} receipts, every file matches SHA256SUMS")


if __name__ == "__main__":
    main()
