"""Does the receipt add up? The course's check, and the check for Indonesian receipts.

The course's contract (doc_extract/validate.py): total = subtotal + shipping + tax.
Restaurants in Indonesia add a service charge, give discounts, and often print a price that already
includes the tax ("PB1 10%" printed only for information). So the check for these receipts accepts:

  total = subtotal + tax + service - discount     (tax added on top)
  total = subtotal + service - discount           (tax included in the prices)

within 1 rupiah per line (receipts round each line).
"""

from __future__ import annotations

from decimal import Decimal


def _d(v) -> Decimal | None:
    return Decimal(str(v)) if v is not None else None


def course_rule(v: dict) -> str:
    """'adds up', 'does not add up' or 'cannot check' with the course's rule (no shipping on these)."""
    sub, tax, total = _d(v.get("subtotal")), _d(v.get("tax")), _d(v.get("total"))
    if None in (sub, tax, total):
        return "cannot check"
    return "adds up" if abs(sub + tax - total) <= Decimal("0.01") else "does not add up"


def indonesian_rule(v: dict) -> str:
    sub, total = _d(v.get("subtotal")), _d(v.get("total"))
    if sub is None or total is None:
        return "cannot check"
    tax, svc, disc = _d(v.get("tax")) or 0, _d(v.get("service")) or 0, abs(_d(v.get("discount")) or 0)
    tolerance = Decimal(3)
    for expected in (sub + tax + svc - disc, sub + svc - disc):
        if abs(expected - total) <= tolerance:
            return "adds up"
    return "does not add up"
