"""The OCR lines of one receipt, top to bottom, with their boxes and reading scores.

    python -m cord_eval.lines cord-test-007            # OCR of the raw photo (as the combined path reads it)
    python -m cord_eval.lines cord-test-007 --prepare  # OCR of the prepared picture (crop, turn, straighten)

Use it on the dev receipts to find the words that the rules must know.
"""

from __future__ import annotations

import sys

from cord_eval import sample
from doc_extract import ocr


def main(argv: list[str] | None = None) -> None:
    argv = sys.argv[1:] if argv is None else argv
    if not argv:
        raise SystemExit("usage: python -m cord_eval.lines RECEIPT_ID [--prepare]")
    r = sample.get(argv[0])
    page = ocr.read(r.path, prepare="--prepare" in argv)[0]
    steps = {k: v for k, v in page.prepared.items() if k != "original_size"}
    print(f"{r.id} ({r.split}): {len(page.lines)} lines, {page.seconds:.2f} s" + (f", prepared: {steps}" if steps else ""))
    for ln in sorted(page.lines, key=lambda ln: ln.cy):
        x0, top, x1, bottom = ln.box
        print(f"  {ln.score:.2f} [{x0:5.0f} {top:5.0f} {x1:5.0f} {bottom:5.0f}]  {ln.text}")


if __name__ == "__main__":
    main()
