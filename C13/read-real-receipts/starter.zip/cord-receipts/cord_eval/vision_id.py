"""The vision model on CORD's receipts: the course's prompt v2, and v2 adapted to rupiah ("v2-idr").

    python -m cord_eval.vision_id cord-test-005               # replay the recorded answer (no key)
    python -m cord_eval.vision_id cord-test-005 --prompt v2   # the course's prompt, unchanged
    python -m cord_eval.vision_id cord-test-005 --live        # call a model yourself (your key, your money)

The course team recorded the answers of a few test receipts (recordings/cord-vision-*.jsonl); this
module replays them, as doc_extract.vision does. The schema is the course's (doc_extract.vision.schema_v2);
only the rules of the prompt change: rupiah amounts and currency IDR.
"""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

from cord_eval import idr, sample
from doc_extract import prices, vision
from doc_extract.fields import Extraction

RECORDINGS = Path(__file__).resolve().parents[1] / "recordings"

PROMPT_V2_IDR = """You read one page of a document attached to a support ticket. It should be a receipt from a shop
or restaurant in Indonesia. Fill the JSON schema from what is PRINTED on this page only.

Rules:
- Copy each value as printed into "printed", and write the normalised form into "value":
  money in Indonesian rupiah, as a whole number with no separators (60.000 -> 60000, 1,565,938 -> 1565938,
  Rp 38.000 -> 38000, 9.500,00 -> 9500); currency as IDR.
- subtotal is the amount before tax and service charge. tax is the sum of all tax lines (PB1, PPN, Pajak,
  VAT, Tax). total is the amount to pay (TOTAL, GRAND TOTAL), not the cash given and not the change.
- shipping is not used on these receipts: set it absent / not_printed.
- order_number is an online order number only. A bill, table or transaction number is NOT an order number.
- If a value is not printed, is cut off, is blurred, or you cannot read it, set value and printed to null,
  status "absent", and reason "not_printed", "cut_off" or "unreadable". Never guess, compute or complete a value.
- status "inferred" only for currency, when no currency is printed (reason: say what you saw).
- confidence: your probability, from 0 to 1, that the value is correct.
- If the page cannot be read at all, set readable to false and every field to absent / unreadable."""

PROMPTS = {"v2": vision.PROMPT_V2, "v2-idr": PROMPT_V2_IDR}


def request(prompt: str, jpeg: bytes) -> dict:
    """The course's request (picture, detail "high", the strict JSON schema), with this prompt."""
    body = vision.request(vision.PROMPT_V2, jpeg)  # the schema comes with prompt v2
    body["messages"][0]["content"][0]["text"] = prompt
    return body


def call_live(prompt_name: str, path: Path) -> dict:
    """Send one receipt picture to the model now. Returns a recording line."""
    from openai import OpenAI

    base, key, model = os.environ.get("VISION_BASE_URL"), os.environ.get("VISION_API_KEY"), os.environ.get("VISION_MODEL")
    if not (base and key and model):
        raise SystemExit("A live call needs VISION_BASE_URL, VISION_API_KEY and VISION_MODEL (see .env.example).")
    client = OpenAI(base_url=base, api_key=key, default_headers={"api-key": key}, timeout=120, max_retries=2)
    jpeg, size = vision.picture(path, 1)
    t = time.perf_counter()
    r = client.chat.completions.create(model=model, **request(PROMPTS[prompt_name], jpeg))
    seconds = time.perf_counter() - t
    return {"file": path.name, "page": 1, "prompt": prompt_name, "model": r.model, "image_px": list(size),
            "image_bytes": len(jpeg), "seconds": round(seconds, 3), "tokens_in": r.usage.prompt_tokens,
            "tokens_out": r.usage.completion_tokens, "answer": r.choices[0].message.content or ""}


def recorded(file: str, prompt: str = "v2-idr") -> dict | None:
    p = RECORDINGS / f"cord-vision-{prompt}.jsonl"
    if not p.exists():
        return None
    for line in p.read_text(encoding="utf-8").splitlines():
        r = json.loads(line)
        if r["file"] == file:
            return r
    return None


def to_extraction(rec: dict) -> Extraction:
    """The model's answer as the same record as the rules give, money as rupiah."""
    ex = vision.to_extraction(rec)
    for name in ("subtotal", "tax", "total"):
        f = ex.fields.get(name)
        if f is not None and f.value is not None:
            f.value = idr.amount(str(f.value)) or f.value
    return ex


def read(file: str, prompt: str = "v2-idr") -> Extraction | None:
    rec = recorded(file, prompt)
    return to_extraction(rec) if rec else None


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser(description="The vision model on one CORD receipt.")
    ap.add_argument("receipt")
    ap.add_argument("--prompt", default="v2-idr", choices=sorted(PROMPTS))
    ap.add_argument("--live", action="store_true", help="call the model now (needs your key)")
    args = ap.parse_args(argv)
    r = sample.get(args.receipt)
    if args.live:
        rec = call_live(args.prompt, r.path)
        print("live call")
    else:
        rec = recorded(Path(r.file).name, args.prompt)
        if rec is None:
            raise SystemExit(f"No recorded answer for {r.id} (prompt {args.prompt}). The recorded receipts are "
                             f"listed in recordings/cord-vision-{args.prompt}.jsonl. Try --live.")
        print("recorded answer (replayed; nothing was sent)")
    ex = to_extraction(rec)
    cost = prices.cost(rec.get("tokens_in"), rec.get("tokens_out"), "chat-strong")
    print(f"{r.id}, prompt {args.prompt}: {rec.get('model')}, {rec.get('tokens_in')} tokens in, "
          f"{rec.get('tokens_out')} out, {rec.get('seconds')} s, about US${cost:.4f}")
    for name in ("total", "subtotal", "tax", "currency"):
        f = ex.fields[name]
        shown = f.value if f.value is not None else f"absent ({f.reason or 'no reason given'})"
        print(f"  {name:<10} {shown}")


if __name__ == "__main__":
    main()
