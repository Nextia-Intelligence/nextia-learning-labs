"""One receipt through one system, field by field: the value, where it came from, its box, and CORD's label.

    python -m cord_eval.show cord-test-059                      # the combined path (run it first)
    python -m cord_eval.show cord-test-008 --system adapted_raw

It reads out/cord/<system>.jsonl, written by `python -m cord_eval.run`.
"""

from __future__ import annotations

import argparse

from cord_eval import sample, score


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser(description="Show one receipt's result.")
    ap.add_argument("receipt")
    ap.add_argument("--system", default="combined")
    args = ap.parse_args(argv)
    r = sample.get(args.receipt)
    run = score.load_run(args.system)
    if r.id not in run:
        raise SystemExit(f"No run of {args.system} in {score.OUT}. Run: python -m cord_eval.run --system {args.system}")
    rec, t = run[r.id], r.truth
    model = rec["model"]
    print(f"{r.id} ({r.split}), system {args.system}")
    if model.get("why"):
        print(f"  model asked: {'; '.join(model['why'])}")
    for name in score.FIELDS:
        f = rec["fields"].get(name, {})
        got = f.get("value")
        o = score.outcome(name, got, t[name])
        src = model.get("source", {}).get(name, "rules")
        box = f.get("box")
        where = f"box {[round(v) for v in box]}" if box else "no box"
        shown = got if got is not None else "-"
        label = t[name] if t[name] is not None else "(no label)"
        print(f"  {name:<9} {shown:<9} {f.get('status', ''):<10} from {src:<6} {where:<26} label {label:<9} {o}")
        for flag in model.get("flags", {}).get(name, []):
            print(f"            {flag}")
    if "review" in model:
        print("  -> review: " + "; ".join(model["review"]) if model["review"] else "  -> straight through")


if __name__ == "__main__":
    main()
