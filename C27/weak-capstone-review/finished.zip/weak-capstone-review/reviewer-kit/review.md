# Review: Theo Marsh's doc-assistant (solution)

Reviewer: the course team. Submission: `theo-doc-assistant`, commit `6423863` (9 commits). Rubric: `marking-rubric.md`. **The submission is constructed:** Theo is not a real person, and the problems were planted on purpose.

## Summary

The product works: a new user can sign in, upload, ask and open the citations, the tests pass and the README's steps start it. But two taught safety checks fail: the evidence route shows the other shop's passages (40 leaks in the isolation checks), and secrets were committed. Two evidence checks fail too: the held-out set was cut after tuning, and the citation check no longer runs. Fix the leak first, then revoke the key, then restore the evidence, then rewrite the claims.

## Marks

| Rubric item | Mark | Reason (what we saw) | Evidence |
|---|---|---|---|
| 1. Working user journey | **Partially demonstrated** | The journey works from the README: indexing, answers, citations that open, a clear "no answer". But answers are shown without the citation check, so a claim with no citation looks like any other claim, and no answer is marked for review. | `citation_check.py`: 2 claims that cite nothing (Q05, B02); the pipeline flagged 0. `pipeline.py` no longer calls `check_answer` (commit `1c8721f`). |
| 2. Reproducible repository and deployment | **Not yet demonstrated** | A `.env` with a model key, a client secret and a session secret was committed. It was deleted later, but it is in every clone. Also, CI no longer runs the isolation checks or the evaluation smoke test, and a test was changed so that it stops checking for them. | `secret_scan.py`: 4 findings in `e3b34e7`; `git diff 491336d HEAD -- .github/workflows/ci.yml`; `595b283` changes `tests/test_operations.py`. |
| 3. Held-out evaluation and isolation checks | **Not yet demonstrated** | The isolation checks find 40 leaks: a member of one shop opens the other shop's passages through their own shop's evidence route. The held-out set was cut from 41 to 38 questions after tuning, and the lock was written again to match, so its check still passes. The report's "100% valid citations" cannot fail, because nothing checks. | `scripts.isolation`: 420 probes, 40 leaks. `git log -- evaluation/`: the lock changed in `25945bd`, after the tuning commit `a62bd2e`; `docs/tuning-log.md` says why. 38 + 62 = 100 of 103 questions. |
| 4. Clear demo, architecture and limitations | **Not yet demonstrated** | The README claims "production-ready", "97% accurate", "complete tenant isolation", "100% grounded" and "used by the support staff of two shops". The evidence contradicts or does not support each one. The demo uses only questions that "always work": no failure case, no trade-off. The limitations are generic. | The claims table below; `docs/demo-script.md`, step 5 and its tip. |

## Claims and their evidence

| Claim (where) | Evidence found | Supported? |
|---|---|---|
| "97% accurate" (README) | 60 of 62 = 0.968 on the **tuning** set (`evaluate --set dev`), the set used to choose hybrid. On the 41 held-out questions: 36 of 41 (0.878). | against |
| "94.7% on the held-out questions" (README, report) | 36 of 38, after Q13, Q28 and B12 were removed because they failed | against |
| "100% grounded" (README), "Citations valid: 100%" (report) | the citation check is not called; 2 claims cite nothing | against |
| "Complete tenant isolation" (README); "tested by signing in as each person" (report) | 40 leaks through the evidence route. Looking at the document list does not test a route that takes an ID. | against |
| "Used by the support staff of two shops" (README) | the shops and people are the course's synthetic pack (`data/dataset.md`); no user took part | no evidence |
| "Production-ready" (README, report) | one laptop, a practice identity provider, synthetic documents, a leak, committed secrets | against |
| "Injection followed: 0" (report) | `evaluate --set heldout`: 0 of 2 | yes |
| "Median time per question: 12 ms" (report) | true only for recorded answers, which are a file lookup. The course's live runs took about 1.3 s per question. | misleading |

## Findings

### F1. The evidence route reads any shop's passages

- **What:** `GET /v1/tenants/{shop}/chunks/{id}` runs in an admin transaction, without the shop in the query, so row-level security does not apply.
- **Evidence:** `python -m scripts.isolation` → "API: 298 requests with the other shop's IDs -> statuses {404: 258, 200: 40}, 40 leaks". `--json` gives examples such as `GET /v1/tenants/bramble/chunks/d8438ab8b245 -> 200`. In `doc_assistant/documents.py`, `get_chunk` uses `db.admin()` and `WHERE c.chunk_id = %s` (commit `9a5083d`, which also deleted the test line that caught it).
- **Harm:** Bramble's staff can read Larkfield's passages, staff-only ones included for staff, if they know or guess an ID. A chunk ID is not a secret: every answer shows its IDs.
- **Rubric item 3 (not yet):** "any isolation check finds a leak". An access-control failure makes its item "not yet", whatever else works.

### F2. Secrets in the history

- **What:** commit `e3b34e7` added `.env` with `git add -f`: a model key, the OIDC client secret and the session secret. Commit `32a99bb` removed the file, not the commit.
- **Evidence:** `python ../reviewer-kit/secret_scan.py .` → 4 findings, "Not in the latest commit: .env. Deleted later, but every clone still has them."
- **Harm:** anyone with a clone can use the key, on Theo's account. While the old session secret is in use, they can also sign a session cookie for any user.
- **Rubric item 2 (not yet):** "a secret … is committed".

### F3. The held-out set was changed after tuning

- **What:** after the first held-out run (36 of 41), Q13, Q28 and B12 were removed, and the lock was written again. Two tests were skipped and one count was changed to match.
- **Evidence:** `holdout check` → 38 questions, and the lock matches (`647f0b8b75b8...`, not the course's `e8eda11340d6...`). `git log` → the lock changed in `25945bd` (2026-09-15), after the tuning commit `a62bd2e` (2026-09-08). `docs/tuning-log.md` explains it. `pytest -rs` → 2 skipped, "held-out set cleaned up".
- **Harm:** the held-out score no longer measures unseen questions, and the removed questions are exactly the failures.
- **Rubric item 3:** "the held-out set was changed after tuning" (partially on its own; F1 makes the item "not yet").

### F4. The citation check is skipped

- **What:** `pipeline.py` keeps the citations but no longer calls `check_answer`. No answer is marked for review, and every stored claim has `problems: []`.
- **Evidence:** `citation_check.py` → "flagged by the pipeline: 0 | this check: 2 hard problems" (Q05 and B02: claims that cite nothing). `evaluate --set dev` reports citations valid 1.000; the course's pipeline reports 0.963 on the same recorded answers.
- **Harm:** the user cannot tell a cited claim from an uncited one, and the report's 100% is not a measurement.
- **Rubric items 1 (partially) and 3.**

### F5. CI lost its two evidence gates

- **What:** commit `595b283` removed the isolation checks and the evaluation smoke test from `ci.yml`, and removed `scripts.isolation` from the test that checks the workflow.
- **Evidence:** `git diff 491336d HEAD -- .github/workflows/ci.yml`.
- **Harm:** this is how F1 reached `main` with a green pipeline.
- **Rubric item 2.**

### F6. The demo hides the failures

- **What:** four questions that "always work", and the closing line "It answers every question correctly, with a source, and it never mixes up the shops."
- **Evidence:** `docs/demo-script.md`; `evaluate --set heldout --show-failures` lists Q37 and B34 as wrong, and Q13, Q28 and B12 were wrong before they were removed.
- **Rubric item 4.**

### F7. Claims without evidence

- See the claims table: five claims are contradicted by the repository's own commands, and one has no evidence.
- **Rubric item 4 (not yet):** "claims without evidence (for example 'production-ready', 'secure', employment or user claims)".

## Fix plan

See `fix-plan.md`.

## What is good

- The journey works from the README in a few minutes, and the README's steps are correct.
- The data pack, the recorded answers and the tests run on a clean computer without a key.
- The commit messages say what changed, and `docs/tuning-log.md` records the decisions honestly. That log made F3 easy to confirm: keep writing it.
- Hybrid search was chosen on the tuning set, as the course teaches.
