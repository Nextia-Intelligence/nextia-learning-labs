# Fix plan for Theo's doc-assistant (solution)

Ordered by harm: what can hurt a shop or cost money first, then the evidence, then the presentation. Each fix names the check that proves it. Resubmit when every check passes.

| Order | Problem | Fix | Check that proves it |
|---|---|---|---|
| 1 | F1: the evidence route reads any shop's passages | Run `get_chunk` inside `db.tenant(who.tenant_id)` with `c.tenant_id = %s` in the query, as the course's version. Restore the deleted assertion in `tests/test_deletion.py`. | `python -m scripts.isolation`: 0 leaks; `python -m pytest` |
| 2 | F2: secrets in the history | **First** revoke the model key at its provider, and make new values for the two secrets (`python -m idp init` writes new ones). Then publish a new repository from a history without `.env`, or rewrite this one before anyone else clones it. | `python ../reviewer-kit/secret_scan.py .`: no secret found. A line in the README: what was exposed, and that it was revoked. |
| 3 | F5: CI lost its gates | Put the isolation checks and the evaluation smoke test back into `ci.yml`, and `scripts.isolation` back into `tests/test_operations.py`. | `tests/test_operations.py` passes against the workflow; the workflow lists both steps |
| 4 | F4: the citation check is skipped | Call `check_answer` again in `pipeline.py`, store its problems, and mark an answer for review when a claim has a hard problem. Restore the `check` span in `tests/test_pipeline.py`. | `python ../reviewer-kit/citation_check.py`: the pipeline's count equals the check's count |
| 5 | F3: the held-out set was cut after tuning | Restore `heldout.jsonl` and `heldout.lock` from the first commit (`git checkout 491336d -- evaluation/heldout.jsonl evaluation/heldout.lock`), and the tests. Report 36 of 41, name the 5 failures, and say in the report that the 41 results have been seen: the next change needs new held-out questions, reserved before it is tuned. | `python -m scripts.holdout check`: 41 questions, `e8eda11340d6...`; `python -m scripts.evaluate --set heldout` |
| 6 | F6, F7: claims and demo | Rewrite the README and the report from the evidence: every claim with its command and result, failures named (B34, Q37, the three retrieval misses), "production-ready" and the user claim removed, specific limitations. Add a failure case and the hybrid trade-off to the demo. Add `docs/portfolio-checklist.md`. | the claims table of the review: every row "yes" |

Not in the plan: a better score. Nothing here should change how many held-out questions are right. If the number changes, find out why before you resubmit.
