# Review: <the submission>

Reviewer: <your name>. Submission: <repository>, commit <hash>. Rubric: `marking-rubric.md`.

## Summary

<Three sentences: the overall result, the most serious problem, and what to do first.>

## Marks

| Rubric item | Mark | Reason (what you saw) | Evidence (command, file or commit) |
|---|---|---|---|
| 1. Working user journey | demonstrated / partially / not yet | | |
| 2. Reproducible repository and deployment | | | |
| 3. Held-out evaluation and isolation checks | | | |
| 4. Clear demo, architecture and limitations | | | |

## Claims and their evidence

| Claim (where) | Evidence found | Supported? |
|---|---|---|
| | | yes / no / against |

## Findings

One block per finding.

### F1. <short name>

- **What:** <what is wrong, in one sentence>
- **Evidence:** <the command and the line of output, or the file and line, or the commit>
- **Harm:** <who could be hurt, or which claim is not true>
- **Rubric item:** <number, and why the mark follows>

## Fix plan

| Order | Fix | Check that proves it |
|---|---|---|
| 1 | | |

## What is good

<Specific things to keep. A review that only lists problems is not a fair review.>
