"""Secret scan: look through EVERY commit of a Git repository for a secret that was committed,
even if a later commit deleted it. A reviewer's tool for the case study "Review a weak capstone".

    python secret_scan.py [REPO]          default: the current folder

What it looks for, in every line that any commit ADDED, on every branch:
  1. a file that should never be committed: .env (not .env.example), *.pem, *.key, id_rsa,
     id_ed25519, or anything in .idp/ (the practice provider's signing keys);
  2. an assignment whose name says secret (KEY, SECRET, TOKEN, PASSWORD, PASSWD) and whose value
     is a literal of 12 characters or more;
  3. a password inside a URL (scheme://user:password@host);
  4. a private key block (-----BEGIN ... PRIVATE KEY-----).
A value that says it is an example is not reported: it contains "example", "change-me",
"not-secret", "test", "dummy" or "placeholder". Neither is a reference such as ${NAME},
os.environ[...], a function call or a Python name (settings.session_secret). It prints where each finding is and the value's first 4 characters, never the
whole value. Exit status 1 if it finds anything.

This is a small teaching scanner, standard library only. In a team, run a maintained scanner in CI
as well (for example gitleaks, MIT licence), and keep this rule: a secret that reached a commit is
public. Revoke it first; cleaning the history comes second.
"""

import re
import subprocess
import sys
from pathlib import Path

NAME = re.compile(r"(?i)\b([A-Za-z0-9_]*(?:api_?key|secret|token|password|passwd)[A-Za-z0-9_]*)\b[\"']?\s*[:=]\s*"
                  r"[\"']?([^\s\"'#,]+)")
URL_PASSWORD = re.compile(r"[a-z][a-z0-9+.-]*://[^\s:/@]+:([^\s@/]+)@")
PRIVATE_KEY = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")
SAYS_EXAMPLE = ("example", "change-me", "changeme", "not-secret", "test", "dummy", "placeholder")
REFERENCE = re.compile(r"[$(){}\[\]<>]|^[A-Za-z_]\w*(\.[A-Za-z_]\w*)+$")   # ${NAME}, f(x), settings.name
RISKY_FILES = re.compile(r"(^|/)(\.env(\.[a-z]+)?|id_rsa|id_ed25519|[^/]+\.pem|[^/]+\.key)$|(^|/)\.idp/")


def git(repo: Path, *args: str) -> str:
    return subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True, text=True,
                          errors="replace").stdout


def literal_secret(value: str, minimum: int = 12) -> bool:
    v = value.strip().rstrip(";")
    return (len(v) >= minimum and not REFERENCE.search(v) and not any(w in v.lower() for w in SAYS_EXAMPLE)
            and not v.lower() in ("true", "false", "none", "null"))


def mask(value: str) -> str:
    return f"{value[:4]}... ({len(value)} characters)"


def scan(repo: Path) -> tuple[list[dict], int, int]:
    log = git(repo, "log", "--all", "--reverse", "-p", "-U0", "--no-color", "--no-ext-diff", "--no-renames",
              "--format=@@@commit %h %ad %s", "--date=short")
    findings, commits, added = [], 0, 0
    commit, path, line_no = "", "", 0
    for line in log.splitlines():
        if line.startswith("@@@commit "):
            commit, commits = line[len("@@@commit "):], commits + 1
            continue
        if line.startswith("+++ "):
            path = line[6:] if line.startswith("+++ b/") else ""
            if path and RISKY_FILES.search(path) and not path.endswith(".example"):
                findings.append({"commit": commit, "file": path, "line": 0, "what": "a file that should never "
                                 "be committed", "value": ""})
            continue
        if line.startswith("@@ "):
            m = re.search(r"\+(\d+)", line)
            line_no = int(m.group(1)) if m else 0
            continue
        if not line.startswith("+") or not path:
            continue
        text, added = line[1:], added + 1
        for name, value in NAME.findall(text):
            if literal_secret(value):
                findings.append({"commit": commit, "file": path, "line": line_no, "what": name, "value": value})
        for value in URL_PASSWORD.findall(text):
            if literal_secret(value, minimum=8):
                findings.append({"commit": commit, "file": path, "line": line_no, "what": "password in a URL",
                                 "value": value})
        if PRIVATE_KEY.search(text):
            findings.append({"commit": commit, "file": path, "line": line_no, "what": "private key", "value": ""})
        line_no += 1
    return findings, commits, added


def main(argv: list[str]) -> int:
    repo = Path(argv[1] if len(argv) > 1 else ".").resolve()
    findings, commits, added = scan(repo)
    print(f"Scanned {commits} commits on every branch of {repo.name}: {added:,} added lines.")
    by_commit: dict[str, list[dict]] = {}
    for f in findings:
        by_commit.setdefault(f["commit"], []).append(f)
    for commit, items in by_commit.items():
        print(f"\n{commit}")
        for f in items:
            where = f["file"] + (f":{f['line']}" if f["line"] else "")
            value = f" = {mask(f['value'])}" if f["value"] else ""
            print(f"  {where:<22} {f['what']}{value}")
    if not findings:
        print("No secret found in the history.")
        return 0
    head = set(git(repo, "ls-tree", "-r", "--name-only", "HEAD").split())
    files = sorted({f["file"] for f in findings})
    gone = [f for f in files if f not in head]
    print(f"\nFound {len(findings)} possible secrets in {len(by_commit)} commit(s), in {', '.join(files)}.")
    if gone:
        print(f"Not in the latest commit: {', '.join(gone)}. Deleted later, but every clone still has them.")
    print("Treat each one as public: revoke or replace it first, then clean the history.")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
