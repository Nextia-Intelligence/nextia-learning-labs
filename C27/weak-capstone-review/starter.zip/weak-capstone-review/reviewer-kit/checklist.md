# Reviewer's checklist

Run every step from inside `theo-doc-assistant/`, with `.venv` active and the database up (see `../README.md`). Write what you see in `review-template.md` as you go: the command, the line that matters, and which rubric item it changes.

Two rules from the rubric decide most marks:

- **Evidence, not impressions.** Every mark has a reason that another reviewer can check: a command and its output, a file and a line, a commit.
- **A failed safety check wins.** If an access-control, data-integrity or irreversible-action check fails, the item it belongs to is *not yet demonstrated*, however good the rest is.

## 0. Read first, do not mark yet (10 minutes)

- [ ] Read `README.md`, `docs/evaluation-report.md` and `docs/demo-script.md`.
- [ ] Copy every claim (accuracy, grounding, security, users, "production-ready") into the claims table of the template. Leave the evidence column empty.
- [ ] `git log --oneline` : read the history once, from the bottom.

## 1. The held-out set (rubric item 3)

- [ ] `python -m scripts.holdout check` : how many questions? Does that match the number that the course reserved?
- [ ] `git log --format="%h %ad %s" --date=short -- evaluation/ docs/tuning-log.md doc_assistant/config.py` : was the lock written before the first tuning commit, and never again?
- [ ] Count the questions in `questions.jsonl`, `heldout.jsonl` and `dev.jsonl`. Is any question lost?
- [ ] Read `docs/tuning-log.md`. Did anyone look at held-out results and then change the set?

## 2. Isolation (rubric item 3; an access-control check)

- [ ] `python -m scripts.isolation` : the last line must say `0 leaks`.
- [ ] If not: `python -m scripts.isolation --json` shows examples. Which route? Open its code and find the query.
- [ ] Can you reproduce one leak with one request? (`python -m idp token usr-sam` gives a bearer token for curl, with `python -m idp` and `fastapi dev doc_assistant/main.py` running.)

## 3. Citations (rubric items 1 and 3)

- [ ] `python ../reviewer-kit/citation_check.py` : compare "flagged by the pipeline" with "this check". They must agree.
- [ ] Read each hard problem that it lists. Could the user check that claim? Would the course's pipeline have marked the answer for review?
- [ ] Find the code that checks citations (`doc_assistant/cite.py`). Is it called? (`grep -rn check_answer doc_assistant/`)

## 4. Secrets (rubric item 2)

- [ ] `python ../reviewer-kit/secret_scan.py .` : any finding is a "not yet" for item 2.
- [ ] Is the file still in the latest commit? Was it ever pushed? (A deleted file is still in every clone.)

## 5. The pipeline and the tests (rubric item 2)

- [ ] `ruff check .` and `python -m pytest -q` : do they pass? Read the last line: are tests skipped? Why?
- [ ] `git diff $(git rev-list --max-parents=0 HEAD) HEAD -- .github/workflows/ci.yml` : which checks did the workflow lose?
- [ ] `git log -p -- tests/` : which tests changed when the code changed? A test changed to match new behaviour is a clue.

## 6. The numbers of the report (rubric item 3)

- [ ] `python -m scripts.evaluate --set heldout --show-failures` and `python -m scripts.evaluate --set dev` : which numbers of the report come from which set?
- [ ] Does the report show the failures, or only the successes?

## 7. The demo and the claims (rubric item 4)

- [ ] Does the demo script have a failure case and a trade-off with its evidence?
- [ ] Do the demo's questions avoid the failures that you found?
- [ ] Fill the evidence column of the claims table. A claim with no evidence, or with evidence against it, is a "not yet" for item 4.

## 8. Marks and the fix plan

- [ ] One mark per rubric item, each with a reason and the evidence.
- [ ] The fix plan: one line per problem, ordered by harm (safety first, then evidence, then presentation), each with the check that proves the fix.
- [ ] Read your review once as Theo. Is every sentence about the work, not about the person? Would Theo know exactly what to do next?
