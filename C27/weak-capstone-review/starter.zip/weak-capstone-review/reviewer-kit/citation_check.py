"""Citation check from outside: ask questions through a submission's own pipeline, then check the
citations of what the user is SHOWN with the course's checks (doc_assistant/cite.py), not the
flags that the pipeline stored. A reviewer's tool for the case study "Review a weak capstone".

    cd theo-doc-assistant                      (the database up and the data pack loaded)
    python ../reviewer-kit/citation_check.py

Two groups of questions, each asked as a real member of the shop, on the question's date:
  1. every question of evaluation/questions.jsonl, asked by a staff member (Sam, Ines);
  2. every staff-only question, asked by a read-only member (Omar, Camille).
For every claim of every answer, it looks the shown citations up again, for THAT member, and runs
the course's checks. Hard problems: a claim that cites nothing the member can open (no_citation),
a citation that does not exist for this member (missing_id), or a passage that the model was not
given (not_in_context). Clues (number_not_found, unsupported): a person reads those.
It also counts what the pipeline flagged itself. If the two counts differ, the pipeline does not
check what it shows: exit status 1. If they agree, the pipeline marks those answers for review.
"""

import logging
import os
import sys
from collections import Counter

sys.path.insert(0, os.getcwd())   # the submission's code, from the folder you run this in

from doc_assistant import retrieve
from doc_assistant.answer import Claim
from doc_assistant.cite import check_claim
from doc_assistant.pipeline import ask
from scripts import holdout
from scripts.common import READ_ONLY, STAFF, as_member, open_deps

HARD = ("missing_id", "not_in_context", "no_citation", "no_claims")


def recheck(deps, who, q, result) -> list[tuple[str, list[str]]]:
    """(claim text, problems) for every claim of an answer, checked again for this member."""
    if not result.answerable:
        return []
    if not result.claims:
        return [(result.answer, ["no_claims"])]
    shown = [c["chunk_id"] for claim in result.claims for c in claim["citations"]]
    with deps.db.tenant(who.tenant_id) as conn:
        known = retrieve.lookup(conn, who.tenant_id, who.access_levels, shown)
    context = [p["chunk_id"] for p in result.passages]
    out = []
    for claim in result.claims:
        ids = tuple(c["chunk_id"] for c in claim["citations"])
        out.append((claim["text"], check_claim(Claim(claim["text"], ids), known, context,
                                               f"{q['question']} {q['as_of']}").problems))
    return out


def run_group(deps, questions, users) -> dict:
    g = Counter()
    hard = []
    for q in questions:
        who = as_member(deps, users[q["tenant"]], q["tenant"])
        result = ask(deps, who, q["question"], q["as_of"])
        g["questions"] += 1
        g["answers_with_claims"] += bool(result.answerable)
        g["pipeline_flagged"] += sum(any(p.startswith(HARD) for p in c.get("problems", [])) for c in result.claims)
        for text, problems in recheck(deps, who, q, result):
            g["claims"] += 1
            if any(p.startswith(HARD) for p in problems):
                g["hard"] += 1
                hard.append(f"  {q['id']:<4} {who.user_id:<12} {', '.join(problems)}: {text[:90]}")
            elif problems:
                g["clues"] += 1
    return {"counts": g, "hard": hard}


def main() -> int:
    for name in ("httpx", "httpx2", "huggingface_hub", "sentence_transformers", "doc_assistant.access"):
        logging.getLogger(name).setLevel(logging.ERROR)
    bank = holdout.load(holdout.EVAL / "questions.jsonl")
    deps = open_deps()
    groups = [("Staff", bank, STAFF), ("Read-only", [q for q in bank if q["kind"] == "staff-only"], READ_ONLY)]
    total_hard = total_flagged = 0
    for label, questions, users in groups:
        r = run_group(deps, questions, users)
        c = r["counts"]
        total_hard += c["hard"]
        total_flagged += c["pipeline_flagged"]
        answers = f"{c['answers_with_claims']} answer{'' if c['answers_with_claims'] == 1 else 's'}"
        print(f"{label}: {c['questions']} questions, {answers} with claims, {c['claims']} "
              f"claims | flagged by the pipeline: {c['pipeline_flagged']} | this check: {c['hard']} hard "
              f"problems, {c['clues']} clues")
        for line in r["hard"]:
            print(line)
    deps.db.close()
    if total_hard != total_flagged:
        print(f"Citation check: {total_hard} claims that the user cannot check; the pipeline flagged "
              f"{total_flagged}. It does not check what it shows.")
        return 1
    if total_hard:
        print(f"Citation check: the pipeline flags the same {total_hard} claims as this check, and marks their "
              "answers for review.")
    else:
        print("Citation check: every claim cites a passage that its reader may open and that the model was given.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
