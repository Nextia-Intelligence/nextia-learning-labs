# doc-assistant

**A production-ready AI document assistant for bookshops and retailers.** Staff upload their policies and get instant, accurate answers with citations. Built by Theo Marsh as the capstone of *Portfolio Capstone: Build, Evaluate and Ship an AI Product* (standard track).

## Highlights

- **97% accurate** on the evaluation questions.
- **100% grounded:** every answer cites its source documents.
- **Secure multi-tenant design:** row-level security and complete tenant isolation. Each shop only ever sees its own data.
- **Used by the support staff of two shops**, Larkfield and Bramble Books.
- **Production-ready:** Docker, CI, health checks and usage limits.

## Quick start

You need Python 3.12, Git and Docker.

```sh
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env                    # then change POSTGRES_PASSWORD in .env
python -m idp init
docker compose up -d db
python -m doc_assistant.migrate
python -m scripts.load_pack
```

Then run `python -m idp` in one terminal and `fastapi dev doc_assistant/main.py` in another, and open http://127.0.0.1:8000.

Tests: `python -m pytest`.

## Demo

See `docs/demo-script.md`.

## Evaluation

See `docs/evaluation-report.md`. In short: 97% on the tuning questions, 94.7% on the held-out questions, 100% valid citations.

## Limitations

- Could be improved with more data and a bigger model.
- More languages could be added.

## Licence

MIT. The documents in `data/` are synthetic (CC0).
