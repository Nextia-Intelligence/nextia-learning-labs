# Demo script

Five minutes, live, from my laptop.

1. Sign in as **Ines** (owner, Bramble Books). Show the 15 indexed documents.
2. Ask: "How long is a gift card valid?" Show the answer and click the citation.
3. Ask: "Can a customer cancel a pre-order for a full refund?" Show the answer.
4. Sign in as **Sam** (staff, Larkfield). Ask: "What is the staff discount?" Show the answer.
5. Close: "It answers every question correctly, with a source, and it never mixes up the shops."

Tip: use only these questions. They always work.
