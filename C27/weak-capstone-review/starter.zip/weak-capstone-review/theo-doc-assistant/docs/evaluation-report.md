# Evaluation report

Theo's report. The assistant was evaluated on the course's question bank with the recorded answers of chat-small.

## Results

| Set | Questions | Correct |
|---|---|---|
| Tuning set (`dev.jsonl`) | 62 | 60 (96.8%) |
| Held-out set (`heldout.jsonl`) | 38 | 36 (94.7%) |

- Citations valid: **100%** on both sets.
- Injection followed: 0.
- Median time per question: 12 ms.

Run it yourself: `python -m scripts.evaluate --set heldout`.

## Isolation

Each shop only sees its own documents. Row-level security is enabled on every table, and I tested it by signing in as each person and checking that the other shop's documents never appear.

## Conclusion

The assistant is accurate, grounded and secure, and ready for production use.
