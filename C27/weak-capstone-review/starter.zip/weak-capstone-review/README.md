# Review a weak capstone

The materials of the case study *Review a weak capstone* in *Portfolio Capstone: Build, Evaluate and Ship an AI Product* (https://learning.nextia-ai.com/courses/capstone/m08/review-a-weak-capstone/).

**Everything in `theo-doc-assistant/` is constructed.** Theo Marsh is not a real person. The course team made this submission from the course's finished `doc-assistant`, and planted problems in it on purpose, so that you can practise a review where the answers are known. The "secrets" in its history were made up for the case study and never worked anywhere. The documents in `data/` are synthetic (CC0).

| Folder or file | What it is |
|---|---|
| `theo-doc-assistant/` | the submission: a Git repository with its history (9 commits) |
| `reviewer-kit/marking-rubric.md` | the course's marking rubric: demonstrated, partially demonstrated or not yet demonstrated, always with a reason |
| `reviewer-kit/checklist.md` | the review, step by step: what to run and what to look for |
| `reviewer-kit/review-template.md` | the review you write: a mark and a reason per rubric item, the evidence, and the fix plan |
| `reviewer-kit/secret_scan.py` | a secret scan over every commit (standard library only) |
| `reviewer-kit/citation_check.py` | the course's citation checks, run from outside the submission's pipeline |

The finished download adds `reviewer-kit/review.md` and `reviewer-kit/fix-plan.md` (the solution review) and `theo-doc-assistant-resubmitted/` (the submission after the fixes).

## Set up

You need Python 3.12 or newer, Git and Docker, as in the course. The checks need the submission's packages (about 1 GB, mostly torch) and its database.

macOS and Linux:

```sh
cd theo-doc-assistant
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m idp init
docker compose up -d --wait db
python -m doc_assistant.migrate
python -m scripts.load_pack
```

Windows (PowerShell): `py -3.12 -m venv .venv`, `.venv\Scripts\Activate.ps1` and `copy .env.example .env`; the other lines are the same.

If your own capstone's database is running on port 5432, stop it first (`docker compose stop` in its folder), or set `DB_PORT` in `.env` and the same port in the two database URLs.

Then follow `reviewer-kit/checklist.md`. The scripts of the kit run from inside `theo-doc-assistant/`, for example `python ../reviewer-kit/secret_scan.py .`.

When you finish: `docker compose down -v` in `theo-doc-assistant/` deletes the database.

## Licence

The code is under the MIT licence (`theo-doc-assistant/LICENSE`, copyright Nextia Learning). The data pack is CC0 (`theo-doc-assistant/data/dataset.md`). The kit is under the MIT licence too.
