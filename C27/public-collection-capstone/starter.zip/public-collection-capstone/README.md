# Agile delivery guide assistant (starter)

The starter of the case study *Capstone on a public document collection* of the course *Portfolio Capstone: Build, Evaluate and Ship an AI Product*. It is the course's finished `doc-assistant`, made ready for one public collection: the 20 "Agile delivery" guides of the GOV.UK Service Manual (Open Government Licence v3.0).

What is already here:

- The course's code, unchanged except that the scripts read the team and its members from `data/identity/`.
- `data/snapshot/`: the exact files of the collection, downloaded from the GOV.UK Content API, with `SHA256SUMS`. `scripts/collection.py` converts them into documents.
- `evaluation/questions.jsonl`: 60 questions written from the guides. You reserve the held-out set yourself.
- `recordings/answers.jsonl`: the course team's recorded answers of a real model (chat-small) for these questions, so you need no key and no money.
- `doc_assistant/prompts/guide_v1.md`: the course's answer prompt, with the words about shops changed to guides.
- `tests/fixtures/pack/`: the course's synthetic two-shop pack. The tests use it: the access and isolation code still needs two tenants and staff-only documents to be tested.

What you do: follow the case study's page, step by step. The finished project is in the other download.

## Quick start

You need Python 3.12 or newer, Git, and Docker (Docker Desktop on macOS and Windows).

```sh
python3 -m venv .venv && source .venv/bin/activate     # Windows: py -3.12 -m venv .venv; .venv\Scripts\Activate.ps1
pip install -r requirements.txt
cp .env.example .env                                    # then change POSTGRES_PASSWORD and the two URLs
python -m idp init                                      # the practice identity provider; writes two secrets to .env
docker compose up -d --wait db
python -m pytest                                        # the course's tests, on the synthetic pack
python -m scripts.collection prepare                    # the 20 guides, from the snapshot
python -m scripts.datapack
```

## Licence

The code: MIT (see `LICENSE`). The guides: Crown copyright, Open Government Licence v3.0. Contains public sector information licensed under the Open Government Licence v3.0. The synthetic pack in `tests/fixtures/pack/`: CC0.
