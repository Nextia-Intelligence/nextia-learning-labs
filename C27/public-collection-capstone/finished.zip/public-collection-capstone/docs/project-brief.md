# Project brief: an assistant for the Service Manual's agile delivery guides

Written with Ruth, the delivery manager of a small digital team (the Westbrook digital team, an invented team of a public body), before any code was changed. The guides are real: the GOV.UK Service Manual's "Agile delivery" topic, under the Open Government Licence v3.0.

## User and decision

- Who uses the product: Ruth, and the new joiners of her team (delivery managers, user researchers and developers who are new to government).
- The decision it helps with: Ruth decides whether the team's onboarding pack sends new joiners to the assistant as their first stop for "what does the Service Manual say about ...?" questions on agile delivery, instead of a reading list of 20 guides. Each joiner then decides what to do in a stand-up, a retro or an assessment, from a cited answer.
- How they do it today, and what goes wrong: new joiners read the guides, or ask Ruth. Last month a joiner told the team that an alpha lasts "about 4 to 8 weeks": that is the discovery guide's figure (the alpha guide says 6 to 8). The phase guides use the same words, and people mix them up.

## Documents

- Which documents the product reads: the 20 guides listed on the "Agile delivery" topic page of the GOV.UK Service Manual (https://www.gov.uk/service-manual/agile-delivery), as one fixed snapshot (`data/snapshot/`), converted to Markdown with their metadata (`python -m scripts.collection prepare`).
- Who owns them, and why we may use them: Crown copyright, published by the Government Digital Service under the Open Government Licence v3.0, which allows copying, adapting and publishing with an attribution. See `data/dataset.md`.

## What success looks like

- A team member asks a question in plain words and gets, in a few seconds, a short answer with a citation to the guide and section for every claim, or a clear "the guides do not say".
- The answer comes from the right guide: a question about alpha is answered from the alpha guide, not the discovery guide.
- When the guides do not answer, the assistant says so, even when the model "knows" an answer.

## Non-goals

- No other Service Manual topics (the Service Standard, design, technology, user research): one topic, 20 guides.
- No advice: the guides are guidance, and GOV.UK says so. The assistant points to the guide; people decide.
- No second tenant: one team, one public collection. Every member may read every guide; the access and isolation code of the course stays, and its tests keep running on the synthetic two-shop pack (`tests/fixtures/pack/`).
- No live copy of GOV.UK: the assistant answers from the snapshot. `python -m scripts.collection check` shows when GOV.UK has changed.
- No injection test: the guides contain no hidden instruction (the prompt rule stays).

## Track

- [ ] Standard track: the supplied two-shop data pack
- [x] Own-idea track: a public collection with an open licence

## Milestones

| Milestone | Done when |
|---|---|
| Scope and data | this brief, the acceptance criteria and the data card are written; the snapshot checks; every guide parses |
| Questions | 60 questions written from the guides; 25 reserved as the held-out set and committed before any answer |
| Baseline | the course's settings answer the 35 tuning questions; the failures are read |
| Comparison | the alternatives are measured on the tuning questions under one measure; one version is chosen |
| Evaluated | the held-out set is run once per version (two passes); the report is written |
| Shipped | a new guide goes in end to end; the README lets a stranger run it |
