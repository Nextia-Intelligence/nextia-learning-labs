# Evaluation report: the agile delivery guide assistant

Written after the one held-out run. Failures are reported as clearly as successes.

## What was evaluated

- Version: the course's finished `doc-assistant` with this project's changes (`data/`, `scripts/collection.py`, prompt `guide_v1`); settings: `RETRIEVAL_MODE=hybrid`, `TOP_K=5`, `PROMPT_VERSION=guide_v1`, model chat-small (Azure OpenAI), two live passes, nothing changed between them. The recorded answers in `recordings/` replay pass 1.
- Questions: 25 held-out questions of 60, reserved before any answer (`evaluation/heldout.lock`, `75f6adf284e4...`): answerable 10, phase 5, paraphrase 3, definition 2, conflict 1, unanswerable 4. One tenant (the team); every guide is public.

## Held-out results

| Measure | Threshold (from the acceptance criteria) | Pass 1 | Pass 2 | Met? |
|---|---|---|---|---|
| Correct, all questions | – | 22 of 25 | 22 of 25 | – |
| Q1 correct, answerable questions | at least 75% | 18 of 21 (85.7%) | 18 of 21 (85.7%) | yes |
| Q2 abstains when the guides do not answer | 100% | 4 of 4 | 4 of 4 | yes |
| Q3 citation validity | 100% | 100% | 100% | yes |
| Q5 median time, question to answer | under 5 s | about 1.3 s | about 1.7 s | yes |
| C1 model cost per question | under US$0.001 | US$0.000201 | US$0.000201 | yes |
| Retrieval hit (a relevant section in the passages) | – | 19 of 21 | 19 of 21 | – |

The same three questions were wrong in both passes:

| Question | Answer (pass 1) | Category |
|---|---|---|
| G01 "How long should our daily standup last?" | "The guides do not say how long a daily standup should last." | retrieval missed: the *Daily standup* section was not among the passages; the assistant abstained |
| G30 "Can members of the public use our service during alpha?" | "The guides do not say whether members of the public can use your service during alpha." | retrieval missed: the alpha guide's opening text was not among the passages; the assistant abstained |
| G13 "What should we show on our team wall?" | "Show work that's in progress, not yet started and done. ..." | key too strict: the answer is right; the key `not started|upcoming` does not match "not yet started". The key stays as it was reserved |

Read by a person, 23 of 25 answers are right. The score stays 22: keys are not changed after a run.

Why the search missed (ranks of the right section, read after the run; no score changed): G01 *Daily standup* was 1st in the vector list and not in the keyword list's top 20, so reciprocal rank fusion put it 6th; G30's section was 20th (vector) and 3rd (keyword), fused 7th. The tuning miss G49: its best right section was 1st (vector) and not in the keyword top 20, fused 8th. Only the top 5 reach the model. Passages found by both lists win the fusion, and the keyword ranking does not weigh rare words ("standup") above common ones ("how", "should").

## Isolation and failure checks

| Check | Result |
|---|---|
| Isolation between tenants | not applicable: one tenant. The course's access and isolation tests still run on the synthetic two-shop pack (`tests/fixtures/pack/`) and pass |
| A made-up team | 404 (`scripts/smoke.py`) |
| A guide that is not in the collection | abstains ("The guides do not say ..."), then answers with a citation after the guide is uploaded (the end-to-end run) |

## Error categories

Found on the tuning questions (dev.jsonl), not on the held-out ones.

| Category | Questions | Cause | Fix tried |
|---|---|---|---|
| retrieval missed, the assistant abstained | G49 (paraphrase: "Hardly anyone uses our old online service any more. Should we keep running it?") | the keyword half of hybrid search pushes the retirement sections down; dense search finds them | dense, dense_rerank and hybrid_rerank answered it; none passed the rule (2 more right answers) |

## Baseline and candidate

| Measure (tuning set, 35 questions, live pass 1) | hybrid (baseline) | dense | dense_rerank | hybrid_rerank |
|---|---|---|---|---|
| Correct | 34 | 35 | 35 | 35 |
| Retrieval hit (30 with relevant passages) | 29 | 30 | 30 | 30 |
| Median search time | about 9 ms | about 7 ms | about 340 ms | about 345 ms |

The baseline's second pass: 34 of 35, the same miss (G49). No alternative was 2 or more questions better, so there is no candidate: the held-out run is the baseline's. Regressions: none to report.

## Cost and speed

Median 1,365 tokens in and 89 to 99 out per held-out question; US$0.000201 per question (price list US$0.10 and 0.50 per million tokens: check the current page). The model call is most of the time (median about 1.3 to 1.6 s); the p95 (about 2.8 to 2.9 s) includes the first question, which loads the embedding model. All model calls of the project (tuning, held-out, the end-to-end run): 229 calls, 0 errors, US$0.045.

## Limitations

- 25 held-out questions: one question is 4 points. The two passes agree, but a second set of new questions would say more than a second pass.
- One person wrote the questions and the keys, by reading the guides; their wording is closer to the guides than a new joiner's would be.
- Two of the three failures are retrieval misses on simple questions. The tuning set showed one (G49) and the rule kept hybrid. G01 and G30 now move to the tuning set for the next version, and new held-out questions replace them.
- The guides change: the evaluation is about the snapshot, not today's GOV.UK.
