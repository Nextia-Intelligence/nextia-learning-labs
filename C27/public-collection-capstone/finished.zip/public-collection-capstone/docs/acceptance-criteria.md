# Acceptance criteria: the agile delivery guide assistant

Written with Ruth before any answer was generated. Every criterion is testable and names how it is checked. The thresholds are the course's worked capstone's, so the two projects can be compared; where a criterion does not apply to a public collection, it says why.

## Required behaviour

| ID | Given | When | Then |
|---|---|---|---|
| B1 | a member of the team | they ask a question that the guides answer | they get a short answer, and every claim cites a section of a guide |
| B2 | a member of the team | they ask a question that the guides do not answer | the answer says that the guides do not say, and cites nothing |
| B3 | two guides that disagree | a question touches both | the answer uses the newer guide, or says that they disagree |
| B4 | the owner of the team | they upload a new guide (.md, .html or .pdf) | they see it move from uploaded to indexed, and the next answer can cite it |
| B5 | any answer | the member opens a citation | they see the passage, its guide, version and date |

## Quality thresholds

Measured on the 25 held-out questions only, once per version (two passes for a live model). Written before any measurement.

| ID | Measure | Threshold | Why this number |
|---|---|---|---|
| Q1 | correct answers on answerable held-out questions | at least 75% | the worked capstone's threshold; Ruth reads the cited section anyway |
| Q2 | abstains on questions the guides do not answer | 100% | a confident answer from outside the guides is worse than "the guides do not say" |
| Q3 | citation validity (every cited passage exists and was given to the model) | 100% | code checks it fully, so anything less is a bug |
| Q4 | follows an instruction hidden in a document | not measured | the guides contain no such instruction (a non-goal) |
| Q5 | median time from question to answer, on a laptop | under 5 seconds | a person waits for it in a meeting |

## How a change is chosen (on the tuning set only)

The baseline is the course's finished settings: hybrid search, top 5, prompt `guide_v1`. An alternative (another retrieval mode) becomes the candidate only if, on the 35 tuning questions in the first live pass, it:

1. gets at least 2 more questions right than the baseline (one question is within the run-to-run change of a live model),
2. gets no unanswerable question wrong that the baseline got right, and
3. adds no more than 0.5 s to the median time of a question.

If no alternative passes, the baseline is the only version, and the held-out set runs once, for it.

## Access control

| ID | Rule | Checked by |
|---|---|---|
| A1 | someone who is not a member of the team gets "not found" | the access tests (on the synthetic pack) and the smoke test (a made-up team: 404) |
| A2 | a read-only member can ask but cannot upload or delete | the access tests |
| A3 | isolation between tenants | not applicable: one tenant, a public collection. The isolation tests still run on the synthetic two-shop pack |

## Budget

| ID | Limit | Value |
|---|---|---|
| C1 | model cost per question | under US$0.001 |
| C3 | money for building and evaluating this project | at most US$0.50 of model calls; no cloud resources |
