"""The public collection: the GOV.UK Service Manual's "Agile delivery" guides (Open Government Licence v3.0).

    python -m scripts.collection prepare     check the committed snapshot, then write the documents
                                             of data/westbrook/ (Markdown with metadata), its
                                             inventory.csv and data/SHA256SUMS
    python -m scripts.collection check       compare the snapshot with the live GOV.UK pages (network)
    python -m scripts.collection fetch       download the topic and its guides into a NEW snapshot
                                             folder (network; --out FOLDER; never over the committed one)
    python -m scripts.collection convert data/snapshot/new-input/how-service-assessments-work.json
                                             one more guide, outside the collection, as a Markdown file
                                             in data/new-input/ (to upload through the API or the page)

Why a snapshot: GOV.UK changes its guides at any time. The evaluation, the held-out lock and the
recorded answers belong to one fixed version of the text, so the project keeps the exact files it
used (data/snapshot/, the GOV.UK Content API's JSON, as downloaded), with their SHA-256 in
data/snapshot/SHA256SUMS. The licence allows the copy; the attribution is in data/dataset.md and in
the metadata of every document. `check` tells you when GOV.UK has moved on.

The conversion keeps the text and its structure and nothing else: the title, the summary, the
headings (h2 and h3 both become sections), paragraphs and list items. Links keep their text only.
Standard library only.
"""

import argparse
import csv
import hashlib
import json
import ssl
import sys
import time
import urllib.request
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
SNAPSHOT = DATA / "snapshot"
TENANT = "westbrook"
API = "https://www.gov.uk/api/content"
TOPIC = "/service-manual/agile-delivery"
OWNER = "Government Digital Service (GOV.UK Service Manual)"
LICENCE = "Open Government Licence v3.0"
ATTRIBUTION = "Contains public sector information licensed under the Open Government Licence v3.0."
COLUMNS = ["file", "doc_id", "title", "version", "effective_from", "effective_to", "owner", "access", "language",
           "doc_type", "format"]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# ---------------------------------------------------------------- HTML -> Markdown

class _Body(HTMLParser):
    """GOV.UK guide HTML (the Content API's details.body) -> Markdown lines."""

    BLOCKS = {"h2": "## ", "h3": "## ", "p": "", "li": "- "}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.lines: list[str] = []
        self.stack: list[str] = []      # open block tags (h2, h3, p, li)
        self.buf: list[str] = []
        self.skip = 0
        self.h2 = ""

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.skip += 1
        elif tag in self.BLOCKS:
            if self.stack and self.stack[-1] == "li" and tag == "p":
                return                  # a paragraph inside a list item stays in the item
            self.flush()
            self.stack.append(tag)
        elif tag == "br":
            self.buf.append(" ")

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self.skip -= 1
        elif tag in self.BLOCKS and self.stack and self.stack[-1] == tag:
            self.flush()
            self.stack.pop()
        elif tag in ("ul", "ol"):
            self.flush()

    def handle_data(self, data):
        if not self.skip:
            self.buf.append(data)

    def flush(self):
        text = " ".join("".join(self.buf).split())
        self.buf = []
        if not text:
            return
        kind = self.stack[-1] if self.stack else "p"
        if kind == "h2":
            self.h2 = text
            self.lines.append(f"## {text}")
        elif kind == "h3":           # h3 becomes a section too, named with its h2: "Kanban" is twice in a guide
            self.lines.append(f"## {self.h2}: {text}" if self.h2 else f"## {text}")
        elif kind == "li":
            self.lines.append(f"- {text}")
        else:
            self.lines.append(text)


def to_markdown(item: dict) -> str:
    """One Content API item -> a Markdown document with the metadata the assistant reads."""
    body = _Body()
    body.feed(item["details"]["body"])
    body.flush()
    lines = body.lines
    # a heading straight before another heading has no text of its own: the h3 sections carry its name
    lines = [x for i, x in enumerate(lines) if not (x.startswith("## ") and i + 1 < len(lines)
                                                     and lines[i + 1].startswith("## "))]
    blocks: list[str] = []
    for x in lines:                     # blank lines between blocks; list items stay together
        if blocks and not (x.startswith("- ") and blocks[-1].startswith("- ")):
            blocks.append("")
        blocks.append(x)
    out = blocks
    slug = item["base_path"].rsplit("/", 1)[-1]
    meta = {
        "doc_id": slug, "title": item["title"], "version": str(len(item["details"].get("change_history") or []) or 1),
        "effective_from": item["public_updated_at"][:10], "effective_to": "", "owner": OWNER, "access": "public",
        "language": item.get("locale", "en"), "doc_type": "guide",
        "source": "https://www.gov.uk" + item["base_path"], "licence": LICENCE,
    }
    head = "\n".join(f'{k}: "{v}"' if k in ("title", "owner", "effective_to", "licence") else f"{k}: {v}"
                     for k, v in meta.items())
    text = f"---\n{head}\n---\n\n# {item['title']}\n\n{item.get('description', '').strip()}\n\n" + "\n".join(out).strip()
    return text + "\n"


# ---------------------------------------------------------------- the snapshot

def load_snapshot(folder: Path = SNAPSHOT) -> tuple[list[dict], int, list[str]]:
    """The guides of the snapshot, in the topic's order, after checking every file's SHA-256."""
    n, bad = 0, []
    for line in (folder / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        n += 1
        p = folder / name
        if not p.exists() or sha256(p.read_bytes()) != digest:
            bad.append(name)
    topic = json.loads((folder / "topic.json").read_text(encoding="utf-8"))
    items = [json.loads((folder / "guides" / f"{link['base_path'].rsplit('/', 1)[-1]}.json").read_text(encoding="utf-8"))
             for link in topic["links"]["linked_items"]]
    return items, n, bad


def prepare(folder: Path = SNAPSHOT, out: Path = DATA) -> int:
    items, n, bad = load_snapshot(folder)
    print(f"Snapshot: {n - len(bad)} of {n} files match data/snapshot/SHA256SUMS"
          + (f"; changed: {', '.join(bad)}" if bad else ""))
    if bad:
        print("A changed snapshot is another collection: restore it (git checkout data/snapshot).")
        return 1
    docs = out / TENANT / "documents"
    docs.mkdir(parents=True, exist_ok=True)
    rows, words = [], 0
    for item in items:
        text = to_markdown(item)
        slug = item["base_path"].rsplit("/", 1)[-1]
        (docs / f"{slug}.md").write_text(text, encoding="utf-8")
        words += len(text.split("---\n", 2)[2].split())
        rows.append({"file": f"documents/{slug}.md", "doc_id": slug, "title": item["title"],
                     "version": str(len(item["details"].get("change_history") or []) or 1),
                     "effective_from": item["public_updated_at"][:10], "effective_to": "", "owner": OWNER,
                     "access": "public", "language": item.get("locale", "en"), "doc_type": "guide", "format": "md"})
    with open(out / TENANT / "inventory.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, COLUMNS, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)
    files = sorted(p for p in (out / TENANT).rglob("*") if p.is_file() and not p.name.startswith("."))
    files += sorted(p for p in (out / "identity").glob("*.csv"))
    sums = "".join(f"{sha256(p.read_bytes())}  {p.relative_to(out).as_posix()}\n" for p in files)
    (out / "SHA256SUMS").write_text(sums, encoding="utf-8")
    dates = sorted(r["effective_from"] for r in rows)
    print(f"Wrote {len(rows)} documents to data/{TENANT}/documents/ ({words:,} words), "
          f"last updated {dates[0]} to {dates[-1]}.")
    print(f"Wrote data/{TENANT}/inventory.csv and data/SHA256SUMS ({len(files)} files, "
          f"SHA-256 of the list {sha256(sums.encode())[:12]}...).")
    return 0


# ---------------------------------------------------------------- the network (fetch, check)

def get(path: str) -> bytes:
    req = urllib.request.Request(API + path, headers={"User-Agent": "doc-assistant capstone (learning project)"})
    try:   # certifi comes with the project's packages; some Python installers have no certificates
        import certifi

        context = ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        context = None
    with urllib.request.urlopen(req, timeout=30, context=context) as r:
        return r.read()


def fetch(out: Path) -> int:
    if out.resolve() == SNAPSHOT.resolve() or (out / "SHA256SUMS").exists():
        print(f"{out} already holds a snapshot: choose a new folder (--out).")
        return 1
    (out / "guides").mkdir(parents=True)
    topic = get(TOPIC)
    (out / "topic.json").write_bytes(topic)
    names = ["topic.json"]
    for link in json.loads(topic)["links"]["linked_items"]:
        slug = link["base_path"].rsplit("/", 1)[-1]
        (out / "guides" / f"{slug}.json").write_bytes(get(link["base_path"]))
        names.append(f"guides/{slug}.json")
        time.sleep(0.2)                 # be polite: a few requests a second at most
    (out / "SHA256SUMS").write_text("".join(f"{sha256((out / n).read_bytes())}  {n}\n" for n in names),
                                    encoding="utf-8")
    print(f"Downloaded the topic and {len(names) - 1} guides into {out}.")
    return 0


def check(folder: Path = SNAPSHOT) -> int:
    items, _, bad = load_snapshot(folder)
    if bad:
        print(f"The snapshot changed on disk: {', '.join(bad)}")
        return 1
    live_topic = json.loads(get(TOPIC))
    ours = [i["base_path"] for i in items]
    theirs = [x["base_path"] for x in live_topic["links"]["linked_items"]]
    same = changed = 0
    for item in items:
        live = json.loads(get(item["base_path"]))
        if sha256(live["details"]["body"].encode()) == sha256(item["details"]["body"].encode()):
            same += 1
        else:
            changed += 1
            print(f"  changed on GOV.UK: {item['base_path']} (snapshot {item['public_updated_at'][:10]}, "
                  f"now {live['public_updated_at'][:10]})")
        time.sleep(0.2)
    for p in sorted(set(theirs) - set(ours)):
        print(f"  new on the topic page: {p}")
    for p in sorted(set(ours) - set(theirs)):
        print(f"  no longer on the topic page: {p}")
    print(f"{same} of {len(items)} guides are the same as the snapshot; {changed} changed.")
    return 0


def convert(path: Path, out: Path = DATA / "new-input") -> int:
    item = json.loads(path.read_text(encoding="utf-8"))
    out.mkdir(parents=True, exist_ok=True)
    target = out / f"{item['base_path'].rsplit('/', 1)[-1]}.md"
    target.write_text(to_markdown(item), encoding="utf-8")
    print(f"Wrote {target.relative_to(ROOT)}: {item['title']} (last updated {item['public_updated_at'][:10]}).")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m scripts.collection")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("prepare")
    sub.add_parser("check")
    f = sub.add_parser("fetch")
    f.add_argument("--out", type=Path, required=True)
    c = sub.add_parser("convert")
    c.add_argument("path", type=Path)
    args = parser.parse_args(argv)
    if args.command == "prepare":
        return prepare()
    if args.command == "check":
        return check()
    if args.command == "convert":
        return convert(args.path)
    return fetch(args.out)


if __name__ == "__main__":
    sys.exit(main())
