"""What the scripts share: the settings, the database, the models and a caller (no server needed).

The scripts call the same code as the API (the pipeline, the ingestion, the worker) inside one
process. A script acts as a person of the identity data, through that person's membership, so
the same checks apply as in the API.
"""

import csv
from pathlib import Path

from doc_assistant import tracing
from doc_assistant.access import Principal, membership
from doc_assistant.config import settings as load_settings
from doc_assistant.db import Database
from doc_assistant.embed import make_embedder
from doc_assistant.pipeline import Deps
from doc_assistant.providers import make_provider
from doc_assistant.rerank import make_reranker


# Who the scripts act as in each tenant: an owner or staff member, and a read-only member
# (the first of each in data/identity/memberships.csv).
def _members(roles: tuple[str, ...]) -> dict[str, str]:
    path = Path(__file__).resolve().parent.parent / "data" / "identity" / "memberships.csv"
    with open(path, encoding="utf-8", newline="") as f:
        found: dict[str, str] = {}
        for m in csv.DictReader(f):
            if m["role"] in roles:
                found.setdefault(m["tenant_id"], m["user_id"])
    return found


STAFF = _members(("owner", "staff"))
READ_ONLY = _members(("read_only",))


def open_deps(settings=None, provider=None) -> Deps:
    s = settings or load_settings()
    if not s.database_url:
        raise SystemExit("Set DATABASE_URL in .env (copy .env.example).")
    tracing.setup(s.trace_file, s.app_version)
    db = Database(s.database_url, s.app_db_role)
    db.open()
    reranker = make_reranker(s.embedder, s.torch_threads) if s.retrieval_mode.endswith("_rerank") else None
    return Deps(db, s, make_embedder(s.embedder, s.torch_threads), provider or make_provider(s), reranker)


def as_member(deps: Deps, user_id: str, tenant: str) -> Principal:
    with deps.db.admin() as conn:
        return membership(conn, user_id, tenant)
