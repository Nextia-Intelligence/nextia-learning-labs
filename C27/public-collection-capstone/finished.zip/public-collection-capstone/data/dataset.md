# Data card: the GOV.UK Service Manual's "Agile delivery" guides

## Source and permission

- Who wrote the documents: the Government Digital Service (GDS), UK government. They are the 20 guides listed on the topic page https://www.gov.uk/service-manual/agile-delivery, downloaded on 2026-10-11 from the GOV.UK Content API (`https://www.gov.uk/api/content/service-manual/agile-delivery` and one address per guide; no key needed).
- Licence or permission: Crown copyright, published under the **Open Government Licence v3.0** (https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/). It allows copying, publishing, adapting and commercial use, with an attribution. Logos and the crown are not covered; this project uses the text only.
- Attribution: "Contains public sector information licensed under the Open Government Licence v3.0." Every converted document also names its source address and the licence in its metadata.
- Personal data: none. The guides name government departments and public programmes, not people.
- The team (Westbrook digital team), Ruth and Leo are invented: `data/identity/` (the email addresses end in `.example`).

## Contents

| Collection | Documents | Formats | Staff-only | Versions |
|---|---|---|---|---|
| `westbrook/` (the team's collection) | 20 guides, 197 sections, about 19,100 words | Markdown, converted from the Content API's HTML | none: every guide is public | one version of each guide: `version` = the number of entries in its change history (1 to 4), `effective_from` = its last update on GOV.UK (2016-05-23 to 2026-05-22) |

- `snapshot/`: the exact files downloaded (`topic.json`, `guides/*.json`, `new-input/how-service-assessments-work.json`), and their checksums in `snapshot/SHA256SUMS`. Never edit them: a changed snapshot is another collection.
- `westbrook/documents/*.md` and `westbrook/inventory.csv`: written by `python -m scripts.collection prepare` from the snapshot. The conversion keeps the title, the summary, the headings, the paragraphs and the list items. Links keep their text only. An `h3` heading becomes a section named "h2: h3", because several guides use the same `h3` twice (for example "Scrum" in *Agile methods: an introduction*). A heading straight before another heading is dropped: it has no text of its own.
- `SHA256SUMS`: the checksums of the converted documents and of `identity/` (`python -m scripts.datapack` checks them).
- `new-input/`: one more guide, outside the collection, for the end-to-end run (`python -m scripts.collection convert ...`).

## Deliberate difficulties

Nothing was planted: these are the difficulties of the real collection.

- Revisions: GOV.UK changes the guides without notice (6 of the 20 were updated in 2026). The project answers from one fixed snapshot; `python -m scripts.collection check` lists what has changed on GOV.UK since.
- Contradiction: *How the discovery phase works* (2021) says "check if you need spend controls approval"; *Getting approval to spend money on a service* (2026-04-01) says that spend controls "were replaced on 1 April 2026". The newer guide applies.
- Similar documents: the four phase guides (discovery, alpha, beta, live) share headings ("Solving a whole problem for users", "Meeting the standard") and differ in the facts (discovery 4 to 8 weeks, alpha 6 to 8 weeks; book the alpha assessment within a fortnight of starting, the beta assessment 6 weeks before the date you want).
- An answer only in a table: none (the guides have no tables).
- Staff-only content: none. The access code is still tested on the synthetic pack in `tests/fixtures/pack/`.
- An instruction hidden in a document: none.
- Questions the documents do not answer: 9 of the 60 questions (for example "How many points are in the Service Standard?", which is in another topic of the Service Manual).

## Questions

`evaluation/questions.jsonl`: 60 questions written by one person by reading the 20 guides; no model wrote or labelled a question. Kinds: answerable 24, phase 12, paraphrase 7, definition 6, conflict 2, unanswerable 9. Each names the sections that answer it (checked against the parsed guides by the author's script). 25 were reserved as the held-out set (`python -m scripts.holdout reserve`, seed 27) and committed before any answer was generated.

## Known limits

- One topic of one manual: about 19,100 words. A real knowledge base is bigger, and retrieval gets harder.
- The guides are well written and consistent. Many real collections are not.
- English only.
- The snapshot ages: the answers are about the guides as they were on 2026-10-11, not as they are today.
- GOV.UK says that it does not publish advice. Neither does this assistant: it points to the guide.
