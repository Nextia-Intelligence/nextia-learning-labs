---
doc_id: governance-principles-for-agile-service-delivery
title: "Governance principles for agile service delivery"
version: 1
effective_from: 2016-05-23
effective_to: ""
owner: "Government Digital Service (GOV.UK Service Manual)"
access: public
language: en
doc_type: guide
source: https://www.gov.uk/service-manual/agile-delivery/governance-principles-for-agile-service-delivery
licence: "Open Government Licence v3.0"
---

# Governance principles for agile service delivery

Six principles for governing service delivery, to help you create the right culture for your service team and organisation.

The following 6 principles will help you create an agile culture for your service team and organisation.

- Do not slow down delivery
- Decisions when they’re needed, at the right level
- Do it with the right people
- Go see for yourself
- Do it only if it adds value
- Trust and verify

## Who is involved in governance

Everyone in the delivery team is responsible for and involved in its governance. Agile tools and techniques (daily stand-ups, regular planning meetings and retrospectives) are all ways of governing delivery.

Delivery teams also need help from people who are responsible for supporting an agile team through management and governance activity. These generally are:

- service owners
- delivery managers
- senior responsible officers (SROs)
- auditors and assurers
- digital leaders, chief technology officers and other senior civil servants

## Do not slow down delivery

Your service team must build a service that you continually improve to meet user needs. As service owner, you should:

- find a way to get work done when it’s ‘blocked’ and slowing down delivery, especially if your team does not have the authority to do so
- be available and make frequent decisions throughout service delivery
- be mindful of the balance between releasing new features and maintaining quality
- protect the team from, or help them handle, external pressures

You should keep a good pace of delivery by:

- having short, frequent meetings, like stand-ups
- managing risks and issues affecting the delivery of your service
- basing controls, for example on spending, on the balance between costs and benefits

Make transitions between phases seamless. People who govern must anticipate problems and make timely decisions.

## Decisions when they’re needed, at the right level

Iterative development is the best way of handling change and improving service quality. Embrace that things change and decisions need to be made frequently. Make sure:

- decision making is evidence-based and focused on meeting user needs
- the service owner and team have the authority to make decisions and only escalate when they need to
- you handle change and improve quality through continuous iterative development

You should also ensure service teams know:

- they have the authority to make decisions about the service
- what the boundaries of that decision making are
- who is accountable for helping them when decisions outside the boundaries need to be made

## Decisions when they’re needed, at the right level: Risk management

You cannot eliminate risks. Highlight and own only the ones that could affect service delivery.

In agile, you need to deal with risks at the right time. Identify the best possible moment to respond to important risks and only then start to plan and carry out your response.

## Do it with the right people

As a service owner or SRO you should:

- make sure the people in your team have all the skills they need
- give them the environment, workspace and tools to collaborate, organise and deliver
- have a flat organisation structure so everyone in your team can contribute to the team’s success

You should make sure that everyone involved in redesigning or creating your government service is:

- capable, motivated and empowered
- focused on goals and outcomes including key performance indicators (KPIs)
- open and honest about what they do

Find out how to set up a service team for each phase.

## Go see for yourself

It’s everyone’s responsibility to stay well informed. Delivery teams talk face to face wherever possible and the best way to measure progress is to ‘see the thing’.

SROs should visit teams regularly and take part in a delivery team’s meetings, particularly sprint reviews or show and tells. This makes sure they’re fully informed and can make decisions quickly.

If these meetings are not happening, find out why.

## Go see for yourself: Reporting and planning

Go see for yourself how delivery teams are using data to manage delivery. Digital formats like Trello are an excellent way to track work and show important things, like what the team is doing and how they’re progressing. It helps planning and communication within the team and to other teams.

Read more in the guide Measuring and reporting progress.

## Do it only if it adds value

In agile delivery management there’s a focus on giving value to users early and continuously. This means your team needs to:

- have a service vision and goals based on user needs
- set out measures of success and communicate these regularly
- value quality and make sure that user needs are met (give the team time to do this)
- explore and develop ideas that could add value - if they do not work, try something else

To do this the service delivery team should develop a charter (for example, a written document or poster) that describes:

- their service vision
- quantifiable goals
- key performance indicators (KPIs) that show progress against meeting user needs and organisational goals

## Trust and verify

Governance should be simple and supportive. It should trust individuals and give decision-making authority to teams so they can focus on delivering.

People who govern should regularly speak to the team to help support, steer and assure. To monitor progress use a light touch. This means checking services a little, but often.

Regular reflection on how teams are doing and finding ways to improve is an important part of good governance. At the end of each iteration every delivery team holds a retrospective where it discusses lessons learned - both what went well and what did not. This lets you identify actions which are then planned into future iterations. Use retrospectives across programmes of work.

## Examples and case studies

Read about how the Home Office used agile governance to help them deliver the Immigration Platform Technologies (IPT) Programme.
