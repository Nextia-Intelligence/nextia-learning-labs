---
doc_id: planning-agile
title: "Planning in agile"
version: 3
effective_from: 2026-03-31
effective_to: ""
owner: "Government Digital Service (GOV.UK Service Manual)"
access: public
language: en
doc_type: guide
source: https://www.gov.uk/service-manual/agile-delivery/planning-agile
licence: "Open Government Licence v3.0"
---

# Planning in agile

Know what your vision and objectives are, what you need to do to achieve them and how you know when you’ve achieved them.

Planning is vital to the success of agile working. Planning allows everyone to understand:

- what your vision and objectives are
- what you need to do to achieve your objectives
- how you know when you’ve achieved them

## Differences between agile and waterfall planning

In waterfall projects you typically do detailed planning early on in a project, before the development stage.

After planning it’s rare that you go back and make changes.

You hold plans in requirement documents and Gantt charts that may not be accessible to everyone.

In agile, you change your plans as you do more work and learn more about your users.

You should focus your efforts on planning at the right level at the right time. Plan work you do not expect to do for a while at a high level. Make a more detailed plan for work you are just about to do.

In agile, you should make your planning visible to the rest of your organisation.

Use your virtual team board or physical team wall to display your vision, goals, roadmap and user stories.

You should also allow anyone in your organisation to see any planning you do using online tools.

## How to make an agile plan

Follow these 3 steps to make an agile plan.

- Decide on a vision.
- Make objectives.
- Make a roadmap.

## How to make an agile plan: Decide on a vision

Every product or service benefits from a vision - a simple statement explaining what you’re trying to achieve.

It’s important that people working on your service and its stakeholders understand the vision and are involved in writing it. This creates a collective sense of ownership.

## How to make an agile plan: Make objectives

You should define some objectives that you want to achieve and have a system for checking when you’ve achieved these objectives.

One way you can do this is by tracking results you can measure for each objective. For example:

- Start by defining 3 to 5 main objectives.
- For each objective, define 3 to 4 results you can measure using quantitative data.

You should also:

- set your objectives a year in advance, although you can change them
- change how you’re measuring results as you learn more about the service

## How to make an agile plan: Make a roadmap

You should make and keep a roadmap of the main features you need to build to achieve your objectives. Your team must have the authority to develop and own the roadmap.

Your roadmap should typically set out your plans 6 to 12 months in advance. If you have fixed deadlines, for example ministerial deadlines, you should focus your roadmap planning around what you can achieve within that deadline.

Revisit your roadmap regularly to re-prioritise what you’ll be working on in the near future. In large programmes of work with many dependencies, you may want to look at your roadmap weekly.

Make your roadmap visible by displaying it on your team wall or board.

If you have more than one team or organisation working towards a common goal, you should put the roadmaps for separate streams of work together on a wall.

This allows you to see cross-team or cross-organisation dependencies, including what any external third parties are doing.

## Hold planning meetings

You should hold a meeting with your whole team to make detailed plans of the work you’ll be carrying out in the next iteration or sprint.

Use this meeting to:

- make sure that the whole team understands the work they’re about to do
- talk about possible approaches, issues and dependencies based on user stories from your backlog
- keep up collaboration between the different disciplines in your team
- include members of other teams or external teams if there are cross-team or cross-organisation dependencies

## Further reading

Read a GOV.UK Verify blog post about making clear goals for complex agile programmes.

## Related guides

You may also find these guides useful:

- Governance principles for agile service delivery
- Measuring and reporting progress
