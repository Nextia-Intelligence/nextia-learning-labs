---
doc_id: team-wall
title: "Set up a physical team wall"
version: 2
effective_from: 2026-03-31
effective_to: ""
owner: "Government Digital Service (GOV.UK Service Manual)"
access: public
language: en
doc_type: guide
source: https://www.gov.uk/service-manual/agile-delivery/team-wall
licence: "Open Government Licence v3.0"
---

# Set up a physical team wall

Physical team walls can help you map out the problems you're exploring and manage work you've agreed to do.

If you work in an office-based agile team, you may want to set up a physical team wall to help you keep a visual record of the work you’re doing.

## How team walls work

You record individual pieces of work on a card or piece of paper and stick them to the wall.

You stick other cards on the wall which represent stages of production, you can then move the pieces of work along the wall as they pass through the production stages.

## What to put on your team wall

Most teams fill the wall with paper or post-it notes and various headings, to show everything the team is working on, the stage of production it’s at, and any work that’s upcoming.

Your wall will differ depending on the service you’re building, but most teams include details of:

- work the team is currently doing
- work the team has not started yet
- work that’s done

You should also use the wall to track:

- progress against your goals and key performance indicators (KPIs) – for live data, you could show this on an electronic dashboard
- any risks and issues you’ve found
- major obstacles to delivery, things which are stopping you getting work done (these are sometimes called ‘blockers’)
- important deadlines and dependencies

You can also display information about your service and your team, for example:

- your service vision
- photos or profiles of the people who are on your team
- your working arrangements, eg when you have retrospectives or other meetings

## How team walls help

Team walls help you to:

- map out problems you’re exploring
- manage work you’ve agreed to do
- share a lot of information quickly and publicly
- put all your work together and see how it’s progressing
- start conversations in your team or with others in your office, eg about your processes or points where work gets blocked
- encourage communication and collaboration in your team, and with the rest of the organisation

An up-to-date wall also allows you to:

- have a physical focal point for the team to look at and comment on during standups and other meetings
- promote transparency and discussion by showing everyone in your organisation the status of your work
- make decisions based on an overview of your work
- manage and measure workflow and spot problems that are delaying you

Example:

A team mapped out the current processes for importing and exporting goods across the UK border, which are currently handled by 26 different government departments and agencies.

Read about what they learned from mapping the processes in their discovery.

## How team walls help: Online tools

As well as your team wall, you may want to record the work your team is doing online, for example using a tool like Trello, Jira or Asana.

If you do this you should always post information about current and future work to your wall.

If possible you can display your online tool on a screen in your work area so it is still visible to everyone.

## Related guides

You may also find these guides useful:

- Creating an agile working environment
- Agile tools and techniques
