---
doc_id: measuring-reporting-progress
title: "Measuring and reporting progress"
version: 1
effective_from: 2016-05-23
effective_to: ""
owner: "Government Digital Service (GOV.UK Service Manual)"
access: public
language: en
doc_type: guide
source: https://www.gov.uk/service-manual/agile-delivery/measuring-reporting-progress
licence: "Open Government Licence v3.0"
---

# Measuring and reporting progress

Agile ways of working require service teams to measure and report continuously so they always have the data they need to improve their work.

Good reporting helps senior responsible officers (SROs) and service managers make decisions and give feedback when necessary. It should show a clear view of progress without creating any extra work for the team.

## Measuring and reporting progress in agile

Measuring and reporting progress are built into agile ways of working so service teams will continuously produce the data you need. This includes:

- continuous planning - setting a vision, goals and objectives, developing a roadmap and tracking progress against them
- visual management - team walls and a backlog open to everyone
- face to face meetings - standup, show and tell, retrospectives for the team and the rest of the organisation

If you think you need extra reporting, make sure it’s really necessary and adds value. Too many reporting requirements become counterproductive as the team has less time to spend on delivery work. This is especially important for you to transition from one phase to another without the team losing momentum.

## Reporting when you have more than one team

If you’re working with more than one team on a service, having some consistency in how they report means you can more effectively:

- see progress
- support service teams
- make informed decisions
- communicate with the rest of your organisation (and the public) about the service

Don’t try to force more consistency than is practical because the circumstances of each team will be different.

## Related guides

The following guides have more information on governing agile teams:

- governance principles for agile service delivery
- planning in agile
