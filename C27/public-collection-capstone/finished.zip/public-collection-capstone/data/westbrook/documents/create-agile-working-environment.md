---
doc_id: create-agile-working-environment
title: "Creating an agile working environment"
version: 3
effective_from: 2026-04-09
effective_to: ""
owner: "Government Digital Service (GOV.UK Service Manual)"
access: public
language: en
doc_type: guide
source: https://www.gov.uk/service-manual/agile-delivery/create-agile-working-environment
licence: "Open Government Licence v3.0"
---

# Creating an agile working environment

Use the right tools and design your environment to encourage agile working.

Things move quickly in agile, so digital teams need easy ways to coordinate their activities, communicate progress and collaborate.

You should design your digital and physical working environments and choose suitable technology to encourage agile ways of working.

## What an agile environment looks like

You should expect to have lots of short meetings throughout each day. These are often using your team’s shared work board. This could be:

- a digital board using tools like Trello and Mural
- a physical team wall covered in notes and reference materials

This may seem strange if you’re more used to formal meetings or conference calls.

People working in creative and technical fields often need plenty of space for focused, detailed work. It’s common to see people spend most of the day with headphones on to help them focus, or deep in conversation with someone they’re pairing with.

## Decide what you need from your environment

Working spaces for digital projects will vary. At the beginning of a project, decide with your team:

- how to structure your space
- the tools you need

## Your working environment

Your working environment includes both your physical space and the digital tools you use. It’s just as important as the choice of programming language or project management tools.

## Your working environment: Working together

Ideally, your team will be able to collaborate easily, even when you’re based in different offices or working remotely.

Short, informal conversations are an important way to test assumptions and solve problems quickly.

If you’re not in the same place, you can create opportunities for these conversations through digital tools and regular check-ins.

## Your working environment: Adapting your environment

Small changes to your setup can make it easier to work together.

Think about your digital setup. Clear naming conventions, shared folders and agreed ways of working can make a big difference.

In an office, removing dividers between desks makes a big difference and allows conversation between the team to flow more freely. If large monitors are getting in the way, remove them. You might also want to think about getting a desk organiser.

## Your working environment: Shared workspace

Teams using agile approaches need a shared visual workspace. This can be either:

- a digital board that your team can access from any location, using tools like Mural and Trello
- a physical team wall in your office, if your whole team works from the same place - if you cannot use a wall, you could try whiteboards or windows

Your workspace should show your work clearly and create a shared focus so that the team can:

- use it during daily stand-ups (online or in person)
- refer to and update it during the day
- show the status of their work to anyone outside of the team

This is called ‘visual management’. It makes it easier for the team to discuss what they’re working on, sort out problems together and talk through ideas.

## The right technology

As a team, you also need online tools to help you communicate and manage your work.

Individual members of the team may also need access to tools to help them with their role (for example, your user researcher may need access to video editing software).

You should check if anyone needs training to use the tools you choose.

## The right technology: Online communication

Regular meetings like standups and retrospectives help teams stay aligned, but you also need a tool for day-to-day online discussions.

An online communication tool helps your team to:

- stay in contact when working in different locations
- make quick decisions
- get support and share information
- keep everyone informed about your work

For example, Slack has useful functionality for collaborating with people in teams, your organisation and across government. Google Chat and Microsoft Teams can also be useful.

These tools allow your team to talk in a more conversational way than they would with emails. They stop large backlogs of emails building up and help teams to stay connected.

## The right technology: Collaboration

You must have a browser-based editing tool so that your team can work on the same documents at the same time.

This is a mandatory open standard requirement for government.

It also helps you avoid having multiple versions of the same document. Examples include Google Drive and Microsoft OneDrive.

Some departments also use collaboration tools like Confluence for internal wikis, while GDS uses Basecamp for cross-government communities.

## The right technology: Managing your backlog

You might find an online board helps you to manage your backlog.

Online boards allow you to:

- add detailed information to backlog items (such as draft designs)
- link to related discussions
- keep work visible to everyone in your team, wherever they’re working

Trello, Jira and Asana are examples of digital boards used by government service teams.

## Visit agile working environments

If you’re setting up an agile working environment for your team, you might find it useful to go and look at how other agile teams are working.

Get in touch with the agile delivery community to arrange a tour.

## Related guides

You may also find the following guides useful:

- Agile tools and techniques
- Set up a physical team wall
