---
doc_id: agile-methodologies
title: "Agile methods: an introduction"
version: 1
effective_from: 2016-07-27
effective_to: ""
owner: "Government Digital Service (GOV.UK Service Manual)"
access: public
language: en
doc_type: guide
source: https://www.gov.uk/service-manual/agile-delivery/agile-methodologies
licence: "Open Government Licence v3.0"
---

# Agile methods: an introduction

An introduction to agile methods, how to use them, and the most popular methods explained.

There are many agile methods you can use when building your service, each has its own set of tools and techniques.

This guide introduces the 3 most popular agile methods:

- Scrum
- Kanban
- Lean

## Popular agile methods explained: Scrum

Scrum is the most commonly used agile method.

It allows a highly structured model with clearly defined roles and responsibilities. This can be particularly useful for traditionally structured organisations that are moving to agile.

Learn more about the features of Scrum in the Scrum Guide, written by the developers of Scrum, Ken Schwaber and Jeff Sutherland.

## Popular agile methods explained: Kanban

Kanban as a development method was inspired by production systems that focus on reducing waste and improving quality, like those created by Toyota.

Kanban is a way of visualising and improving your current working practices so that work flows through a system quickly.

A fast and smooth flow of work means you can:

- deliver value quickly and predictably
- get early feedback to find out whether your product or service is meeting user needs

Read a brief introduction to Kanban.

## Popular agile methods explained: Lean

Lean software development, like Kanban, is adapted from lean manufacturing principles like the Toyota Production System.

The principles of Lean aim to help your team focus on:

- reducing waste
- delivering quickly
- learning and improving
- using evidence and data to make decisions

Read the following to learn more about Lean:

- The Lean Mindset
- The Lean Startup

## Working with multiple agile methods

You do not have to work with just one method, you can choose tools and techniques from several to meet your team’s needs.

Each method has its own language for describing basic tools and techniques, the important thing is to understand:

- why you’ve chosen a tool or technique
- its agile objective

Find other agile methods you can use.

## Deciding which methods to work with: Scrum

Scrum is a good starting point if your team is new to agile working.

Your team will generally find Scrum most useful when you’re:

- building a new product or service
- enhancing existing features
- adding new features in each ‘sprint’ (a fixed period of time)

When you’re running your live service and have urgent requests you may find sprints constraining and want to move to a flow-based method like Kanban.

But you can still keep using many of the activities associated with Scrum, like daily standup meetings, retrospectives and regular reviews of progress.

## Deciding which methods to work with: Kanban

Kanban helps your team to:

- find the bottlenecks in your processes
- control the amount of work you’re doing
- predict your output based on actual delivery

It’s particularly useful at times when your team needs to react quickly to changing priorities.

## Deciding which methods to work with: Lean

Lean allows your team to focus on learning as quickly as possible.

Lean’s tools and techniques are particularly useful when your team is first discovering what your users’ needs are and deciding how to address those needs.

## Related guides

You may also find these guides useful:

- Agile and government services: an introduction
- Core principles of agile
- Agile tools and techniques
