---
doc_id: agile-government-services-introduction
title: "Agile and government services: an introduction"
version: 2
effective_from: 2022-04-06
effective_to: ""
owner: "Government Digital Service (GOV.UK Service Manual)"
access: public
language: en
doc_type: guide
source: https://www.gov.uk/service-manual/agile-delivery/agile-government-services-introduction
licence: "Open Government Licence v3.0"
---

# Agile and government services: an introduction

Agile is the approach to project management that is used to build and run government digital services.

You must use the agile approach to project management to build and run government digital services.

Agile methods encourage teams to build quickly, test what they’ve built and iterate their work based on regular feedback and other useful data.

## Where agile comes from

Agile started out as an alternative approach to software development, but is now applied more widely to running other types of projects and products.

The principles behind agile are set out in the Agile Manifesto (2001).

## The differences between traditional and agile methods

Agile can be very different for people used to traditional waterfall methods for software development.

With waterfall methods the process is sequential. You start by gathering requirements, making plans and going through procurement processes. You then design the product and build it. In the final stage you test and release it to the public. It’s only at this end stage that you get feedback and find out if it works for your users. You only have one chance to get each part of the project right, because you do not return to earlier stages.

Agile takes a different approach. You do all these things - gathering requirements, planning, designing, building and testing - at the same time. You start small in the discovery and alpha phases.

You research, prototype, gather data, test and learn about your users’ needs before you start building the real service in the beta phase.

You only go live when you have enough feedback and data to show your service works for your users and meets their needs. You continuously learn and improve to build a service that meets user needs.

## Why agile is better for services

While a sequential waterfall approach is necessary to build things like bridges and buildings, it’s less effective for building and running services when technology changes quickly.

Government services also need to be able to respond quickly to policy changes and the needs of the public.

Using waterfall methods means you may spend 18 months building a service that no longer meets government policy, cannot work with the latest technology and does not meet users’ needs.

Agile methods allow you to quickly make any changes while you’re building the service, and also when it’s live on GOV.UK.

## Case studies and examples

The following examples show how different teams across government have successfully adopted an agile approach:

- The Public Guardian on agile development - the Public Guardian on using agile methods to build the Lasting Power of Attorney service
- Working together to help people with court fees - HM Courts and Tribunals Service on how an agile approach helped redesign how people get help with court fees
