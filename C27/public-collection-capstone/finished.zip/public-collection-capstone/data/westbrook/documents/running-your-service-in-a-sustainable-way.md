---
doc_id: running-your-service-in-a-sustainable-way
title: "Managing and improving your service through its lifecycle"
version: 2
effective_from: 2026-05-22
effective_to: ""
owner: "Government Digital Service (GOV.UK Service Manual)"
access: public
language: en
doc_type: guide
source: https://www.gov.uk/service-manual/agile-delivery/running-your-service-in-a-sustainable-way
licence: "Open Government Licence v3.0"
---

# Managing and improving your service through its lifecycle

Manage and plan the resources your service needs to operate reliably, from public beta launch through ongoing delivery.

Your service should be backed by a plan and budget that allows for continuous large and small improvements throughout its lifetime.

Making improvements can mean:

- carrying out user research to better understand what users need for the service
- responding to technical problems and changes in user behaviour
- making the service simpler to use or more cost effective to run
- adding new features - for example, the Carer’s Allowance service worked with operations colleagues to speed up processing of claims
- supporting the service as it’s used more widely - for example by expanding user support or training operations colleagues so they can help people to use the service

There is separate guidance for creating environmentally sustainable services

## Go beyond essential maintenance

Operating a service means doing more than basic things like fixing bugs in code, upgrading software, fixing security vulnerabilities and keeping call centre scripts up to date. If you only respond to issues as they arise, you risk building up technical debt and leave yourself open to emerging security threats. And your service may stop meeting user needs.

You’ll need to do continuous improvement. This will allow you to respond to changes in user needs, technology or government policy throughout the lifetime of your service.

Make sure services have access to people with the skills needed to do continuous improvement. Keep the technology as flexible as possible, so it’s easy to iterate and improve your service often.

## Budget for uncertainty

Allocate people and resources for continuous improvement in a way that lets teams focus on doing the work that has the most value. Try to avoid limiting your focus to a single transaction or a particular channel. Service teams need to be able to tackle the root cause of problems, wherever they are.

Some organisations change how they allocate people and resources to work on services once they’re in the live phase. For example, they might not have a full team working on every service for 100% of the time. If you choose to do this, it’s important that it does not stop you doing continuous improvement.

Responsibility for keeping services running should not just belong to the service team, but the whole organisation. Look for ways to maximise flexibility. For example, by agreeing a common set of languages, tools, and ways of working for technical staff - either informally, or through something more formal like the GDS way.

## Deciding where to focus

All services will need to do continuous improvement. But the amount of work your team needs to do will depend on:

- what the service health indicators say
- whether there are external factors the service needs to respond to, such as changes in technology or government policy
- how critical the service is to users and government

Service health indicators could include:

- performance metrics
- analysis of support tickets and user feedback
- user satisfaction
- web analytics (for example, changes to how long it takes a website page to load, or the number of people leaving abandoning an application at a particular point)

You will not be able to do everything you want to do, so you’ll have to decide on priorities.

## Related guides

You may also find these guides useful:

- How the discovery phase works
- How the alpha phase works
- How the beta phase works
- How the live phase works
- Retiring your service
