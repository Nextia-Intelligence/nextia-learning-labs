---
doc_id: getting-approval-to-spend-money-on-a-service
title: "Getting approval to spend money on a service"
version: 1
effective_from: 2026-04-01
effective_to: ""
owner: "Government Digital Service (GOV.UK Service Manual)"
access: public
language: en
doc_type: guide
source: https://www.gov.uk/service-manual/agile-delivery/getting-approval-to-spend-money-on-a-service
licence: "Open Government Licence v3.0"
---

# Getting approval to spend money on a service

Working with your department's assurance team if you need support or approval to spend money on digital services.

Digital and technology spend controls were replaced on 1 April 2026.

From this date, central government departments are responsible for making most of their own digital and technology spending decisions.

If you’re planning to spend money or have an idea for a service, contact your department’s assurance team.

## How your assurance team can support you

Tell your assurance team about new ideas, projects or planned spending as soon as possible.

They will help you:

- follow cross-government standards, including the Service Standard and Technology Code of Practice
- spot risks
- avoid building things that already exist
- check your plans align with wider organisational priorities
- identify if you need extra approval or support

You can find detailed guidance on the spending and assurance process in the Digital Assurance Playbook.

## When you need extra approval or support

You need approval from HM Treasury (HMT) to spend money above your department’s spend limit, or on proposals that are any of the following:

- ‘novel’, or unlike the work your department normally does – for example, using artificial intelligence (AI) if you don’t have any internal expertise
- ‘contentious’ – for example, awarding a new contract to a supplier after they’ve had negative press interest
- ‘repercussive’, or likely to create financial pressure across the public sector – for example, licensing a popular product in a way that sets a precedent

The Government Digital Service (GDS) will support your assurance team with complex or high-risk services, including anything that needs HMT approval.
