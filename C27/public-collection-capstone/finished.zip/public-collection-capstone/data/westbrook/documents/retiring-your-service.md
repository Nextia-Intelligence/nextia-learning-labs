---
doc_id: retiring-your-service
title: "Retiring your service"
version: 2
effective_from: 2025-08-26
effective_to: ""
owner: "Government Digital Service (GOV.UK Service Manual)"
access: public
language: en
doc_type: guide
source: https://www.gov.uk/service-manual/agile-delivery/retiring-your-service
licence: "Open Government Licence v3.0"
---

# Retiring your service

When to retire a service, considering user needs, telling your users and what to do after the service is retired.

Your service may eventually need to be retired, for example if policies change or if there’s evidence that users’ needs have changed.

When retiring a service you should consider user needs in the same way you did when you built the service.

## Consider user needs

You need to consider how the user need your service met will be met after your service is retired.

It might be the case that:

- the user need no longer exists
- a new government service will meet the user need
- the user need will no longer be met by government

## Consider user needs: If a user need no longer exists

In some cases, policy could change to mean that your service is obsolete, for example when Universal Credit replaced 6 other benefits.

## Consider user needs: If a new service will meet the need

If a new government service or services will meet the user need then you should work with those services’ teams.

Share your experiences, findings and knowledge of the user with them so that they can learn from them.

This means you can understand how you’ll support your users through the transition, for example by:

- making sure the new service meets proven user needs
- helping users to find out about the new services in the best way

## Consider user needs: If the need will no longer be met by government

If the needs will no longer be met by government but by the private or voluntary sectors then you must:

- share knowledge and insight with these organisations, like open source elements
- help the private or voluntary team use the knowledge or information you share
- make sure that users who would normally go to GOV.UK are sent to the new service in the best way possible

## Telling your users: Users who access your service on GOV.UK

The vast majority of people who use your service will begin and end their journeys on GOV.UK.

As soon as you know that your service is likely to be retired you should email the GOV.UK team at govuk-enquiries@dsit.gov.uk to make sure that those journeys are amended and appropriate information is supplied.

You need to tell the GOV.UK team why you’re retiring the service and how its user needs will be met, so that they can help users with information and links.

## Telling your users: Users who access your service directly

Retiring the service means a significant change for users, but you should try to minimise it by telling them:

- what’s changing and why
- what they’ll have to do to continue to have their needs met in future
- what will happen to their data, whether you’re passing it on to another service and the rights they have under your organisation’s data protection policy

You can tell people using a notification system if your service has one, otherwise use a GOV.UK content page.

## Telling your users: Users who access your service using APIs

You need to give users who access your service via an application programming interface (API) the time to update their software to use the replacement service’s APIs or make other adjustments.

Contact these users as soon as possible. Keep in mind that they may have significant lead times for making and distributing changes.

## Telling your users: Users who access your service with assisted digital support

You must tell users who do not use the digital service or use it with assisted digital support that the service is being retired.

To do this, use your service’s assisted digital channel and assisted digital support organisations.

You may need to carry out user research to decide the best way to tell users the service is retiring.

You could use existing research or talk to teams who’ve retired other services that have similar users and use their research.

You may need to make sure that contact centres used by your users tell them the service has been retired and about any replacement service.

You could also put up posters in places that users are likely to visit (for example, in airports for visa or passport services).

## Make a plan to redirect traffic

Once the GOV.UK content team updates GOV.UK to say that your service has retired, the majority of users will be directed to the new service.

Some users will still try to access the service at the retired web address.

You should have a plan for redirecting those users to the new service, or telling them that the service that has permanently retired.

## Make a plan to redirect traffic: Make sure your subdomain continues to work

After your service is retired, you must help users by:

- continuing to use SSL
- serving a redirect from your service to the GOV.UK start page

If your service has been live for less than 6 months, you must do this until a year after your service went live.

If your service has been live for longer than 6 months, you must do this for a year after the time it retired or until the current SSL certificate expires, whichever comes first.

Your GOV.UK start page will be changed to explain that the service is no longer running, and the start button will be removed.

## Protecting information

You should have a plan for securing the information you’ve got about your users.

You should already have policies in place to manage that data responsibly, including details of how long it’ll be retained.

You must make sure that there’s support in place to maintain these policies and protect information.

If you’re giving data to a new service owner, you must:

- do so in line with your organisation’s data protection policies
- tell your users

## Related guides

You may also find these guides useful:

- How the discovery phase works
- How the alpha phase works
- How the beta phase works
- How the live phase works
