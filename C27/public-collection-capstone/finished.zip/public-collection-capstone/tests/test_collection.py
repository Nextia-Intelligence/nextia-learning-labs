"""The public collection: the snapshot is unchanged, and the conversion keeps the text and its structure."""

import shutil

from doc_assistant.parse import parse
from scripts import collection


def item(body: str) -> dict:
    return {"base_path": "/service-manual/agile-delivery/example", "title": "An example", "description": "A summary.",
            "public_updated_at": "2026-03-31T10:00:00+01:00", "locale": "en",
            "details": {"body": body, "change_history": [{"note": "first"}, {"note": "second"}]}}


def test_h3_sections_carry_their_h2_and_empty_headings_are_dropped():
    text = collection.to_markdown(item(
        "<p>Intro with <a href='/x'>a link</a>.</p><h2>Methods</h2><h3>Scrum</h3><p>Sprints.</p>"
        "<h2>Choosing</h2><h3>Scrum</h3><p>Start here.</p><ol><li>one</li><li><p>two</p></li></ol>"))
    doc = parse("example.md", text.encode())
    assert [b.text for b in doc.blocks if b.kind == "heading"] == ["Methods: Scrum", "Choosing: Scrum"]
    assert "Intro with a link." in doc.text and "- one\n- two" in doc.text
    assert doc.meta["version"] == "2" and doc.meta["effective_from"] == "2026-03-31"
    assert doc.meta["access"] == "public" and doc.meta["licence"] == "Open Government Licence v3.0"


def test_the_snapshot_matches_its_checksums():
    items, n, bad = collection.load_snapshot()
    assert bad == [] and n == 22 and len(items) == 20


def test_prepare_writes_one_parsable_document_per_guide(tmp_path):
    shutil.copytree(collection.DATA / "identity", tmp_path / "identity")
    assert collection.prepare(collection.SNAPSHOT, tmp_path) == 0
    docs = sorted((tmp_path / "westbrook" / "documents").glob("*.md"))
    assert len(docs) == 20
    for p in docs:
        assert parse(p.name, p.read_bytes()).meta["doc_id"] == p.stem
