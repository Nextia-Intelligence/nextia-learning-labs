# Agile delivery guide assistant

Answers questions about the GOV.UK Service Manual's 20 "Agile delivery" guides, with a citation to the guide and section for every claim, or a clear "the guides do not say". Built for one user and one decision: Ruth, a delivery manager, decides whether her team's new joiners use it as their first stop instead of a reading list. The team and its people are invented; the guides are real (Open Government Licence v3.0).

**Result on 25 held-out questions** (reserved before any answer, two live passes, chat-small): 22 of 25 correct in both passes; 18 of 21 answerable questions (85.7%, threshold 75%); abstained on 4 of 4 questions the guides do not answer; every citation valid; median about 1.3 to 1.7 s and US$0.0002 per question. **Recommendation:** use it as the first stop, with the cited section open, and watch two kinds of miss (below).

## What it does

- Ruth or a team member asks a question. The assistant searches the 20 guides (keywords and vectors, fused), gives the model the best passages, and returns a short answer. Every claim cites a guide and a section, and the code checks each citation.
- If the guides do not answer, it says so, even when the model "knows" an answer ("How many points are in the Service Standard?" is in another topic of the manual).
- A new guide goes in through the same upload as any document, and the next answer can cite it.

## Quick start

You need Python 3.12 or newer, Git and Docker (Docker Desktop on macOS and Windows). No key and no money: the answers are recorded.

```sh
python3 -m venv .venv && source .venv/bin/activate     # Windows: py -3.12 -m venv .venv; .venv\Scripts\Activate.ps1
pip install -r requirements.txt
cp .env.example .env                                    # then change POSTGRES_PASSWORD and the two URLs
python -m idp init
docker compose up -d --wait db
python -m pytest
python -m scripts.load_pack                             # the 20 guides (downloads the embedding model once)
python -m scripts.evaluate --set heldout                # the held-out result, from the recorded answers
python -m scripts.ask "How long does an alpha usually last?"
```

## How it was built

1. **Scope** (`docs/project-brief.md`): one user, one decision, non-goals (no other topics, no advice, one tenant, no live copy of GOV.UK).
2. **Data** (`data/dataset.md`): the guides as one fixed snapshot of the GOV.UK Content API (`data/snapshot/`, with `SHA256SUMS`), converted by `python -m scripts.collection prepare`. `python -m scripts.collection check` shows what GOV.UK has changed since.
3. **Questions**: 60, written by reading the guides; 25 reserved as the held-out set (`python -m scripts.holdout reserve`) and committed before any answer.
4. **Thresholds and the change rule** (`docs/acceptance-criteria.md`), written before any answer.
5. **Baseline and alternatives** on the 35 tuning questions: hybrid (the course's default) 34, dense 35, dense with a reranker 35, hybrid with a reranker 35. The rule asks for 2 more right answers; none had them, so hybrid stayed.
6. **One held-out run**, two passes (`docs/evaluation-report.md`, `reports/`).

The code is the course's `doc-assistant` (FastAPI, PostgreSQL with pgvector, a CPU embedding model, a provider adapter with recorded answers). This project changed the data, the scripts that named the course's two shops, and the prompt's words ("guides", not "shop policies"). The course's synthetic two-shop pack stays in `tests/fixtures/pack/`: the access and isolation tests need two tenants and staff-only documents, which a public collection does not have.

## Evaluation

| Measure | Result (pass 1 / pass 2) | Threshold |
|---|---|---|
| Correct, answerable | 18 of 21 / 18 of 21 | at least 75% |
| Abstains when the guides do not answer | 4 of 4 / 4 of 4 | 100% |
| Citation validity | 100% / 100% | 100% |
| Median time | about 1.3 s / 1.7 s | under 5 s |
| Cost per question | US$0.000201 | under US$0.001 |

The three wrong answers: two **retrieval misses** that ended in a safe "the guides do not say" (G01, the length of a stand-up; G30, the public in alpha), and one **key that was too strict** (G13: "not yet started" against the key `not started`). Details in `docs/evaluation-report.md`.

## Limitations

- 25 held-out questions, written by one person who read the guides: the wording is closer to the guides than a new joiner's.
- Hybrid search can miss a simple question: the vector search ranks the right section first, the keyword search (which does not weigh rare words higher) misses it, and the fusion pushes it below the top 5 (G01: 6th). The assistant then abstains: safe, but not helpful.
- The answers are about the snapshot, not today's GOV.UK.
- The guides are guidance; the assistant points to them and gives no advice.
- Tested on macOS (Apple silicon) only. The Windows commands are written, not tested.

## Data and licence

The code: MIT (`LICENSE`). The guides: Crown copyright, Open Government Licence v3.0 (https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/). Contains public sector information licensed under the Open Government Licence v3.0. Source: https://www.gov.uk/service-manual/agile-delivery. The recorded answers were made with chat-small (Azure OpenAI). The synthetic pack in `tests/fixtures/pack/`: CC0.
