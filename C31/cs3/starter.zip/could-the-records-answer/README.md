# Could the records have answered?

A case study of the course *Observability for AI Agents: Traces, Costs and Audit Trails* (Nextia Learning).

In 2024, reporters found that New York City's business chatbot gave answers that contradicted the city's
own rules, and the city had to defend it in public (`CASE.md`). This project asks: which records would have
answered the questions that the case raised? It runs a small practice assistant for a made-up city,
Harbourton, for 190 practice days, records the same conversations in four designs, and asks the case's ten
questions of each design.

| Design | What it keeps |
|---|---|
| A. The app log (the baseline) | one log line per conversation; the chats for 30 days; a feedback form |
| B. Every question and answer | the person's question and the answer, with their account or session, for ever |
| C. Traces only | OpenTelemetry traces: 10% of the conversations, for 14 days, no text |
| D. Audit trail, answers and metrics | audit events with the course's schema (never sampled), each distinct answer once, daily counters, plus C |

## Run it

Python 3.12 or newer. No account, no key, no model call: the model's answers are recordings, replayed.

```sh
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-dev.txt
python pilot.py                      # 190 practice days: writes work/pilot/ (about 5 seconds)
python -m casefile matrix            # the ten questions, four designs
python -m casefile ask Q3            # one question, what each design's records say
python -m casefile verify            # the audit trail's chain and anchor
python -m casefile investigate       # the complaint of day 186, end to end
python -m pytest
```

In the starter, design D records only the end of each conversation. Part 4 of the case study adds the rest
(`records/audit.py`, the TODO comments). Check your work with `python -m pytest -m design_d`.

## Files

| Path | What it is |
|---|---|
| `CASE.md` | the public case in our words, with links |
| `DATASET.md` | the dataset card: what is made up, what is recorded, the limits |
| `data/pages/` | Harbourton's practice rule pages, one file per version |
| `data/questions.json`, `data/releases.json` | the eight questions; the release log, indexes, warnings and page history |
| `data/labels.json` | one label per distinct answer, by a person who read it |
| `recordings/chat-small.jsonl` | the recorded answers of the course's `chat-small` model (17 requests × 10 samples) |
| `helper/` | the practice assistant: search, topic code, replay, guardrail |
| `pilot.py` | the constructed pilot, seeded, with the four recorders |
| `records/` | the four designs: a Recorder (writes) and a View (reads what is kept on a day) |
| `auditstore/` | the course project's audit store; the schema is renamed `cityhelp.audit/1` |
| `casefile/` | the case's questions, the answers from each design, the complaint |
| `tests/` | the checks |

## Licence

MIT (`LICENSE`), code and data. The public sources in `CASE.md` are linked, not copied. Harbourton is a
made-up city: its pages are not legal advice and not any real city's rules.
