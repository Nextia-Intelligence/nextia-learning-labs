# The public case: New York City's MyCity business chatbot

This file tells the public case in our own words, with a link to each source. It copies no article and no
transcript: short quotes only, with where they come from. It draws no legal conclusion. We do not know what
the city recorded about its chatbot, and nothing in this project says what it recorded.

## What the sources say

| When | What happened | Source |
|---|---|---|
| October 2023 | The city announces an AI action plan and, with it, a pilot chatbot on its MyCity Business site. It is to give business owners information from "more than 2,000 NYC Business web pages and articles", and it is "still in its beta phase". | [NYC Mayor's Office, 16 October 2023](https://www.nyc.gov/office-of-the-mayor/news/777-23/mayor-adams-releases-first-of-its-kind-plan-responsible-artificial-intelligence-use-nyc) |
| 29 March 2024 | The Markup, with THE CITY and Documented, reports tests in which the chatbot gave answers that the reporters say contradict local rules: on tips, on accepting cash, on housing vouchers, and more. One reporter got one answer to the voucher question; ten other staff members got the opposite one. The article says the bot runs on Microsoft's Azure AI services, and that the bot's own page says the city reviews questions to improve answers and otherwise deletes data within 30 days. | [The Markup, 29 March 2024](https://themarkup.org/news/2024/03/29/nycs-ai-chatbot-tells-businesses-to-break-the-law) |
| 2 April 2024 | Asked whether the chatbot should come down, the mayor answers that it will be fixed ("We're going to fix them"), and officials call it "a pilot". | [NYC Mayor's Office, transcript of 2 April 2024](https://www.nyc.gov/mayors-office/news/2024/04/transcript-mayor-adams-holds-in-person-media-availability-april-02) |
| 2 April 2024 | The Markup reports that the chatbot stays online with a new warning: a "beta product" whose answers may be "inaccurate or incomplete", and "Do not use its responses as legal or professional advice". A reader's screenshot shows a flat "no" to a tenant's question. | [The Markup, 2 April 2024](https://themarkup.org/artificial-intelligence/2024/04/02/malfunctioning-nyc-ai-chatbot-still-active-despite-widespread-evidence-its-encouraging-illegal-behavior) |
| 30 January 2026 | The next administration plans to take the chatbot down. The mayor calls it "functionally unusable" and puts its cost at "around half a million dollars". An update of 4 February says that the city took it down. | [The Markup and THE CITY, 30 January 2026](https://themarkup.org/artificial-intelligence/2026/01/30/mamdani-to-kill-the-nyc-ai-chatbot-we-caught-telling-businesses-to-break-the-law) |
| (index) | The AI Incident Database lists the case as incident 714. | [AI Incident Database, incident 714](https://incidentdatabase.ai/cite/714/) |

## The questions it raised

We turned what reporters, officials and critics asked in public into ten questions to a system's records
(`casefile/case.py`). For example: did the bot really give the answer in this screenshot? How many people got
a wrong answer, and when? Did a fix change the answers? Did anybody check the answers before they went out?

## What this project does with it

The project does not copy the real chatbot. It builds a small practice assistant for a made-up city,
Harbourton, with its own short rule pages (`data/pages/`), and runs it for 190 practice days with constructed
traffic and real recorded model answers (`DATASET.md`). Then it asks the ten questions of four designs for the
assistant's records, and counts which design can answer each one.

The sources' own terms: The Markup's articles are under a Creative Commons licence that does not allow changed
or commercial copies (CC BY-NC-ND 4.0), so this project links to them and never copies them. The city's pages
are linked, not copied.
