"""One answer of the Harbourton Business Helper: topic, search, model, check, reply."""

import json
from dataclasses import dataclass, field

from . import model
from .pages import page, release_log, search, topic

MODEL_DEPLOYMENT = "chat-small"
PROMPTS = {
    "p1": ("You are the Harbourton Business Helper, a city web service for business owners. Answer the "
           "question with the pages below. Reply with JSON only: {\"short_answer\": \"yes\" | \"no\" | "
           "\"it_depends\", \"answer\": \"<at most 60 words>\", \"sources\": [\"<page id>\", ...]}."),
    "p2": ("You are the Harbourton Business Helper, a city web service for business owners. Answer the "
           "question with the pages below, and use only the pages. If the pages do not answer the question, "
           "reply with the short answer \"refer\" and say which city office to ask. Cite every page that you "
           "used. Do not give legal advice. Reply with JSON only: {\"short_answer\": \"yes\" | \"no\" | "
           "\"it_depends\" | \"refer\", \"answer\": \"<at most 60 words>\", \"sources\": [\"<page id>\", ...]}."),
}


@dataclass
class Answer:
    question: str
    topic: str
    release: str
    prompt: str
    index: str
    disclaimer: str
    pages: list[str] = field(default_factory=list)      # what the search found: BP-102@1, ...
    short_answer: str = ""                               # yes | no | it_depends | refer | unparsed
    text: str = ""                                       # the reply that the person reads
    cites: list[str] = field(default_factory=list)       # the page IDs that the model named
    refused_by: str = ""                                 # a guardrail that answered instead of the model
    input_tokens: int = 0
    output_tokens: int = 0
    latency_s: float = 0.0
    sample: int = -1


def request_body(question: str, pages, prompt: str) -> dict:
    context = "\n\n".join(f"[{p.id} v{p.version}] {p.title}\n{p.text}" for p in pages)
    return {"model": MODEL_DEPLOYMENT, "max_completion_tokens": 400, "reasoning_effort": "none",
            "messages": [{"role": "system", "content": PROMPTS[prompt]},
                         {"role": "user", "content": f"Pages:\n{context}\n\nQuestion: {question}"}]}


def parse(content: str) -> tuple[str, str, list[str]]:
    try:
        d = json.loads(content.strip().removeprefix("```json").removesuffix("```").strip())
        return str(d.get("short_answer", "")).lower(), str(d.get("answer", "")).strip(), list(d.get("sources", []))
    except (json.JSONDecodeError, AttributeError):
        return "unparsed", content.strip(), []


def answer(question: str, rel: dict, sample: int) -> Answer:
    """Answer one question with release `rel` (a line of data/releases.json), using recorded sample `sample`."""
    a = Answer(question, topic(question), rel["id"], rel["prompt"], rel["index"], rel["disclaimer"])
    guard = release_log()["guardrails"].get(rel["guardrail"])
    if guard and a.topic in guard["refer_topics"]:
        a.short_answer, a.refused_by = "refer", rel["guardrail"]
        a.text = f"This helper does not answer this kind of question. Please ask {guard['office']}."
        return a
    found = search(question, rel["index"])
    a.pages = [p.ref for p in found]
    r = model.replay(request_body(question, found, rel["prompt"]), sample)
    a.short_answer, a.text, a.cites = parse(r["content"])
    a.input_tokens, a.output_tokens, a.latency_s, a.sample = (r["input_tokens"], r["output_tokens"],
                                                              r["latency_s"], r["sample"])
    return a


__all__ = ["Answer", "answer", "request_body", "parse", "page", "PROMPTS"]
