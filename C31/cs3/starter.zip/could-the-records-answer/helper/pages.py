"""The practice rule pages, the release log and the search index of each release."""

import json
import re
from dataclasses import dataclass
from datetime import date, timedelta
from functools import cache
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data"
STOP = set("a an the and or of to in on for with by at from is are be may must can do does i my me your you "
           "it its this that as not if any who which what how up over".split())


@dataclass(frozen=True)
class Page:
    id: str
    version: int
    topic: str
    title: str
    text: str

    @property
    def ref(self) -> str:          # the page and its version, as every record names it: BP-102@1
        return f"{self.id}@{self.version}"


def _words(s: str) -> set[str]:
    out = set()
    for w in re.findall(r"[a-z0-9']+", s.lower().replace("’", "'")):
        w = w.removesuffix("'s").rstrip("'")
        if len(w) > 3 and w.endswith("s"):
            w = w[:-1]
        if w and w not in STOP:
            out.add(w)
    return out


@cache
def page(ref: str) -> Page:
    head, _, body = (DATA / "pages" / f"{ref}.md").read_text(encoding="utf-8").partition("\n---\n")
    meta = dict(line.split(": ", 1) for line in head.splitlines())
    return Page(meta["id"], int(meta["version"]), meta["topic"], meta["title"], " ".join(body.split()))


@cache
def release_log() -> dict:
    return json.loads((DATA / "releases.json").read_text(encoding="utf-8"))


@cache
def questions() -> dict[str, dict]:
    return {q["id"]: q for q in json.loads((DATA / "questions.json").read_text(encoding="utf-8"))["questions"]}


def day_date(day: int) -> date:
    """Day 1 of the pilot is Monday 5 January 2026."""
    return date.fromisoformat(release_log()["start"]) + timedelta(days=day - 1)


def truth(question_id: str, day: int) -> str:
    """The right short answer on that day, by the practice pages."""
    q = questions()[question_id]
    t = q["truth"]
    for d, v in sorted(((int(k), v) for k, v in q.get("truth_from_day", {}).items())):
        if day >= d:
            t = v
    return t


def search(question: str, index: str, k: int = 2) -> list[Page]:
    """Keyword search over the release's index: the k pages that share most words with the question."""
    words = _words(question)
    scored = []
    for ref in release_log()["indexes"][index]:
        p = page(ref)
        score = len(words & _words(p.title + " " + p.text))
        if score:
            scored.append((-score, ref, p))
    return [p for _, _, p in sorted(scored)[:k]]


TOPIC_WORDS = {                    # the topic classifier: keywords of the question, a fixed list of codes
    "tips": {"tip"}, "cash": {"cash"}, "scheduling": {"schedule"}, "minimum_wage": {"hour", "wage"},
    "signs": {"sign"}, "sidewalk_cafe": {"table", "chair"}, "food_permit": {"coffee", "food"},
    "housing_vouchers": {"voucher", "tenant"},
}


def topic(question: str) -> str:
    """A code from a fixed list, from the question's own words (never from the pages that the search found)."""
    w = _words(question)
    for code, keys in TOPIC_WORDS.items():
        if w & keys:
            return code
    return "other"
