"""The Harbourton Business Helper: a small practice assistant built like the chatbot in the public case.

    helper/pages.py       the city's practice rule pages and the search index of each release
    helper/assistant.py   one answer: classify the topic, search the pages, ask the model, check, reply
    helper/model.py       the model: replay of the recorded answers (default) or a live call (authors only)

Harbourton is a made-up city. Its pages are short practice rules written for this case study: they are not
the law of any real city and not legal advice.
"""
