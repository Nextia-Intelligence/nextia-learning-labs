"""The model: a replay of recorded answers. Each request is looked up byte for byte in recordings/.

The recordings are real answers of the course's chat-small deployment to exactly these requests, several
samples of each (the same request can get different answers). `replay()` returns sample `n` of the request;
a request that was never recorded is an error, not a guess. Only the course team's recording script calls
the model; this project never does, and it needs no key.
"""

import hashlib
import json
from functools import cache
from pathlib import Path

RECORDINGS = Path(__file__).resolve().parent.parent / "recordings" / "chat-small.jsonl"


def request_key(body: dict) -> str:
    return hashlib.sha256(json.dumps(body, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
                          .encode("utf-8")).hexdigest()[:16]


@cache
def _recorded() -> dict[str, list[dict]]:
    out: dict[str, list[dict]] = {}
    if RECORDINGS.exists():
        for line in RECORDINGS.read_text(encoding="utf-8").splitlines():
            r = json.loads(line)
            out.setdefault(r["key"], []).append(r)
    for samples in out.values():
        samples.sort(key=lambda r: r["sample"])
    return out


class NotRecorded(LookupError):
    pass


def samples(body: dict) -> int:
    return len(_recorded().get(request_key(body), []))


def replay(body: dict, n: int) -> dict:
    """Sample n (0, 1, ...) of the recorded answers to this exact request: content, usage, latency."""
    recs = _recorded().get(request_key(body))
    if not recs:
        raise NotRecorded(f"request {request_key(body)} was never recorded")
    r = recs[n % len(recs)]
    return {"content": r["content"], "input_tokens": r["input_tokens"], "output_tokens": r["output_tokens"],
            "latency_s": r["latency_s"], "model": r["model"], "sample": r["sample"]}
