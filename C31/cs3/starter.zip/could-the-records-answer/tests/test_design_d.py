"""Design D: the audit trail, the answer store and the metrics. Run: python -m pytest -m design_d"""

import json

import pytest

from auditstore.schema import AuditEventError, check
from auditstore.store import AuditStore
from casefile.answers import QUESTION_FUNCS, Records
from records.audit import Recorder

pytestmark = pytest.mark.design_d


def events(pilot, type_):
    return [e for e in AuditStore(pilot / "audit" / "audit.jsonl").events() if e["type"] == type_]


def test_every_answer_has_a_proposal_or_a_refusal_and_a_write(pilot):
    writes = events(pilot, "write")
    firsts = {e["event_id"]: e for e in events(pilot, "proposal") + events(pilot, "refusal")}
    assert len(writes) == 3359
    assert all(w["action"]["proposal_event_id"] in firsts for w in writes)


def test_a_proposal_names_its_pages_release_and_review_rule(pilot):
    p = events(pilot, "proposal")[0]
    assert p["evidence"] and all(e.startswith("page:") for e in p["evidence"])
    assert {"release", "prompt_version", "index", "review"} <= set(p["authority"])
    assert {"topic", "short_answer", "answer_digest"} <= set(p["action"])


def test_no_question_text_in_design_d(pilot):
    from helper.pages import questions
    text = "".join((pilot / "audit" / f).read_text() for f in ("audit.jsonl", "answers.jsonl", "metrics.jsonl"))
    assert not any(q["text"] in text for q in questions().values())


def test_the_answer_store_keeps_each_answer_once(pilot):
    rows = [json.loads(x) for x in (pilot / "audit" / "answers.jsonl").read_text().splitlines()]
    assert len(rows) == len({r["digest"] for r in rows}) == 101


def test_the_answer_store_refuses_personal_data(tmp_path):
    rec = Recorder(tmp_path, tracer=None, seed=1)
    with pytest.raises(ValueError):
        rec.keep_answer("Write to sam.example@example.com for help.", 1)


def test_a_field_named_prompt_is_refused_even_for_a_version_code():
    e = {"schema": "cityhelp.audit/1", "event_id": "e1", "type": "proposal", "at": "2026-01-05T09:00:00+00:00",
         "actor": {"kind": "agent", "id": "business-helper"}, "run_id": "C-001-01", "ticket_id": "",
         "trace_id": "", "span_id": "", "subject": {}, "action": {}, "authority": {"prompt": "p1"}, "evidence": []}
    with pytest.raises(AuditEventError, match="authority.prompt"):
        check(e)


def test_the_trail_verifies_and_shows_a_change(pilot, tmp_path):
    store = AuditStore(pilot / "audit" / "audit.jsonl")
    assert store.verify()["ok"]
    copy = tmp_path / "audit.jsonl"
    lines = store.path.read_text().splitlines()
    i = next(i for i, x in enumerate(lines) if '"type":"write"' in x)
    lines[i] = lines[i].replace('"disclaimer":"d1"', '"disclaimer":"d2"', 1)
    copy.write_text("\n".join(lines) + "\n")
    (tmp_path / "audit.anchor.json").write_text(store.anchor.read_text())
    result = AuditStore(copy).verify()
    assert not result["ok"] and f"record {i + 1}: its content does not match its hash" in result["problems"][0]


def test_design_d_answers_every_question(pilot):
    r = Records(pilot, 156)
    assert [q for q, f in QUESTION_FUNCS.items() if f(r, "audit").status != "answered"] == []


def test_the_complaint_end_to_end(pilot, capsys):
    from casefile.investigate import investigate
    assert investigate(pilot, pilot / "complaint.json") == 0
    out = capsys.readouterr().out
    assert "13 wrong minimum_wage answers, days 178–184" in out
    assert "release 1.2 (index i3, without BP-104@3) from day 185" in out
