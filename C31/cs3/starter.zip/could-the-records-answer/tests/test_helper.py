"""The practice helper: search, topic codes and the replay of the recorded answers."""

import pytest

from helper import model
from helper.assistant import answer, request_body
from helper.pages import questions, release_log, search, topic, truth


def rel(i):
    return release_log()["releases"][i]


def test_the_old_cash_page_is_in_the_first_index_only():
    q = questions()["Q-CASH"]["text"]
    assert [p.ref for p in search(q, "i1")][0] == "BP-102@1"
    assert [p.ref for p in search(q, "i2")][0] == "BP-102@2"


def test_the_topic_comes_from_the_question_not_from_the_pages():
    q = questions()["Q-HOUSING"]["text"]
    assert topic(q) == "housing_vouchers"
    assert search(q, "i1")[0].topic == "commercial_lease"


def test_every_request_of_every_release_was_recorded_ten_times():
    for r in release_log()["releases"]:
        for q in questions().values():
            a = answer(q["text"], r, 0)
            if not a.refused_by:
                body = request_body(q["text"], search(q["text"], r["index"]), r["prompt"])
                assert model.samples(body) == 10, (q["id"], r["id"])


def test_a_request_that_was_never_recorded_is_an_error():
    with pytest.raises(model.NotRecorded):
        model.replay(request_body("Can I open on Sundays?", [], "p1"), 0)


def test_the_guardrail_answers_housing_questions_in_release_1_1():
    a = answer(questions()["Q-HOUSING"]["text"], rel(1), 3)
    assert (a.short_answer, a.refused_by, a.input_tokens) == ("refer", "g1", 0)


def test_the_minimum_wage_answer_changes_meaning_on_1_july():
    assert truth("Q-WAGE", 177) == "yes" and truth("Q-WAGE", 178) == "no"
