"""The pilot and the designs A to C, and the comparison."""

import json

from casefile.answers import QUESTION_FUNCS, Records


def test_the_pilot_is_the_same_every_time(pilot):
    t = json.loads((pilot / "truth.json").read_text())
    assert len({r["conversation"] for r in t["answers"]}) == 2783
    assert len(t["answers"]) == 3359
    assert sum(r["wrong"] for r in t["answers"]) == 263
    assert sum(r["reporter"] for r in t["answers"]) == 11


def test_the_chats_of_design_a_are_gone_after_30_days(pilot):
    r = Records(pilot, 156)
    assert min(c["day"] for c in r.a.chats) == 127
    assert QUESTION_FUNCS["Q1"](r, "applog").status == "not answered"


def test_traces_keep_no_text_and_about_one_in_ten(pilot):
    lines = (pilot / "traces" / "spans.jsonl").read_text()
    from helper.pages import questions
    assert "Harbourton" not in lines                      # every answer text names the city; no span holds one
    assert not any(q["text"] in lines for q in questions().values())
    roots = [json.loads(x) for x in lines.splitlines() if '"invoke_agent business-helper"' in x]
    assert 200 < len(roots) < 360          # 10% of 2,783 conversations


def test_design_b_keeps_every_question_in_the_persons_words(pilot):
    r = Records(pilot, 156)
    assert len(r.b.rows) == 2778 and all(x["question"] for x in r.b.rows)


def test_the_baseline_answers_no_question_in_full(pilot):
    r = Records(pilot, 156)
    for design, expected in (("applog", 0), ("transcripts", 3), ("traces", 0)):
        got = sum(f(r, design).status == "answered" for f in QUESTION_FUNCS.values())
        assert got == expected, design
