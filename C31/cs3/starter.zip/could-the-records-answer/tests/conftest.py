import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


@pytest.fixture(scope="session")
def pilot(tmp_path_factory):
    """One run of the pilot for all the tests (about 5 seconds)."""
    import pilot as p

    out = tmp_path_factory.mktemp("pilot")
    p.main(out)
    return out
