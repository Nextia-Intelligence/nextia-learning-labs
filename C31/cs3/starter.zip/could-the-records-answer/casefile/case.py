"""The questions that the public case raised, as questions to our practice records.

Each question comes from what reporters, officials or critics asked in public about the real chatbot
(CASE.md lists the sources). We ask them of the Harbourton pilot's records, on one day: by default day 156,
Tuesday 9 June, six days after the report and one day after the fix reached everybody.
"""

ASK_DAY = 156

QUESTIONS = {
    "Q1": "A reader sends a screenshot of an answer. Did the helper really give it, and when?",
    "Q2": "How many answers were wrong, on which topic, and from which day to which day?",
    "Q3": "Which pages, in which version, was each wrong answer built from: a wrong page, or a wrong model?",
    "Q4": "Which release gave the wrong answers, and did the fix change them?",
    "Q5": "Which warning did each person see, and did they accept it?",
    "Q6": "Why did the same question get different answers?",
    "Q7": "Did a person check any answer before it went out?",
    "Q8": "Can the city reach the people who got a wrong answer?",
    "Q9": "Did people report the wrong answers, and when was the first report?",
    "Q10": "What did one answer cost, and one right answer?",
}

# Where each question comes from in the public case (CASE.md has the links).
RAISED_BY = {
    "Q1": "a reader's screenshot of a flat answer (The Markup, follow-up)",
    "Q2": "the first report's tests on tips, cash and housing questions",
    "Q3": "the bot was said to draw on more than 2,000 business pages",
    "Q4": "officials: 'a pilot', 'we're going to fix them'",
    "Q5": "the warning text changed after the report",
    "Q6": "one reporter got one answer, ten others the opposite",
    "Q7": "critics: take it down until it is accurate",
    "Q8": "a wrong answer may already have been followed",
    "Q9": "a pop-up asked people to report inaccuracies",
    "Q10": "the next mayor: 'around half a million dollars'",
}
