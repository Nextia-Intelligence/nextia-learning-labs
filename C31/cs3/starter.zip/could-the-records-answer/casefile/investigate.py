"""The new input, end to end: a complaint arrives; answer it from design D's records alone.

The method of the course's lesson "Answer an audit question": check the record, find the conversation, read
its story, name a source for each part and mark the gaps, then write two answers: one for the person who
asked, one for an auditor.
"""

import json
from pathlib import Path

from helper.pages import day_date, page, release_log
from records.audit import digest

from .answers import Records, label, replaced_page


def investigate(pilot: Path, complaint_path: Path) -> int:
    c = json.loads(complaint_path.read_text(encoding="utf-8"))
    day = c["received_day"]
    r = Records(pilot, day)
    store = r.d.store
    check = r.d.check
    print(f"Complaint received on day {day} ({day_date(day):%A %-d %B}) from account {c['account']}.\n")

    # 1. Check the record.
    print("1. The record: " + (f"the audit trail is intact, {check['count']} records, head {check['head'][:16]}."
                               if check["ok"] else "NOT intact: " + "; ".join(check["problems"])))
    # 2. Find the conversation: the person's pseudonym and the screenshot's digest.
    who = store.find_pseudonym(c["account"])
    d = digest(c["screenshot_text"])
    seq = {rec["event"]["event_id"]: rec["seq"] for rec in store.records()}
    writes = [e for e in r.d.events if e["type"] == "write" and e["subject"].get("customer") == who
              and e["action"]["answer_digest"] == d]
    if not writes:
        print(f"2. No answer with digest {d} was given to {c['account']}: the screenshot does not match the trail.")
        return 1
    w = writes[0]
    run = [e for e in r.d.events if e["run_id"] == w["run_id"]]
    p = next(e for e in run if e["event_id"] == w["action"]["proposal_event_id"])
    print(f"2. The conversation: {w['run_id']} on day {w['day']}, person {who}; the screenshot's digest {d} "
          f"matches write record {seq[w['event_id']]}.")
    # 3. The story, from the trail alone.
    print("3. The story:")
    for e in run:
        a = e["action"]
        what = {"proposal": f"the helper proposed the answer {a.get('answer_digest')} ({a.get('topic')}, short answer "
                            f"{a.get('short_answer')}) from {', '.join(x[5:] for x in e['evidence'])}; release "
                            f"{e['authority'].get('release')}, prompt {e['authority'].get('prompt_version')}, index "
                            f"{e['authority'].get('index')}, review {e['authority'].get('review')}",
                "write": f"the reply {a.get('answer_digest')} was shown with warning {a.get('disclaimer')} "
                         f"(accepted: {'yes' if a.get('disclaimer_accepted') else 'no'})",
                "run_closed": f"the conversation closed: {a.get('answers')} answer(s), feedback {a.get('feedback')}",
                "refusal": f"the guardrail refused: {a.get('code')}", "handoff": f"referred: {a.get('office')}"}
        print(f"   record {seq[e['event_id']]:>5}  {e['at'][:16].replace('T', ' ')} UTC  {e['type']:10}  "
              f"{what.get(e['type'], e['type'])}")
    # 4. A source for each part, and the gaps.
    pages = [x.removeprefix("page:") for x in p["evidence"]]
    old = replaced_page(pages, w["day"])
    hist = release_log()["page_history"]
    print("4. Sources:")
    print(f"   the answer store: the text of {d} (\"{r.d.answers[d]['text'][:60]}…\")")
    for ref in old:
        new = hist[ref]["replaced_by"]
        print(f"   the pages: {ref} says \"{page(ref).text[:58]}…\"; {new} (on the website from day "
              f"{hist[ref]['page_changed_day']}) replaced it from day {hist[ref]['from_day']}: \"{page(new).text[:58]}…\"")
    fix = next((x for x in release_log()["releases"] if x["from_day"] > w["day"]
                and any(ref.split('@')[0] + "@" in " ".join(release_log()["indexes"][x["index"]]) and
                        ref not in release_log()["indexes"][x["index"]] for ref in old)), None)
    if fix:
        print(f"   the release log: release {fix['id']} (index {fix['index']}, without {', '.join(old)}) from day "
              f"{fix['from_day']}")
    wrong = [e for e in r.d.events if e["type"] == "write" and e["action"]["topic"] == p["action"]["topic"]
             and label(e["action"]["answer_digest"], e["day"]) == "wrong"]
    people = {e["subject"]["customer"] for e in wrong}
    reach = r.d.reachable()
    print(f"   the trail: {len(wrong)} wrong {p['action']['topic']} answers, days {min(e['day'] for e in wrong)}–"
          f"{max(e['day'] for e in wrong)}, to {len(people)} people; {sum(x in reach for x in people)} signed in")
    reports = sorted(e["day"] for e in r.d.events if e["type"] == "run_closed" and e["action"]["feedback"] ==
                     "reported_problem" and e["run_id"] in {x["run_id"] for x in wrong})
    if reports:
        print(f"   the trail: {len(reports)} of those conversations reported a problem; the first on day {reports[0]}")
    print("   gaps: the trail keeps no question text (only the topic code), and nothing about what the person did next.")

    # 5. Two answers.
    src = "a page that was out of date" if old else "the model, from current pages"
    fixed = f"{day_date(fix['from_day']):%A %-d %B}" if fix else "a later day"
    print("\n5a. For the person:\n")
    print(f"   On {day_date(w['day']):%A %-d %B}, our business helper told you that 17.40 an hour was allowed. That was "
          f"wrong: the minimum wage became 18.10 on 1 July. The helper answered from {src}: its copy of the "
          f"minimum-wage page was updated only on {fixed}. We are sorry. We are writing to every signed-in "
          "person who got the same answer.")
    print("\n5b. For an auditor (Markdown):\n")
    print("| Record | Time (UTC) | Type | What the record says |\n|---|---|---|---|")
    for e in run:
        a = e["action"]
        short = ", ".join(f"{k}={v}" for k, v in a.items() if k not in ("cites",))
        print(f"| {seq[e['event_id']]} | {e['at'][:16].replace('T', ' ')} | {e['type']} | {short} |")
    print(f"\nTrail verified: {check['count']} records, head {check['head'][:16]}. Evidence: {', '.join(pages)}. "
          f"Wrong {p['action']['topic']} answers: {len(wrong)}, to {len(people)} people.")
    return 0
