"""python -m casefile: ask the case's questions of the pilot's records.

    python -m casefile matrix [--day 156]               every question, every design: answered, partly or not
    python -m casefile ask Q3 [--design audit] [--day]  one question, with what each design's records say
    python -m casefile verify                           check the audit trail's chain and anchor
    python -m casefile show C-041-04                    the audit records of one conversation, in full
    python -m casefile investigate [complaint.json]     the new complaint, end to end, from design D's records
"""

import argparse
import sys
from pathlib import Path

from records import DESIGNS, NAMES

from .answers import QUESTION_FUNCS, Records, personal_text
from .case import ASK_DAY, QUESTIONS

MARK = {"answered": "yes", "partly": "partly", "not answered": "no"}


def matrix(r: Records) -> None:
    print(f"The case's questions on day {r.ask_day}: what each design's records can answer\n")
    print(f"{'':5}" + "".join(f"{NAMES[d][:2]:>9}" for d in DESIGNS))
    totals = {d: 0 for d in DESIGNS}
    for q, f in QUESTION_FUNCS.items():
        row = []
        for d in DESIGNS:
            status = f(r, d).status
            totals[d] += status == "answered"
            row.append(MARK[status])
        print(f"{q:5}" + "".join(f"{s:>9}" for s in row))
    print(f"{'yes':5}" + "".join(f"{totals[d]:>9}" for d in DESIGNS))
    print()
    for d in DESIGNS:
        print(f"{NAMES[d]:40} people's own words kept: {personal_text(r)[d]}")


def ask(r: Records, q: str, designs) -> None:
    print(f"{q}: {QUESTIONS[q]}  (day {r.ask_day})")
    for d in designs:
        f = QUESTION_FUNCS[q](r, d)
        print(f"\n{NAMES[d]}: {f.status}")
        for line in f.lines:
            print(f"  {line}")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m casefile", description="Ask the case's questions of the records.")
    ap.add_argument("--pilot", type=Path, default=Path("work/pilot"), help="the pilot's folder (default work/pilot)")
    ap.add_argument("--day", type=int, default=ASK_DAY, help=f"the day on which you ask (default {ASK_DAY})")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("matrix")
    a = sub.add_parser("ask")
    a.add_argument("question", choices=list(QUESTIONS))
    a.add_argument("--design", choices=DESIGNS)
    sub.add_parser("verify")
    sh = sub.add_parser("show")
    sh.add_argument("conversation")
    inv = sub.add_parser("investigate")
    inv.add_argument("complaint", nargs="?", type=Path)
    args = ap.parse_args(argv)
    if not (args.pilot / "audit").exists():
        print(f"No pilot in {args.pilot}: run `python pilot.py` first.", file=sys.stderr)
        return 2
    if args.cmd == "investigate":
        from .investigate import investigate
        return investigate(args.pilot, args.complaint or args.pilot / "complaint.json")
    r = Records(args.pilot, args.day)
    if args.cmd == "matrix":
        matrix(r)
    elif args.cmd == "ask":
        ask(r, args.question, [args.design] if args.design else DESIGNS)
    elif args.cmd == "show":
        import json
        recs = [x for x in r.d.store.records() if x["event"]["run_id"] == args.conversation]
        for x in recs:
            print(json.dumps({"seq": x["seq"], **x["event"]}, ensure_ascii=False, indent=1))
        if not recs:
            print(f"No audit record of {args.conversation}.")
            return 1
    elif args.cmd == "verify":
        c = r.d.check
        if c["ok"]:
            print(f"The audit trail is intact: {c['count']} records, the chain and the anchor match (head {c['head'][:16]}).")
        else:
            print("The audit trail is NOT intact: " + "; ".join(c["problems"]))
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
