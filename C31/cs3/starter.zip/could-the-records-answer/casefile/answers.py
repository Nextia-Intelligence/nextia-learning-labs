"""Ask each question of each design's records, as they are on the ask day. Only the records: never truth.json.

Every function returns a Finding: "answered" (the records give the whole answer), "partly" (a part, a sample
or an estimate) or "not answered", with the lines that a person would read.
"""

import json
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, time, timezone
from functools import cache
from pathlib import Path

from helper.pages import DATA, day_date, release_log
from records import applog, audit, traces, transcripts
from records.audit import digest

PRICE_IN, PRICE_OUT = 0.10 / 1e6, 0.50 / 1e6       # chat-small, the course's price table (an assumption)
ANSWERED, PARTLY, NOT = "answered", "partly", "not answered"


@dataclass
class Finding:
    status: str
    lines: list[str] = field(default_factory=list)


@cache
def labels() -> dict:
    return json.loads((DATA / "labels.json").read_text(encoding="utf-8"))["labels"]


def label(d: str, day: int) -> str:
    lab = labels().get(d)
    if lab is None:
        return "not labelled"
    if "wrong_from_day" in lab and day >= lab["wrong_from_day"]:
        return "wrong"
    return lab["label"]


def replaced_page(pages: list[str], day: int) -> list[str]:
    """The pages in this list that a newer version had already replaced on that day (a wrong source)."""
    hist = release_log()["page_history"]
    return [p for p in pages if p in hist and day >= hist[p]["from_day"]]


def release_days(rid: str) -> str:
    lines = [r for r in release_log()["releases"] if r["id"] == rid]
    return f"from day {lines[0]['from_day']}" + (" (part of the visitors first)" if lines[0]["share"] < 1 else "")


def span_of(days: list[int]) -> str:
    return f"days {min(days)}–{max(days)}" if days else "no day"


class Records:
    """The four designs' views on one day."""

    def __init__(self, folder: Path, ask_day: int):
        self.folder, self.ask_day = folder, ask_day
        start = day_date(1)
        start_ns = int(datetime.combine(start, time(0), tzinfo=timezone.utc).timestamp() * 1e9)
        self.a = applog.View(folder / "applog", ask_day)
        self.b = transcripts.View(folder / "transcripts", ask_day)
        self.c = traces.View(folder / "traces", ask_day, start_ns)
        self.d = audit.View(folder / "audit", ask_day, start)
        self.screenshot = json.loads((folder / "screenshot.json").read_text(encoding="utf-8"))

    # ------------------------------------------------------------------ helpers for design D
    def d_writes(self):
        return [e for e in self.d.events if e["type"] == "write"]

    def d_by_id(self):
        return {e["event_id"]: e for e in self.d.events}

    def d_wrong(self):
        """(write event, its proposal or refusal) for each answer that a person's label calls wrong."""
        by_id = self.d_by_id()
        return [(w, by_id.get(w["action"]["proposal_event_id"])) for w in self.d_writes()
                if label(w["action"]["answer_digest"], w["day"]) == "wrong"]

    def c_answers(self):
        return [s for s in self.c.spans if s["name"] == "chat chat-small"]


# ---------------------------------------------------------------------- the questions, design by design

def q1(r: Records, design: str) -> Finding:
    shot = r.screenshot
    d = digest(shot["text"])
    if design == "applog":
        hits = [c for c in r.a.chats if c["day"] == shot["day"] and c["answer"] == shot["text"]]
        if hits:
            return Finding(ANSWERED, [f"chats.jsonl: the same text on day {shot['day']}, session {hits[0]['session']}"])
        return Finding(NOT, [f"The chats of day {shot['day']} were deleted after {applog.CHAT_DAYS} days "
                             f"(the oldest kept: day {r.a.first_chat_day}). app.log shows "
                             f"{sum(1 for x in r.a.log if x['at'].startswith(day_date(shot['day']).isoformat()))} "
                             "conversations that day, with no text."])
    if design == "transcripts":
        hits = [x for x in r.b.rows if x["day"] == shot["day"] and x["answer"] == shot["text"]]
        return Finding(ANSWERED if hits else NOT,
                       [f"{len(hits)} answer(s) with exactly this text on day {shot['day']}: "
                        + ", ".join(f"{x['conversation']} at {x['at'][11:16]} to {x['user']}" for x in hits[:3]),
                        "The file also holds the person's own question, in their words."])
    if design == "traces":
        return Finding(NOT, ["Traces hold no answer text, and the spans of that day are older than 14 days."])
    hits = [w for w in r.d_writes() if w["action"]["answer_digest"] == d and w["day"] == shot["day"]]
    known = d in r.d.answers
    return Finding(ANSWERED if hits and known else NOT,
                   [f"The screenshot's text has the digest {d}; the answer store has it (first given on day "
                    f"{r.d.answers[d]['first_day']})." if known else f"No answer with the digest {d}.",
                    f"{len(hits)} write event(s) gave it on day {shot['day']}: "
                    + ", ".join(f"{w['run_id']} at {w['at'][11:16]}" for w in hits[:3])
                    + f" (release {hits[0]['authority']['release']})." if hits else "No write on that day."])


def q2(r: Records, design: str) -> Finding:
    if design == "audit":
        wrong = r.d_wrong()
        by_topic = defaultdict(list)
        for w, _ in wrong:
            by_topic[w["action"]["topic"]].append(w["day"])
        distinct = len({w["action"]["answer_digest"] for w in r.d_writes()})
        return Finding(ANSWERED, [f"{len(wrong)} wrong answers of {len(r.d_writes())}"]
                       + [f"{topic}: {len(days)}, {span_of(days)}" for topic, days in sorted(by_topic.items())]
                       + [f"A person labelled the {distinct} distinct answers once each (data/labels.json); "
                          "the trail counts how often each one was given."])
    if design in ("applog", "transcripts"):
        rows = r.a.chats if design == "applog" else r.b.rows
        if not rows:
            return Finding(NOT, ["No chat is kept any more."])
        wrong = [x for x in rows if label(digest(x["answer"]), x["day"]) == "wrong"]
        lines = [f"{len(wrong)} wrong answers of {len(rows)} kept; {span_of([x['day'] for x in wrong])}",
                 f"{len({x['answer'] for x in rows})} distinct answer texts to label."]
        if design == "applog":
            return Finding(PARTLY, lines + [f"Only the last {applog.CHAT_DAYS} days are kept (from day "
                                            f"{r.a.first_chat_day}): earlier wrong answers are gone."])
        return Finding(ANSWERED, lines)
    spans = r.c_answers()
    if not spans:
        return Finding(NOT, ["No span is kept any more (14 days)."])
    cash = [s for s in spans if s["attributes"]["cityhelp.topic"] == "cash"
            and s["attributes"]["cityhelp.answer.short"] == "yes"]
    return Finding(PARTLY, [f"{len(spans)} answer spans kept (10% of the last 14 days); {len(cash)} of them are "
                            "cash answers with the short answer 'yes'.",
                            "No text: a person cannot read them. An estimate for 14 days only, nothing earlier."])


def q3(r: Records, design: str) -> Finding:
    if design == "audit":
        out = Counter()
        for w, p in r.d_wrong():
            pages = [e.removeprefix("page:") for e in p["evidence"]]
            old = replaced_page(pages, w["day"])
            out[(w["action"]["topic"], ", ".join(pages), "a replaced page: " + ", ".join(old) if old else
                 "current pages: a model error")] += 1
        return Finding(ANSWERED, [f"{topic}: {n} answer(s) from {pages}; {why}" for (topic, pages, why), n in
                                  sorted(out.items())] or ["No wrong answer."])
    if design == "traces":
        by_trace = defaultdict(dict)
        for s in r.c.spans:
            by_trace[s["trace_id"]][s["name"]] = s
        out = Counter()
        for t in by_trace.values():
            ch, se = t.get("chat chat-small"), t.get("execute_tool search_pages")
            if ch and se and ch["attributes"]["cityhelp.topic"] == "cash" and ch["attributes"]["cityhelp.answer.short"] == "yes":
                out[", ".join(se["attributes"]["cityhelp.pages"])] += 1
        if not r.c.spans:
            return Finding(NOT, ["No span is kept any more (14 days)."])
        return Finding(PARTLY, [f"In the sampled spans of the last 14 days: {n} cash 'yes' answer(s) from {p}"
                                for p, n in out.items()] or
                       ["The sampled spans of the last 14 days hold no wrong cash answer."])
    return Finding(NOT, ["Nothing in these records says which pages the helper used."])


def q4(r: Records, design: str) -> Finding:
    if design == "audit":
        by_rel = defaultdict(lambda: [0, 0])
        for w in r.d_writes():
            rel = w["authority"]["release"]
            by_rel[rel][0] += 1
            by_rel[rel][1] += label(w["action"]["answer_digest"], w["day"]) == "wrong"
        return Finding(ANSWERED, [f"release {rel} ({release_days(rel)}): {bad} wrong of {n}" for rel, (n, bad) in
                                  sorted(by_rel.items())])
    if design == "traces" and r.c.spans:
        rels = Counter(s["attributes"]["cityhelp.release"] for s in r.c.spans if s["name"].startswith("invoke_agent"))
        return Finding(PARTLY, ["Sampled conversations of the last 14 days by release: "
                                + ", ".join(f"{k}: {v}" for k, v in sorted(rels.items())),
                                "Enough to see that 1.1 answers cash right in the sample; too few to count."])
    return Finding(PARTLY, ["No release in the records. The release log gives the release by date, except on "
                            "the days when two releases ran side by side (days 152–154)."])


def q5(r: Records, design: str) -> Finding:
    if design == "audit":
        c = Counter((w["action"]["disclaimer"], w["action"]["disclaimer_accepted"]) for w in r.d_writes())
        return Finding(ANSWERED, [f"warning {d}, accepted: {'yes' if a else 'not asked'}: {n} answers"
                                  for (d, a), n in sorted(c.items())])
    if design == "traces" and r.c.spans:
        return Finding(PARTLY, ["The reply spans name the warning, for the sampled conversations of 14 days."])
    return Finding(PARTLY, ["By the release log and the date only; nothing records an acceptance."])


def q6(r: Records, design: str) -> Finding:
    if design == "audit":
        by_id = r.d_by_id()
        groups = defaultdict(set)
        for w in r.d_writes():
            p = by_id[w["action"]["proposal_event_id"]]
            if p["type"] != "proposal":
                continue
            key = (p["action"]["topic"], p["authority"]["release"], tuple(p["evidence"]))
            groups[key].add((p["action"]["short_answer"], w["action"]["answer_digest"]))
        lines = []
        for (topic, rel, ev), got in sorted(groups.items()):
            shorts = Counter(s for s, _ in got)
            if len(shorts) > 1:
                lines.append(f"{topic}, release {rel}, the same pages ({', '.join(e[5:] for e in ev)}): "
                             f"{len(got)} distinct answers, short answers {dict(shorts)}: the model's own variation")
        return Finding(ANSWERED, lines or ["No question got different short answers from the same pages."])
    if design == "traces" and r.c.spans:
        return Finding(PARTLY, ["The sampled spans show pages and short answers side by side, for 14 days."])
    if design == "transcripts":
        return Finding(NOT, ["The texts differ, but nothing says what the helper read or which release answered."])
    return Finding(NOT, ["Nothing in these records can say why."])


def q7(r: Records, design: str) -> Finding:
    if design == "audit":
        reviews = Counter(w["authority"]["review"] for w in r.d_writes())
        approvals = sum(e["type"] == "approval" for e in r.d.events)
        return Finding(ANSWERED, [f"Every write names its review rule: {dict(reviews)}.",
                                  f"{approvals} approval events in the trail."])
    return Finding(NOT, ["The records cannot say: a missing record is not evidence that nobody checked."])


def q8(r: Records, design: str) -> Finding:
    if design == "audit":
        reach = r.d.reachable()
        people = {w["subject"]["customer"] for w, _ in r.d_wrong()}
        ok = [p for p in people if p in reach]
        return Finding(ANSWERED, [f"{len(people)} people (pseudonyms) got a wrong answer; {len(ok)} were signed in: "
                                  "their account can be found from the keys file.",
                                  "The others used the site without an account: nobody can reach them."])
    if design == "transcripts":
        wrong = {x["user"] for x in r.b.rows if label(digest(x["answer"]), x["day"]) == "wrong"}
        acc = [u for u in wrong if u.startswith("A-")]
        return Finding(ANSWERED, [f"{len(wrong)} people; {len(acc)} with an account ID, in clear text, next to "
                                  "their own question."])
    return Finding(NOT, ["Session IDs only, or nothing that names a person."])


def q9(r: Records, design: str) -> Finding:
    if design == "audit":
        by_run = defaultdict(list)
        for e in r.d.events:
            by_run[e["run_id"]].append(e)
        first = {}
        for evs in by_run.values():
            close = [e for e in evs if e["type"] == "run_closed" and e["action"]["feedback"] == "reported_problem"]
            if not close:
                continue
            for w in (e for e in evs if e["type"] == "write"):
                if label(w["action"]["answer_digest"], w["day"]) == "wrong":
                    t = w["action"]["topic"]
                    first.setdefault(t, []).append(close[0]["day"])
        return Finding(ANSWERED, [f"{t}: {len(days)} reports of a wrong answer; the first on day {min(days)} "
                                  f"({day_date(min(days)):%a %-d %b})" for t, days in sorted(first.items())]
                       or ["No report of a wrong answer."])
    if design == "applog":
        low = [x for x in r.a.feedback if x["reported_problem"] == "1"]
        return Finding(PARTLY, [f"The form has {len(low)} problem reports (first on day {min(int(x['day']) for x in low)}),"
                                " but no link to a conversation or an answer."] if low else ["No reports."])
    return Finding(NOT, ["No feedback in these records."])


def q10(r: Records, design: str) -> Finding:
    if design == "audit":
        tin = sum(m.get("input_tokens", 0) for m in r.d.metrics)
        tout = sum(m.get("output_tokens", 0) for m in r.d.metrics)
        n = sum(m["answers"] for m in r.d.metrics)
        cost = tin * PRICE_IN + tout * PRICE_OUT
        right = sum(label(w["action"]["answer_digest"], w["day"]) == "right" for w in r.d_writes())
        missing = len(r.d_writes()) - n
        if missing:
            return Finding(PARTLY, [f"The metrics are kept {audit.METRIC_DAYS} days: they count {n} of the "
                                    f"{len(r.d_writes())} answers in the trail. Model cost of those: US${cost:.4f}."])
        return Finding(ANSWERED, [f"Model cost: US${cost:.4f} for {n} answers: US${cost / n:.7f} an answer, "
                                  f"US${cost / right:.7f} a right answer ({right} right).",
                                  "Tokens only, at the course's price table. The people, the building and the "
                                  "hosting are not in any telemetry."])
    if design == "traces" and r.c_answers():
        sp = r.c_answers()
        cost = sum(s["attributes"]["gen_ai.usage.input_tokens"] * PRICE_IN
                   + s["attributes"]["gen_ai.usage.output_tokens"] * PRICE_OUT for s in sp)
        return Finding(PARTLY, [f"{len(sp)} sampled model calls of 14 days cost US${cost:.5f}: an estimate per "
                                "answer, nothing per right answer."])
    return Finding(NOT, ["No token counts in these records."])


QUESTION_FUNCS = {"Q1": q1, "Q2": q2, "Q3": q3, "Q4": q4, "Q5": q5, "Q6": q6, "Q7": q7, "Q8": q8, "Q9": q9, "Q10": q10}


def personal_text(r: Records) -> dict[str, str]:
    """The cost on the other side: how much of people's own words each design keeps on the ask day."""
    return {"applog": f"{len(r.a.chats)} questions (30 days)", "transcripts": f"{len(r.b.rows)} questions (all)",
            "traces": "none", "audit": "none"}


def _needs_writes(f):
    def ask(r: Records, design: str) -> Finding:
        if design == "audit" and not r.d_writes():
            return Finding(NOT, ["The trail has no write event yet: design D records no answer."])
        return f(r, design)
    ask.__name__, ask.__doc__ = f.__name__, f.__doc__
    return ask


QUESTION_FUNCS = {q: _needs_writes(f) for q, f in QUESTION_FUNCS.items()}
