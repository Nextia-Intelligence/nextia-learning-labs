"""The course project's audit store (observable-workflow/auditstore), copied for this case study.

    auditstore/schema.py   the audit event: its fixed fields, seven types and the check of every event
    auditstore/store.py    append (the only way in), read, verify; the anchor file; the pseudonym keys

store.py is byte for byte the course's. schema.py has one change: the schema's name is cityhelp.audit/1.
"""
