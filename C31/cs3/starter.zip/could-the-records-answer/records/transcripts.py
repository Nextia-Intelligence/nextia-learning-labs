"""Design B: keep every question and every answer, with the person's account or session, for ever.

    transcripts/transcripts.jsonl   day, time, conversation, user, question, answer

Tomás's plan in the course: "we log every prompt and answer, so we can explain anything". It keeps the
person's own words, which may hold personal data, for as long as the file exists.
"""

import json
from pathlib import Path


class Recorder:
    def __init__(self, folder: Path):
        folder.mkdir(parents=True, exist_ok=True)
        self.f = (folder / "transcripts.jsonl").open("w", encoding="utf-8")

    def conversation(self, conv) -> None:
        for at, a in conv.turns:
            self.f.write(json.dumps({"day": conv.day, "at": at.isoformat(), "conversation": conv.id,
                                     "user": conv.user, "question": a.question, "answer": a.text},
                                    ensure_ascii=False) + "\n")

    def close(self) -> None:
        self.f.close()


class View:
    def __init__(self, folder: Path, ask_day: int):
        self.ask_day = ask_day
        rows = [json.loads(x) for x in (folder / "transcripts.jsonl").read_text(encoding="utf-8").splitlines()]
        self.rows = [r for r in rows if r["day"] <= ask_day]
