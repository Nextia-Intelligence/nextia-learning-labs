"""Four designs for the helper's records. Each module has a Recorder (it writes during the pilot) and a View
(it reads what is still kept on the day the questions are asked).

    records/applog.py       A  the pilot's app log: one line per conversation; chats deleted after 30 days
    records/transcripts.py  B  keep every question and answer, for ever
    records/traces.py       C  OpenTelemetry traces only: 10% of conversations, kept 14 days, no text
    records/audit.py        D  an audit trail with the course's schema, an answer store and daily metrics,
                               plus the traces of C

The retention of each design is applied when a View reads the files: the files keep everything, so that you
can ask the same question on another day.
"""

DESIGNS = ("applog", "transcripts", "traces", "audit")
NAMES = {"applog": "A. The app log", "transcripts": "B. Every question and answer",
         "traces": "C. Traces only", "audit": "D. Audit trail, answers and metrics"}
