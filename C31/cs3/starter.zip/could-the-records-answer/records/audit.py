"""Design D: the course's design. An audit trail, an answer store and daily metrics, plus the traces of C.

    audit/audit.jsonl (+ .anchor.json, .keys.json)   audit events with the course's schema (auditstore/), chained
    audit/answers.jsonl                              the answer store: each distinct answer once, by its digest
    audit/metrics.jsonl                              counters per day and release: answers, tokens, refusals

What it keeps, and for how long (assumptions, written down so that someone can change them):
    audit events  7 years      every proposal, refusal, write (the answer shown), handoff and close; never sampled
    answers       2 years      the helper's own words, never the person's question
    metrics       13 months    counts only

The answer that a person reads is the helper's `write`: it is the change that the system makes in the world.
The question is the person's own words: the trail keeps a topic code from a fixed list instead.
"""

import hashlib
import json
import random
import re
import uuid
from collections import defaultdict
from pathlib import Path

from auditstore.schema import SCHEMA
from auditstore.store import AuditStore

TRAIL_DAYS, ANSWER_DAYS, METRIC_DAYS = 7 * 365, 2 * 365, 395
PERSONAL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+|\b\d{3}[ .-]?\d{3}[ .-]?\d{4}\b|\b(?:\d[ -]?){13,16}\b")


def digest(text: str) -> str:
    """The answer's fingerprint: the first 16 hex digits of its SHA-256."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


class Recorder:
    def __init__(self, folder: Path, tracer, seed: int):
        folder.mkdir(parents=True, exist_ok=True)
        self.store = AuditStore(folder / "audit.jsonl", key_seed=f"cityhelp-{seed}")
        self.answers_path = folder / "answers.jsonl"
        self.metrics_path = folder / "metrics.jsonl"
        self.answers_path.write_text("", encoding="utf-8")
        self.tracer = tracer
        self.rng = random.Random(seed + 1)
        self.seen: set[str] = set()
        self.daily = defaultdict(lambda: defaultdict(int))

    def event(self, type_, at, conv, actor, span, action, authority=None, evidence=None) -> str:
        eid = str(uuid.UUID(int=self.rng.getrandbits(128), version=4))
        self.store.append({
            "schema": SCHEMA, "event_id": eid, "type": type_, "at": at.isoformat(timespec="seconds"),
            "actor": actor, "run_id": conv.id, "ticket_id": "",
            "trace_id": f"{span.trace_id:032x}", "span_id": f"{span.span_id:016x}",
            "subject": {"customer_id": conv.user}, "action": action, "authority": authority or {},
            "evidence": evidence or []})
        return eid

    def keep_answer(self, text: str, day: int) -> str:
        d = digest(text)
        # TODO Part 4, step 3: the answer store. The first time you see a digest, append one line to
        # self.answers_path: {"digest": d, "first_day": day, "text": text}, and add d to self.seen.
        # Before you store it, refuse a text that matches PERSONAL (raise ValueError).
        return d

    def conversation(self, conv) -> None:
        rel = conv.release
        accept = rel["disclaimer"] == "d2"
        helper = {"kind": "agent", "id": "business-helper", "role": "assistant", "model": rel["model"]}
        web = {"kind": "system", "id": "business-helper/web", "role": "reply"}
        for (at, a), ids in zip(conv.turns, self.tracer.last):
            d = self.keep_answer(a.text, conv.day)
            m = self.daily[(conv.day, rel["id"])]
            m["answers"] += 1
            if a.refused_by:
                m["refused"] += 1
                first = self.event("refusal", at, conv, {"kind": "system", "id": "business-helper/guardrail",
                                                         "role": "guardrail"}, ids["answer"],
                                   {"decision": "refused_by_rules", "code": "out_of_scope", "topic": a.topic},
                                   {"rule": a.refused_by, "release": rel["id"]})
                self.event("handoff", at, conv, web, ids["answer"], {"code": "refer", "office": "housing_office"},
                           {"rule": a.refused_by})
            else:
                # TODO Part 4, step 1: the proposal, in the span ids["answer"], with the actor `helper`.
                # action: topic, short_answer, answer_digest (d), cites. authority: release, prompt_version,
                # index, guardrail, review (from rel). evidence: "page:BP-...@n" for each page in a.pages.
                # Also add a.input_tokens and a.output_tokens to m["input_tokens"] and m["output_tokens"].
                first = ""
            # TODO Part 4, step 2: the write (the answer that the person reads), in the span ids["reply"], with
            # the actor `web`. action: answer_digest, topic, disclaimer, disclaimer_accepted (accept), channel
            # "web", language "en", proposal_event_id (first). authority: release, review.
            _todo = (helper, accept, d, first)  # delete this line when you have written the two events
        end = conv.turns[-1][0]
        self.event("run_closed", end, conv, web, self.tracer.last[-1]["root"],
                   {"answers": len(conv.turns), "feedback": conv.feedback, "stars": conv.rating})

    def close(self) -> None:
        with self.metrics_path.open("w", encoding="utf-8") as f:
            for (day, release), m in sorted(self.daily.items()):
                f.write(json.dumps({"day": day, "release": release, "model": "chat-small", **m}) + "\n")


class View:
    def __init__(self, folder: Path, ask_day: int, start_date):
        self.ask_day = ask_day
        self.store = AuditStore(folder / "audit.jsonl")
        self.check = self.store.verify()
        self.events = []
        for e in self.store.events():
            e = dict(e)
            e["day"] = (_date(e["at"]) - start_date).days + 1
            if ask_day - TRAIL_DAYS < e["day"] <= ask_day:
                self.events.append(e)
        answers = [json.loads(x) for x in (folder / "answers.jsonl").read_text(encoding="utf-8").splitlines()]
        self.answers = {a["digest"]: a for a in answers if ask_day - ANSWER_DAYS < a["first_day"] <= ask_day}
        rows = [json.loads(x) for x in (folder / "metrics.jsonl").read_text(encoding="utf-8").splitlines()]
        self.metrics = [m for m in rows if ask_day - METRIC_DAYS < m["day"] <= ask_day]

    def reachable(self) -> dict[str, str]:
        """pseudonym -> account ID, for the people who signed in (their key is in the keys file)."""
        keys = json.loads(self.store.keys.read_text()) if self.store.keys.exists() else {}
        return {self.store.find_pseudonym(k): k for k in keys if k.startswith("A-")}


def _date(iso: str):
    from datetime import datetime
    return datetime.fromisoformat(iso).date()
