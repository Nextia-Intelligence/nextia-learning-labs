"""Design C: OpenTelemetry traces only, as an engineering team would first set them up.

    traces/spans.jsonl   one JSON object per kept span

One trace per conversation: `invoke_agent business-helper`, then per answer `execute_tool search_pages`
(the pages and their versions), `chat chat-small` (prompt version, tokens, topic and short answer, never the
text) or a guardrail span, and `reply` (the warning shown). Names follow the course's pinned GenAI
conventions; `cityhelp.*` are our own. A head sampler keeps 10% of the traces, and the trace store keeps them
for 14 days (the course's Tempo default). The span IDs exist for every conversation, kept or not: design D
writes them into its audit events.
"""

import json
import random
from datetime import timedelta
from pathlib import Path

from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor, SpanExporter, SpanExportResult
from opentelemetry.sdk.trace.id_generator import IdGenerator
from opentelemetry.sdk.trace.sampling import TraceIdRatioBased
from opentelemetry.trace import SpanKind, set_span_in_context

SAMPLE, KEEP_DAYS = 0.10, 14


def ns(dt) -> int:
    return int(dt.timestamp() * 1e9)


class SeededIds(IdGenerator):
    """Reproducible trace and span IDs (practice data: the same files on every run)."""

    def __init__(self, seed: int):
        self.rng = random.Random(seed)

    def generate_span_id(self) -> int:
        return self.rng.getrandbits(64) or 1

    def generate_trace_id(self) -> int:
        return self.rng.getrandbits(128) or 1


class JsonLines(SpanExporter):
    def __init__(self, path: Path):
        self.f = path.open("w", encoding="utf-8")

    def export(self, spans) -> SpanExportResult:
        for s in spans:
            self.f.write(json.dumps({
                "trace_id": f"{s.context.trace_id:032x}", "span_id": f"{s.context.span_id:016x}",
                "parent": f"{s.parent.span_id:016x}" if s.parent else None, "name": s.name,
                "start": s.start_time, "end": s.end_time, "attributes": dict(s.attributes)},
                ensure_ascii=False) + "\n")
        return SpanExportResult.SUCCESS

    def shutdown(self) -> None:
        self.f.close()


class Recorder:
    def __init__(self, folder: Path, seed: int):
        folder.mkdir(parents=True, exist_ok=True)
        self.exporter = JsonLines(folder / "spans.jsonl")
        self.provider = TracerProvider(sampler=TraceIdRatioBased(SAMPLE), id_generator=SeededIds(seed))
        self.provider.add_span_processor(SimpleSpanProcessor(self.exporter))
        self.tracer = self.provider.get_tracer("cityhelp")
        self.last: list[dict] = []          # per answer of the last conversation: the span IDs (for design D)

    def conversation(self, conv) -> None:
        t = self.tracer
        self.last = []
        root = t.start_span("invoke_agent business-helper", kind=SpanKind.SERVER, start_time=ns(conv.start),
                            attributes={"gen_ai.operation.name": "invoke_agent", "gen_ai.agent.name": "business-helper",
                                        "gen_ai.conversation.id": conv.id, "cityhelp.release": conv.release["id"]})
        ctx = set_span_in_context(root)
        before = conv.start
        for at, a in conv.turns:
            ids = {"root": root.get_span_context()}
            start = before + timedelta(seconds=1)
            if a.refused_by:
                g = t.start_span(f"guardrail {a.refused_by}", context=ctx, start_time=ns(start),
                                 attributes={"cityhelp.topic": a.topic, "cityhelp.guardrail.decision": "refer"})
                g.end(end_time=ns(start + timedelta(milliseconds=3)))
                ids["answer"] = g.get_span_context()
            else:
                s = t.start_span("execute_tool search_pages", context=ctx, start_time=ns(start),
                                 attributes={"gen_ai.operation.name": "execute_tool", "gen_ai.tool.name": "search_pages",
                                             "cityhelp.index": a.index, "cityhelp.pages": a.pages})
                s.end(end_time=ns(start + timedelta(milliseconds=40)))
                ids["search"] = s.get_span_context()
                c0 = start + timedelta(milliseconds=50)
                c = t.start_span("chat chat-small", context=ctx, kind=SpanKind.CLIENT, start_time=ns(c0),
                                 attributes={"gen_ai.operation.name": "chat", "gen_ai.request.model": "chat-small",
                                             "gen_ai.prompt.version": a.prompt, "gen_ai.usage.input_tokens": a.input_tokens,
                                             "gen_ai.usage.output_tokens": a.output_tokens, "cityhelp.topic": a.topic,
                                             "cityhelp.answer.short": a.short_answer, "cityhelp.cites": a.cites})
                c.end(end_time=ns(c0 + timedelta(seconds=a.latency_s)))
                ids["answer"] = c.get_span_context()
            r = t.start_span("reply", context=ctx, start_time=ns(at - timedelta(milliseconds=5)),
                             attributes={"cityhelp.disclaimer": a.disclaimer})
            r.end(end_time=ns(at))
            ids["reply"] = r.get_span_context()
            self.last.append(ids)
            before = at
        root.end(end_time=ns(conv.turns[-1][0]))

    def close(self) -> None:
        self.provider.shutdown()


class View:
    def __init__(self, folder: Path, ask_day: int, start_ns: int):
        """start_ns: the pilot's day 1 at 00:00 UTC; spans older than 14 days on ask_day are gone."""
        day_ns = 86_400 * 10**9
        lo, hi = start_ns + (ask_day - KEEP_DAYS) * day_ns, start_ns + ask_day * day_ns
        spans = [json.loads(x) for x in (folder / "spans.jsonl").read_text(encoding="utf-8").splitlines()]
        self.spans = [s for s in spans if lo <= s["start"] < hi]
        for s in self.spans:
            s["day"] = (s["start"] - start_ns) // day_ns + 1
        self.ask_day = ask_day
