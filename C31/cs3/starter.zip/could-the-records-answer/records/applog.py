"""Design A, the baseline: what a quick pilot keeps.

    applog/app.log            one line per conversation: time, ID, number of answers, status, latency (90 days)
    applog/chats.jsonl        the chat: the question and the answer, by session (deleted after 30 days)
    applog/feedback.csv       the feedback form: day, time, stars, "report a problem" (kept; not linked to a chat)

The 30 days come from one public statement about the real chatbot: the city "deletes data within 30 days",
except questions that it reviews. Everything else here is an assumption: nobody outside the city knows what
it kept.
"""

import csv
import json
from pathlib import Path

LOG_DAYS, CHAT_DAYS = 90, 30


class Recorder:
    def __init__(self, folder: Path):
        folder.mkdir(parents=True, exist_ok=True)
        self.log = (folder / "app.log").open("w", encoding="utf-8")
        self.chats = (folder / "chats.jsonl").open("w", encoding="utf-8")
        self.form = (folder / "feedback.csv").open("w", encoding="utf-8", newline="")
        self.csv = csv.writer(self.form)
        self.csv.writerow(["day", "at", "stars", "reported_problem"])

    def conversation(self, conv) -> None:
        end = conv.turns[-1][0]
        ms = round(sum(a.latency_s for _, a in conv.turns) * 1000)
        self.log.write(f"{end.isoformat()} INFO conversation={conv.id} answers={len(conv.turns)} status=ok "
                       f"latency_ms={ms}\n")
        for at, a in conv.turns:
            self.chats.write(json.dumps({"day": conv.day, "at": at.isoformat(), "session": conv.user,
                                         "question": a.question, "answer": a.text}, ensure_ascii=False) + "\n")
        if conv.rating or conv.feedback != "none":
            self.csv.writerow([conv.day, end.isoformat(), conv.rating or "", int(conv.feedback != "none")])

    def close(self) -> None:
        for f in (self.log, self.chats, self.form):
            f.close()


class View:
    """What design A still has on `ask_day`."""

    def __init__(self, folder: Path, ask_day: int):
        self.ask_day = ask_day
        self.log = []
        for line in (folder / "app.log").read_text(encoding="utf-8").splitlines():
            at, _, rest = line.partition(" INFO ")
            fields = dict(kv.split("=", 1) for kv in rest.split())
            self.log.append({"at": at, **fields})
        chats = [json.loads(x) for x in (folder / "chats.jsonl").read_text(encoding="utf-8").splitlines()]
        self.chats = [c for c in chats if ask_day - CHAT_DAYS < c["day"] <= ask_day]
        with (folder / "feedback.csv").open(encoding="utf-8") as f:
            self.feedback = [r for r in csv.DictReader(f) if int(r["day"]) <= ask_day]
        self.first_chat_day = min((c["day"] for c in self.chats), default=None)
