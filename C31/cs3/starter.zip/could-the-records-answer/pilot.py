"""The practice pilot: 190 days of the Harbourton Business Helper, recorded by four designs at once.

    python pilot.py [--out work/pilot]

Constructed traffic (seeded: the same files every time), real recorded answers (replayed). Every
conversation goes to the four recorders in records/: the same events, four ways of keeping them.

    day 1    Mon 5 Jan   release 1.0: prompt p1, index i1 (an old copy of the cash page), warning d1
    day 148  Mon 1 Jun   eleven reporters ask the housing-voucher question
    day 150  Wed 3 Jun   the report is published
    day 152  Fri 5 Jun   release 1.1 for 20% of visitors: prompt p2, index i2, warning d2 (accept), housing guardrail
    day 155  Mon 8 Jun   release 1.1 for everybody
    day 171  Wed 24 Jun  the minimum-wage page changes (version 4): 18.10 from 1 July
    day 178  Wed 1 Jul   the new minimum wage applies; the index still has version 3
    day 185  Wed 8 Jul   release 1.2: index i3 with the new page
    day 186  Thu 9 Jul   a business owner complains (work/pilot/complaint.json)
    day 190  Mon 13 Jul  the end
"""

import argparse
import hashlib
import json
import random
import shutil
from dataclasses import dataclass, field
from datetime import datetime, time, timedelta, timezone
from pathlib import Path

from helper.assistant import Answer, answer
from helper.pages import day_date, questions, release_log, truth
from records import applog, audit, traces, transcripts

SEED = 31_903
DAYS = 190
WEIGHTS = {"Q-FOOD": 18, "Q-SIGN": 16, "Q-CAFE": 16, "Q-WAGE": 12, "Q-SCHED": 10, "Q-TIPS": 10, "Q-CASH": 10,
           "Q-HOUSING": 8}
REPORTERS_DAY, REPORT_DAY = 148, 150
COMPLAINT_DAY = 186


@dataclass
class Conversation:
    id: str
    day: int
    start: datetime
    user: str                    # an account ID (A-...) if the person signed in, or a session ID (S-...)
    release: dict
    turns: list[tuple[datetime, Answer]] = field(default_factory=list)
    feedback: str = "none"       # none | reported_problem
    rating: int = 0              # 0: no rating; 1..5 stars
    reporter: bool = False       # truth only: one of the reporters' tests (no record knows this)


def release_for(day: int, user: str) -> dict:
    """The release that served this person on that day. A partial release goes to a fixed share of users."""
    live = [r for r in release_log()["releases"] if r["from_day"] <= day]
    newest = live[-1]
    if newest["share"] >= 1.0:
        return newest
    bucket = int(hashlib.sha256(user.encode()).hexdigest()[:8], 16) / 0xFFFFFFFF
    older = [r for r in live if r["id"] != newest["id"]][-1]
    return newest if bucket < newest["share"] else older


def is_wrong(a: Answer, qid: str, day: int) -> bool:
    return a.short_answer in ("yes", "no") and a.short_answer != truth(qid, day)


def conversations(rng: random.Random):
    qids, weights = list(WEIGHTS), list(WEIGHTS.values())
    for day in range(1, DAYS + 1):
        d = day_date(day)
        n = 18 if d.weekday() < 5 else 6
        starts = sorted(rng.uniform(8 * 3600, 20 * 3600) for _ in range(n))
        extra = []
        if day == REPORTERS_DAY:   # the reporters: eleven people, one question, anonymous, between 10:00 and 11:00
            extra = [(36000 + 300 * i, "Q-HOUSING", True) for i in range(11)]
        plan = [(s, None, False) for s in starts] + extra
        for i, (s, fixed, reporter) in enumerate(sorted(plan, key=lambda p: p[0])):
            start = datetime.combine(d, time(0), tzinfo=timezone.utc) + timedelta(seconds=round(s))
            user = (f"A-{rng.randrange(10_000, 99_999)}" if not reporter and rng.random() < 0.25
                    else f"S-{rng.getrandbits(32):08x}")
            conv = Conversation(f"C-{day:03d}-{i + 1:02d}", day, start, user, release_for(day, user), reporter=reporter)
            asks = [fixed] if fixed else rng.choices(qids, weights, k=1 if rng.random() < 0.8 else 2)
            t = start
            wrong = False
            for qid in asks:
                a = answer(questions()[qid]["text"], conv.release, rng.randrange(10))
                t += timedelta(seconds=8 + a.latency_s)
                conv.turns.append((t, a))
                wrong |= is_wrong(a, qid, day)
            if rng.random() < (0.15 if wrong else 0.01):
                conv.feedback, conv.rating = "reported_problem", rng.choice([1, 1, 2])
            elif rng.random() < 0.10:
                conv.rating = rng.choice([3, 4, 5, 5])
            yield conv


def complaint(convs: list[Conversation]) -> dict:
    """The new input: the first signed-in owner who got the old minimum wage from day 178 writes on day 186."""
    for c in convs:
        for t, a in c.turns:
            if (178 <= c.day < COMPLAINT_DAY and c.user.startswith("A-") and a.topic == "minimum_wage"
                    and a.short_answer == "yes"):
                return {"received_day": COMPLAINT_DAY, "account": c.user,
                        "says": f"On {day_date(c.day):%A %-d %B} your business helper told me that I could pay a new "
                                "cashier 17.40 an hour. I did. Now I owe back pay. Why did it say that?",
                        "screenshot_day": c.day, "screenshot_text": a.text}
    raise SystemExit("no conversation for the complaint")


def screenshot(convs: list[Conversation]) -> dict:
    """A reader's screenshot, as in the public case: the first cash answer from day 41 on (anonymous)."""
    for c in convs:
        for t, a in c.turns:
            if c.day >= 41 and a.topic == "cash" and c.user.startswith("S-"):
                return {"day": c.day, "time": t.strftime("%H:%M"), "text": a.text}
    raise SystemExit("no conversation for the screenshot")


def main(out: Path) -> None:
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    rng = random.Random(SEED)
    tracer = traces.Recorder(out / "traces", seed=SEED)
    recorders = [applog.Recorder(out / "applog"), transcripts.Recorder(out / "transcripts"), tracer,
                 audit.Recorder(out / "audit", tracer=tracer, seed=SEED)]   # audit after traces: it names their spans
    convs = []
    for conv in conversations(rng):
        convs.append(conv)
        for r in recorders:
            r.conversation(conv)
    for r in recorders:
        r.close()
    # What really happened (for checks, never read by the designs' answers).
    rows = [{"conversation": c.id, "day": c.day, "user": c.user, "release": c.release["id"],
             "question": next(q for q, v in questions().items() if v["text"] == a.question),
             "topic": a.topic, "short_answer": a.short_answer, "pages": a.pages,
             "wrong": is_wrong(a, next(q for q, v in questions().items() if v["text"] == a.question), c.day),
             "reporter": c.reporter, "feedback": c.feedback} for c in convs for _, a in c.turns]
    (out / "truth.json").write_text(json.dumps({"seed": SEED, "days": DAYS, "answers": rows}, indent=0) + "\n")
    (out / "screenshot.json").write_text(json.dumps(screenshot(convs), indent=2, ensure_ascii=False) + "\n")
    (out / "complaint.json").write_text(json.dumps(complaint(convs), indent=2, ensure_ascii=False) + "\n")
    shown = sum(len(c.turns) for c in convs)
    print(f"{len(convs)} conversations, {shown} answers over {DAYS} days; "
          f"{sum(r['wrong'] for r in rows)} wrong by the practice pages. Records in {out}/")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--out", type=Path, default=Path("work/pilot"))
    main(ap.parse_args().out)

