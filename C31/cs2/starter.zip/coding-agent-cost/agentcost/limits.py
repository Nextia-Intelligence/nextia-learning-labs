"""Replay a run's limits on the recorded runs: a step limit and a cost limit, checked before each model call.

The check is the one of the agents course's loop (resolver/loop.py, check_budget): before the next call, stop if
the run has already made max_steps calls, or if its cost so far is over max_cost_usd. A limit cannot know what
the next call will cost, so a run can end a little over its cost limit.

A recording shows what the agent did when nothing stopped it. When a limit stops a run, the replay ends there:
the run is "stopped", its task goes to a person, and it is not solved, even if the recording solved it later.
"""

from dataclasses import dataclass

from .data import Run
from .loops import kinds
from .prices import TABLE, price, step_cost


@dataclass
class Limits:
    max_steps: int = 0          # 0 = no step limit
    max_cost_usd: float = 0.0   # 0 = no cost limit
    max_idle: int = 0           # 0 = no idle limit: stop after this many idle steps in a row (loops.py)

    def describe(self) -> str:
        parts = []
        if self.max_steps:
            parts.append(f"step limit {self.max_steps}")
        if self.max_cost_usd:
            parts.append(f"cost limit US${self.max_cost_usd:g}")
        if self.max_idle:
            parts.append(f"idle limit {self.max_idle}")
        return ", ".join(parts) or "no limit"


@dataclass
class Replayed:
    run: Run
    steps: int = 0             # model calls made (and paid) before the stop or the end
    cost: float = 0.0          # what those calls cost
    stopped_by: str = ""       # "", "max_steps", "cost" or "idle"

    @property
    def outcome(self) -> str:
        return "stopped" if self.stopped_by else self.run.outcome

    @property
    def wrong_block(self) -> bool:
        """The limit stopped a run that the recording solved."""
        return bool(self.stopped_by) and self.run.outcome == "solved"


def replay(run: Run, limits: Limits, table: dict = TABLE) -> Replayed:
    p = price(run.model, table)
    ks = kinds(run) if limits.max_idle else []
    out = Replayed(run)
    idle_in_a_row = 0
    for i, step in enumerate(run.steps):
        # TODO (Part 2): the step limit and the cost limit, checked before this call.
        # If the run has already made limits.max_steps calls (out.steps), set out.stopped_by = "max_steps" and break.
        # If its cost so far (out.cost) is over limits.max_cost_usd, set out.stopped_by = "cost" and break.
        # A setting of 0 means no limit.
        if limits.max_idle and idle_in_a_row >= limits.max_idle:
            out.stopped_by = "idle"
            break
        out.steps += 1
        out.cost += step_cost(step, p)
        if ks:
            idle_in_a_row = idle_in_a_row + 1 if ks[i] != "work" else 0
    return out


def replay_all(runs: list[Run], limits: Limits, table: dict = TABLE) -> list[Replayed]:
    return [replay(r, limits, table) for r in runs]


def summary(replayed: list[Replayed]) -> dict:
    """The numbers of one setting: what it cost, what it solved, and the solved runs it stopped (wrong blocks).
    Read the cost per solved task next to the wrong blocks: on its own, it can praise a limit that stops good work."""
    solved = sum(1 for x in replayed if x.outcome == "solved")
    cost = sum(x.cost for x in replayed)
    return {
        "runs": len(replayed),
        "solved": solved,
        "cost_usd": cost,
        "per_solved_usd": cost / solved if solved else None,
        "stopped": sum(1 for x in replayed if x.stopped_by),
        "wrong_blocks": sum(1 for x in replayed if x.wrong_block),
        "timed_out_stopped": sum(1 for x in replayed if x.stopped_by and x.run.outcome == "timed_out"),
        "timed_out": sum(1 for x in replayed if x.run.outcome == "timed_out"),
        "steps": sum(x.steps for x in replayed),
    }
