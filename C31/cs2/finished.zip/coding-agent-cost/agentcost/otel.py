"""Write the recorded runs as OpenTelemetry traces (OTLP JSON), so that the course's own tools can read them.

One run = one trace: an `invoke_agent terminus-2` span, a `chat {model}` span for each model call, and an
`execute_tool bash_command` span for each command. The token counts use the GenAI conventions' names
(gen_ai.usage.input_tokens includes the cached tokens; gen_ai.usage.cache_read.input_tokens says how many). The
cost, the step and the outcome use the course project's names (larkfield.cost.usd, larkfield.step,
larkfield.outcome, larkfield.run.id): `python -m obs` reads these names, so it reads these runs unchanged.
A solved task is written as the outcome "resolved", the word obs counts.

The file is what the course's Collector would write with its file exporter: one export request per line, gzip.
Times: the records give the moment each answer arrived. A chat span lasts from the previous answer to this one,
so it holds the model's time and the terminal's time together: the records do not split them.
"""

import gzip
import hashlib
import json
from datetime import datetime
from pathlib import Path

from .data import Run
from .limits import Limits, replay
from .loops import kinds
from .prices import TABLE, step_costs

OUTCOME = {"solved": "resolved", "failed": "failed", "timed_out": "timed_out", "error": "error", "stopped": "stopped"}


def _id(text: str, n: int) -> str:
    return hashlib.sha256(text.encode()).hexdigest()[:n]


def _attr(key: str, value) -> dict:
    if isinstance(value, bool):
        return {"key": key, "value": {"boolValue": value}}
    if isinstance(value, int):
        return {"key": key, "value": {"intValue": str(value)}}
    if isinstance(value, float):
        return {"key": key, "value": {"doubleValue": value}}
    return {"key": key, "value": {"stringValue": str(value)}}


def _span(trace, span, parent, name, kind, start, end, attrs, error=False) -> dict:
    s = {"traceId": trace, "spanId": span, "name": name, "kind": kind,
         "startTimeUnixNano": str(start), "endTimeUnixNano": str(end),
         "attributes": [_attr(k, v) for k, v in attrs.items() if v is not None],
         "status": {"code": 2 if error else 1}}
    if parent:
        s["parentSpanId"] = parent
    return s


def run_request(run: Run, limits: Limits | None = None, table: dict = TABLE) -> dict:
    """One OTLP export request with the spans of one run (only the steps a limit lets through, if one is given)."""
    model = run.model.split("/")[-1]
    costs = step_costs(run, table)
    ks = kinds(run)
    n = len(run.steps)
    outcome = run.outcome
    stop = "time" if outcome == "timed_out" else ""
    if limits:
        r = replay(run, limits, table)
        n, outcome, stop = r.steps, r.outcome, (r.stopped_by or stop)
    t0 = int(datetime.fromisoformat(run.started.replace("Z", "+00:00")).timestamp() * 1e9)
    trace, root = _id(run.id, 32), _id(run.id + "/root", 16)
    spans, prev = [], t0
    for i, step in enumerate(run.steps[:n]):
        end = t0 + int((step.seconds or 0) * 1e9) if step.seconds is not None else prev
        end = max(end, prev)
        chat = _id(f"{run.id}/{i}", 16)
        spans.append(_span(trace, chat, root, f"chat {model}", 3, prev, end, {
            "gen_ai.operation.name": "chat", "gen_ai.request.model": model,
            "gen_ai.usage.input_tokens": step.prompt_tokens,
            "gen_ai.usage.cache_read.input_tokens": step.cached_tokens,
            "gen_ai.usage.output_tokens": step.completion_tokens,
            "larkfield.cost.usd": round(costs[i], 9), "larkfield.step": i + 1,
            "larkfield.price_table": table["version"], "agentcost.step.kind": ks[i]}))
        for j, (program, digest) in enumerate(zip(step.programs, step.digests)):
            spans.append(_span(trace, _id(f"{run.id}/{i}/{j}", 16), root, "execute_tool bash_command", 1, end, end, {
                "gen_ai.operation.name": "execute_tool", "gen_ai.tool.name": "bash_command",
                "agentcost.command.program": program or "(empty)", "agentcost.command.digest": digest}))
        prev = end
    total = round(sum(costs[:n]), 9)
    spans.insert(0, _span(trace, root, "", "invoke_agent terminus-2", 1, t0, max(prev, t0), {
        "gen_ai.operation.name": "invoke_agent", "gen_ai.agent.name": "terminus-2", "gen_ai.request.model": model,
        "larkfield.run.id": run.id, "larkfield.ticket.id": run.task, "larkfield.outcome": OUTCOME[outcome],
        "larkfield.stop_reason": stop or None, "larkfield.cost.usd": total, "larkfield.price_table": table["version"],
        "agentcost.steps": n}, error=outcome in ("timed_out", "error", "stopped")))
    return {"resourceSpans": [{
        "resource": {"attributes": [_attr("service.name", "coding-agent"), _attr("deployment.environment.name", "benchmark")]},
        "scopeSpans": [{"scope": {"name": "agentcost"}, "spans": spans}]}]}


def export(runs: list[Run], folder: Path, limits: Limits | None = None, table: dict = TABLE) -> Path:
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "traces.jsonl.gz"
    with gzip.open(path, "wt", encoding="utf-8") as f:
        for run in sorted(runs, key=lambda r: r.started):
            f.write(json.dumps(run_request(run, limits, table), separators=(",", ":")) + "\n")
    return path
