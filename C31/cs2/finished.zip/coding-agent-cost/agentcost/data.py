"""The recorded runs: load them, check them, and say how each one ended.

Each file in data/runs/ is a fixed sample of the Terminal-Bench 2.0 leaderboard's published runs of the
Terminus-2 agent (see data/dataset.md). Every line is one RUN: one attempt of the agent at one task, with each of
its model calls (a STEP: the recorded token counts and a digest of each command it sent to the terminal) and how
the run ended (the task's tests passed, failed, or the agent ran out of time).
"""

import gzip
import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
RUNS = HERE / "data" / "runs"

# The samples. "deepseek" is the agent the team runs today; "opus" is new input for the end.
FILES = {
    "deepseek": "terminus2-deepseek-v3.2.jsonl.gz",
    "opus": "terminus2-claude-opus-4.6.jsonl.gz",
}
WAIT = "e3b0c44298"   # the digest of an empty command: the agent only waits for the terminal


@dataclass
class Step:
    """One model call of the agent: its recorded tokens, and the commands it asked the terminal to run."""
    prompt_tokens: int          # every input token of the call, cached ones included
    cached_tokens: int          # the part of the input that the provider served from its cache
    completion_tokens: int
    seconds: float | None       # when the answer came, in seconds from the start of the run
    recorded_cost: float | None  # what the run's own software computed (None: it did not)
    programs: list = field(default_factory=list)   # the first word of each command ("" = an empty command)
    digests: list = field(default_factory=list)    # a short SHA-256 of each command's exact text

    @property
    def commands(self) -> tuple:
        """The step's commands, as digests: two steps with the same tuple sent the same keystrokes."""
        return tuple(self.digests)

    @property
    def waits(self) -> bool:
        """The model sent only empty commands: it waited for the terminal and paid for a full call."""
        return bool(self.digests) and all(d == WAIT for d in self.digests)


@dataclass
class Run:
    id: str
    task: str
    model: str
    reward: float | None
    exception: str | None
    started: str
    agent_seconds: float | None
    steps: list

    @property
    def outcome(self) -> str:
        """solved: the task's tests passed. timed_out: the agent hit the benchmark's time limit and the tests did
        not pass. failed: the agent stopped and the tests failed. error: the benchmark could not check the run."""
        if self.reward == 1.0:
            return "solved"
        if self.exception == "AgentTimeoutError":
            return "timed_out"
        if self.reward == 0.0:
            return "failed"
        return "error"

    @property
    def end(self) -> float:
        """When the run finished (seconds since 1970): the order in which a budget alert sees the runs."""
        start = datetime.fromisoformat(self.started.replace("Z", "+00:00")).timestamp()
        return start + (self.agent_seconds or 0)

    @property
    def prompt_tokens(self) -> int:
        return sum(s.prompt_tokens for s in self.steps)

    @property
    def cached_tokens(self) -> int:
        return sum(s.cached_tokens for s in self.steps)

    @property
    def completion_tokens(self) -> int:
        return sum(s.completion_tokens for s in self.steps)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_sums(folder: Path = RUNS) -> dict:
    """Every file named in SHA256SUMS, with True if its SHA-256 matches. A changed file stops the analysis."""
    out = {}
    for line in (folder / "SHA256SUMS").read_text().splitlines():
        if line.strip():
            digest, name = line.split()
            out[name] = (folder / name).exists() and sha256(folder / name) == digest
    return out


def load(name: str = "deepseek", folder: Path = RUNS) -> list[Run]:
    """The runs of one sample, checked against SHA256SUMS first."""
    file = FILES.get(name, name)
    sums = check_sums(folder)
    if not sums.get(file):
        raise SystemExit(f"{file}: the file is missing or its SHA-256 does not match data/runs/SHA256SUMS. "
                         "Download the project again.")
    runs = []
    with gzip.open(folder / file, "rt", encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            steps = [Step(s["prompt"] or 0, s["cached"] or 0, s["completion"] or 0, s["t"], s["cost"],
                          s["programs"], s["digests"]) for s in r["steps"]]
            runs.append(Run(r["id"], r["task"], r["model"], r["reward"], r["exception"], r["started"],
                            r["agent_seconds"], steps))
    return runs
