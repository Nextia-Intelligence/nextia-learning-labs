"""Find the steps that bought nothing: model calls after which the terminal did nothing new.

A coding agent pays for every model call, and each call sends the whole history again. A step is IDLE when the
model answered but the terminal got nothing new to do:

    none     the answer had no command at all
    wait     every command was empty: the agent only waited for the terminal
    repeat   exactly the same commands as the step before (the same keystrokes, by their digests)

One idle step is often normal: the agent waits for an install, or confirms that it has finished. A long STREAK
of idle steps is a loop that costs money and does no work.
"""

from dataclasses import dataclass

from .data import Run
from .prices import step_costs


def kinds(run: Run) -> list[str]:
    """One word per step: work, none, wait or repeat."""
    out = []
    for i, s in enumerate(run.steps):
        if not s.digests:
            out.append("none")
        elif s.waits:
            out.append("wait")
        elif i and s.commands == run.steps[i - 1].commands:
            out.append("repeat")
        else:
            out.append("work")
    return out


@dataclass
class IdleReport:
    run: Run
    idle_steps: int
    longest_streak: int
    streak_start: int        # the first step (1 = the first) of the longest streak
    streak_kind: str         # the most common kind of idle step in that streak
    streak_cost: float       # what the steps of that streak cost
    cost: float


def idle(run: Run) -> IdleReport:
    ks = kinds(run)
    costs = step_costs(run)
    best = (0, 0)  # (length, start index)
    cur = 0
    for i, k in enumerate(ks):
        cur = cur + 1 if k != "work" else 0
        if cur > best[0]:
            best = (cur, i - cur + 1)
    length, start = best
    streak = ks[start:start + length]
    kind = max(("none", "wait", "repeat"), key=streak.count) if streak else ""
    return IdleReport(run, sum(1 for k in ks if k != "work"), length, start + 1, kind,
                      sum(costs[start:start + length]), sum(costs))
