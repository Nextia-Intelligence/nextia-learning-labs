"""agentcost: what a coding agent's runs cost, which runs waste money, and what limits and budget to set.

    python -m agentcost check   [--data deepseek|opus]
    python -m agentcost cost    [--by outcome|task|length|model] [--no-cache] [--data ...]
    python -m agentcost steps   RUN_ID [--every N] [--data ...]
    python -m agentcost idle    [--top N] [--data ...]
    python -m agentcost limits  [--max-steps N] [--max-cost US$] [--max-idle N] [--data ...]
    python -m agentcost sweep   --max-steps 20,30,40 | --max-cost 0.02,0.05 | --max-idle 5,10 [--data ...]
    python -m agentcost budget  --budget US$ [--window N] [--data ...]
    python -m agentcost export  [--out DIR] [--max-steps N] [--max-cost US$] [--data ...]
    python -m agentcost report  [--recommendation recommendation.json] [--data ...]

Every cost is tokens x the price table prices.json (its version is printed). The data are recorded runs of an open
benchmark (data/dataset.md): no model is called, nothing costs money.
"""

import argparse
import json
import os
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

from . import budget as budget_mod
from .data import FILES, HERE, check_sums, load
from .limits import Limits, replay_all, summary
from .loops import idle, kinds
from .prices import VERSION, price, run_cost, step_costs

OUTCOMES = ("solved", "failed", "timed_out", "error")


def money(x: float | None, n: int = 4) -> str:
    return "-" if x is None else f"{x:.{n}f}"


def footer() -> None:
    print(f"Cost = recorded tokens x the price table {VERSION} (prices.json): assumptions, check the current prices.")


# ------------------------------------------------------------------ check

def cmd_check(args):
    sums = check_sums()
    for name, ok in sums.items():
        print(f"{name:<40} SHA-256 {'ok' if ok else 'DOES NOT MATCH'}")
    runs = load(args.data)
    model = runs[0].model
    steps = sum(len(r.steps) for r in runs)
    tasks = len({r.task for r in runs})
    print(f"{args.data}: {len(runs)} runs of {model} ({tasks} tasks), {steps:,} model calls, "
          f"{sum(r.prompt_tokens for r in runs):,} tokens in ({sum(r.cached_tokens for r in runs):,} cached), "
          f"{sum(r.completion_tokens for r in runs):,} out")
    c = Counter(r.outcome for r in runs)
    print("outcomes: " + ", ".join(f"{k} {c[k]}" for k in OUTCOMES if c[k]))
    zero = sum(1 for r in runs for s in r.steps if s.prompt_tokens == 0)
    print(f"model calls with 0 input tokens recorded: {zero}")
    p = price(model)
    pairs = [(s.recorded_cost, c) for r in runs for s, c in zip(r.steps, step_costs(r)) if s.recorded_cost is not None]
    if pairs:
        same = sum(1 for rec, ours in pairs if abs(rec - ours) < 1e-9)
        rec, ours = sum(x[0] for x in pairs), sum(x[1] for x in pairs)
        print(f"recorded cost on {len(pairs):,} calls: US${rec:.2f}; our price table: US${ours:.2f} "
              f"({same:,} calls equal to the recorded cost, {ours / rec - 1:+.1%} in all)")
    print(f"price table {VERSION}: {p['name']} US${p['input']:g} in, US${p['cached_input']:g} cached in, "
          f"US${p['output']:g} out per 1M tokens")


# ------------------------------------------------------------------ cost

BANDS = ((1, 10), (11, 20), (21, 30), (31, 40), (41, 50), (51, 100), (101, 10**6))


def length_band(n: int) -> str:
    """The run's number of model calls, in a band: '  1-10 ' … ' 101+  ' (sorted as text in this order)."""
    lo, hi = next(b for b in BANDS if b[0] <= n <= b[1])
    return f"{lo:>4}+ calls" if hi == 10**6 else f"{lo:>4}-{hi:<3} calls"


def cmd_cost(args):
    runs = load(args.data)
    cache = not args.no_cache
    key = {"outcome": lambda r: r.outcome, "task": lambda r: r.task, "model": lambda r: r.model,
           "length": lambda r: length_band(len(r.steps))}[args.by]
    groups = defaultdict(list)
    for r in runs:
        groups[key(r)].append(r)
    total = sum(run_cost(r, cache=cache) for r in runs)
    print(f"{args.by:<26} {'runs':>5} {'solved':>6} {'steps':>6} {'cost US$':>9} {'share':>6} {'per run':>8} "
          f"{'per solved':>10} {'success':>8}")
    order = OUTCOMES if args.by == "outcome" else sorted(groups)
    rows = [(k, groups[k]) for k in order if k in groups]
    if args.by == "task":
        rows.sort(key=lambda kv: -sum(run_cost(r, cache=cache) for r in kv[1]))
        rows = rows[:args.top]
    for k, rs in rows:
        cost = sum(run_cost(r, cache=cache) for r in rs)
        solved = sum(1 for r in rs if r.outcome == "solved")
        steps = statistics.median(len(r.steps) for r in rs)
        print(f"{str(k):<26} {len(rs):>5} {solved:>6} {steps:>6g} {cost:>9.4f} {cost / total:>6.0%} "
              f"{cost / len(rs):>8.4f} {money(cost / solved if solved else None):>10} {solved / len(rs):>8.1%}")
    solved = sum(1 for r in runs if r.outcome == "solved")
    print(f"{'total':<26} {len(runs):>5} {solved:>6} {statistics.median(len(r.steps) for r in runs):>6g} "
          f"{total:>9.4f} {1:>6.0%} {total / len(runs):>8.4f} {money(total / solved):>10} {solved / len(runs):>8.1%}")
    if args.by == "task":
        print(f"(the {len(rows)} tasks that cost the most of {len(groups)}; steps = the median per run)")
    else:
        print("(steps = the median number of model calls per run)")
    if not cache:
        print("Without the provider's cache: every input token at the full input price.")
    footer()


# ------------------------------------------------------------------ steps

def cmd_steps(args):
    runs = {r.id: r for r in load(args.data)}
    run = runs.get(args.run) or next((r for k, r in runs.items() if k.startswith(args.run)), None)
    if run is None:
        sys.exit(f"No run {args.run} in {args.data}.")
    costs, ks = step_costs(run), kinds(run)
    print(f"{run.id}: task {run.task}, {run.model}, {run.outcome}, {len(run.steps)} model calls, "
          f"US${sum(costs):.4f}")
    print(f"{'step':>5} {'tokens in':>10} {'cached':>9} {'out':>6} {'cost US$':>9} {'so far':>8}  kind    commands")
    so_far = 0.0
    for i, (s, c, k) in enumerate(zip(run.steps, costs, ks)):
        so_far += c
        if args.every > 1 and i not in (0, len(run.steps) - 1) and (i + 1) % args.every:
            continue
        progs = " ".join(p or "(empty)" for p in s.programs) or "-"
        print(f"{i + 1:>5} {s.prompt_tokens:>10,} {s.cached_tokens:>9,} {s.completion_tokens:>6,} {c:>9.5f} "
              f"{so_far:>8.4f}  {k:<7} {progs[:40]}")
    footer()


# ------------------------------------------------------------------ idle

def cmd_idle(args):
    runs = load(args.data)
    reports = [idle(r) for r in runs]
    print("Idle steps: the model answered, and the terminal got nothing new (no command, only empty commands, "
          "or the same commands again).")
    print(f"{'outcome':<10} {'runs':>5} {'longest idle streak: median':>28} {'max':>5}")
    for o in OUTCOMES:
        rs = [x for x in reports if x.run.outcome == o]
        if rs:
            print(f"{o:<10} {len(rs):>5} {statistics.median(x.longest_streak for x in rs):>28g} "
                  f"{max(x.longest_streak for x in rs):>5}")
    print(f"The {args.top} runs with the longest idle streak:")
    w = max(len(x.run.id) for x in reports)
    print(f"{'run':<{w}} {'outcome':<10} {'steps':>5} {'cost US$':>9} {'streak':>6} {'from':>5} {'kind':<6} "
          f"{'streak US$':>10}")
    for x in sorted(reports, key=lambda x: (-x.longest_streak, -x.cost))[:args.top]:
        print(f"{x.run.id:<{w}} {x.run.outcome:<10} {len(x.run.steps):>5} {x.cost:>9.4f} {x.longest_streak:>6} "
              f"{x.streak_start:>5} {x.streak_kind:<6} {x.streak_cost:>10.4f}")
    footer()


# ------------------------------------------------------------------ limits

def parse_limits(args) -> Limits:
    return Limits(max_steps=args.max_steps or 0, max_cost_usd=args.max_cost or 0.0,
                  max_idle=getattr(args, "max_idle", None) or 0)


def cmd_limits(args):
    runs = load(args.data)
    limits = parse_limits(args)
    base, rep = summary(replay_all(runs, Limits())), replay_all(runs, limits)
    s = summary(rep)
    print(f"{args.data} ({runs[0].model}): {len(runs)} runs | {limits.describe()} (checked before each model call)")
    print(f"{'recorded outcome':<16} {'runs':>5} {'stopped':>7} {'cost US$':>9} {'of US$':>9}")
    for o in OUTCOMES:
        xs = [x for x in rep if x.run.outcome == o]
        if xs:
            print(f"{o:<16} {len(xs):>5} {sum(1 for x in xs if x.stopped_by):>7} {sum(x.cost for x in xs):>9.4f} "
                  f"{sum(run_cost(x.run) for x in xs):>9.4f}")
    print(f"cost US${s['cost_usd']:.4f} (no limit: US${base['cost_usd']:.4f}, saved US${base['cost_usd'] - s['cost_usd']:.4f}) "
          f"| solved {s['solved']} of {base['solved']} | solved runs stopped (wrong blocks): {s['wrong_blocks']}")
    print(f"cost per solved task: US${money(s['per_solved_usd'])} (no limit: US${money(base['per_solved_usd'])})")
    over = [x for x in rep if x.stopped_by == "cost" and x.cost > limits.max_cost_usd]
    if over:
        worst = max(over, key=lambda x: x.cost)
        print(f"runs stopped by cost that ended over the limit: {len(over)} (the most: US${worst.cost:.4f}, {worst.run.id})")
    footer()


def cmd_sweep(args):
    runs = load(args.data)
    values = [float(v) for v in (args.max_steps or args.max_cost or args.max_idle).split(",")]
    base = summary(replay_all(runs, Limits()))
    what = "step limit" if args.max_steps else "cost limit US$" if args.max_cost else "idle limit"
    print(f"{args.data} ({runs[0].model}), {len(runs)} runs | no limit: US${base['cost_usd']:.4f}, "
          f"{base['solved']} solved, US${money(base['per_solved_usd'])} per solved task")
    print(f"{what:>14} {'cost US$':>9} {'saved':>7} {'solved':>6} {'wrong blocks':>12} {'timed out stopped':>17} "
          f"{'per solved':>10}")
    rows = []
    for v in values:
        lim = (Limits(max_steps=int(v)) if args.max_steps else Limits(max_cost_usd=v) if args.max_cost
               else Limits(max_idle=int(v)))
        s = summary(replay_all(runs, lim))
        rows.append({"setting": v, **s})
        print(f"{v:>14g} {s['cost_usd']:>9.4f} {base['cost_usd'] - s['cost_usd']:>7.4f} {s['solved']:>6} "
              f"{s['wrong_blocks']:>12} {s['timed_out_stopped']:>8} of {s['timed_out']:<5} {money(s['per_solved_usd']):>10}")
    if args.json:
        Path(args.json).parent.mkdir(parents=True, exist_ok=True)
        Path(args.json).write_text(json.dumps({"data": args.data, "base": base, "rows": rows}, indent=1))
    footer()


# ------------------------------------------------------------------ budget

def budget_report(runs, budget: float, window: int, min_runs: int, limits: Limits | None = None) -> None:
    lim = f", with {limits.describe()}" if limits and (limits.max_steps or limits.max_cost_usd) else ""
    print(f"Budget: US${budget:g} per solved task over the last {window} finished runs (from {min_runs} runs on{lim})")
    lo, mid, hi = budget_mod.normal_range(runs, window, min_runs, limits=limits)
    print(f"Cost per solved task of the windows: lowest US${lo:.4f}, median US${mid:.4f}, highest US${hi:.4f}")
    c = budget_mod.first_crossing(runs, budget, window, min_runs, limits=limits)
    if c is None:
        print("Never over budget.")
        return
    print(f"Over budget after finished run {c.index} ({c.run.id}): US${c.per_solved:.4f} per solved task "
          f"({c.solved} solved, US${c.cost:.4f})")
    share = sum(x[1] for x in c.costly) / c.cost if c.cost else 0
    print(f"The {len(c.costly)} runs that cost most in that window ({share:.0%} of its cost):")
    w = max(len(r.id) for r, _ in c.costly)
    print(f"{'run':<{w}} {'outcome':<10} {'steps':>5} {'cost US$':>9} {'idle streak':>11}")
    for r, cost in c.costly:
        print(f"{r.id:<{w}} {r.outcome:<10} {len(r.steps):>5} {cost:>9.4f} {idle(r).longest_streak:>11}")
    n = budget_mod.crossings(runs, budget, window, min_runs, limits=limits)
    print(f"Windows over the budget: {n} of {max(0, len(runs) - min_runs + 1)}")


def cmd_budget(args):
    runs = load(args.data)
    budget_report(runs, args.budget, args.window, args.min_runs, parse_limits(args))
    footer()


# ------------------------------------------------------------------ report

RECOMMENDATION = HERE / "recommendation.json"


def settings_for(rec: dict, model: str) -> tuple[dict, str]:
    """The model's own entry in the recommendation, or the default entry (the team's settings for any model)."""
    if model in (rec.get("models") or {}):
        return rec["models"][model], model
    return rec.get("default") or {}, "default"


def cmd_report(args):
    """The whole check on one sample, with the settings of recommendation.json: the end-to-end run."""
    rec = json.loads(Path(args.recommendation).read_text())
    runs = load(args.data)
    model = runs[0].model
    entry, which = settings_for(rec, model)
    limits = Limits(max_steps=entry.get("max_steps") or 0)
    window = rec.get("window", 89)
    print(f"== {args.data}: {len(runs)} runs of {model} | settings: {Path(args.recommendation).name}, "
          f"{'the entry for ' + model if which == model else 'the default entry (no entry for ' + model + ')'}")
    c = Counter(r.outcome for r in runs)
    total = sum(run_cost(r) for r in runs)
    print("outcomes: " + ", ".join(f"{k} {c[k]}" for k in OUTCOMES if c[k])
          + f" | cost US${total:.2f}, US${total / len(runs):.4f} a run, US${total / c['solved']:.4f} per solved task")
    solved_steps = sorted(len(r.steps) for r in runs if r.outcome == "solved")
    solved_cost = sorted(run_cost(r) for r in runs if r.outcome == "solved")
    print(f"solved runs: model calls median {solved_steps[len(solved_steps) // 2]}, longest {solved_steps[-1]} | "
          f"cost median US${solved_cost[len(solved_cost) // 2]:.4f}, highest US${solved_cost[-1]:.4f}")
    print(f"== the step limit: {limits.describe()}")
    base, s = summary(replay_all(runs, Limits())), summary(replay_all(runs, limits))
    print(f"cost US${s['cost_usd']:.2f} (saved US${base['cost_usd'] - s['cost_usd']:.2f}, "
          f"{(base['cost_usd'] - s['cost_usd']) / base['cost_usd']:.0%}) | timed-out runs stopped "
          f"{s['timed_out_stopped']} of {s['timed_out']} | solved runs stopped (wrong blocks): {s['wrong_blocks']}")
    print(f"cost per solved task: US${money(s['per_solved_usd'])} (no limit: US${money(base['per_solved_usd'])})")
    streak = rec.get("idle_alert_streak") or 0
    if streak:
        flagged = [x for x in (idle(r) for r in runs) if x.longest_streak >= streak]
        print(f"== the idle alert: {streak} idle steps in a row (an alert to a person, not a stop)")
        print(f"runs it flags: {len(flagged)} ("
              + ", ".join(f"{o} {sum(1 for x in flagged if x.run.outcome == o)}" for o in OUTCOMES
                          if any(x.run.outcome == o for x in flagged)) + ")")
    print("== the budget")
    if entry.get("budget_per_solved_usd"):
        budget_report(runs, entry["budget_per_solved_usd"], window, 20, limits)
    else:
        print("No budget in the settings.")
    footer()


# ------------------------------------------------------------------ export

def cmd_export(args):
    from .otel import export
    runs = load(args.data)
    limits = parse_limits(args)
    out = Path(args.out or HERE / "work" / "telemetry" / args.data)
    limited = bool(limits.max_steps or limits.max_cost_usd or limits.max_idle)
    path = export(runs, out, limits if limited else None)
    spans = sum(1 + len(r.steps) + sum(len(s.digests) for s in r.steps) for r in runs)
    shown = os.path.relpath(path)
    print(f"Wrote {len(runs)} traces to {shown} ({path.stat().st_size / 1e6:.1f} MB, "
          f"{'up to ' if limited else ''}{spans:,} spans), {limits.describe()}, price table {VERSION}")
    print("Read them with the course's obs, in ../observable-workflow: "
          f"python -m obs cost --by outcome --data ../coding-agent-cost/{os.path.relpath(out)}")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python -m agentcost", description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="command", required=True)

    def data(p):
        p.add_argument("--data", default="deepseek", choices=sorted(FILES))
        return p

    data(sub.add_parser("check"))
    p = data(sub.add_parser("cost"))
    p.add_argument("--by", default="outcome", choices=["outcome", "task", "length", "model"])
    p.add_argument("--no-cache", action="store_true", help="price every input token at the full price")
    p.add_argument("--top", type=int, default=10)
    p = data(sub.add_parser("steps"))
    p.add_argument("run")
    p.add_argument("--every", type=int, default=1, help="show every Nth step (and the first and last)")
    p = data(sub.add_parser("idle"))
    p.add_argument("--top", type=int, default=8)
    for name in ("limits", "export"):
        p = data(sub.add_parser(name))
        p.add_argument("--max-steps", type=int)
        p.add_argument("--max-cost", type=float)
        p.add_argument("--max-idle", type=int, help="stop after this many idle steps in a row")
        if name == "export":
            p.add_argument("--out")
    p = data(sub.add_parser("sweep"))
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--max-steps")
    g.add_argument("--max-cost")
    g.add_argument("--max-idle")
    p.add_argument("--json")
    p = data(sub.add_parser("budget"))
    p.add_argument("--budget", type=float, required=True)
    p.add_argument("--max-steps", type=int, help="the runs as they would cost under this step limit")
    p.add_argument("--max-cost", type=float)
    p.add_argument("--window", type=int, default=89, help="finished runs per window (89 = one run of each task)")
    p.add_argument("--min-runs", type=int, default=20)
    p = data(sub.add_parser("report"))
    p.add_argument("--recommendation", default=str(RECOMMENDATION))
    args = ap.parse_args(argv)
    {"check": cmd_check, "cost": cmd_cost, "steps": cmd_steps, "idle": cmd_idle, "limits": cmd_limits,
     "sweep": cmd_sweep, "budget": cmd_budget, "export": cmd_export, "report": cmd_report}[args.command](args)


if __name__ == "__main__":
    main()
