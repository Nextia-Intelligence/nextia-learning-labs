"""A budget per solved task, checked over a window of recent runs: the budget alert of the course's cost module.

The alert looks at the last WINDOW finished runs. When their cost per solved task is over the BUDGET, it fires,
and it names the runs that cost the most in that window, so that the first click leads to a run, not to a search.
It waits for MIN_RUNS runs, so that the first few runs cannot set it off alone. An alert reports spending after it
happened: it stops nothing (the limits in limits.py do).
"""

from dataclasses import dataclass

from .data import Run
from .limits import Limits, replay
from .prices import TABLE


@dataclass
class Crossing:
    index: int            # the finished run (1 = the first) after which the window went over the budget
    run: Run
    solved: int
    cost: float
    costly: list          # [(run, cost)], the most expensive runs of the window

    @property
    def per_solved(self) -> float:
        return self.cost / self.solved if self.solved else float("inf")


def windows(runs: list[Run], window: int, min_runs: int = 20, table: dict = TABLE, limits: Limits | None = None):
    """(index, run, solved, cost, [(run, cost)]) for the window that ends with each finished run, from MIN_RUNS on.
    With LIMITS, each run costs what it would have cost under them, and a stopped run is not solved."""
    order = sorted(runs, key=lambda r: r.end)
    replayed = [replay(r, limits or Limits(), table) for r in order]
    costs = [x.cost for x in replayed]
    solved = [x.outcome == "solved" for x in replayed]
    for i, run in enumerate(order):
        lo = max(0, i + 1 - window)
        if i + 1 - lo < min_runs:
            continue
        yield i, run, sum(solved[lo:i + 1]), sum(costs[lo:i + 1]), list(zip(order[lo:i + 1], costs[lo:i + 1]))


def first_crossing(runs: list[Run], budget: float, window: int, min_runs: int = 20, top: int = 5,
                   table: dict = TABLE, limits: Limits | None = None) -> Crossing | None:
    for i, run, solved, cost, pairs in windows(runs, window, min_runs, table, limits):
        if not solved or cost / solved > budget:
            costly = sorted(pairs, key=lambda rc: -rc[1])[:top]
            return Crossing(i + 1, run, solved, cost, costly)
    return None


def crossings(runs: list[Run], budget: float, window: int, min_runs: int = 20, table: dict = TABLE,
              limits: Limits | None = None) -> int:
    """How many windows were over the budget (each finished run moves the window by one)."""
    return sum(1 for _, _, solved, cost, _ in windows(runs, window, min_runs, table, limits)
               if not solved or cost / solved > budget)


def normal_range(runs: list[Run], window: int, min_runs: int = 20, table: dict = TABLE,
                 limits: Limits | None = None) -> tuple[float, float, float]:
    """The lowest, median and highest cost per solved task of the windows: what "normal" looked like."""
    v = sorted(cost / solved for _, _, solved, cost, _ in windows(runs, window, min_runs, table, limits) if solved)
    return v[0], v[len(v) // 2], v[-1]
