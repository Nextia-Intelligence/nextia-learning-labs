"""What a coding agent costs: the case study of Observability for AI Agents (Nextia Learning)."""
