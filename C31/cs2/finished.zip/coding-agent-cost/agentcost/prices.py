"""The price table, and the cost of one step and one run.

The table is ours and it has a version (prices.json). A provider changes its prices; a report made with an old
table must keep its numbers. So the cost of a step is always "tokens x the table of this version".
"""

import json
from pathlib import Path

from .data import HERE, Run, Step

PRICES_FILE = HERE / "prices.json"


def load_prices(path: Path = PRICES_FILE) -> dict:
    return json.loads(Path(path).read_text())


TABLE = load_prices()
VERSION = TABLE["version"]


def price(model: str, table: dict = TABLE) -> dict:
    """The model's prices (US$ per 1M tokens). A model without a price is an error, never a cost of 0."""
    key = model.split("/")[-1]
    if key not in table["models"]:
        raise KeyError(f"No price for {model} in the price table {table['version']}: add it first.")
    return table["models"][key]


def step_cost(step: Step, p: dict, cache: bool = True) -> float:
    """The cost of one model call in US$. Cached input tokens are part of prompt_tokens; the provider charges them
    at the cheaper cached_input price. With cache=False, every input token is charged at the full price: what
    the same call would cost without the provider's cache."""
    cached = step.cached_tokens if cache else 0
    uncached = step.prompt_tokens - cached
    return (uncached * p["input"] + cached * p["cached_input"] + step.completion_tokens * p["output"]) / 1e6


def run_cost(run: Run, table: dict = TABLE, cache: bool = True) -> float:
    p = price(run.model, table)
    return sum(step_cost(s, p, cache) for s in run.steps)


def step_costs(run: Run, table: dict = TABLE) -> list[float]:
    p = price(run.model, table)
    return [step_cost(s, p) for s in run.steps]
