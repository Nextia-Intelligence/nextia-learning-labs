"""The limits, checked before each model call, on a tiny run that you can count by hand."""

from agentcost.data import Run, Step
from agentcost.limits import Limits, replay, summary

# Six calls of 1,000,000 tokens in (none cached) and 0 out: US$0.28 each at DeepSeek's price.
SIX = [Step(1_000_000, 0, 0, float(i), None, ["make"], [f"d{i}"]) for i in range(6)]


def run(outcome_reward=1.0, steps=SIX):
    return Run("tiny", "task", "deepseek-chat", outcome_reward, None, "2026-01-01T00:00:00Z", 60.0, steps)


def test_no_limit_replays_the_whole_run():
    r = replay(run(), Limits())
    assert (r.steps, r.stopped_by, r.outcome) == (6, "", "solved")
    assert round(r.cost, 2) == 1.68


def test_a_step_limit_of_4_lets_4_calls_through():
    r = replay(run(), Limits(max_steps=4))
    assert (r.steps, r.stopped_by) == (4, "max_steps")
    assert round(r.cost, 2) == 1.12


def test_a_stopped_solved_run_is_a_wrong_block():
    r = replay(run(), Limits(max_steps=4))
    assert r.outcome == "stopped" and r.wrong_block


def test_a_cost_limit_is_checked_before_the_call_so_the_run_ends_over_it():
    # After 2 calls: US$0.56, under US$0.60, so the third call goes out. After 3 calls: US$0.84, over: stop.
    r = replay(run(), Limits(max_cost_usd=0.60))
    assert (r.steps, r.stopped_by) == (3, "cost")
    assert round(r.cost, 2) == 0.84


def test_the_measure_counts_both_errors():
    runs = [run(1.0), run(0.0, SIX * 3)]
    s = summary([replay(r, Limits(max_steps=10)) for r in runs])
    assert s["solved"] == 1 and s["wrong_blocks"] == 0 and s["stopped"] == 1
    assert round(s["per_solved_usd"], 2) == round((6 + 10) * 0.28, 2)
