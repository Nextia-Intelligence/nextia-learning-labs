"""The course's own tool reads the exported traces and finds the same total (skipped without the course project)."""

import os
import re
import subprocess
import sys
from pathlib import Path

import pytest

from agentcost.data import HERE, load
from agentcost.otel import export
from agentcost.prices import run_cost

COURSE = Path(os.environ.get("OBS_PROJECT", HERE.parent / "observable-workflow"))


@pytest.mark.skipif(not (COURSE / "obs" / "__main__.py").exists(),
                    reason="the course project (observable-workflow) is not next to this folder; set OBS_PROJECT")
def test_obs_cost_finds_the_same_total(tmp_path):
    runs = load("deepseek")
    export(runs, tmp_path)
    out = subprocess.run([sys.executable, "-m", "obs", "cost", "--by", "model", "--data", str(tmp_path)],
                         cwd=COURSE, capture_output=True, text=True, check=True).stdout
    total = re.search(r"^total\s+(\d+)\s+(\d+)\s+([\d.]+)", out, re.M)
    assert total, out
    assert int(total.group(1)) == len(runs)
    assert int(total.group(2)) == sum(1 for r in runs if r.outcome == "solved")
    assert float(total.group(3)) == round(sum(run_cost(r) for r in runs), 4)
