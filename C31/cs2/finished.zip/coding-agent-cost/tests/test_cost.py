"""The cost of one step and of one run: a tiny example by hand, then the recorded costs of the real runs."""

import pytest

from agentcost.data import Run, Step, load
from agentcost.prices import TABLE, price, run_cost, step_cost

DEEPSEEK = price("deepseek-chat")


def test_a_step_by_hand():
    # 10,000 tokens in, 9,000 of them from the cache, 500 out:
    # 1,000 x 0.28 + 9,000 x 0.028 + 500 x 0.42 = 280 + 252 + 210 = 742 millionths of a dollar
    step = Step(prompt_tokens=10_000, cached_tokens=9_000, completion_tokens=500, seconds=1.0, recorded_cost=None)
    assert step_cost(step, DEEPSEEK) == pytest.approx(0.000742)


def test_the_same_step_without_the_cache():
    step = Step(10_000, 9_000, 500, 1.0, None)
    assert step_cost(step, DEEPSEEK, cache=False) == pytest.approx((10_000 * 0.28 + 500 * 0.42) / 1e6)


def test_our_price_table_gives_every_recorded_cost():
    """The runs' own software recorded a cost for each DeepSeek call. Our table must give the same number."""
    runs = load("deepseek")
    for run in runs:
        for s in run.steps:
            assert step_cost(s, DEEPSEEK) == pytest.approx(s.recorded_cost, abs=1e-9), (run.id, s)


def test_a_model_without_a_price_is_an_error_not_free():
    run = Run("x", "task", "some-new-model", 1.0, None, "2026-01-01T00:00:00Z", 1.0, [Step(10, 0, 10, 1.0, None)])
    with pytest.raises(KeyError):
        run_cost(run)


def test_the_price_table_has_a_version():
    assert TABLE["version"]
    for p in TABLE["models"].values():
        assert p["cached_input"] < p["input"] < p["output"]
