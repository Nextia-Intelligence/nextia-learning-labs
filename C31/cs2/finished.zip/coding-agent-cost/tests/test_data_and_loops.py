"""The data checks, the idle steps, the budget window and the OpenTelemetry export."""

import gzip
import json

from agentcost.budget import first_crossing
from agentcost.data import FILES, Run, Step, check_sums, load
from agentcost.loops import idle, kinds
from agentcost.otel import export
from agentcost.prices import run_cost

EMPTY = "e3b0c44298"


def test_every_file_matches_its_checksum():
    sums = check_sums()
    assert set(FILES.values()) <= set(sums) and all(sums.values())


def test_the_design_sample():
    runs = load("deepseek")
    assert len(runs) == 445 and len({r.task for r in runs}) == 89
    assert {r.outcome for r in runs} <= {"solved", "failed", "timed_out", "error"}


def test_the_kinds_of_steps():
    steps = [Step(10, 0, 1, 0.0, None, ["ls"], ["a"]), Step(10, 0, 1, 1.0, None, [""], [EMPTY]),
             Step(10, 0, 1, 2.0, None, ["ls"], ["a"]), Step(10, 0, 1, 3.0, None, ["ls"], ["a"]),
             Step(10, 0, 1, 4.0, None, [], [])]
    run = Run("r", "t", "deepseek-chat", 0.0, None, "2026-01-01T00:00:00Z", 5.0, steps)
    assert kinds(run) == ["work", "wait", "work", "repeat", "none"]
    report = idle(run)
    assert (report.longest_streak, report.streak_start) == (2, 4)


def test_a_budget_alert_names_the_runs_of_its_window():
    cheap = [Run(f"c{i}", "t", "deepseek-chat", 1.0, None, f"2026-01-01T00:{i:02d}:00Z", 1.0,
                 [Step(1000, 0, 0, 1.0, None)]) for i in range(30)]
    dear = Run("dear", "t", "deepseek-chat", 0.0, None, "2026-01-01T00:40:00Z", 1.0, [Step(10_000_000, 0, 0, 1.0, None)])
    assert first_crossing(cheap, budget=0.01, window=20) is None
    c = first_crossing(cheap + [dear], budget=0.01, window=20)
    assert c.run.id == "dear" and c.costly[0][0].id == "dear"


def test_the_export_keeps_every_token_and_every_cent(tmp_path):
    runs = load("deepseek")[:40]
    path = export(runs, tmp_path)
    cost = tokens = 0
    for line in gzip.open(path, "rt"):
        for rs in json.loads(line)["resourceSpans"]:
            for s in rs["scopeSpans"][0]["spans"]:
                a = {x["key"]: x["value"] for x in s["attributes"]}
                if s["name"].startswith("chat "):
                    cost += a["larkfield.cost.usd"]["doubleValue"]
                    tokens += int(a["gen_ai.usage.input_tokens"]["intValue"])
    assert round(cost, 6) == round(sum(run_cost(r) for r in runs), 6)
    assert tokens == sum(r.prompt_tokens for r in runs)
