"""Make the fixed sample in data/runs/ from the reduced download (authors only; kept so that anyone can redo it).

    python -I tools/make_sample.py REDUCED.jsonl OUT.jsonl.gz

REDUCED.jsonl is the output of reduce_tb.py (reference/c31/m09/L02/): one line per trial of a Terminus-2 job of
the Terminal-Bench 2.0 leaderboard, already without any text (no prompt, no answer, no terminal output, no command
text). This step only orders the runs by start time, marks empty commands as "" and writes a gzip file whose bytes
are the same every time (so that its SHA-256 is stable).
"""

import gzip
import io
import json
import sys

WAIT = "e3b0c44298"   # sha256("")[:10]


def main(src: str, out: str) -> None:
    runs = [json.loads(line) for line in open(src, encoding="utf-8") if line.strip()]
    runs.sort(key=lambda r: (r["started"], r["id"]))
    buf = io.StringIO()
    for r in runs:
        for s in r["steps"]:
            s["programs"] = ["" if d == WAIT else p for p, d in zip(s["programs"], s["digests"])]
            s.pop("tools", None)   # always bash_command in Terminus-2
        r.pop("trajectory_agent", None)
        r["model"] = r["model"].split("/")[-1]
        buf.write(json.dumps(r, separators=(",", ":"), sort_keys=True) + "\n")
    with open(out, "wb") as f, gzip.GzipFile(fileobj=f, mode="wb", mtime=0, filename="") as g:
        g.write(buf.getvalue().encode("utf-8"))
    print(f"{out}: {len(runs)} runs")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
