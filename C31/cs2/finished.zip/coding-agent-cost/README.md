# coding-agent-cost: what a coding agent's runs cost

A case study of the course *Observability for AI Agents: Traces, Costs and Audit Trails* (Nextia Learning). It
measures the cost of 445 recorded runs of an open coding agent (Terminus 2 with DeepSeek-V3.2, on the 89 tasks of
Terminal-Bench 2.0) per task, per model call and per outcome. It finds the runs that loop or over-spend, and it
chooses a step limit, an idle alert and a budget per solved task. Then it checks the choice on 445 runs of the same
agent with another model (Claude Opus 4.6).

No model is called and nothing costs money: every token count is a recording (`data/dataset.md`).

## What you need

- Python 3.12 or newer. The project uses only the standard library; the tests use pytest. The course project's
  virtual environment has both: put this folder next to `observable-workflow` and activate that environment.
- About 2 MB of disk.

```sh
cd coding-agent-cost
source ../observable-workflow/.venv/bin/activate      # Windows: ..\observable-workflow\.venv\Scripts\Activate.ps1
python -m pytest -q                                   # 15 passed, 1 skipped (the obs test needs ../observable-workflow)
```

## Commands

| Command | What it does |
|---|---|
| `python -m agentcost check` | the checksums, the size of the sample, our price table against the recorded costs |
| `python -m agentcost cost --by outcome` | cost, per run and per solved task, by outcome (`--by length`, `task`; `--no-cache`) |
| `python -m agentcost steps RUN --every 20` | one run, model call by model call |
| `python -m agentcost idle` | the runs with the longest streak of idle model calls |
| `python -m agentcost sweep --max-steps 30,40,50,60` | each setting of a limit under one measure (`--max-cost`, `--max-idle`) |
| `python -m agentcost limits --max-steps 60` | one setting, by outcome |
| `python -m agentcost budget --budget 0.09 --max-steps 60` | the budget alert over windows of 89 finished runs |
| `python -m agentcost report --data opus` | the whole check with the settings of `recommendation.json` |
| `python -m agentcost export` | the runs as OpenTelemetry traces (OTLP JSON) in `work/telemetry/deepseek/` |

`--data` is `deepseek` (the design sample, the default) or `opus` (the new input). The exported traces open in the
course's own tool: in `../observable-workflow`, `python -m obs cost --by outcome --data ../coding-agent-cost/work/telemetry/deepseek`.

## Files

| Path | What it holds |
|---|---|
| `agentcost/data.py` | load the runs, check the SHA-256, the outcome of a run |
| `agentcost/prices.py` and `prices.json` | the versioned price table, the cost of a step and of a run |
| `agentcost/loops.py` | idle steps: no command, only empty commands, the same commands again |
| `agentcost/limits.py` | a step, cost or idle limit checked before each model call, replayed on the recordings |
| `agentcost/budget.py` | a budget per solved task over a window of runs, and the runs that cost the most in it |
| `agentcost/otel.py` | the runs as OTLP JSON traces with the GenAI conventions' token names |
| `recommendation.json` | the chosen step limits, idle alert and budgets (a default, and one entry per model) |
| `data/runs/` | the fixed sample, its `SHA256SUMS` and the Apache-2.0 licence of the data |
| `tools/make_sample.py` | how the fixed sample was written from the reduced download |

## Licence

The code is MIT (`LICENSE`). The data is from the Terminal-Bench 2.0 leaderboard (Apache-2.0, reduced: see
`data/dataset.md`).
