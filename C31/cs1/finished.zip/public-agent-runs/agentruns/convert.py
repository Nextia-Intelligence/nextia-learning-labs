"""Convert recorded agent runs to OpenTelemetry traces (OTLP JSON), the format obs and the Collector read.

    python -m agentruns.convert design                     -> telemetry/design/traces.jsonl.gz + truth.json
    python -m agentruns.convert o4-mini
    python -m agentruns.convert design --otlp              send the traces to a Collector instead (Grafana,
                                                           optional): OTEL_EXPORTER_OTLP_ENDPOINT, the times
                                                           moved so that the last run ends now

One run (one conversation of the agent with a simulated customer) becomes one trace:

    invoke_agent retail-agent           the run: outcome, how the customer ended, the task
      chat <model>                      one span per model call: tokens, finish reason, cost, the tools it asked for
      execute_tool <tool>               one span per tool call: kind, status, order ID, a digest of the arguments
      customer_turn                     the time the customer took to answer

Times are the benchmark's recorded timestamps: a model span lasts as long as the recorded call did. The grade of
each run goes to truth.json, never on a span.
"""

import argparse
import gzip
import hashlib
import json
import os
import random
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import SpanKind, Status, StatusCode

from . import HERE
from . import names as n
from .data import load, tasks
from .store import HANDOFF, WRITE, kind
from .truth import grade_runs

AGENT = "retail-agent"
SERVICE = "tau2-retail-agent"


def ns(stamp: str) -> int:
    """The benchmark's timestamps have no time zone: we read them as UTC."""
    return int(datetime.fromisoformat(stamp).replace(tzinfo=timezone.utc).timestamp() * 1e9)


def run_id(sim: dict) -> str:
    return f"R-{int(sim['task_id']):03d}-{sim['trial']}"


def digest(args: dict) -> str:
    return hashlib.sha256(json.dumps(args, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]


def requested(call: dict) -> str:
    return f"{call['name']}({','.join(sorted(call['args']))})"


def outcome(sim: dict) -> tuple[str, str]:
    """(our outcome, how the customer ended). A transfer to a person is handed_to_person, also when the
    simulated customer then wrote ###STOP###."""
    end = next((m.get("end") for m in reversed(sim["messages"]) if m["role"] == "user"), None) or "none"
    handoff = any(c["name"] == "transfer_to_human_agents" for m in sim["messages"] for c in m.get("calls") or [])
    if handoff or end == "transfer":
        return "handed_to_person", end
    return ("resolved" if end == "stop" else end), end


class Seeded:
    """Span and trace IDs from a seed, so that the same runs give the same files every time."""

    def __init__(self, seed: int):
        self.rng = random.Random(seed)

    def is_trace_id_random(self) -> bool:
        return True

    def generate_span_id(self) -> int:
        return self.rng.getrandbits(64) or 1

    def generate_trace_id(self) -> int:
        return self.rng.getrandbits(128) or 1


def resource(dataset: str) -> Resource:
    # service.instance.id is fixed too: the SDK would add a random one, and the files would change every time
    return Resource.create({"service.name": SERVICE, "service.version": "tau2-bench v1.0.0",
                            "service.instance.id": f"tau2-retail-{dataset}"})


def provider_name(model: str) -> str:
    return "anthropic" if model.startswith("claude") else "openai"


def record(tracer, sim: dict, info: dict, shift: int = 0) -> None:
    """Make the spans of one run with the recorded times (moved by `shift` nanoseconds)."""
    model = info["agent_llm"]
    msgs = sim["messages"]
    results = {m.get("id"): m for m in msgs if m["role"] == "tool"}
    out, end = outcome(sim)
    start_ns = ns(sim["start"]) + shift
    end_ns = max([ns(sim["end"])] + [ns(m["t"]) for m in msgs if m.get("t")]) + shift
    root = tracer.start_span(f"invoke_agent {AGENT}", kind=SpanKind.INTERNAL, start_time=start_ns, attributes={
        n.OPERATION: n.OP_AGENT, n.AGENT_NAME: AGENT, n.PROVIDER: provider_name(model), n.REQUEST_MODEL: model,
        n.CONVERSATION_ID: sim["id"], n.RUN_ID: run_id(sim), n.TICKET_ID: f"task-{sim['task_id']}",
        n.LANGUAGE: "en", n.DESIGN: "llm_agent", n.RELEASE: "tau2-bench v1.0.0",
        n.OUTCOME: out, n.STOP_REASON: "finished" if sim["termination_reason"] == "user_stop" else sim["termination_reason"],
        n.CUSTOMER_END: end, n.TASK: str(sim["task_id"]), n.TRIAL: sim["trial"]})
    ctx = trace.set_span_in_context(root)
    prev, step = start_ns, 0
    for m in msgs:
        t = ns(m["t"]) + shift if m.get("t") else prev
        if m["role"] == "user":
            attrs = {n.TURN: m["turn"]}
            if m.get("end"):
                attrs[n.CUSTOMER_END] = m["end"]
            tracer.start_span(n.CUSTOMER_TURN, context=ctx, start_time=prev, attributes=attrs).end(end_time=t)
        elif m["role"] == "assistant" and m.get("model_call"):
            step += 1
            calls = m.get("calls") or []
            chat = tracer.start_span(f"chat {model}", context=ctx, kind=SpanKind.CLIENT, start_time=prev, attributes={
                n.OPERATION: n.OP_CHAT, n.PROVIDER: provider_name(model), n.REQUEST_MODEL: model,
                n.INPUT_TOKENS: m["in"], n.OUTPUT_TOKENS: m["out"],
                n.FINISH_REASONS: [m.get("finish") or ("tool_calls" if calls else "stop")],
                n.COST: m.get("cost", 0.0), n.PRICE_TABLE: "recorded by tau2-bench",
                n.REQUESTED: [requested(c) for c in calls], n.STEP: step, n.TURN: m["turn"]})
            chat.end(end_time=t)
            for c in calls:
                res = results.get(c["id"]) or {}
                done = ns(res["t"]) + shift if res.get("t") else t
                k = kind(c["name"])
                attrs = {n.OPERATION: n.OP_TOOL, n.TOOL_NAME: c["name"], n.TOOL_TYPE: "function",
                         n.TOOL_CALL_ID: c.get("id") or "", n.TOOL_KIND: k,
                         n.TOOL_STATUS: "error" if res.get("error") else "ok",
                         n.ARGS_SHAPE: ",".join(sorted(c["args"])), n.ARGS_DIGEST: digest(c["args"]), n.STEP: step}
                if isinstance(c["args"].get("order_id"), str):
                    attrs[n.ORDER_ID] = c["args"]["order_id"]
                if k == WRITE:
                    attrs[n.WRITE_OUTCOME] = "refused" if res.get("error") else "done"
                if k == HANDOFF:
                    attrs[n.TOOL_STATUS] = "handed_over"
                span = tracer.start_span(f"execute_tool {c['name']}", context=ctx, start_time=t, attributes=attrs)
                if res.get("error"):
                    span.set_attribute(n.ERROR_TYPE, "tool_error")
                    span.set_status(Status(StatusCode.ERROR, res.get("error_text", "")))
                span.end(end_time=max(done, t))
                t = max(done, t)
        prev = t
    root.end(end_time=max(end_ns, prev))


def encode(spans) -> dict:
    """OTLP JSON as the Collector's file exporter writes it (IDs in hex)."""
    import base64

    from google.protobuf.json_format import MessageToDict
    from opentelemetry.exporter.otlp.proto.common.trace_encoder import encode_spans

    def hex_ids(node):
        if isinstance(node, dict):
            for k, v in node.items():
                if k in ("traceId", "spanId", "parentSpanId") and isinstance(v, str):
                    node[k] = base64.b64decode(v).hex() if v else ""
                else:
                    hex_ids(v)
        elif isinstance(node, list):
            for x in node:
                hex_ids(x)
        return node

    return hex_ids(MessageToDict(encode_spans(spans)))


def shown(path: Path) -> str:
    """A path as the learner typed it: relative to the current folder when it is inside it."""
    try:
        return Path(path).resolve().relative_to(Path.cwd()).as_posix()
    except ValueError:
        return Path(path).as_posix()


def convert(dataset: str, out: Path) -> dict:
    info, sims = load(dataset)
    memory = InMemorySpanExporter()
    tp = TracerProvider(resource=resource(dataset),
                        id_generator=Seeded(int(hashlib.sha256(dataset.encode()).hexdigest()[:8], 16)))
    tp.add_span_processor(SimpleSpanProcessor(memory))
    tracer = tp.get_tracer("agentruns.convert")
    out.mkdir(parents=True, exist_ok=True)
    count = 0
    with open(out / "traces.jsonl.gz", "wb") as raw, gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0) as f:
        for sim in sims:
            record(tracer, sim, info)
            spans = memory.get_finished_spans()
            count += len(spans)
            f.write((json.dumps(encode(spans), ensure_ascii=False, separators=(",", ":")) + "\n").encode())
            memory.clear()
    truth = grade_runs(sims, tasks(), info, run_id)
    (out / "truth.json").write_text(json.dumps(truth, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    failed = sum(1 for r in truth["runs"] if r["failed"])
    out = shown(out)
    print(f"{dataset} ({info['agent_llm']}): {len(sims)} runs -> {count:,} spans in {out}/traces.jsonl.gz")
    print(f"the benchmark's grade -> {out}/truth.json ({failed} of {len(sims)} runs failed; obs never reads it)")
    return {"runs": len(sims), "spans": count, "failed": failed}


def send(dataset: str) -> None:
    """Send the runs to a Collector over OTLP/HTTP, moved in time so that the last run ends now."""
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

    info, sims = load(dataset)
    base = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "http://127.0.0.1:4318").rstrip("/")
    last = max(ns(s["end"]) for s in sims)
    shift = time.time_ns() - last
    tp = TracerProvider(resource=resource(dataset),
                        id_generator=Seeded(int(hashlib.sha256(dataset.encode()).hexdigest()[:8], 16)))
    exporter = OTLPSpanExporter(endpoint=f"{base}/v1/traces")
    memory = InMemorySpanExporter()
    tp.add_span_processor(SimpleSpanProcessor(memory))
    tracer = tp.get_tracer("agentruns.convert")
    sent = 0
    for sim in sims:
        record(tracer, sim, info, shift)
        spans = memory.get_finished_spans()
        if exporter.export(spans).name != "SUCCESS":
            sys.exit(f"The Collector at {base} did not accept the spans. Is Grafana running?")
        sent += len(spans)
        memory.clear()
    print(f"{dataset}: {len(sims)} runs, {sent:,} spans sent to {base}/v1/traces (times moved to end now)")


def main(argv=None) -> None:
    p = argparse.ArgumentParser(prog="python -m agentruns.convert", description=__doc__.split("\n")[0])
    p.add_argument("data", help="design, o4-mini, gpt-4.1-mini or claude-3.7-sonnet")
    p.add_argument("--out", help="folder (default telemetry/<data>)")
    p.add_argument("--otlp", action="store_true", help="send to a Collector (OTEL_EXPORTER_OTLP_ENDPOINT)")
    a = p.parse_args(argv)
    if a.otlp:
        send(a.data)
    else:
        convert(a.data, Path(a.out) if a.out else HERE / "telemetry" / a.data)


if __name__ == "__main__":
    main()
