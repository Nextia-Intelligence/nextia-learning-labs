"""Make the case study's fixed sample from one published results file of tau2-bench (MIT).

    python -I tools/make_sample.py RAW.json OUT.jsonl.gz [TASKS.jsonl.gz]

RAW.json is one results file of sierra-research/tau2-bench, folder data/tau2/results/final, release v1.0.0
(commit 17e07b1da2bbc0cadfddeea36412686e0604127b). Download it into its own new, empty folder, run this script from
another folder, then delete the download. The files we used and their SHA-256 are in data/dataset.md.

What we keep, for each simulation (one conversation of the agent with a simulated customer): its ID, task, trial,
timestamps, and for each message: who sent it and when, the agent's recorded token counts and cost, the tool calls
that the agent asked for (name and arguments), whether each tool answered with an error (and the error's short
text), and how the customer ended the conversation (###STOP###, ###TRANSFER### or ###OUT-OF-SCOPE###).
What we drop: every other text (the agent's and the customer's words, the tool results, the policy).

The benchmark's grade of each run (its reward and the checks behind it) goes in a separate "grade" object. The
converter writes it to truth.json, never on a span: a production trace has no grade.

With TASKS.jsonl.gz, the script also writes the tasks' expected actions (the benchmark's answer key), once per domain.
"""

import gzip
import json
import sys

END_TOKENS = {"###STOP###": "stop", "###TRANSFER###": "transfer", "###OUT-OF-SCOPE###": "out_of_scope"}


def end_token(text: str | None) -> str | None:
    for token, name in END_TOKENS.items():
        if token in (text or ""):
            return name
    return None


def compact_message(m: dict) -> dict:
    out = {"role": m["role"], "turn": m.get("turn_idx"), "t": m.get("timestamp")}
    if m["role"] == "assistant":
        usage = m.get("usage") or {}
        out["model_call"] = bool(m.get("usage"))
        if usage:
            out["in"], out["out"] = usage["prompt_tokens"], usage["completion_tokens"]
            out["cost"] = round(m.get("cost") or 0.0, 8)
            out["finish"] = (m.get("raw_data") or {}).get("finish_reason")
        out["text"] = bool((m.get("content") or "").strip())
        out["calls"] = [{"id": tc.get("id"), "name": tc["name"], "args": tc.get("arguments") or {}}
                        for tc in m.get("tool_calls") or []]
    elif m["role"] == "tool":
        out["id"] = m.get("id")
        out["error"] = bool(m.get("error"))
        if out["error"]:
            out["error_text"] = (m.get("content") or "")[:160]
    elif m["role"] == "user":
        out["end"] = end_token(m.get("content"))
    return out


def compact(sim: dict) -> dict:
    ri = sim["reward_info"]
    grade = {"reward": ri["reward"],
             "db_match": (ri.get("db_check") or {}).get("db_match"),
             "breakdown": ri.get("reward_breakdown") or {},
             "communicate_met": [c.get("met") for c in ri.get("communicate_checks") or []],
             "nl_met": [c.get("met") for c in ri.get("nl_assertions") or []]}
    return {"id": sim["id"], "task_id": sim["task_id"], "trial": sim["trial"],
            "start": sim["start_time"], "end": sim["end_time"], "duration_s": round(sim["duration"], 3),
            "termination_reason": sim["termination_reason"],
            "agent_cost_usd": round(sim["agent_cost"] or 0.0, 8), "user_cost_usd": round(sim["user_cost"] or 0.0, 8),
            "messages": [compact_message(m) for m in sim["messages"]], "grade": grade}


def main(raw: str, out: str, tasks_out: str | None = None) -> None:
    with open(raw, encoding="utf-8") as f:
        d = json.load(f)
    i = d["info"]
    info = {"agent_llm": i["agent_info"]["llm"], "user_llm": i["user_info"]["llm"],
            "domain": i["environment_info"]["domain_name"], "max_steps": i["max_steps"],
            "max_errors": i["max_errors"], "num_trials": i["num_trials"], "tau2_git_commit": i.get("git_commit")}
    with gzip.open(out, "wt", encoding="utf-8", compresslevel=9) as f:
        f.write(json.dumps({"info": info}) + "\n")
        for s in d["simulations"]:
            f.write(json.dumps(compact(s), separators=(",", ":"), ensure_ascii=False) + "\n")
    print(out, len(d["simulations"]), "simulations", info)
    if tasks_out:
        with gzip.open(tasks_out, "wt", encoding="utf-8", compresslevel=9) as f:
            for t in d["tasks"]:
                ec = t.get("evaluation_criteria") or {}
                f.write(json.dumps({"id": t["id"],
                                    "actions": [{"name": a["name"], "args": a.get("arguments") or {}}
                                                for a in ec.get("actions") or []],
                                    "communicate": len(ec.get("communicate_info") or [])},
                                   separators=(",", ":"), ensure_ascii=False) + "\n")
        print(tasks_out, len(d["tasks"]), "tasks")


if __name__ == "__main__":
    main(*sys.argv[1:])
