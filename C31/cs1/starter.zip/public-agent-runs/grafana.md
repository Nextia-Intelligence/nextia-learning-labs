# The store's runs in Grafana (optional, Docker)

Grafana is optional: every step of the case study also works with `python -m obs` and `python -m agentruns`.

1. In the course project's folder (`observable-workflow`), start Grafana:
   `docker compose -f grafana/compose.yaml up -d`
2. In this folder, send the design runs to its Collector. The times move so that the last run ends now:
   `python -m agentruns.convert design --otlp`
3. Open http://127.0.0.1:3031, then **Explore**, choose **Tempo**, and choose the **TraceQL** query type.
   Set the time range to **Last 1 hour**.
4. When you have finished: `docker compose -f grafana/compose.yaml down -v` (in `observable-workflow`).

The Collector's tail sampling keeps a trace with a write, an error or more than 30 seconds: almost every run here.

## TraceQL queries

| Question | TraceQL |
|---|---|
| Every run of the store's agent | `{ resource.service.name = "tau2-retail-agent" && span.gen_ai.operation.name = "invoke_agent" }` |
| A change that the store refused (refused_change, before the "repaired later" check) | `{ resource.service.name = "tau2-retail-agent" && span.larkfield.write.outcome = "refused" }` |
| A failed call in a run that ended resolved (hidden_tool_error, before the "later success" check) | `{ span.larkfield.outcome = "resolved" } && { resource.service.name = "tau2-retail-agent" && status = error }` |
| Handed to a person | `{ resource.service.name = "tau2-retail-agent" && span.gen_ai.tool.name = "transfer_to_human_agents" }` |
| Slow model calls (over 5 s) | `{ resource.service.name = "tau2-retail-agent" && span.gen_ai.operation.name = "chat" && duration > 5s }` |

TraceQL cannot compare one span with a later span of the same trace, or count calls with the same arguments.
The rules in `agentruns/rules.py` do that on the saved telemetry. Use TraceQL to find the candidates and to read
their waterfalls.
