"""The fixed sample: checksums, sizes and the numbers that the case study quotes."""

import json
from collections import Counter

from agentruns import data
from agentruns.convert import outcome
from agentruns.store import KINDS


def test_every_file_matches_its_checksum():
    for name in data.sums():
        data.checked(name)


def test_the_design_runs():
    info, runs = data.load("design")
    assert info["agent_llm"] == "gpt-4.1-2025-04-14" and info["domain"] == "retail"
    assert len(runs) == 456 and len({r["task_id"] for r in runs}) == 114
    assert sum(r["grade"]["reward"] == 0 for r in runs) == 118
    assert Counter(outcome(r)[0] for r in runs) == {"resolved": 428, "handed_to_person": 28}


def test_every_tool_has_a_kind():
    used = {c["name"] for d in data.DATASETS for r in data.load(d)[1] for m in r["messages"] for c in m.get("calls") or []}
    assert used <= set(KINDS), used - set(KINDS)


def test_no_text_in_the_sample():
    _, runs = data.load("design")
    keys = {k for r in runs for m in r["messages"] for k in m}
    assert "content" not in keys and "text" in keys            # "text" is a yes/no: the agent wrote to the customer
    assert json.dumps(runs).count("###STOP###") == 0
