"""The measure: failed runs found when a person reviews a fixed number of runs."""

from agentruns.compare import found


def test_the_tiny_example():
    # 10 runs, 3 failed. A rule flags 4 runs, and 2 of them failed: a hit rate of 50% against a base rate of 30%.
    # With 2 reviews: at random 2 x 3/10 = 0.6 failed runs found; flagged runs first 2 x 2/4 = 1.0.
    assert found(2, 10, 3, 0, 0) == 0.6
    assert found(2, 10, 3, 4, 2) == 1.0
    # With 6 reviews: the 4 flagged runs (2 failed), then 2 of the 6 others at random (1 failed among them).
    assert round(found(6, 10, 3, 4, 2), 4) == round(2 + 2 * 1 / 6, 4)


def test_no_flag_is_the_random_sample():
    assert found(5, 100, 20, 0, 0) == 5 * 20 / 100
