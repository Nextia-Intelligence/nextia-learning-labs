"""A tiny run, written by hand in the sample's format: the case study's small worked example."""

import gzip
import json

from agentruns import convert

INFO = {"agent_llm": "gpt-4.1-2025-04-14", "user_llm": "gpt-4.1-2025-04-14", "domain": "retail"}


def message(role, t, **kw):
    return {"role": role, "turn": kw.pop("turn", 0), "t": f"2025-06-05T15:00:{t:06.3f}", **kw}


def tiny_run(task="7", trial=0, calls=None, end="stop", reward=1.0):
    """The customer asks to cancel an order. Times in seconds after 15:00:00."""
    calls = calls if calls is not None else [
        ("find_user_id_by_email", {"email": "sam@example.com"}, None),
        ("get_order_details", {"order_id": "#W1"}, None),
        ("cancel_pending_order", {"order_id": "#W1", "reason": "no longer needed"}, None),
    ]
    msgs = [message("assistant", 0.0, model_call=False, text=True, calls=[]),
            message("user", 4.0, end=None)]
    t = 4.0
    for i, (name, args, error) in enumerate(calls):
        t += 1.0
        msgs.append(message("assistant", t, model_call=True, **{"in": 1000 + i, "out": 20}, cost=0.002,
                            finish="tool_calls", text=False, calls=[{"id": f"c{i}", "name": name, "args": args}]))
        res = {"id": f"c{i}", "error": bool(error)}
        if error:
            res["error_text"] = error
        msgs.append(message("tool", t + 0.01, **res))
    msgs.append(message("assistant", t + 2.0, model_call=True, **{"in": 1500, "out": 40}, cost=0.003,
                        finish="stop", text=True, calls=[]))
    msgs.append(message("user", t + 3.0, end=end))
    return {"id": f"sim-{task}-{trial}", "task_id": task, "trial": trial, "start": msgs[0]["t"], "end": msgs[-1]["t"],
            "duration_s": t + 3.0, "termination_reason": "user_stop", "agent_cost_usd": 0.0, "user_cost_usd": 0.0,
            "messages": msgs, "grade": {"reward": reward, "db_match": reward == 1.0,
                                        "breakdown": {"DB": reward, "COMMUNICATE": 1.0}}}


def write_telemetry(folder, sims, tasks=None):
    """Convert hand-made runs into a telemetry folder, as agentruns.convert does with the real ones."""
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor
    from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

    from agentruns.truth import grade_runs

    memory = InMemorySpanExporter()
    tp = TracerProvider(resource=convert.resource("test"), id_generator=convert.Seeded(1))
    tp.add_span_processor(SimpleSpanProcessor(memory))
    tracer = tp.get_tracer("test")
    folder.mkdir(parents=True, exist_ok=True)
    with gzip.open(folder / "traces.jsonl.gz", "wt", encoding="utf-8") as f:
        for sim in sims:
            convert.record(tracer, sim, INFO)
            f.write(json.dumps(convert.encode(memory.get_finished_spans())) + "\n")
            memory.clear()
    tasks = tasks or {s["task_id"]: {"id": s["task_id"], "actions": []} for s in sims}
    (folder / "truth.json").write_text(json.dumps(grade_runs(sims, tasks, INFO, convert.run_id)))
    return folder
