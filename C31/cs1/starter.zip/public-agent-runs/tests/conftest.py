import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import agentruns  # noqa: E402,F401  (finds the course project and its obs)
