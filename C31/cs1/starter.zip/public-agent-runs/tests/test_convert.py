"""The converter: one run becomes one trace with the course's names, the recorded times and no personal values."""

import json

from obs.model import Telemetry

from helpers import tiny_run, write_telemetry


def test_one_run_becomes_one_trace_with_the_genai_names(tmp_path):
    t = Telemetry(write_telemetry(tmp_path / "t", [tiny_run()]))
    run = t.runs["R-007-0"]
    assert len(run.trace_ids) == 1
    names = [s.name for s in run.spans]
    assert names[0] == "invoke_agent retail-agent"
    assert names.count("chat gpt-4.1-2025-04-14") == 4          # 3 calls with a tool, 1 answer
    assert [s.tool for s in run.tool_spans] == ["find_user_id_by_email", "get_order_details", "cancel_pending_order"]
    assert names.count("customer_turn") == 2
    assert run.root.get("gen_ai.operation.name") == "invoke_agent"
    assert run.outcome == "resolved"
    assert run.tokens == (1000 + 1001 + 1002 + 1500, 20 * 3 + 40)


def test_the_spans_keep_the_recorded_times(tmp_path):
    run = Telemetry(write_telemetry(tmp_path / "t", [tiny_run()])).runs["R-007-0"]
    first_chat = run.model_spans[0]
    assert round(first_chat.seconds, 3) == 1.0          # from the customer's message (4 s) to the answer (5 s)
    assert round(run.root.seconds, 3) == 10.0           # 0 s to the customer's last message at 10 s
    turns = [s for s in run.spans if s.name == "customer_turn"]
    assert round(turns[0].seconds, 3) == 4.0


def test_tool_kinds_statuses_and_the_order_id(tmp_path):
    sim = tiny_run(calls=[("find_user_id_by_email", {"email": "sam@example.com"}, "Error: User not found"),
                          ("cancel_pending_order", {"order_id": "#W1", "reason": "x"}, "Error: Non-pending order")])
    run = Telemetry(write_telemetry(tmp_path / "t", [sim])).runs["R-007-0"]
    lookup, cancel = run.tool_spans
    assert lookup.get("larkfield.tool.kind") == "read" and lookup.error
    assert lookup.status_message == "Error: User not found"
    assert cancel.get("larkfield.tool.kind") == "write"
    assert cancel.get("larkfield.write.outcome") == "refused"
    assert cancel.get("larkfield.order.id") == "#W1"


def test_no_name_email_or_zip_and_no_grade_on_the_spans(tmp_path):
    folder = write_telemetry(tmp_path / "t", [tiny_run(reward=0.0)])
    import gzip
    text = gzip.open(folder / "traces.jsonl.gz", "rt").read()
    assert "sam@example.com" not in text
    assert "reward" not in text and "db_match" not in text
    run = Telemetry(folder).runs["R-007-0"]
    assert run.tool_spans[0].get("larkfield.tool.arguments") == "email"      # the names, not the values
    assert len(run.tool_spans[0].get("tau2.tool.arguments_digest")) == 16
    truth = json.loads((folder / "truth.json").read_text())
    assert truth["runs"][0]["failed"] is True


def test_a_transfer_is_handed_to_person(tmp_path):
    sim = tiny_run(calls=[("transfer_to_human_agents", {"summary": "wants a refund in cash"}, None)], end="transfer")
    run = Telemetry(write_telemetry(tmp_path / "t", [sim])).runs["R-007-0"]
    assert run.outcome == "handed_to_person"
    assert run.tool_spans[0].get("larkfield.tool.kind") == "handoff"
