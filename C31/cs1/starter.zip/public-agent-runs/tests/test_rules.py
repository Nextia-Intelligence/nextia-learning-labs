"""The store's rules on tiny runs, and why the course's rules flag these runs wrongly."""

from obs.model import Telemetry

from agentruns.rules import flag_run
from helpers import tiny_run, write_telemetry

LOOKUP = ("find_user_id_by_email", {"email": "a@example.com"}, None)


def run_of(tmp_path, calls, **kw):
    return Telemetry(write_telemetry(tmp_path / "t", [tiny_run(calls=calls, **kw)])).runs["R-007-0"]


def test_three_different_orders_are_not_a_loop(tmp_path):
    run = run_of(tmp_path, [LOOKUP] + [("get_order_details", {"order_id": f"#W{i}"}, None) for i in range(3)])
    assert "loop" in run.flags                      # the course's rule counts tool + argument NAMES
    assert "loop" not in flag_run(run)              # the store's rule counts the same arguments


def test_the_same_order_three_times_is_a_loop(tmp_path):
    run = run_of(tmp_path, [LOOKUP] + [("get_order_details", {"order_id": "#W1"}, None)] * 3)
    why = flag_run(run)["loop"]
    assert why.startswith("get_order_details with the same arguments") and "3 times" in why


def test_two_different_writes_are_not_a_duplicate(tmp_path):
    run = run_of(tmp_path, [LOOKUP, ("cancel_pending_order", {"order_id": "#W1", "reason": "x"}, None),
                            ("cancel_pending_order", {"order_id": "#W2", "reason": "x"}, None)])
    assert "duplicate_write" in run.flags           # the course's rule: the same idempotency key (none)
    assert "duplicate_write" not in flag_run(run)


def test_the_same_write_twice_is_a_duplicate(tmp_path):
    w = ("cancel_pending_order", {"order_id": "#W1", "reason": "x"}, None)
    assert "accepted twice" in flag_run(run_of(tmp_path, [LOOKUP, w, w]))["duplicate_write"]


def test_the_policys_second_lookup_is_not_a_hidden_error(tmp_path):
    run = run_of(tmp_path, [("find_user_id_by_email", {"email": "a@example.com"}, "Error: User not found"),
                            ("find_user_id_by_name_zip", {"first_name": "A", "last_name": "B", "zip": "1"}, None)])
    assert "hidden_tool_error" in run.flags         # the course's rule: no later call of the SAME tool
    assert "hidden_tool_error" not in flag_run(run)


def test_a_refused_change_that_was_never_repaired(tmp_path):
    bad = ("exchange_delivered_order_items", {"order_id": "#W1", "item_ids": ["1"], "new_item_ids": ["2"]},
           "Error: Non-delivered order cannot be exchanged")
    flags = flag_run(run_of(tmp_path, [LOOKUP, bad]))
    assert flags["refused_change"].startswith("the store refused exchange_delivered_order_items #W1")
    assert "hidden_tool_error" in flags             # the run ended resolved after the failed call


def test_a_refused_change_that_was_repaired_is_not_flagged(tmp_path):
    bad = ("modify_pending_order_items", {"order_id": "#W1", "item_ids": ["1"], "new_item_ids": ["1"]},
           "Error: The new item id should be different from the old item")
    good = ("modify_pending_order_items", {"order_id": "#W1", "item_ids": ["1"], "new_item_ids": ["2"]}, None)
    assert flag_run(run_of(tmp_path, [LOOKUP, bad, good])) == {}


def test_a_clean_run_has_no_flag(tmp_path):
    assert flag_run(run_of(tmp_path, None)) == {}
