"""Check the flags against the benchmark's grade (truth.json): how many flagged runs really failed?

    python -m agentruns.check --data telemetry/design --rules course
    python -m agentruns.check --data telemetry/design --rules store
    python -m agentruns.check --data telemetry/design --run R-051-0      one run: its flags and its grade

The HIT RATE of a rule is the share of the runs it flags that really failed. Compare it with the BASE RATE, the
share of all runs that failed: a rule is useful when its hit rate is clearly higher.
"""

import argparse
import json
from collections import Counter

from .flags import SETS, flagged, truth

WHY = ["wrong_arguments", "different_changes", "unasked_change", "missing_change", "no_change",
       "right_changes_not_told", "other"]


def check(data: str, rules: str) -> dict:
    t, flags = flagged(data, rules)
    grade = truth(data)
    failed = {rid for rid, g in grade.items() if g["failed"]}
    names = sorted({x for f in flags.values() for x in f}, key=lambda x: -sum(x in f for f in flags.values()))
    rows = []
    for x in names + ["any rule"]:
        hit = {rid for rid, f in flags.items() if (f if x == "any rule" else x in f)}
        rows.append({"rule": x, "flagged": len(hit), "failed": len(hit & failed)})
    anyf = {rid for rid, f in flags.items() if f}
    by_why = Counter(grade[rid]["why"] for rid in failed)
    seen = Counter(grade[rid]["why"] for rid in failed & anyf)
    return {"data": data, "rules": rules, "runs": len(t.runs), "failed": len(failed), "rows": rows,
            "why": [{"why": w, "failed": by_why[w], "flagged": seen[w]} for w in WHY if by_why[w]]}


def show(r: dict) -> str:
    out = [f"{r['runs']} runs, {r['failed']} failed by the benchmark's grade: base rate "
           f"{r['failed'] / r['runs']:.0%}. The {r['rules']}'s rules:",
           f"  {'rule':<20} {'flagged':>7} {'failed':>7} {'hit rate':>9}"]
    for x in r["rows"]:
        rate = f"{x['failed'] / x['flagged']:.0%}" if x["flagged"] else "-"
        out.append(f"  {x['rule']:<20} {x['flagged']:>7} {x['failed']:>7} {rate:>9}")
    caught = sum(w["flagged"] for w in r["why"])
    out.append(f"Failed runs that a rule flagged: {caught} of {r['failed']}. Why they failed (truth.json):")
    out.append(f"  {'why':<24} {'failed':>7} {'flagged':>8}")
    for w in r["why"]:
        out.append(f"  {w['why']:<24} {w['failed']:>7} {w['flagged']:>8}")
    return "\n".join(out)


def one(data: str, run_id: str) -> str:
    grade = truth(data).get(run_id)
    if grade is None:
        raise SystemExit(f"No run {run_id} in {data}.")
    lines = [f"{run_id} (task {grade['task_id']}, trial {grade['trial']}): the benchmark's grade "
             f"{grade['reward']:g}" + (f", failed: {grade['why']}" if grade["failed"] else ", passed")]
    if grade["arguments_that_differ"]:
        lines.append(f"  arguments that differ from the expected change: {', '.join(grade['arguments_that_differ'])}")
    lines.append(f"  changes made {grade['changes']}, expected {grade['expected_changes']}; database as expected: "
                 f"{'yes' if grade['db_match'] else 'no'}; customer told what they had to hear: "
                 f"{'yes' if grade['told_customer'] else 'no'}")
    for rules in SETS:
        _, flags = flagged(data, rules)
        f = flags.get(run_id) or {}
        lines.append(f"  the {rules}'s rules: " + ("; ".join(f"{k}: {v}" for k, v in f.items()) or "no flag"))
    return "\n".join(lines)


def main(argv=None) -> None:
    p = argparse.ArgumentParser(prog="python -m agentruns.check")
    p.add_argument("--data", default="design")
    p.add_argument("--rules", choices=SETS, default="store")
    p.add_argument("--json", help="also write the numbers to this file")
    p.add_argument("--run", help="show one run's flags and grade")
    a = p.parse_args(argv)
    if a.run:
        print(one(a.data, a.run))
        return
    r = check(a.data, a.rules)
    print(show(r))
    if a.json:
        from pathlib import Path
        Path(a.json).parent.mkdir(parents=True, exist_ok=True)
        with open(a.json, "w", encoding="utf-8") as f:
            json.dump(r, f, indent=1)


if __name__ == "__main__":
    main()
