"""Find failures in public agent runs: tau2-bench's retail runs, converted to OpenTelemetry and read with obs.

The course's tool `obs` lives in the course project (observable-workflow). This package reads the same saved
telemetry with the same code, so it needs that project: by default the folder ../observable-workflow next to this
one, or the folder in the environment variable OBS_PROJECT.
"""

import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent


def course_project() -> Path:
    return Path(os.environ.get("OBS_PROJECT") or HERE.parent / "observable-workflow").resolve()


def _use_course_obs() -> None:
    project = course_project()
    if not (project / "obs" / "model.py").exists():
        sys.exit(f"The course project is not in {project}. Put this folder next to observable-workflow, "
                 "or set OBS_PROJECT to the course project's folder.")
    if str(project) not in sys.path:
        sys.path.insert(0, str(project))


_use_course_obs()
