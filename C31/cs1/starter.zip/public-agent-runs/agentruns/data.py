"""The fixed sample: tau2-bench retail runs (MIT), checked with SHA-256 before they are read.

    data/runs/retail-<model>.jsonl.gz   line 1: {"info": ...}; then one simulation (run) per line
    data/runs/retail-tasks.jsonl.gz     the 114 tasks' expected actions (the benchmark's answer key)
    data/runs/SHA256SUMS                the checksums
"""

import gzip
import hashlib
import json
from pathlib import Path

from . import HERE

RUNS = HERE / "data" / "runs"
DATASETS = {   # name on the command line -> file
    "design": "retail-gpt-4.1",            # the runs we study and choose the rules on
    "gpt-4.1": "retail-gpt-4.1",
    "o4-mini": "retail-o4-mini",            # new input: other models on the same 114 tasks
    "gpt-4.1-mini": "retail-gpt-4.1-mini",
    "claude-3.7-sonnet": "retail-claude-3.7-sonnet",
}


def sums() -> dict[str, str]:
    out = {}
    for line in (RUNS / "SHA256SUMS").read_text().splitlines():
        if line.strip():
            digest, name = line.split()
            out[name] = digest
    return out


def checked(name: str) -> Path:
    path = RUNS / name
    want = sums().get(name)
    got = hashlib.sha256(path.read_bytes()).hexdigest()
    if want != got:
        raise SystemExit(f"{path}: SHA-256 {got[:12]}... is not the one in data/runs/SHA256SUMS. "
                         "Download the case study again.")
    return path


def load(dataset: str) -> tuple[dict, list[dict]]:
    """(info, runs) of one dataset, in the benchmark's order."""
    if dataset not in DATASETS:
        raise SystemExit(f"Unknown data {dataset}: use one of {', '.join(DATASETS)}")
    with gzip.open(checked(DATASETS[dataset] + ".jsonl.gz"), "rt", encoding="utf-8") as f:
        info = json.loads(f.readline())["info"]
        runs = [json.loads(line) for line in f if line.strip()]
    return info, runs


def tasks() -> dict[str, dict]:
    with gzip.open(checked("retail-tasks.jsonl.gz"), "rt", encoding="utf-8") as f:
        return {t["id"]: t for t in map(json.loads, f) if t}
