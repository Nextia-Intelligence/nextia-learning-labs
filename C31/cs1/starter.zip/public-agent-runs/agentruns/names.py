"""The names on the converted spans: the course's names, written once.

The GenAI names are the ones that the course project pins (observable-workflow, resolver/conventions.py: the
GenAI conventions at one commit, status development). obs reads the course's own names, which start with
"larkfield." because obs was built for Larkfield's workflow. We write them where they mean the same thing (a run
ID, an outcome, a tool's kind and status, an order ID, a cost), so that obs reads these runs unchanged.
The benchmark's own facts get our own prefix, "tau2.".

Rule (the course's): a name carries a count, a status, an ID or a name of a model or a tool. Never a text and never
a customer's name, e-mail address or zip code: the arguments are kept as their names and a digest.
"""

# GenAI (development), as in the course project's resolver/conventions.py
OPERATION = "gen_ai.operation.name"
PROVIDER = "gen_ai.provider.name"
REQUEST_MODEL = "gen_ai.request.model"
FINISH_REASONS = "gen_ai.response.finish_reasons"
INPUT_TOKENS = "gen_ai.usage.input_tokens"
OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
CONVERSATION_ID = "gen_ai.conversation.id"
AGENT_NAME = "gen_ai.agent.name"
TOOL_NAME = "gen_ai.tool.name"
TOOL_TYPE = "gen_ai.tool.type"
TOOL_CALL_ID = "gen_ai.tool.call.id"
ERROR_TYPE = "error.type"
OP_AGENT, OP_CHAT, OP_TOOL = "invoke_agent", "chat", "execute_tool"

# The course's own names (obs reads them)
RUN_ID = "larkfield.run.id"
TICKET_ID = "larkfield.ticket.id"
LANGUAGE = "larkfield.ticket.language"
DESIGN = "larkfield.design"
RELEASE = "larkfield.release"
OUTCOME = "larkfield.outcome"
STOP_REASON = "larkfield.stop_reason"
STEP = "larkfield.step"
COST = "larkfield.cost.usd"
PRICE_TABLE = "larkfield.price_table"
REQUESTED = "larkfield.model.requested"
TOOL_KIND = "larkfield.tool.kind"
TOOL_STATUS = "larkfield.tool.status"
ARGS_SHAPE = "larkfield.tool.arguments"
ORDER_ID = "larkfield.order.id"
WRITE_OUTCOME = "larkfield.write.outcome"

# The benchmark's own facts (our prefix)
TASK = "tau2.task.id"
TRIAL = "tau2.trial"
CUSTOMER_END = "tau2.customer.end"       # how the simulated customer ended: stop, transfer, out_of_scope
TURN = "tau2.turn"
ARGS_DIGEST = "tau2.tool.arguments_digest"   # the same call twice has the same digest; the values stay out
CUSTOMER_TURN = "customer_turn"          # span name: the time the customer took to answer (not a GenAI operation)
