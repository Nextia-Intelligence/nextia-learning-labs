"""The benchmark's grade of each run, and why a failed run failed (truth.json). Spans never carry it.

tau2-bench grades a retail run by its end: the store's database must match the database that the task's expected
actions make, and the agent must tell the customer what the task says (reward 1 or 0). We add one more field,
`why`: the difference between the changes the agent made (its writes that the store accepted) and the expected
ones.

    right_changes_not_told  the right changes, but the customer was not told something they had to hear
    wrong_arguments         the right tool, with other arguments (another item, payment method or order)
    unasked_change          a change that the task did not ask for
    missing_change          a change that the task asked for is not there
    no_change               no change at all, and the task expected some
    different_changes       other changes than the expected ones
    other                   the changes match, and the grade failed for another reason
"""

from collections import Counter
import json

from .store import WRITE, kind


def _key(name: str, args: dict) -> tuple:
    return name, json.dumps(args, sort_keys=True, ensure_ascii=False)


def accepted_writes(sim: dict) -> list[tuple[str, dict]]:
    results = {m.get("id"): m for m in sim["messages"] if m["role"] == "tool"}
    return [(c["name"], c["args"]) for m in sim["messages"] for c in m.get("calls") or []
            if kind(c["name"]) == WRITE and not (results.get(c["id"]) or {}).get("error")]


def why(sim: dict, task: dict) -> tuple[str, list[str]]:
    """(the category, the argument names that differ for wrong_arguments)."""
    expected = Counter(_key(a["name"], a["args"]) for a in task["actions"] if kind(a["name"]) == WRITE)
    got = Counter(_key(n, a) for n, a in accepted_writes(sim))
    missing, extra = expected - got, got - expected
    if not missing and not extra:
        return ("right_changes_not_told" if sim["grade"]["breakdown"].get("COMMUNICATE") == 0 else "other"), []
    if not got:
        return "no_change", []
    shared = {k[0] for k in missing} & {k[0] for k in extra}
    if shared:
        diff = set()
        for tool in shared:
            want = [json.loads(k[1]) for k in missing if k[0] == tool]
            have = [json.loads(k[1]) for k in extra if k[0] == tool]
            for w, h in zip(want, have):
                diff |= {name for name in set(w) | set(h) if w.get(name) != h.get(name)}
        return "wrong_arguments", sorted(diff)
    if extra and not missing:
        return "unasked_change", []
    if missing and not extra:
        return "missing_change", []
    return "different_changes", []


def grade_runs(sims: list[dict], tasks: dict, info: dict, run_id) -> dict:
    runs = []
    for s in sims:
        task = tasks[s["task_id"]]
        failed = s["grade"]["reward"] == 0
        category, diff = why(s, task) if failed else ("", [])
        runs.append({"run_id": run_id(s), "conversation_id": s["id"], "task_id": s["task_id"], "trial": s["trial"],
                     "reward": s["grade"]["reward"], "failed": failed, "db_match": s["grade"]["db_match"],
                     "told_customer": s["grade"]["breakdown"].get("COMMUNICATE"),
                     "expected_changes": sum(1 for a in task["actions"] if kind(a["name"]) == WRITE),
                     "changes": len(accepted_writes(s)), "why": category, "arguments_that_differ": diff})
    return {"about": "tau2-bench's grade of each run (reward 1 or 0) and why a failed run failed "
                     "(agentruns/truth.py). A production system has no such file: look at it after you have counted.",
            "agent_llm": info["agent_llm"], "runs": runs}
