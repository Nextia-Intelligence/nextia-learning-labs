"""The retail agent's tools, as tau2-bench declares them (src/tau2/domains/retail/tools.py, release v1.0.0).

The benchmark marks each tool READ, WRITE or GENERIC. Our kinds follow it: a read changes nothing, a write changes
the store's database. Of the two GENERIC tools, calculate changes nothing (we count it as a read), and
transfer_to_human_agents hands the customer to a person (kind "handoff").
"""

READ, WRITE, HANDOFF = "read", "write", "handoff"

KINDS = {
    "find_user_id_by_email": READ,
    "find_user_id_by_name_zip": READ,
    "get_user_details": READ,
    "get_order_details": READ,
    "get_product_details": READ,
    "get_item_details": READ,
    "list_all_product_types": READ,
    "calculate": READ,
    "cancel_pending_order": WRITE,
    "modify_pending_order_address": WRITE,
    "modify_pending_order_items": WRITE,
    "modify_pending_order_payment": WRITE,
    "modify_user_address": WRITE,
    "return_delivered_order_items": WRITE,
    "exchange_delivered_order_items": WRITE,
    "transfer_to_human_agents": HANDOFF,
}

# The policy's identity check: "authenticate the user identity by locating their user id via email, or via name
# + zip code" (data/tau2/domains/retail/policy.md).
AUTHENTICATE = {"find_user_id_by_email", "find_user_id_by_name_zip"}

# "Exchange or modify order tools can only be called once per order."
ONCE_PER_ORDER = {"exchange_delivered_order_items", "modify_pending_order_items"}


def kind(tool: str) -> str:
    return KINDS.get(tool, READ)
