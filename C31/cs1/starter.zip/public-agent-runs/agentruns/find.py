"""Find runs that match the store's failure rules (agentruns/rules.py), as obs find does with the course's rules.

    python -m agentruns.find all --data telemetry/design
    python -m agentruns.find refused_change --data telemetry/design
"""

import argparse

from obs.__main__ import when

from .flags import flagged
from .rules import RULES


def main(argv=None) -> None:
    p = argparse.ArgumentParser(prog="python -m agentruns.find")
    p.add_argument("pattern", nargs="?", default="all", help=f"{', '.join(RULES)} or all")
    p.add_argument("--data", default="design")
    a = p.parse_args(argv)
    names = list(RULES) if a.pattern == "all" else [a.pattern]
    if any(x not in RULES for x in names):
        raise SystemExit(f"Unknown pattern {a.pattern}: use one of {', '.join(RULES)} or all")
    t, flags = flagged(a.data, "store")
    hits = [(r, f"{x}: {flags[r.run_id][x]}") for r in t.runs.values() for x in names if x in flags[r.run_id]]
    for r, why in hits:
        print(f"{r.run_id:<8} {r.ticket:<8} {when(r.start, '%a %H:%M')}  {why}")
    print(f"{len(hits)} match(es) in {len(t.runs)} run(s), {len({r.run_id for r, _ in hits})} run(s) flagged")


if __name__ == "__main__":
    main()
