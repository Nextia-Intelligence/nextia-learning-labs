"""The retail agent's failure rules: the course's patterns, adapted to this agent, and one rule from its policy.

Each rule reads the spans of one run (obs's Run, from the course project) and returns None or a sentence that
says why, with the span names and times, so that a person can check it in the trace. Like the course's rules
(obs/flags.py), a flag is a reason to look, not a verdict.

    loop                the same tool with the same arguments (the same digest) 3 or more times in one run
    duplicate_write     two changes that the store accepted, with the same tool and the same arguments
    hidden_tool_error   a call failed, no later call of that tool succeeded (for the identity check: neither
                        lookup), and the run ended as resolved
    refused_change      the store refused a change (a write answered with an error), and no later change of the
                        same tool on the same order was accepted

What changed from the course's rules, and why:
    loop                counts the argument VALUES (a digest), not only their names: one customer has several
                        orders, and get_order_details(order_id) five times is normal here
    duplicate_write     this agent sends no idempotency key: two writes are the same when tool and arguments are
    hidden_tool_error   an identity lookup by e-mail that fails, then one by name and zip that works, is the
                        policy's normal path, not a hidden error
    no_action           dropped: the agent's reply is its text answer, not a send_reply tool, and a run with no
                        change is often right (the customer asked a question)
    followed_injection  dropped: the data has no injected instructions and no marker
"""

from collections import Counter

from obs.flags import _t as at   # the course's way to give a span's time in a reason

from . import names as n
from .store import AUTHENTICATE

LOOP_MIN = 3


def loop(run) -> str | None:
    def same(s):
        # TODO (Part 2): the course's rule counts a tool with its argument NAMES (n.ARGS_SHAPE), as below.
        # Count a tool with the digest of its arguments' values (n.ARGS_DIGEST) instead.
        return s.tool, s.get(n.ARGS_SHAPE)
    calls = Counter(same(s) for s in run.tool_spans)
    for key, count in calls.most_common(1):
        if count >= LOOP_MIN:
            first = next(s for s in run.tool_spans if same(s) == key)
            return f"{key[0]} with the same arguments ({key[1][:8]}) {count} times, first at {at(run, first)}"
    return None


def _writes(run):
    return [s for s in run.tool_spans if s.get(n.TOOL_KIND) == "write"]


def duplicate_write(run) -> str | None:
    seen = {}
    for s in _writes(run):
        if s.get(n.WRITE_OUTCOME) != "done":
            continue
        k = (s.tool, s.get(n.ARGS_DIGEST))
        if k in seen:
            return (f"{s.tool} {s.get(n.ORDER_ID, '')} was accepted twice with the same arguments: at "
                    f"{at(run, seen[k])} and at {at(run, s)}").replace("  ", " ")
        seen[k] = s
    return None


def _same_purpose(a: str, b: str) -> bool:
    return a == b or (a in AUTHENTICATE and b in AUTHENTICATE)


def hidden_tool_error(run) -> str | None:
    if run.outcome != "resolved":
        return None
    spans = run.tool_spans
    for i, s in enumerate(spans):
        if not s.error:
            continue
        if not any(_same_purpose(x.tool, s.tool) and not x.error for x in spans[i + 1:]):
            return (f"{s.tool} failed at {at(run, s)} ({s.status_message[:90]}), no later {s.tool} call "
                    "succeeded, and the run ended as resolved")
    return None


def refused_change(run) -> str | None:
    # TODO (Part 3): for each write of the run (_writes(run)) that the store refused (n.WRITE_OUTCOME is
    # "refused"), look for a LATER write of the same tool on the same order (n.ORDER_ID) that was "done".
    # If there is none, return a sentence that starts with f"the store refused {s.tool} {s.get(n.ORDER_ID, '')}"
    # and gives the time (at(run, s)) and the error (s.status_message).
    return None


RULES = {"loop": loop, "duplicate_write": duplicate_write, "hidden_tool_error": hidden_tool_error,
         "refused_change": refused_change}


def flag_run(run) -> dict:
    out = {}
    for name, rule in RULES.items():
        why = rule(run)
        if why:
            out[name] = why
    return out
