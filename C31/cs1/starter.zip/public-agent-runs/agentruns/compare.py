"""A fair comparison under one measure: the failed runs that a person finds when they review one run in five.

    python -m agentruns.compare --data design
    python -m agentruns.compare --data design o4-mini gpt-4.1-mini claude-3.7-sonnet --json results/compare.json

Every way of choosing gets the same budget (the same number of reviews), the same runs and the same grade.
    random        the reviewer takes runs at random (the course's sampled reviews)
    course        the runs that the course's five rules flag first, then others at random
    store         the runs that the store's rules flag first, then others at random
When more runs are flagged than the budget allows, the reviewer takes the flagged runs at random. The numbers are
expected values: the average over every random choice, so they do not depend on a seed.
"""

import argparse
import json
import math

from .flags import flagged, truth

BUDGET = 0.2   # one run in five, as Priya's sampled reviews


def found(budget: int, n: int, failed: int, flagged_runs: int, flagged_failed: int) -> float:
    """Expected failed runs in `budget` reviews: flagged runs first, then the others at random."""
    if flagged_runs >= budget:
        return budget * flagged_failed / flagged_runs if flagged_runs else 0.0
    rest = n - flagged_runs
    return flagged_failed + (budget - flagged_runs) * ((failed - flagged_failed) / rest if rest else 0.0)


def compare(data: str, share: float = BUDGET) -> dict:
    grade = truth(data)
    n = len(grade)
    failed = {rid for rid, g in grade.items() if g["failed"]}
    budget = math.ceil(n * share)
    out = {"data": data, "runs": n, "failed": len(failed), "budget": budget,
           "random": {"found": budget * len(failed) / n, "flagged": 0, "flagged_failed": 0}}
    for rules in ("course", "store"):
        _, flags = flagged(data, rules)
        hit = {rid for rid, f in flags.items() if f}
        out[rules] = {"found": found(budget, n, len(failed), len(hit), len(hit & failed)),
                      "flagged": len(hit), "flagged_failed": len(hit & failed)}
    return out


def show(r: dict) -> str:
    b = r["budget"]
    out = [f"{r['data']}: review {b} of {r['runs']} runs (one in five); {r['failed']} failed by the grade. "
           "Failed runs found, on average:",
           f"  {'how the reviewer chooses':<28} {'found':>6} {'hit rate':>9}"]
    for key, label in (("random", "at random"), ("course", "the course's rules first"),
                       ("store", "the store's rules first")):
        x = r[key]
        note = ""
        if key != "random":
            note = (f"  ({x['flagged']} flagged: {b} of them at random)" if x["flagged"] >= b else
                    f"  ({x['flagged']} flagged, then {b - x['flagged']} at random)")
        out.append(f"  {label:<28} {x['found']:>6.1f} {x['found'] / b:>9.0%}{note}")
    return "\n".join(out)


def main(argv=None) -> None:
    p = argparse.ArgumentParser(prog="python -m agentruns.compare")
    p.add_argument("--data", nargs="+", default=["design"])
    p.add_argument("--json", help="also write the numbers to this file")
    a = p.parse_args(argv)
    results = [compare(d) for d in a.data]
    print("\n".join(show(r) for r in results))
    if a.json:
        from pathlib import Path
        Path(a.json).parent.mkdir(parents=True, exist_ok=True)
        with open(a.json, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=1)


if __name__ == "__main__":
    main()
