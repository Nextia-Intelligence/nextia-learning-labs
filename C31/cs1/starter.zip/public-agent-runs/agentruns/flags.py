"""Read converted runs with obs's reader and flag them with the course's rules or the store's rules."""

import json
import sys
from pathlib import Path

from obs.model import Telemetry

from . import HERE

SETS = ("course", "store")


def folder(data: str) -> Path:
    """--data: a folder, or a dataset name (telemetry/<name>)."""
    p = Path(data)
    if not p.exists() and (HERE / "telemetry" / data).exists():
        p = HERE / "telemetry" / data
    if not (p / "traces.jsonl.gz").exists() and not (p / "traces.jsonl").exists():
        sys.exit(f"No converted runs in {p}. Convert them first: python -m agentruns.convert {Path(data).name}")
    return p


def flagged(data: str, rules: str) -> tuple[Telemetry, dict]:
    """The runs and their flags: {run_id: {rule: why}}. Telemetry() already ran the course's rules (obs)."""
    t = Telemetry(folder(data))
    if rules == "course":
        return t, {rid: r.flags for rid, r in t.runs.items()}
    from .rules import flag_run
    return t, {rid: flag_run(r) for rid, r in t.runs.items()}


def truth(data: str) -> dict:
    path = folder(data) / "truth.json"
    return {r["run_id"]: r for r in json.loads(path.read_text(encoding="utf-8"))["runs"]}
