# public-agent-runs: find failures in public agent runs

A case study of the course *Observability for AI Agents: Traces, Costs and Audit Trails* (Nextia Learning). It
converts 456 recorded runs of an open AI customer-service agent (τ²-bench's retail domain, MIT) to OpenTelemetry
traces with the course's GenAI names, reads them with the course's `obs`, and finds and counts their failures with
evidence: the course's rules, the same rules adapted to this agent, and a check of every flag against the
benchmark's grade.

## What you need

- The course project at the end of the course, in a folder `observable-workflow` next to this one (or set
  `OBS_PROJECT` to its folder), with its virtual environment. This folder adds no package.
- About 4 MB of disk for the converted runs of the four models.

```sh
cd public-agent-runs
source ../observable-workflow/.venv/bin/activate     # Windows: ..\observable-workflow\.venv\Scripts\Activate.ps1
python -m pytest -q                                   # 19 passed
```

## Commands

| Command | What it does |
|---|---|
| `python -m agentruns.convert design` | the design runs (gpt-4.1) to `telemetry/design/`: traces + `truth.json` |
| `python -m agentruns.convert claude-3.7-sonnet` | new input (also `o4-mini`, `gpt-4.1-mini`) |
| `python -m obs runs --data ../public-agent-runs/telemetry/design` | in `observable-workflow`: the course's tool, unchanged |
| `python -m agentruns.find all --data design` | the store's rules (`agentruns/rules.py`) |
| `python -m agentruns.check --data design --rules course` | the course's rules against the grade |
| `python -m agentruns.check --data design --rules store` | the store's rules against the grade |
| `python -m agentruns.compare --data design` | the measure: failed runs found when one run in five is reviewed |
| `python -m agentruns.convert design --otlp` | optional: send the runs to Grafana's Collector (`grafana.md`) |

## Files

| File | What it does |
|---|---|
| `data/runs/` | the fixed sample (4 files of runs, 1 of tasks, `SHA256SUMS`, the τ²-bench licence) |
| `data/dataset.md` | the dataset card: source, licence, changes, limits |
| `agentruns/names.py` | every name on the converted spans, written once |
| `agentruns/store.py` | the agent's tools: read, write or handoff, as the benchmark declares them |
| `agentruns/convert.py` | one run to one trace (OpenTelemetry SDK, OTLP JSON); `--otlp` to a Collector |
| `agentruns/truth.py` | the benchmark's grade and why a run failed, in `truth.json` (never on a span) |
| `agentruns/rules.py` | the store's failure rules |
| `agentruns/find.py`, `check.py`, `compare.py` | find, check against the grade, compare under one measure |
| `grafana.md` | the optional Grafana steps and TraceQL queries |
| `tools/make_sample.py` | how the fixed sample was made from the benchmark's results files |
| `tests/` | 19 tests |

## Licences

The code: MIT (`LICENSE`). The data: τ²-bench by Sierra Research, MIT (`data/runs/LICENSE-tau2-bench.txt`), reduced
to times, counts, names, arguments and grades by Nextia Learning (`data/dataset.md`).
