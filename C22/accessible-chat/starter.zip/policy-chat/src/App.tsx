// The policy assistant's chat: ask a question about Larkfield's policies, read the answer as it is
// written, stop it if it goes wrong. It works with a mouse. (This version has accessibility problems
// on purpose: the case study finds and fixes them.)
import { useState, type FormEvent, type KeyboardEvent } from 'react';
import { useChat } from './chat/useChat';

const SendIcon = () => (
  <svg viewBox="0 0 24 24" width="20" height="20">
    <path d="M3 20 21 12 3 4v6l12 2-12 2z" fill="currentColor" />
  </svg>
);
const StopIcon = () => (
  <svg viewBox="0 0 24 24" width="20" height="20">
    <rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" />
  </svg>
);

export function App() {
  const { messages, send, stop, busy } = useChat();
  const [question, setQuestion] = useState('');

  const submit = (e?: FormEvent) => {
    e?.preventDefault();
    if (!question.trim() || busy) return;
    send(question.trim());
    setQuestion('');
  };
  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  return (
    <div className="page">
      <header className="top">
        <h1>Policy assistant</h1>
        <p className="hint">Answers from Larkfield's policy documents. Check them before you reply to a customer.</p>
      </header>
      <main className="chat">
        <div className="log" aria-live="polite">
          {messages.map((m) => (
            <div key={m.id} className={`msg ${m.role}`} data-status={m.status}>
              <div className="who">{m.role === 'user' ? 'You' : 'Assistant'}</div>
              <div className="text">{m.text || (m.status === 'waiting' ? 'Writing…' : '')}</div>
              {m.status === 'stopped' && <div className="note">Stopped. The text is not complete.</div>}
              {m.problem && <div className="note error">{m.problem}</div>}
              {m.sources && m.sources.length > 0 && (
                <div className="sources">Sources: {m.sources.map((s) => `${s.document} (${s.section})`).join('; ')}</div>
              )}
            </div>
          ))}
        </div>
        <form className="ask" onSubmit={submit}>
          <textarea
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyDown={onKey}
            placeholder="Ask about a policy…"
            rows={2}
            disabled={busy}
          />
          {busy ? (
            <div className="stop" onClick={stop}>
              <StopIcon />
            </div>
          ) : (
            <button className="send" type="submit">
              <SendIcon />
            </button>
          )}
        </form>
      </main>
    </div>
  );
}
