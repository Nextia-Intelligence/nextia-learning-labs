import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { expect, test } from 'vitest';
import { App } from './App';
import { installFakeChat } from './test/fakeChat';

test('a question and its streamed answer appear in the conversation', async () => {
  installFakeChat('A garden sprinkler has a 1-year warranty.');
  const { container } = render(<App />);
  await userEvent.type(container.querySelector('textarea')!, 'How long is the warranty on a garden sprinkler?{Enter}');
  expect(await screen.findByText('A garden sprinkler has a 1-year warranty.')).toBeInTheDocument();
  expect(screen.getByText('How long is the warranty on a garden sprinkler?')).toBeInTheDocument();
});
