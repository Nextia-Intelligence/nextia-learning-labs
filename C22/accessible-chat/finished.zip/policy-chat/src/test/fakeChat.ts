// A fake chat API for component tests: fetch answers with a stream of server-sent events. The pieces
// come one by one; the stream stops when the request's signal is aborted (Stop).
import { vi } from 'vitest';

export function installFakeChat(answer: string, { language = 'en', gapMs = 5, sources = 1 } = {}) {
  const pieces = answer.match(/\s*[\p{L}\p{N}’'_-]+|\s*[^\p{L}\p{N}\s]/gu) ?? [];
  vi.stubGlobal('fetch', async (_url: string, init: RequestInit) => {
    const signal = init.signal!;
    const encoder = new TextEncoder();
    const body = new ReadableStream<Uint8Array>({
      async start(controller) {
        const send = (event: string, data: unknown) =>
          controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
        send('start', { id: 'Q00', language });
        for (const text of pieces) {
          await new Promise((r) => setTimeout(r, gapMs));
          if (signal.aborted) return controller.error(new DOMException('Aborted', 'AbortError'));
          send('piece', { text });
        }
        const list = Array.from({ length: sources }, (_, i) => ({ document: `Policy ${i + 1}`, section: 'Rules' }));
        send('done', { answer, sources: list, language, answerable: true });
        controller.close();
      },
    });
    return new Response(body, { status: 200, headers: { 'Content-Type': 'text/event-stream' } });
  });
}
