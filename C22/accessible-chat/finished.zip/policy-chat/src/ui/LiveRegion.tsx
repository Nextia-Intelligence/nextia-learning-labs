/**
 * A short message for screen readers, read when it changes ("polite": after what the user hears now).
 * It stays in the page, empty, so that screen readers know it before its first message.
 */
export function LiveRegion({ message }: { message: string }) {
  return (
    <p className="visually-hidden" role="status" aria-live="polite" aria-atomic="true">
      {message}
    </p>
  );
}
