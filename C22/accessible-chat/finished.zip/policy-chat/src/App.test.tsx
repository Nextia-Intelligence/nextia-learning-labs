import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { expect, test } from 'vitest';
import { App } from './App';
import { installFakeChat } from './test/fakeChat';

test('a question and its streamed answer appear in the conversation', async () => {
  installFakeChat('A garden sprinkler has a 1-year warranty.');
  render(<App />);
  await userEvent.type(screen.getByLabelText('Your question'), 'How long is the warranty on a garden sprinkler?{Enter}');
  expect(await screen.findByText('A garden sprinkler has a 1-year warranty.')).toBeInTheDocument();
});

test('the focus stays in the message box, and the status says the reply once, at the end', async () => {
  installFakeChat('A garden sprinkler has a 1-year warranty.');
  render(<App />);
  const box = screen.getByLabelText('Your question');
  await userEvent.type(box, 'How long is the warranty on a garden sprinkler?{Enter}');
  expect(box).toHaveFocus();
  expect(screen.getByRole('status')).toHaveTextContent(/^$/);
  await screen.findByText('A garden sprinkler has a 1-year warranty.');
  expect(screen.getByRole('status')).toHaveTextContent('Assistant: A garden sprinkler has a 1-year warranty. 1 source.');
});

test('Stop is a button that Tab reaches; Enter on it stops the reply', async () => {
  installFakeChat('Express delivery to Calgary takes 1 to 2 business days and costs $14.95.', { gapMs: 40 });
  render(<App />);
  await userEvent.type(screen.getByLabelText('Your question'), 'How long does express delivery to Calgary take?{Enter}');
  await userEvent.tab();
  expect(screen.getByRole('button', { name: 'Stop' })).toHaveFocus();
  await userEvent.keyboard('{Enter}');
  await waitFor(() => expect(screen.getByRole('status')).toHaveTextContent('You stopped the reply. The text is not complete.'));
  expect(screen.getByRole('button', { name: 'Send' })).toHaveFocus();
});

test('a reply in French is marked as French', async () => {
  installFakeChat('La garantie d’un barbecue dure 2 ans.', { language: 'fr' });
  render(<App />);
  await userEvent.type(screen.getByLabelText('Your question'), 'Combien de temps dure la garantie d’un barbecue?{Enter}');
  const text = await screen.findByText('La garantie d’un barbecue dure 2 ans.');
  expect(text.closest('[lang]')).toHaveAttribute('lang', 'fr');
});
