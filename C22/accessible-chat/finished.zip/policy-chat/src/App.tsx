// The policy assistant's chat: ask a question about Larkfield's policies, read the answer as it is
// written, stop it if it goes wrong. Usable by keyboard and with a screen reader: every control has a
// name, the focus stays in the message box, Stop is a real button, a reply is announced once when it
// ends, each reply is marked with its language, and the text has enough contrast.
import { useState, type FormEvent, type KeyboardEvent } from 'react';
import { announcement, wayFromAddress } from './chat/announce';
import { useChat } from './chat/useChat';
import { LiveRegion } from './ui/LiveRegion';

const SendIcon = () => (
  <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
    <path d="M3 20 21 12 3 4v6l12 2-12 2z" fill="currentColor" />
  </svg>
);
const StopIcon = () => (
  <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
    <rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" />
  </svg>
);

// Read once: the comparison of the case study opens /?announce=pieces, busy, sentences or reply.
const way = wayFromAddress(window.location.search);

export function App() {
  const { messages, send, stop, busy } = useChat();
  const [question, setQuestion] = useState('');

  const submit = (e?: FormEvent) => {
    e?.preventDefault();
    if (!question.trim() || busy) return;
    send(question.trim());
    setQuestion('');
  };
  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      submit();
    } else if (e.key === 'Escape' && busy) {
      stop();
    }
  };
  // Only for the comparison: the conversation itself as a live region (the first two ways).
  const live = way === 'pieces' || way === 'busy' ? { 'aria-live': 'polite' as const } : {};

  return (
    <div className="page" data-announce={way}>
      <header className="top">
        <h1>Policy assistant</h1>
        <p className="hint">Answers from Larkfield's policy documents. Check them before you reply to a customer.</p>
      </header>
      <main className="chat">
        <section className="log" aria-label="Conversation" {...live} aria-busy={way === 'busy' ? busy : undefined}>
          {messages.map((m) => (
            <div key={m.id} className={`msg ${m.role}`} data-status={m.status} lang={m.language}>
              <div className="who">{m.role === 'user' ? 'You' : 'Assistant'}</div>
              <div className="text">{m.text || (m.status === 'waiting' ? 'Writing…' : '')}</div>
              {m.status === 'stopped' && <div className="note">Stopped. The text is not complete.</div>}
              {m.problem && <div className="note error">{m.problem}</div>}
              {m.sources && m.sources.length > 0 && (
                <div className="sources">Sources: {m.sources.map((s) => `${s.document} (${s.section})`).join('; ')}</div>
              )}
            </div>
          ))}
        </section>
        <LiveRegion message={announcement(way, messages.at(-1))} />
        <form className="ask" onSubmit={submit}>
          <label htmlFor="question">Your question</label>
          <div className="ask-row">
            {/* Never disabled: a disabled field loses the focus, and the focus falls to the page. */}
            <textarea
              id="question"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              onKeyDown={onKey}
              placeholder="For example: how long does a refund take?"
              aria-describedby="question-help"
              rows={2}
            />
            {/* One real button whose label changes: Tab reaches it, Enter and Space press it. */}
            <button className={busy ? 'stop' : 'send'} type={busy ? 'button' : 'submit'} onClick={busy ? stop : undefined}>
              {busy ? <StopIcon /> : <SendIcon />}
              <span>{busy ? 'Stop' : 'Send'}</span>
            </button>
          </div>
          <p id="question-help" className="help">
            Enter sends. Shift+Enter starts a new line. Escape stops a reply.
          </p>
        </form>
      </main>
    </div>
  );
}
