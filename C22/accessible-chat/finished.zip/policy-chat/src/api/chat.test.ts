import { expect, test } from 'vitest';
import { parseEvents } from './chat';

test('an event cut in two waits for its second half', () => {
  const first = parseEvents('event: piece\ndata: {"text":"We"}\n\nevent: piece\ndata: {"te');
  expect(first.events).toEqual([{ event: 'piece', data: '{"text":"We"}' }]);
  const second = parseEvents(first.rest + 'xt":" refund"}\n\n');
  expect(second.events).toEqual([{ event: 'piece', data: '{"text":" refund"}' }]);
  expect(second.rest).toBe('');
});
