// Asks the mock chat API a question and reads the answer as server-sent events, piece by piece.
// fetch + a stream reader, because EventSource can only send GET requests.

const API = import.meta.env.VITE_API_URL ?? 'http://127.0.0.1:8200';

export interface Source {
  document: string;
  section: string;
}

/** What the stream can tell the interface. */
export type ChatEvent =
  | { type: 'start'; language: string }
  | { type: 'piece'; text: string }
  | { type: 'done'; answer: string; sources: Source[]; language: string; answerable: boolean };

/** Splits text that arrives in parts into complete server-sent events. */
export function parseEvents(buffer: string): { events: { event: string; data: string }[]; rest: string } {
  const events: { event: string; data: string }[] = [];
  const blocks = buffer.replace(/\r\n?/g, '\n').split('\n\n');
  const rest = blocks.pop() ?? '';
  for (const block of blocks) {
    let event = 'message';
    const data: string[] = [];
    for (const line of block.split('\n')) {
      if (line.startsWith('event:')) event = line.slice(6).trim();
      else if (line.startsWith('data:')) data.push(line.slice(5).replace(/^ /, ''));
    }
    if (data.length) events.push({ event, data: data.join('\n') });
  }
  return { events, rest };
}

/** Sends the question; calls onEvent for every event until the answer is done or the signal stops it. */
export async function ask(question: string, onEvent: (e: ChatEvent) => void, signal: AbortSignal): Promise<void> {
  const res = await fetch(`${API}/v1/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' },
    body: JSON.stringify({ question }),
    signal,
  });
  if (!res.ok || !res.body) throw new Error(`The assistant did not answer (HTTP ${res.status}). Try again.`);
  const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
  let buffer = '';
  let done = false;
  while (!done) {
    const { value, done: end } = await reader.read();
    if (end) break;
    const parsed = parseEvents(buffer + value);
    buffer = parsed.rest;
    for (const { event, data } of parsed.events) {
      const body = JSON.parse(data);
      if (event === 'start') onEvent({ type: 'start', language: body.language ?? 'en' });
      else if (event === 'piece') onEvent({ type: 'piece', text: body.text });
      else if (event === 'done') {
        onEvent({ type: 'done', ...body });
        done = true;
      }
    }
  }
  if (!done) throw new Error('The connection ended before the answer was finished. Try again.');
}
