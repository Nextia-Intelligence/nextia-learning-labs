// The conversation: the messages, the reply that is being written, and Stop.
import { useCallback, useRef, useState } from 'react';
import { ask, type Source } from '../api/chat';

export type ReplyStatus = 'waiting' | 'streaming' | 'done' | 'stopped' | 'failed';

export interface Message {
  id: number;
  role: 'user' | 'assistant';
  text: string;
  /** Only for the assistant's replies. */
  status?: ReplyStatus;
  sources?: Source[];
  /** The language of the reply, from the API ("en" or "fr"). */
  language?: string;
  problem?: string;
}

export function useChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const controller = useRef<AbortController | null>(null);
  const nextId = useRef(1);

  const update = (id: number, change: (m: Message) => Partial<Message>) =>
    setMessages((all) => all.map((m) => (m.id === id ? { ...m, ...change(m) } : m)));

  const send = useCallback(async (question: string) => {
    if (controller.current) return; // one reply at a time
    const userId = nextId.current++;
    const id = nextId.current++;
    setMessages((all) => [
      ...all,
      { id: userId, role: 'user', text: question },
      { id, role: 'assistant', text: '', status: 'waiting' },
    ]);
    const c = new AbortController();
    controller.current = c;
    try {
      await ask(
        question,
        (e) => {
          if (e.type === 'start') update(id, () => ({ language: e.language }));
          else if (e.type === 'piece') update(id, (m) => ({ text: m.text + e.text, status: 'streaming' }));
          else update(id, () => ({ text: e.answer, sources: e.sources, language: e.language, status: 'done' }));
        },
        c.signal,
      );
    } catch (err) {
      if (c.signal.aborted) update(id, () => ({ status: 'stopped' }));
      else update(id, () => ({ status: 'failed', problem: (err as Error).message }));
    } finally {
      controller.current = null;
    }
  }, []);

  const stop = useCallback(() => controller.current?.abort(), []);
  const last = messages.at(-1);
  const busy = last?.role === 'assistant' && (last.status === 'waiting' || last.status === 'streaming');
  return { messages, send, stop, busy };
}
