import { expect, test } from 'vitest';
import { announcement, wayFromAddress } from './announce';
import type { Message } from './useChat';

const reply = (status: Message['status'], text: string, sources = 0): Message => ({
  id: 2,
  role: 'assistant',
  text,
  status,
  sources: Array.from({ length: sources }, () => ({ document: 'Delivery policy', section: 'Rules' })),
});

test('the chat says nothing while a reply is written, then the whole reply once', () => {
  expect(announcement('reply', reply('waiting', ''))).toBe('');
  expect(announcement('reply', reply('streaming', 'No. Once the parcel'))).toBe('');
  expect(announcement('reply', reply('done', 'No. Once the parcel has shipped, it cannot be changed.', 1))).toBe(
    'Assistant: No. Once the parcel has shipped, it cannot be changed. 1 source.',
  );
});

test('a stopped or failed reply has its own sentence', () => {
  expect(announcement('reply', reply('stopped', 'No. Once'))).toBe('You stopped the reply. The text is not complete.');
  expect(announcement('reply', { ...reply('failed', ''), problem: 'Try again.' })).toBe('No reply. Try again.');
});

test('the sentence way says each sentence once it is complete', () => {
  expect(announcement('sentences', reply('streaming', 'No. Once the'))).toBe('No.');
  expect(announcement('sentences', reply('done', 'No. Once the parcel has shipped.'))).toBe('Once the parcel has shipped.');
});

test('the way comes from the address, "reply" by default', () => {
  expect(wayFromAddress('?announce=pieces')).toBe('pieces');
  expect(wayFromAddress('?announce=loud')).toBe('reply');
  expect(wayFromAddress('')).toBe('reply');
});
