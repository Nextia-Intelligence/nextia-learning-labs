// What a screen reader is told about a reply. The chat uses "reply": one message when the reply ends.
// The other three ways are here for the comparison of the case study (open /?announce=pieces).
import type { Message } from './useChat';

export const WAYS = ['pieces', 'busy', 'sentences', 'reply'] as const;
export type Way = (typeof WAYS)[number];

/** The way from the address (?announce=...); "reply" when there is none. */
export function wayFromAddress(search: string): Way {
  const way = new URLSearchParams(search).get('announce');
  return (WAYS as readonly string[]).includes(way ?? '') ? (way as Way) : 'reply';
}

/** The sentences of a text; the last one may still be incomplete while the reply is written. */
const sentences = (text: string) => text.trim().split(/(?<=[.!?])\s+/).filter(Boolean);

/** The message of the status region for the last reply. Empty: nothing to say. */
export function announcement(way: Way, reply: Message | undefined): string {
  if (!reply || reply.role !== 'assistant') return '';
  if (way === 'pieces' || way === 'busy') return ''; // the conversation itself is the live region
  if (reply.status === 'stopped') return 'You stopped the reply. The text is not complete.';
  if (reply.status === 'failed') return `No reply. ${reply.problem ?? ''}`.trim();
  if (way === 'sentences') {
    const all = sentences(reply.text);
    if (reply.status === 'streaming') return all.length > 1 ? all[all.length - 2] : '';
    return reply.status === 'done' ? (all.at(-1) ?? '') : '';
  }
  if (reply.status !== 'done') return '';
  const n = reply.sources?.length ?? 0;
  return `Assistant: ${reply.text} ${n ? `${n} ${n === 1 ? 'source' : 'sources'}.` : 'No sources.'}`;
}
