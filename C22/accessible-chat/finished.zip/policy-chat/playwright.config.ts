// The accessibility checks run in a real browser (Chromium), against the production build and the mock.
//   npx playwright install chromium   (once: downloads the browser)
//   npm run check:a11y                the six checks, on the questions you used while building
//   QUESTIONS=new npm run check:a11y  the same checks on questions you did not use (macOS/Linux)
// Ports: E2E_API_PORT (8200) and E2E_WEB_PORT (4183), if those are busy on your computer.
import { defineConfig, devices } from '@playwright/test';

const apiPort = Number(process.env.E2E_API_PORT ?? 8200);
const webPort = Number(process.env.E2E_WEB_PORT ?? 4183);
const web = `http://localhost:${webPort}`;

export default defineConfig({
  testDir: 'e2e',
  timeout: 120_000,
  workers: 1,
  retries: 0,
  reporter: [['list']],
  use: { ...devices['Desktop Chrome'], baseURL: web },
  webServer: [
    {
      command: `node mock/server.mjs --port ${apiPort}`,
      url: `http://127.0.0.1:${apiPort}/health`,
      env: { CORS_ORIGINS: web },
      reuseExistingServer: false,
    },
    {
      command: `npx vite build --logLevel warn && npx vite preview --port ${webPort} --strictPort`,
      url: web,
      env: { VITE_API_URL: `http://127.0.0.1:${apiPort}` },
      reuseExistingServer: false,
      timeout: 120_000,
    },
  ],
});
