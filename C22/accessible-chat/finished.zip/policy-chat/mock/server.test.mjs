// Checks of the mock chat API (node:test, no packages): npm test runs them first.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { findReply, makeServer, pieces } from './server.mjs';

test('pieces keep every character of the answer', () => {
  const text = 'We refund the extra charge within 3 business days.';
  assert.equal(pieces(text).join(''), text);
  assert.deepEqual(pieces('No. Once'), ['No', '.', ' Once']);
});

test('a question finds its recorded answer, also with other words around it', () => {
  assert.equal(findReply('How many Rewards points does a customer need for a 10-dollar reward?').id, 'Q04');
  assert.equal(findReply('how many rewards points for a 10-dollar reward').id, 'Q04');
  assert.equal(findReply('What is the weather today?'), null);
});

test('POST /v1/chat streams pieces, then the whole answer', async () => {
  const server = makeServer({ stream: 'slow' }).listen(0);
  const port = server.address().port;
  try {
    const res = await fetch(`http://127.0.0.1:${port}/v1/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' },
      body: JSON.stringify({ question: 'How long is the warranty on a garden sprinkler?' }),
    });
    assert.equal(res.status, 200);
    const text = await res.text();
    const events = [...text.matchAll(/^event: (\w+)$/gm)].map((m) => m[1]);
    assert.equal(events[0], 'start');
    assert.equal(events.at(-1), 'done');
    assert.equal(events.filter((e) => e === 'piece').length, pieces('A garden sprinkler has a 1-year warranty.').length);
    assert.match(text, /"answer":"A garden sprinkler has a 1-year warranty\."/);
  } finally {
    server.close();
  }
});

test('an empty question gets 422', async () => {
  const server = makeServer().listen(0);
  try {
    const res = await fetch(`http://127.0.0.1:${server.address().port}/v1/chat`, { method: 'POST', body: '{}' });
    assert.equal(res.status, 422);
  } finally {
    server.close();
  }
});
