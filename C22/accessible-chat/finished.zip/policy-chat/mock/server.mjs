// The chat's mock API: Node.js only, no packages. It replays 67 REAL recorded answers of a policy
// assistant (a hosted model, chat-small, recorded in Nextia's RAG course) as a stream of pieces.
//   node mock/server.mjs                  # http://127.0.0.1:8200
//   node mock/server.mjs --port 8201      # another port
//   node mock/server.mjs --stream slow    # 60 ms per piece, to watch and stop a reply by hand
// What is real and what is simulated:
// - the answers, their sources and the time each call took were recorded (mock/data/replies.json);
// - the stream is simulated from that time: the first piece after most of the recorded time, then one
//   piece every few milliseconds, as in real recorded streams;
// - the choice of answer is simulated too: the mock picks the recorded question that shares the most
//   words with yours. A question that matches none gets a short "no recorded answer" reply.
// Routes: GET /health, GET /v1/questions, POST /v1/chat (JSON {"question": "..."}, answer as
// server-sent events: start, piece, done, error).
import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';

const REPLIES = JSON.parse(readFileSync(new URL('./data/replies.json', import.meta.url), 'utf8'));
const STOP = new Set(
  'the a an and or of to in on for is are was do does did can what how which who when where why our we you your with from by at it its this that be has have not there their they any after about'.split(' '),
);

/** Splits a reply into pieces of about one token: a word with its space, or a punctuation mark. */
export function pieces(text) {
  return text.match(/\s*[\p{L}\p{N}’'_-]+|\s*[^\p{L}\p{N}\s]|\s+$/gu) ?? [];
}

const words = (text) =>
  new Set(
    text
      .toLowerCase()
      .normalize('NFD')
      .replace(/[̀-ͯ]/g, '')
      .match(/[\p{L}\p{N}-]+/gu)
      ?.filter((w) => w.length > 2 && !STOP.has(w)) ?? [],
  );

/** The recorded reply whose question shares the most words with this one (at least half of its words). */
export function findReply(question) {
  const asked = words(question);
  let best = null;
  let bestScore = 0;
  for (const r of REPLIES) {
    const known = words(r.question);
    let shared = 0;
    for (const w of known) if (asked.has(w)) shared += 1;
    const score = known.size ? shared / known.size : 0;
    if (score > bestScore) [best, bestScore] = [r, score];
  }
  return bestScore >= 0.5 ? best : null;
}

const NO_ANSWER = {
  id: null,
  language: 'en',
  answerable: false,
  answer: 'I have no recorded answer for this question. This mock replays 67 recorded answers: see mock/data/replies.json.',
  sources: [],
  first_piece_ms: 300,
  piece_gap_ms: 6,
};

function wait(ms, signal) {
  return new Promise((resolve) => {
    if (signal.aborted) return resolve(false);
    const timer = setTimeout(() => resolve(true), ms);
    signal.addEventListener('abort', () => {
      clearTimeout(timer);
      resolve(false);
    });
  });
}

export function makeServer({ stream = 'recorded', origins = ['http://localhost:5173', 'http://localhost:4183'] } = {}) {
  const stats = { started: 0, completed: 0, stopped_by_client: 0 };

  function cors(req, res) {
    const origin = req.headers.origin;
    if (origin && origins.includes(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    }
  }
  const json = (res, status, body) => {
    res.writeHead(status, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(body));
  };

  async function chat(req, res) {
    let body = '';
    for await (const chunk of req) body += chunk;
    let question;
    try {
      question = JSON.parse(body).question;
    } catch {
      /* checked below */
    }
    if (typeof question !== 'string' || !question.trim()) {
      return json(res, 422, { error: { code: 'invalid', message: 'Send {"question": "..."} with a question in it.' } });
    }
    const reply = findReply(question) ?? NO_ANSWER;
    const controller = new AbortController();
    res.on('close', () => controller.abort());
    stats.started += 1;
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
    const event = (name, data) => res.write(`event: ${name}\ndata: ${JSON.stringify(data)}\n\n`);
    event('start', { id: reply.id, language: reply.language, model: 'chat-small', mode: stream });
    const slow = stream === 'slow';
    let ok = await wait(slow ? 400 : reply.first_piece_ms, controller.signal);
    for (const text of pieces(reply.answer)) {
      if (!ok) break;
      event('piece', { text });
      ok = await wait(slow ? 60 : reply.piece_gap_ms, controller.signal);
    }
    if (!ok) {
      stats.stopped_by_client += 1;
      return;
    }
    stats.completed += 1;
    const { first_piece_ms: _f, piece_gap_ms: _g, recorded_ms: _r, ...done } = reply;
    event('done', done);
    res.end();
  }

  const server = createServer((req, res) => {
    cors(req, res);
    const path = new URL(req.url, 'http://x').pathname;
    if (req.method === 'OPTIONS') return res.writeHead(204).end();
    if (req.method === 'GET' && path === '/health') return json(res, 200, { status: 'ok' });
    if (req.method === 'GET' && path === '/v1/questions') return json(res, 200, { items: REPLIES.map((r) => r.question) });
    if (req.method === 'GET' && path === '/admin/stats') return json(res, 200, stats);
    if (req.method === 'POST' && path === '/v1/chat') return chat(req, res);
    json(res, 404, { error: { code: 'not_found', message: `No route ${req.method} ${path}.` } });
  });
  return server;
}

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  const arg = (name, fallback) => {
    const i = process.argv.indexOf(name);
    return i > 0 ? process.argv[i + 1] : fallback;
  };
  const port = Number(arg('--port', 8200));
  const stream = arg('--stream', 'recorded');
  const origins = (process.env.CORS_ORIGINS ?? 'http://localhost:5173,http://localhost:4183').split(',');
  makeServer({ stream, origins }).listen(port, '127.0.0.1', () => {
    console.log(`Mock chat API on http://127.0.0.1:${port} (${REPLIES.length} recorded answers; stream=${stream})`);
    console.log('The answers were recorded from a real model in an earlier course; the streaming is simulated.');
  });
}
