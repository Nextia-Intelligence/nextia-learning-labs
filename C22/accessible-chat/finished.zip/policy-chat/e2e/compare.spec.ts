// The fair comparison of four ways to announce a reply: the same 12 questions, the same recorded
// timing, the same browser, one measure (changes of the live regions per reply). Writes
// results/compare.json and prints a table. The app reads the way from the address: /?announce=pieces
import { mkdirSync, writeFileSync } from 'node:fs';
import { expect, test } from '@playwright/test';
import { announcements, ask, recordAnnouncements } from './checks';
import { DEV } from './questions';

const WAYS = ['pieces', 'busy', 'sentences', 'reply'] as const;
const results: Record<string, { id: string; changes: number; complete: boolean }[]> = {};

for (const way of WAYS) {
  test(`announce=${way}`, async ({ page }) => {
    await page.goto(`/?announce=${way}`);
    await expect(page.locator('#root > [data-announce]'), 'This version of the app does not read ?announce= yet (Part 4).').toHaveAttribute('data-announce', way);
    results[way] = [];
    for (const q of DEV) {
      await recordAnnouncements(page);
      await ask(page, q.question);
      const said = await announcements(page);
      results[way].push({ id: q.id, changes: said.length, complete: said.at(-1)?.includes(q.answer.slice(-40)) ?? false });
    }
  });
}

test.afterAll(() => {
  mkdirSync('results', { recursive: true });
  writeFileSync('results/compare.json', JSON.stringify(results, null, 1) + '\n');
  const median = (v: number[]) => {
    const s = [...v].sort((a, b) => a - b);
    return (s[Math.floor((s.length - 1) / 2)] + s[Math.ceil((s.length - 1) / 2)]) / 2;
  };
  console.log('way        median  min  max  last change = whole reply');
  for (const [way, rows] of Object.entries(results)) {
    const c = rows.map((r) => r.changes);
    const whole = rows.filter((r) => r.complete).length;
    console.log(`${way.padEnd(10)} ${String(median(c)).padStart(6)} ${String(Math.min(...c)).padStart(4)} ${String(Math.max(...c)).padStart(4)}  ${whole} of ${rows.length}`);
  }
});
