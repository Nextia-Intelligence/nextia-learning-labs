// Prints the accessibility tree of the chat, as assistive tools get it: once while a reply is written,
// once after it. Run: npm run tree
import { test } from '@playwright/test';
import { replyEnded } from './checks';
import { QUESTIONS } from './questions';

test('the accessibility tree of the chat', async ({ page }) => {
  await page.goto('/');
  await page.locator('textarea').fill(QUESTIONS[0].question);
  await page.locator('textarea').press('Enter');
  await page.waitForTimeout(300);
  console.log('--- while the reply is written ---\n' + (await page.locator('body').ariaSnapshot()));
  await replyEnded(page);
  console.log('--- after the reply ---\n' + (await page.locator('body').ariaSnapshot()));
});
