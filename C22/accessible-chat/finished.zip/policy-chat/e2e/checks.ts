// Small accessibility checks in the style of the automatic checkers: each returns a list of problems,
// and an empty list means that the check passed. They read what assistive tools read: the browser's
// accessibility tree (through the Chrome DevTools Protocol), the computed colours, the keyboard focus,
// and the changes of the live regions. Chromium only.
import type { Page } from '@playwright/test';

const CONTROLS = new Set(['button', 'textbox', 'link', 'checkbox', 'radio', 'combobox', 'switch', 'menuitem', 'tab']);

interface AXValue { value?: unknown }
interface AXSource { type: string; attribute?: string; value?: AXValue; superseded?: boolean }
interface AXNode { ignored: boolean; role?: AXValue; name?: AXValue & { sources?: AXSource[] } }

/** Names: every control in the accessibility tree has a name, and not only the placeholder. */
export async function namesProblems(page: Page): Promise<string[]> {
  const cdp = await page.context().newCDPSession(page);
  const { nodes } = (await cdp.send('Accessibility.getFullAXTree')) as { nodes: AXNode[] };
  await cdp.detach();
  const problems: string[] = [];
  for (const n of nodes) {
    const role = String(n.role?.value ?? '');
    if (n.ignored || !CONTROLS.has(role)) continue;
    const name = String(n.name?.value ?? '').trim();
    const used = n.name?.sources?.find((s) => s.value && !s.superseded && String(s.value.value ?? '').trim() === name);
    if (!name) problems.push(`${role} with no name`);
    else if (used?.attribute === 'placeholder') problems.push(`${role} "${name}" is named only by its placeholder`);
  }
  return problems;
}

/** The element that has the keyboard focus, as "role name" (role from the tag or the role attribute). */
export function focused(page: Page): Promise<string> {
  return page.evaluate(() => {
    const e = document.activeElement as HTMLElement | null;
    if (!e || e === document.body) return 'body (nothing)';
    const role = e.getAttribute('role') ?? e.tagName.toLowerCase();
    const label = e.id ? document.querySelector(`label[for="${e.id}"]`)?.textContent : null;
    const name = (e.getAttribute('aria-label') ?? label ?? e.textContent ?? '').trim().replace(/\s+/g, ' ');
    return `${role} "${name.slice(0, 40)}"`;
  });
}

/** Contrast (WCAG 2): 4.5:1 for normal text, 3:1 for large text (24 px, or 18.66 px bold). Placeholders too. */
export function contrastProblems(page: Page): Promise<string[]> {
  return page.evaluate(() => {
    const rgba = (c: string) => (c.match(/[\d.]+/g) ?? ['0', '0', '0', '0']).map(Number);
    const lum = ([r, g, b]: number[]) => {
      const f = (v: number) => ((v /= 255) <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4);
      return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
    };
    const ratio = (a: number[], b: number[]) => {
      const [hi, lo] = [lum(a), lum(b)].sort((x, y) => y - x);
      return (hi + 0.05) / (lo + 0.05);
    };
    const background = (e: Element | null): number[] => {
      for (; e; e = e.parentElement) {
        const c = rgba(getComputedStyle(e).backgroundColor);
        if ((c[3] ?? 1) > 0) return c;
      }
      return [255, 255, 255, 1];
    };
    const hex = (c: number[]) => '#' + c.slice(0, 3).map((v) => Math.round(v).toString(16).padStart(2, '0')).join('');
    const problems: string[] = [];
    const check = (e: Element, color: string, text: string) => {
      const s = getComputedStyle(e);
      const size = parseFloat(s.fontSize);
      const large = size >= 24 || (size >= 18.66 && Number(s.fontWeight) >= 700);
      const fg = rgba(color);
      const bg = background(e);
      const r = ratio(fg, bg);
      const need = large ? 3 : 4.5;
      if (r < need) problems.push(`"${text.slice(0, 30)}": ${hex(fg)} on ${hex(bg)} is ${r.toFixed(2)}:1, needs ${need}:1`);
    };
    const seen = new Set<string>();
    for (const e of document.body.querySelectorAll('*')) {
      const own = [...e.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent ?? '').join('').trim();
      const box = (e as HTMLElement).getBoundingClientRect();
      if (own && box.width > 0 && box.height > 0 && !e.closest('[aria-hidden="true"], .visually-hidden')) {
        const before = problems.length;
        check(e, getComputedStyle(e).color, own);
        // One line per kind of text is enough: the same class with the same colours.
        const key = problems.at(-1)?.replace(/^"[^"]*"/, e.className);
        if (problems.length > before && key && seen.has(key)) problems.pop();
        else if (key) seen.add(key);
      }
      const placeholder = e.getAttribute('placeholder');
      if (placeholder) check(e, getComputedStyle(e, '::placeholder').color, `placeholder ${placeholder}`);
    }
    return problems;
  });
}

/** Starts to record every change of a live region that a screen reader would read. */
export function recordAnnouncements(page: Page): Promise<void> {
  return page.evaluate(() => {
    const w = window as unknown as { __said: string[]; __observer?: MutationObserver };
    w.__said = [];
    w.__observer?.disconnect();
    const seen = new Map<Element, string>();
    const regions = () =>
      [...document.querySelectorAll('[aria-live]:not([aria-live="off"]), [role="status"], [role="log"], [role="alert"]')];
    for (const r of regions()) seen.set(r, (r.textContent ?? '').trim());
    const observer = new MutationObserver(() => {
      for (const r of regions()) {
        // While a region (or its parent) is aria-busy, assistive tools should wait; they read it when it is done.
        if (r.closest('[aria-busy="true"]')) continue;
        const text = (r.textContent ?? '').trim();
        if (text && text !== seen.get(r)) w.__said.push(text.slice(-300));
        seen.set(r, text);
      }
    });
    observer.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['aria-busy'] });
    w.__observer = observer;
  });
}

/** The changes recorded since recordAnnouncements(). */
export function announcements(page: Page): Promise<string[]> {
  return page.evaluate(() => (window as unknown as { __said: string[] }).__said);
}

/** Types a question in the message box and sends it with Enter; waits until the reply has ended. */
export async function ask(page: Page, question: string): Promise<void> {
  const box = page.locator('textarea');
  await box.click();
  await box.fill(question);
  await page.keyboard.press('Enter');
  await replyEnded(page);
  await page.waitForTimeout(300);
}

/** Waits until the last reply is done, stopped or failed. */
export function replyEnded(page: Page) {
  return page.waitForFunction(
    () => ['done', 'stopped', 'failed'].includes([...document.querySelectorAll('.msg.assistant')].at(-1)?.getAttribute('data-status') ?? ''),
    null,
    { timeout: 20_000 },
  );
}
