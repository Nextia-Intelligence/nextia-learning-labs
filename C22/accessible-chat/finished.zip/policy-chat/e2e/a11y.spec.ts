// Six accessibility checks of the chat. Each test is one check; its error lists every problem found.
// They complement a keyboard test by hand and a real screen reader; they do not replace them.
import { expect, test } from '@playwright/test';
import { announcements, ask, contrastProblems, focused, namesProblems, recordAnnouncements, replyEnded } from './checks';
import { QUESTIONS } from './questions';

test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await page.locator('textarea').waitFor();
});

test('names: every control has a name, and not only a placeholder', async ({ page }) => {
  await ask(page, QUESTIONS[0].question);
  expect(await namesProblems(page)).toEqual([]);
});

test('focus: after sending, the focus stays in the message box', async ({ page }) => {
  await page.locator('textarea').fill(QUESTIONS[0].question);
  await page.locator('textarea').focus();
  await page.keyboard.press('Enter');
  await page.waitForTimeout(200);
  const after = await focused(page);
  await replyEnded(page);
  expect(after, 'where the focus went after Enter').toMatch(/^textarea /);
});

test('keyboard: Tab reaches Stop while a reply is written, and Enter stops it', async ({ page }) => {
  await page.locator('textarea').fill(QUESTIONS[0].question);
  await page.locator('textarea').focus();
  await page.keyboard.press('Enter');
  const path: string[] = [];
  for (let i = 0; i < 4; i += 1) {
    await page.keyboard.press('Tab');
    path.push(await focused(page));
    if (/^button "Stop"$/.test(path.at(-1)!)) break;
  }
  expect(path.at(-1), `where each Tab went: ${path.join(' → ')}`).toBe('button "Stop"');
  await page.keyboard.press('Enter');
  await replyEnded(page);
  await expect(page.locator('.msg.assistant').last()).toHaveAttribute('data-status', 'stopped');
});

test('announcements: one per finished reply, never one per piece', async ({ page }) => {
  const counts: string[] = [];
  for (const q of QUESTIONS.slice(0, 3)) {
    await recordAnnouncements(page);
    await ask(page, q.question);
    const said = await announcements(page);
    const complete = said.at(-1)?.includes(q.answer.slice(-40)) ?? false;
    if (said.length !== 1 || !complete) counts.push(`${q.id}: ${said.length} changes, last one complete: ${complete}`);
  }
  expect(counts, 'replies whose live-region changes were not exactly one complete announcement').toEqual([]);
});

test('contrast: all text has at least 4.5:1 (3:1 when large)', async ({ page }) => {
  await ask(page, QUESTIONS[0].question);
  expect(await contrastProblems(page)).toEqual([]);
});

test('language: each reply is marked with its language', async ({ page }) => {
  const wrong: string[] = [];
  for (const q of QUESTIONS) {
    await ask(page, q.question);
    const lang = await page.locator('.msg.assistant').last().evaluate((e) => e.closest('[lang]')?.getAttribute('lang') ?? '');
    if (lang !== q.language) wrong.push(`${q.id}: reply in "${q.language}", marked "${lang}"`);
  }
  expect(wrong).toEqual([]);
});
