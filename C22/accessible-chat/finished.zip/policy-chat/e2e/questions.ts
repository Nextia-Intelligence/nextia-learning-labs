// The questions of the checks. "dev": the 12 questions used while building and fixing the chat.
// "new": 10 questions kept aside for the end-to-end run, 4 of them in French.
// Every question is one of the 67 recorded in mock/data/replies.json.
import { readFileSync } from 'node:fs';

export interface Reply {
  id: string;
  question: string;
  language: string;
  answer: string;
  sources: { document: string; section: string }[];
}

const all: Reply[] = JSON.parse(readFileSync(new URL('../mock/data/replies.json', import.meta.url), 'utf8'));
const byId = (ids: string[]) => ids.map((id) => all.find((r) => r.id === id)!);

export const DEV = byId(['Q01', 'Q02', 'Q04', 'Q08', 'Q10', 'Q11', 'Q14', 'Q30', 'Q34', 'Q45', 'Q49', 'Q53']);
export const NEW = byId(['Q07', 'Q13', 'Q21', 'Q37', 'Q47', 'Q50', 'Q54', 'Q57', 'Q59', 'Q66']);
export const QUESTIONS = process.env.QUESTIONS === 'new' ? NEW : DEV;
