# policy-chat

A small chat for Larkfield's help-desk agents: ask the policy assistant a question, read the answer as it is
written, stop it if it goes wrong. It is the project of the case study
[Make an AI chat interface accessible](https://learning.nextia-ai.com/courses/frontend/m07/make-an-ai-chat-interface-accessible/)
of Nextia Learning's course *Frontend Architecture and Performance for AI Apps*.

The chat talks to a **mock API on your computer** (`mock/`). Its answers are 67 real answers of a hosted
language model (`chat-small`), recorded in Nextia's RAG course, with the time each call took. The mock replays
them as a stream of small pieces of text. No model, no account, no money.

## Run it

Node.js 24 (LTS) or 22.22.2+. Two terminals, in this folder:

```sh
npm install
npm run mock     # terminal 1: http://127.0.0.1:8200
npm run dev      # terminal 2: http://localhost:5173/
```

Ask one of the recorded questions, for example "How many Rewards points does a customer need for a 10-dollar
reward?". `GET http://127.0.0.1:8200/v1/questions` lists all 67. `npm run mock -- --stream slow` sends one
piece every 60 ms, so you can stop a reply by hand.

## Check it

```sh
npm test                           # the mock's checks (node:test) and the component tests (Vitest)
npx playwright install chromium    # once: the browser for the checks below
npm run check:a11y                 # six accessibility checks in Chromium (12 questions)
QUESTIONS=new npm run check:a11y   # the same checks on 10 other questions (PowerShell: $env:QUESTIONS="new"; npm run check:a11y)
npm run tree                       # print the accessibility tree, during and after a reply
npm run compare                    # four ways to announce a reply, the same 12 questions (results/compare.json)
```

The checks start the mock API on port 8200 and the built app on port 4183. If those ports are busy, set
`E2E_API_PORT` and `E2E_WEB_PORT`.

The automatic checks do not replace a keyboard test by hand and a test with a real screen reader (VoiceOver on
macOS, NVDA on Windows), ideally by a person who uses one every day.

## Files

| Path | What it is |
|---|---|
| `src/App.tsx` | the chat: conversation, message box, Send/Stop |
| `src/chat/useChat.ts` | the messages and the reply being written |
| `src/api/chat.ts` | asks the mock, reads its server-sent events |
| `mock/server.mjs`, `mock/data/replies.json` | the mock API and its recorded answers (`DATASET.md`) |
| `e2e/checks.ts`, `e2e/a11y.spec.ts` | the accessibility checks |
| `e2e/compare.spec.ts` | the comparison of four ways to announce a reply |

## Licence

Code: MIT (`LICENSE`). Data: CC0 1.0 (`DATASET.md`).
