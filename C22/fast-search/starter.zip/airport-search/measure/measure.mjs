// Measures the search page in a real browser (Playwright's Chromium), as the course's own scripts do.
// Build and serve the page first (npm run build && npm run preview), and run the API (npm run api).
//
//   npm run measure -- open    --label finished      # first rows after opening the page
//   npm run measure -- type    --label finished      # type "paris": which answer stays, and when
//   npm run measure -- session --label finished      # open the page and type "paris": time to the right rows
//   npm run measure -- click   --label finished      # 2,000 rows loaded: click two rows, time to their details
//   npm run measure -- timeline --label finished     # type "paris" once: every request, when it left and ended
//
// Options: --url http://localhost:4173/  --api http://127.0.0.1:8200  --profile fast|phone|both
//          --passes 5  --word paris  --rows 2000  --out results
// Each run writes results/<label>-<group>.json (the machine, the load before, every pass, the
// medians) and prints the medians. The numbers are from your computer: compare runs made on the
// same computer, one after the other, never numbers from two computers.
import { execSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import os from 'node:os';
import { join } from 'node:path';
import { chromium } from '@playwright/test';

const args = process.argv.slice(2);
const group = args[0];
const opt = (name, fallback) => {
  const i = args.indexOf(`--${name}`);
  return i === -1 ? fallback : args[i + 1];
};
const URL_ = opt('url', 'http://localhost:4173/');
const API = opt('api', 'http://127.0.0.1:8200');
const LABEL = opt('label', 'run');
const PROFILES = opt('profile', 'both') === 'both' ? ['fast', 'phone'] : [opt('profile')];
const PASSES = Number(opt('passes', group === 'type' ? 10 : group === 'click' ? 3 : 5));
const WORD = opt('word', 'paris');
const ROWS = Number(opt('rows', 2000));
const OUT = opt('out', 'results');

const median = (xs) => {
  const s = xs.filter((x) => x !== null && x !== undefined).sort((a, b) => a - b);
  const n = s.length;
  return n === 0 ? null : n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2;
};
const round = (x, d = 1) => (x === null || x === undefined ? x : Math.round(x * 10 ** d) / 10 ** d);
const range = (xs) => {
  const s = xs.filter((x) => x !== null && x !== undefined);
  return s.length ? [round(Math.min(...s)), round(Math.max(...s))] : null;
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function machine() {
  let macos = '';
  try { macos = execSync('sw_vers -productVersion', { stdio: ['ignore', 'pipe', 'ignore'] }).toString().trim(); } catch { /* not macOS */ }
  return { cpu: os.cpus()[0].model, cores: os.cpus().length, memory_gb: Math.round(os.totalmem() / 2 ** 30), os: `${os.type()} ${os.release()}${macos ? ` (macOS ${macos})` : ''}`, node: process.version };
}

// "Phone-like", as Lighthouse's default for phones and the course's measurements: 150 ms round
// trip, 1.6 Mbit/s down, 750 kbit/s up, a CPU 4 times slower than this computer.
const PHONE = { latency: 150, downloadThroughput: (1.6 * 1024 * 1024) / 8, uploadThroughput: (750 * 1024) / 8, cpu: 4 };
async function throttle(page, profile) {
  if (profile !== 'phone') return;
  const cdp = await page.context().newCDPSession(page);
  await cdp.send('Network.enable');
  await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: PHONE.latency, downloadThroughput: PHONE.downloadThroughput, uploadThroughput: PHONE.uploadThroughput });
  await cdp.send('Emulation.setCPUThrottlingRate', { rate: PHONE.cpu });
}

// Records, inside the page, every change of the results line: which search it shows, and when.
function watchResults() {
  window.__shown = [];
  const seen = () => {
    const el = document.querySelector('[data-results-for]');
    const q = el ? el.getAttribute('data-results-for') : null;
    const last = window.__shown.at(-1);
    if (!last || last.q !== q) window.__shown.push({ q, t: performance.now() });
  };
  new MutationObserver(seen).observe(document, { subtree: true, childList: true, attributes: true, attributeFilter: ['data-results-for'] });
  window.__keys = [];
  document.addEventListener('keydown', () => window.__keys.push(performance.now()), true);
  window.__long = [];
  new PerformanceObserver((list) => window.__long.push(...list.getEntries().map((e) => ({ start: e.startTime, ms: e.duration })))).observe({ type: 'longtask', buffered: true });
}

// Counts the requests to the API, and those the browser closed early (cancelled).
function countRequests(page) {
  const c = { sent: 0, cancelled: 0, kb: 0 };
  page.on('request', (r) => { if (r.url().startsWith(API + '/v1/')) c.sent += 1; });
  page.on('requestfailed', (r) => { if (r.url().startsWith(API + '/v1/') && /ABORTED|cancel/i.test(r.failure()?.errorText ?? '')) c.cancelled += 1; });
  return c;
}

async function fresh(browser, profile) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  await context.addInitScript(watchResults);
  const page = await context.newPage();
  await throttle(page, profile);
  return { context, page };
}

const searchbox = (page) => page.getByRole('searchbox', { name: 'Search' });
const rowsShown = (page) => page.evaluate(() => Number(document.querySelector('[data-rows]')?.getAttribute('data-rows') ?? 0));

const groups = {
  async open(browser, profile) {
    const { context, page } = await fresh(browser, profile);
    const requests = countRequests(page);
    await page.goto(URL_);
    await page.locator('[data-rows]').first().waitFor({ timeout: 120_000 });
    await page.waitForFunction(() => performance.getEntriesByName('search:first-rows').length > 0, null, { timeout: 120_000 });
    await sleep(500);
    const m = await page.evaluate((api) => {
      const res = performance.getEntriesByType('resource');
      const js = res.filter((r) => r.name.endsWith('.js'));
      const data = res.filter((r) => r.name.startsWith(api + '/v1/'));
      return {
        first_rows_ms: performance.getEntriesByName('search:first-rows')[0].startTime,
        fcp_ms: performance.getEntriesByName('first-contentful-paint')[0]?.startTime ?? null,
        js_files: js.length,
        js_kb: js.reduce((s, r) => s + r.transferSize, 0) / 1000,
        data_kb: data.reduce((s, r) => s + r.transferSize, 0) / 1000,
        rows: Number(document.querySelector('[data-rows]').getAttribute('data-rows')),
        elements: document.querySelectorAll('*').length,
      };
    }, API);
    await context.close();
    return { ...m, api_requests: requests.sent };
  },

  async type(browser, profile) {
    const { context, page } = await fresh(browser, profile);
    await page.goto(URL_);
    await page.locator('[data-rows]').first().waitFor({ timeout: 120_000 });
    await sleep(1000);
    const requests = countRequests(page);
    const startAt = await page.evaluate(() => performance.now());
    await searchbox(page).pressSequentially(WORD, { delay: 120 });
    await sleep(3000);
    const r = await page.evaluate(([word, start]) => {
      const lastKey = window.__keys.at(-1);
      const shown = window.__shown.filter((s) => s.t >= start);
      const final = window.__shown.at(-1)?.q ?? null;
      const right = [...window.__shown].reverse().find((s) => s.q === word);
      return {
        shown_in_order: shown.map((s) => s.q),
        final_shown: final,
        wrong: final !== word,
        last_key_to_right_rows_ms: final === word && right ? right.t - lastKey : null,
        long_tasks_ms: window.__long.filter((l) => l.start >= start).reduce((s, l) => s + l.ms, 0),
      };
    }, [WORD, startAt]);
    await context.close();
    return { ...r, api_requests: requests.sent, cancelled: requests.cancelled };
  },

  async session(browser, profile) {
    const { context, page } = await fresh(browser, profile);
    const requests = countRequests(page);
    await page.goto(URL_);
    await searchbox(page).waitFor({ timeout: 120_000 });
    await searchbox(page).pressSequentially(WORD, { delay: 120 });
    // Wait until the right rows are on the screen, then 3 s more to see if they stay.
    await page.waitForFunction((w) => document.querySelector('[data-results-for]')?.getAttribute('data-results-for') === w, WORD, { timeout: 120_000 }).catch(() => {});
    await sleep(3000);
    const r = await page.evaluate((word) => {
      const final = window.__shown.at(-1)?.q ?? null;
      const right = [...window.__shown].reverse().find((s) => s.q === word);
      return { final_shown: final, wrong: final !== word, right_rows_ms: final === word && right ? right.t : null };
    }, WORD);
    await context.close();
    return { ...r, api_requests: requests.sent, cancelled: requests.cancelled };
  },

  async timeline(browser, profile) {
    const { context, page } = await fresh(browser, profile);
    await page.goto(URL_);
    await page.locator('[data-rows]').first().waitFor({ timeout: 120_000 });
    await sleep(1000);
    const requests = [];
    let t0 = null;
    const now = () => performance.now() - t0;
    page.on('request', (r) => {
      if (t0 !== null && r.url().startsWith(API + '/v1/')) requests.push({ r, q: new URL(r.url()).searchParams.get('q') ?? '', start: now(), end: null, result: null });
    });
    const done = (result) => (r) => {
      const x = requests.find((y) => y.r === r && y.end === null);
      if (x) Object.assign(x, { end: now(), result: result === 'failed' ? (r.failure()?.errorText ?? 'failed') : String(result) });
    };
    page.on('requestfinished', async (r) => done((await r.response())?.status() ?? 'finished')(r));
    page.on('requestfailed', done('failed'));
    const box = searchbox(page);
    await box.click();
    t0 = performance.now();
    await box.pressSequentially(WORD, { delay: 120 });
    await sleep(3000);
    const finalShown = await page.evaluate(() => window.__shown.at(-1)?.q ?? null);
    await context.close();
    return {
      final_shown: finalShown,
      wrong: finalShown !== WORD,
      requests: requests.map(({ q, start, end, result }) => ({ q, start: round(start), end: round(end), result: /ABORTED/.test(result ?? '') ? 'cancelled' : result })),
    };
  },

  async click(browser, profile) {
    // Rows are loaded at full speed; the phone-like profile starts only before the clicks.
    const { context, page } = await fresh(browser, 'fast');
    await page.goto(URL_);
    await page.locator('[data-rows]').first().waitFor({ timeout: 120_000 });
    // Load rows until there are ROWS: press "Load 50 more", or scroll to the end of the list.
    for (let guard = 0; (await rowsShown(page)) < ROWS && guard < 400; guard += 1) {
      const before = await rowsShown(page);
      const more = page.getByRole('button', { name: 'Load 50 more' });
      if (await more.isVisible() && await more.isEnabled()) await more.click();
      else await page.evaluate(() => { const s = document.querySelector('.scroller'); if (s) s.scrollTop = s.scrollHeight; });
      await page.waitForFunction((n) => Number(document.querySelector('[data-rows]')?.getAttribute('data-rows') ?? 0) > n, before, { timeout: 30_000 }).catch(() => {});
    }
    await page.evaluate(() => { const s = document.querySelector('.scroller'); if (s) s.scrollTop = 0; });
    await sleep(1000);
    const rows = await rowsShown(page);
    const elements = await page.evaluate(() => document.querySelectorAll('*').length);
    await throttle(page, profile);
    const clickTimes = [];
    for (const n of [2, 4]) {
      const row = page.locator('.row').nth(n);
      const iata = (await row.locator('.code').textContent()).trim();
      await page.evaluate(() => { window.__clickAt = null; document.addEventListener('pointerdown', () => { window.__clickAt = performance.now(); }, { once: true, capture: true }); });
      await row.click();
      const ms = await page.evaluate((code) => new Promise((resolve) => {
        const check = () => {
          if (document.querySelector(`[data-detail-for="${code}"]`)) requestAnimationFrame(() => setTimeout(() => resolve(performance.now() - window.__clickAt), 0));
          else requestAnimationFrame(check);
        };
        check();
      }), iata);
      clickTimes.push(ms);
      await sleep(500);
    }
    await context.close();
    return { rows, elements, first_click_ms: clickTimes[0], second_click_ms: clickTimes[1] };
  },
};

if (!groups[group]) {
  console.error(`Unknown group "${group ?? ''}". Use one of: ${Object.keys(groups).join(', ')}`);
  process.exit(2);
}
const health = await fetch(`${API}/health`).then((r) => r.json()).catch(() => null);
if (!health) {
  console.error(`The API does not answer at ${API}. Start it with npm run api (or npm run api -- --slow).`);
  process.exit(1);
}
const browser = await chromium.launch();
const result = {
  group, label: LABEL, url: URL_, word: WORD, command: `node measure/measure.mjs ${args.join(' ')}`,
  date: new Date().toISOString(), machine: { ...machine(), browser: `Chromium ${browser.version()} (Playwright)` },
  load_before: os.loadavg().map((x) => round(x, 2)), passes: PASSES, phone_like: PHONE, runs: [], summary: {},
};
try {
  for (const profile of PROFILES) {
    for (let i = 0; i < PASSES; i += 1) {
      const r = await groups[group](browser, profile);
      result.runs.push({ profile, pass: i + 1, load: round(os.loadavg()[0], 2), ...r });
    }
    const runs = result.runs.filter((r) => r.profile === profile);
    const numeric = Object.keys(runs[0]).filter((k) => typeof runs[0][k] === 'number' && !['pass', 'load'].includes(k));
    const s = Object.fromEntries(numeric.map((k) => [k, { median: round(median(runs.map((r) => r[k]))), range: range(runs.map((r) => r[k])) }]));
    if ('wrong' in runs[0]) s.wrong = { count: runs.filter((r) => r.wrong).length, of: runs.length, shown: [...new Set(runs.map((r) => r.final_shown))] };
    result.summary[profile] = s;
    console.log(`${LABEL} ${group} (${profile}, ${runs.length} passes): ` + Object.entries(s).map(([k, v]) => (k === 'wrong' ? `wrong ${v.count} of ${v.of} (shown: ${v.shown.join(', ')})` : `${k} ${v.median}`)).join(' · '));
  }
} finally {
  await browser.close();
}
mkdirSync(OUT, { recursive: true });
const file = join(OUT, `${LABEL}-${group}.json`);
writeFileSync(file, JSON.stringify(result, null, 1) + '\n');
console.log(`wrote ${file}`);
