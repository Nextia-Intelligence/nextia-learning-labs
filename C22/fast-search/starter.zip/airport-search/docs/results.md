# Results

Fill this in with your own runs. Numbers from another computer are not comparable with yours.

## The computer and the setup

- Computer: (the `machine` field of any results/*.json file)
- Browser: Chromium … (Playwright …)
- API: `npm run api -- --slow` (simulated server time: 60 ms + 0.1 ms per matching airport)
- Page: `npm run build && npm run preview`
- Load before the runs: (the `load_before` field)

## The one measure: time to the right rows

Open the page in a fresh browser and type "paris" (120 ms between keys). Time from the start of the page until the rows for "paris" are on the screen and stay. Median of 5 passes (lowest–highest).

| Version | Fast | Phone-like | Wrong answers |
|---|---|---|---|
| Starter (everything downloaded) | | | |
| Finished (server pages) | | | |

## The other numbers

| Version | First rows, fast / phone-like | JavaScript (kB) | Data (kB) | Elements in the page | Click to details |
|---|---|---|---|---|---|
| Starter | | | | | |
| Finished | | | | | |

## What I conclude

- 
