import type { Airport, SearchFilter } from '../api/types';

const TYPE_RANK = { large_airport: 0, medium_airport: 1, small_airport: 2, seaplane_base: 3, heliport: 4 };
const byDefaultOrder = (a: Airport, b: Airport) => TYPE_RANK[a.type] - TYPE_RANK[b.type] || a.name.localeCompare(b.name, 'en');

/**
 * The airports that match, best first, searched in the browser. The same rules as the server's
 * search (api/airports.mjs): the words anywhere in the code, name, city or country; the IATA code
 * itself first, then names or cities that start with the words, larger airports first.
 */
export function matchAirports(airports: Airport[], filter: SearchFilter): Airport[] {
  const query = filter.q.trim().toLowerCase();
  const found = airports.filter(
    (a) => (!filter.type || a.type === filter.type) && (!query || `${a.iata} ${a.ident} ${a.name} ${a.municipality} ${a.country}`.toLowerCase().includes(query)),
  );
  if (!query) return found;
  const group = (a: Airport) =>
    a.iata.toLowerCase() === query ? 0
      : a.name.toLowerCase().startsWith(query) || a.municipality.toLowerCase().startsWith(query) ? 1
        : 2;
  return found.sort((a, b) => group(a) - group(b) || byDefaultOrder(a, b));
}
