// The moment the first result rows are on the screen. The measurements read the mark
// (measure/measure.mjs), and App starts loading the details' code after it.

let firstRows = false;
const waiting: Array<() => void> = [];

/** Called by the list when it has drawn rows. Only the first call counts. */
export function markFirstRows(): void {
  if (firstRows) return;
  firstRows = true;
  performance.mark('search:first-rows');
  for (const fn of waiting.splice(0)) fn();
}

/** Runs `fn` once the first rows are on the screen (at once if they already are). */
export function afterFirstRows(fn: () => void): void {
  if (firstRows) fn();
  else waiting.push(fn);
}
