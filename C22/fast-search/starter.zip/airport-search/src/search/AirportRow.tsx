import type { Airport } from '../api/types';
import { TYPE_LABELS } from '../api/types';

interface Props {
  airport: Airport;
  selected: boolean;
  onSelect: (airport: Airport) => void;
}

/** One result: the code, the name, the city and country, and the type. 56 px high. */
export function AirportRow({ airport, selected, onSelect }: Props) {
  return (
    <button type="button" className="row" aria-pressed={selected} onClick={() => onSelect(airport)}>
      <span className="code">{airport.iata}</span>
      <span className="name">{airport.name}</span>
      <span className="place">{[airport.municipality, airport.country].filter(Boolean).join(', ')}</span>
      <span className={`badge badge-${airport.type}`}>{TYPE_LABELS[airport.type]}</span>
    </button>
  );
}
