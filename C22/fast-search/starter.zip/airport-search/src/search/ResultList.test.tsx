import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { useState } from 'react';
import { expect, test } from 'vitest';
import type { SearchFilter } from '../api/types';
import { airport, installFakeApi, json } from '../test/fake';
import { SearchForm } from './SearchForm';
import { ResultList } from './ResultList';

function Page() {
  const [filter, setFilter] = useState<SearchFilter>({ q: '', type: '' });
  return (
    <>
      <SearchForm value={filter} onChange={setFilter} />
      <ResultList filter={filter} selected={null} onSelect={() => {}} />
    </>
  );
}

const items = [
  airport(1, { iata: 'CDG', name: 'Charles de Gaulle International Airport', municipality: 'Paris', type: 'large_airport' }),
  airport(2, { iata: 'ORY', name: 'Paris-Orly Airport', municipality: 'Paris' }),
  airport(3, { iata: 'LHR', name: 'London Heathrow Airport', municipality: 'London', type: 'large_airport' }),
];

test('downloads every airport once and shows them', async () => {
  const fake = installFakeApi(() => json(200, { items, total: 3 }));
  render(<Page />);
  expect(await screen.findByText('Showing 3 airports.')).toBeInTheDocument();
  expect(fake).toHaveBeenCalledTimes(1);
});

test('searches in the browser: the name or city, case does not matter', async () => {
  const fake = installFakeApi(() => json(200, { items, total: 3 }));
  render(<Page />);
  await screen.findByText('Showing 3 airports.');
  await userEvent.type(screen.getByRole('searchbox', { name: 'Search' }), 'PARIS');
  expect(screen.getByText('Showing 2 airports.')).toBeInTheDocument();
  expect(screen.queryByText('London Heathrow Airport')).not.toBeInTheDocument();
  expect(fake).toHaveBeenCalledTimes(1); // no request per key press
});
