import { useEffect, useState } from 'react';
import { allAirports } from '../api/airports';
import type { Airport } from '../api/types';

export type AllAirports =
  | { status: 'loading'; airports: null; error: null }
  | { status: 'success'; airports: Airport[]; error: null }
  | { status: 'error'; airports: null; error: Error };

/** Downloads every airport once, when the page opens (the cleanup cancels it if the page goes). */
export function useAllAirports(): AllAirports {
  const [state, setState] = useState<AllAirports>({ status: 'loading', airports: null, error: null });
  useEffect(() => {
    const controller = new AbortController();
    allAirports(controller.signal).then(
      (all) => setState({ status: 'success', airports: all.items, error: null }),
      (error: Error) => {
        if (!controller.signal.aborted) setState({ status: 'error', airports: null, error });
      },
    );
    return () => controller.abort();
  }, []);
  return state;
}
