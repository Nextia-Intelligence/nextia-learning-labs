import { useEffect, useMemo } from 'react';
import type { Airport, SearchFilter } from '../api/types';
import { AirportRow } from './AirportRow';
import { markFirstRows } from './marks';
import { matchAirports } from './match';
import { useAllAirports } from './useAllAirports';

interface Props {
  filter: SearchFilter;
  selected: string | null;
  onSelect: (airport: Airport) => void;
}

/** The results: every airport is downloaded once, searched in the browser, and every match drawn. */
export function ResultList({ filter, selected, onSelect }: Props) {
  const all = useAllAirports();
  const airports = useMemo(() => (all.airports ? matchAirports(all.airports, filter) : []), [all.airports, filter]);

  useEffect(() => {
    if (airports.length > 0) markFirstRows();
  }, [airports.length]);

  return (
    <>
      <h2 id="results-heading">Results</h2>
      {all.status === 'error' ? (
        <p role="alert" className="error">{all.error.message}</p>
      ) : all.status === 'loading' ? (
        <p className="muted" role="status">Loading the airports…</p>
      ) : (
        <p className="muted" role="status" data-results-for={filter.q.trim()} data-rows={airports.length}>
          {airports.length === 0 ? 'No airport matches.' : `Showing ${airports.length.toLocaleString('en')} airports.`}
        </p>
      )}
      <div className="scroller" tabIndex={0} role="region" aria-label="Search results">
        <ul className="rows">
          {airports.map((a) => (
            <li key={a.iata}>
              <AirportRow airport={a} selected={a.iata === selected} onSelect={onSelect} />
            </li>
          ))}
        </ul>
      </div>
    </>
  );
}
