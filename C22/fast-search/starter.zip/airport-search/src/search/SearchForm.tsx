import type { AirportType, SearchFilter } from '../api/types';
import { TYPE_LABELS } from '../api/types';

interface Props {
  value: SearchFilter;
  onChange: (filter: SearchFilter) => void;
}

/** The search box and the type filter. Every key press changes the filter. */
export function SearchForm({ value, onChange }: Props) {
  return (
    <form className="filters" role="search" onSubmit={(e) => e.preventDefault()}>
      <label>
        Search
        <input
          type="search"
          value={value.q}
          placeholder="Code, name, city or country"
          autoComplete="off"
          onChange={(e) => onChange({ ...value, q: e.target.value })}
        />
      </label>
      <label>
        Type
        <select value={value.type} onChange={(e) => onChange({ ...value, type: e.target.value as AirportType | '' })}>
          <option value="">Any type</option>
          {Object.entries(TYPE_LABELS).map(([type, label]) => (
            <option key={type} value={type}>{label}</option>
          ))}
        </select>
      </label>
    </form>
  );
}
