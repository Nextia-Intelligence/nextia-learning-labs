import { useState } from 'react';
import type { Airport, SearchFilter } from './api/types';
import { DetailPanel } from './details/DetailPanel';
import { SearchForm } from './search/SearchForm';
import { ResultList } from './search/ResultList';

export function App() {
  const [filter, setFilter] = useState<SearchFilter>({ q: '', type: '' });
  const [selected, setSelected] = useState<Airport | null>(null);
  return (
    <main className="layout">
      <header className="top">
        <h1>Airport search</h1>
        <p className="muted">
          9,051 airports with an IATA code. Data:{' '}
          <a href="https://ourairports.com/data/">OurAirports</a> (public domain).
        </p>
      </header>
      <section className="search" aria-labelledby="results-heading">
        <SearchForm value={filter} onChange={setFilter} />
        <ResultList filter={filter} selected={selected?.iata ?? null} onSelect={setSelected} />
      </section>
      <aside className="details" aria-label="Airport details">
        {selected === null ? <p className="muted">Choose an airport to see where it is.</p> : <DetailPanel airport={selected} />}
      </aside>
    </main>
  );
}
