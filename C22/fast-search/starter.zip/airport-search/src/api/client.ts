// The one place that talks HTTP to the airport API: the address, JSON and the error shape.

export const API_URL: string = import.meta.env.VITE_API_URL ?? 'http://127.0.0.1:8200';

/** An error answer of the API, with its code. */
export class ApiError extends Error {
  constructor(readonly status: number, readonly code: string, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

/** GETs a path and gives back the JSON answer, or throws an ApiError. An abort is passed on. */
export async function apiGet<T>(path: string, signal?: AbortSignal): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_URL}${path}`, { signal });
  } catch (error) {
    if ((error as Error).name === 'AbortError') throw error;
    throw new ApiError(0, 'network_error', 'The airport service did not answer. Is npm run api running?');
  }
  const body = await response.json().catch(() => null);
  if (!response.ok) {
    throw new ApiError(response.status, body?.error?.code ?? 'unknown_error', body?.error?.message ?? `The airport service answered ${response.status}.`);
  }
  return body as T;
}
