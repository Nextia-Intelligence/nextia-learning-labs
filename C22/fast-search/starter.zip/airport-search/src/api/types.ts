// The shapes of the airport API's answers (api/server.mjs).

export type AirportType = 'large_airport' | 'medium_airport' | 'small_airport' | 'seaplane_base' | 'heliport';

export interface Airport {
  iata: string;
  ident: string;
  name: string;
  type: AirportType;
  municipality: string;
  country_code: string;
  country: string;
  continent: string;
  latitude: number;
  longitude: number;
  elevation_ft: number | null;
  scheduled_service: 'yes' | 'no';
}

/** One page of a search: `next` is the cursor of the next page, or null after the last one. */
export interface AirportPage {
  items: Airport[];
  next: string | null;
  total: number;
}

/** What the visitor asks for: words to find, and an airport type ('' = any). */
export interface SearchFilter {
  q: string;
  type: AirportType | '';
}

export const TYPE_LABELS: Record<AirportType, string> = {
  large_airport: 'Large airport',
  medium_airport: 'Medium airport',
  small_airport: 'Small airport',
  seaplane_base: 'Seaplane base',
  heliport: 'Heliport',
};
