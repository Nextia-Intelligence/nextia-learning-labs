import { apiGet } from './client';
import type { Airport } from './types';

/** Every airport at once (about 300 kB compressed). The page searches them itself. */
export function allAirports(signal?: AbortSignal): Promise<{ items: Airport[]; total: number }> {
  return apiGet('/v1/airports/all', signal);
}
