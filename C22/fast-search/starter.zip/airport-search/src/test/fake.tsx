// Test helpers: a fake fetch that answers from a function, airports, and a promise you resolve by hand.
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render } from '@testing-library/react';
import type { ReactElement, ReactNode } from 'react';
import { vi } from 'vitest';
import type { Airport } from '../api/types';

export function airport(n: number, extra: Partial<Airport> = {}): Airport {
  return {
    iata: `A${String(n).padStart(2, '0')}`.slice(0, 3), ident: `XX${n}`, name: `Airport number ${n}`, type: 'medium_airport',
    municipality: `City ${n}`, country_code: 'GB', country: 'United Kingdom', continent: 'EU',
    latitude: 51.47, longitude: -0.46, elevation_ft: 83, scheduled_service: 'yes', ...extra,
  };
}

export const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });

/** Replaces fetch: `answer` gets the URL and the signal of each request. */
export function installFakeApi(answer: (url: URL, signal?: AbortSignal) => Response | Promise<Response>) {
  const fake = vi.fn((input: RequestInfo | URL, init?: RequestInit) => Promise.resolve(answer(new URL(String(input)), init?.signal ?? undefined)));
  vi.stubGlobal('fetch', fake);
  return fake;
}

export function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((r) => (resolve = r));
  return { promise, resolve };
}

/** Renders inside a fresh cache, as main.tsx does, without retries. */
export function renderWithCache(ui: ReactElement) {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  const wrapper = ({ children }: { children: ReactNode }) => <QueryClientProvider client={client}>{children}</QueryClientProvider>;
  return render(ui, { wrapper });
}
