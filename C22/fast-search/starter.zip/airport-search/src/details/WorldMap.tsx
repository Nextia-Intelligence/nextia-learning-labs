import { LAND_PATH, WORLD_HEIGHT, WORLD_WIDTH } from './worldPath';

interface Props {
  latitude: number;
  longitude: number;
  label: string;
}

/** A world map (Natural Earth, public domain) with a dot on one position. */
export function WorldMap({ latitude, longitude, label }: Props) {
  const x = (longitude + 180) * 4;
  const y = (90 - latitude) * 4;
  return (
    <svg className="map" viewBox={`0 0 ${WORLD_WIDTH} ${WORLD_HEIGHT}`} role="img" aria-label={label}>
      <rect width={WORLD_WIDTH} height={WORLD_HEIGHT} className="sea" />
      <path d={LAND_PATH} className="land" />
      <circle cx={x} cy={y} r={14} className="dot" />
    </svg>
  );
}
