import type { Airport } from '../api/types';
import { TYPE_LABELS } from '../api/types';
import { WorldMap } from './WorldMap';

/** The facts of one airport, and where it is on a world map. */
export function DetailPanel({ airport }: { airport: Airport }) {
  return (
    <div data-detail-for={airport.iata}>
      <h2>
        {airport.iata} · {airport.name}
      </h2>
      <dl className="facts">
        <dt>Place</dt>
        <dd>{[airport.municipality, airport.country].filter(Boolean).join(', ')}</dd>
        <dt>Type</dt>
        <dd>{TYPE_LABELS[airport.type]}{airport.scheduled_service === 'yes' ? ', scheduled flights' : ''}</dd>
        <dt>ICAO or local code</dt>
        <dd>{airport.ident}</dd>
        <dt>Position</dt>
        <dd>
          {airport.latitude.toFixed(2)}°, {airport.longitude.toFixed(2)}°
          {airport.elevation_ft !== null && `, ${airport.elevation_ft.toLocaleString('en')} ft above sea level`}
        </dd>
      </dl>
      <WorldMap latitude={airport.latitude} longitude={airport.longitude} label={`${airport.name} on a world map`} />
    </div>
  );
}
