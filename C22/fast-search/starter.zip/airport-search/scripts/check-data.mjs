// Checks that data/airports.csv is the exact file of the case study (its SHA-256 checksum).
//   npm run check:data
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';

const EXPECTED = '15c19f9318288d3173ca5a04e2da63274e3474b9a3969944587785a7f8489f3e';
const file = new URL('../data/airports.csv', import.meta.url);
const data = readFileSync(file);
const sha = createHash('sha256').update(data).digest('hex');
const rows = data.toString('utf8').trimEnd().split('\n').length - 1;
if (sha !== EXPECTED) {
  console.error(`data/airports.csv has changed: SHA-256 ${sha.slice(0, 12)}…, expected ${EXPECTED.slice(0, 12)}…`);
  console.error('Your numbers will not match the case study. Download the starter again, or see DATASET.md.');
  process.exit(1);
}
console.log(`data/airports.csv: ${rows.toLocaleString('en')} airports, ${data.length.toLocaleString('en')} bytes, SHA-256 ${sha.slice(0, 12)}… is correct`);
