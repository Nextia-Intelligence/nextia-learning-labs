// Checks of the airport API: node --test "api/*.test.mjs" (part of npm test).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createApi } from './server.mjs';
import { loadAirports, parseCsv } from './airports.mjs';

const airports = loadAirports();

async function withApi(fn, options = {}) {
  const { server } = createApi({ log: false, airports, ...options });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    await fn(base);
  } finally {
    server.close();
  }
}
const get = async (url, headers = {}) => {
  const res = await fetch(url, { headers });
  return { status: res.status, headers: res.headers, body: await res.json() };
};

test('the CSV reader keeps commas and quotes inside quoted fields', () => {
  assert.deepEqual(parseCsv('a,b\n"x, y","say ""hi"""\n'), [{ a: 'x, y', b: 'say "hi"' }]);
});

test('the data has 9,051 airports, each with a unique IATA code', () => {
  assert.equal(airports.length, 9051);
  assert.equal(new Set(airports.map((a) => a.iata)).size, 9051);
});

test('one airport by its code, and 404 for an unknown code', async () => {
  await withApi(async (base) => {
    assert.equal((await get(`${base}/v1/airports/lhr`)).body.name, 'London Heathrow Airport');
    const missing = await get(`${base}/v1/airports/QQQ`);
    assert.equal(missing.status, 404);
    assert.equal(missing.body.error.code, 'not_found');
  });
});

test('every airport at once, compressed when the client accepts gzip', async () => {
  await withApi(async (base) => {
    const res = await fetch(`${base}/v1/airports/all`, { headers: { 'Accept-Encoding': 'gzip' } });
    assert.equal(res.headers.get('content-encoding'), 'gzip');
    assert.equal((await res.json()).items.length, 9051);
  });
});

test('only the allowed origins get the CORS header', async () => {
  await withApi(async (base) => {
    const ok = await get(`${base}/health`, { Origin: 'http://localhost:5173' });
    assert.equal(ok.headers.get('access-control-allow-origin'), 'http://localhost:5173');
    const other = await get(`${base}/health`, { Origin: 'http://evil.example' });
    assert.equal(other.headers.get('access-control-allow-origin'), null);
  });
});

test('--slow waits 60 ms plus 0.1 ms per airport, and counts a request the client closed', async () => {
  await withApi(async (base) => {
    const controller = new AbortController();
    const slow = fetch(`${base}/v1/airports/all`, { signal: controller.signal }); // about 965 ms
    setTimeout(() => controller.abort(), 50);
    await assert.rejects(slow);
    await new Promise((r) => setTimeout(r, 50));
    assert.equal((await get(`${base}/admin/stats`)).body.closed_early, 1);
  }, { slow: true });
});
