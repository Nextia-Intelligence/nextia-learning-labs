// The airports of the API: read the CSV file and keep them in the default order.
// No packages: a small CSV reader is enough for this file (quotes, commas inside quotes).
import { readFileSync } from 'node:fs';

export const TYPES = ['large_airport', 'medium_airport', 'small_airport', 'seaplane_base', 'heliport'];
const TYPE_RANK = Object.fromEntries(TYPES.map((t, i) => [t, i]));

/** Reads CSV text into an array of objects, one per row, keyed by the header. */
export function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const c = text[i];
    if (quoted) {
      if (c === '"' && text[i + 1] === '"') { field += '"'; i += 1; }
      else if (c === '"') quoted = false;
      else field += c;
    } else if (c === '"') quoted = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
    else if (c !== '\r') field += c;
  }
  if (field !== '' || row.length > 0) { row.push(field); rows.push(row); }
  const [header, ...body] = rows;
  return body.map((r) => Object.fromEntries(header.map((h, i) => [h, r[i] ?? ''])));
}

/** The airports of data/airports.csv, with numbers as numbers, in the default order. */
export function loadAirports(file = new URL('../data/airports.csv', import.meta.url)) {
  const airports = parseCsv(readFileSync(file, 'utf8')).map((a) => ({
    ...a,
    latitude: Number(a.latitude),
    longitude: Number(a.longitude),
    elevation_ft: a.elevation_ft === '' ? null : Number(a.elevation_ft),
  }));
  return airports.sort(byDefaultOrder);
}

/** Larger airports first, then by name: the order of an empty search. */
export function byDefaultOrder(a, b) {
  return TYPE_RANK[a.type] - TYPE_RANK[b.type] || a.name.localeCompare(b.name, 'en');
}
