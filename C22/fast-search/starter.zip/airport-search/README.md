# airport-search (starter)

The starter of the case study *Fast search over a public dataset* in [Frontend Architecture and Performance for AI Apps](https://learning.nextia-ai.com/courses/frontend/) (Nextia Learning). Follow the steps on the case study's page.

It is a first prototype that works, and that you will measure and improve:

- **The API** (`api/`, Node.js, no packages) has one way to get airports: `GET /v1/airports/all`, all 9,051 at once.
- **The page** (`src/`, React, TypeScript, Vite) downloads them all when it opens, searches them in the browser at every key press, and draws every matching row.
- **The measurements** (`measure/measure.mjs`, Playwright's Chromium) time the first rows, the search while you type, the whole session and a click on a row.

The packages of the finished project are already in `package.json`, so one `npm install` is enough.

Data: [OurAirports](https://ourairports.com/data/), public domain; see `DATASET.md`. Map: [Natural Earth](https://www.naturalearthdata.com/), public domain. Code: MIT.

## What you need

- Node.js 24 (LTS; 24.15 or later). Check with `node --version`.
- No account, no key and no money.

## Run it

In this folder, in a first terminal:

```sh
npm install
npm run check:data
npm run api
```

In a second terminal:

```sh
npm run dev
```

Open http://localhost:5173/.

| Command | What it does |
|---|---|
| `npm run api` | the API on http://127.0.0.1:8200 (`--slow` adds a simulated server time: 60 ms plus 0.1 ms per airport in the answer) |
| `npm run dev` | the page on http://localhost:5173/ while you work |
| `npm test` | the API's checks (node:test) and the page's tests (Vitest) |
| `npm run build` | type check, then the production build in `dist/` |
| `npm run preview` | serves `dist/` on http://localhost:4173/ |
| `npm run size` | the size of each JavaScript file, unpacked and gzip |
| `npm run check:data` | checks the SHA-256 of `data/airports.csv` |
| `npm run measure -- GROUP --label NAME` | measures the page served by `npm run preview` (groups: `open`, `type`, `session`, `click`) |
