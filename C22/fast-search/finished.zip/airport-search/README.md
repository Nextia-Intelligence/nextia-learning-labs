# airport-search

A fast search interface over 9,051 airports, with a tiny local API. It is the finished project of the case study *Fast search over a public dataset* in [Frontend Architecture and Performance for AI Apps](https://learning.nextia-ai.com/courses/frontend/) (Nextia Learning).

- **The API** (`api/`, Node.js, no packages) searches, filters and pages the airports on the server: `GET /v1/airports?q=paris&type=large_airport&limit=50&after=…`.
- **The page** (`src/`, React, TypeScript, Vite) asks for one page of 50 at a time with TanStack Query, so an old, slow answer never replaces a new one. It draws only the rows in view (TanStack Virtual), and loads the details and their world map in a separate file after the first rows.
- **The measurements** (`measure/measure.mjs`, Playwright's Chromium) time the first rows, the search while you type, the whole session and a click on a row, on a fast network and on a phone-like profile.

Data: [OurAirports](https://ourairports.com/data/), public domain; see `DATASET.md`. Map: [Natural Earth](https://www.naturalearthdata.com/), public domain. Code: MIT.

## What you need

- Node.js 24 (LTS; 24.15 or later). Check with `node --version`.
- No account, no key and no money.

## Run it

In this folder, in a first terminal:

```sh
npm install
npm run check:data
npm run api
```

In a second terminal:

```sh
npm run dev
```

Open http://localhost:5173/. `npm run api -- --slow` adds a simulated server time (60 ms plus 0.1 ms per matching airport), so that you can see what a real server's time does to the page.

| Command | What it does |
|---|---|
| `npm run api` | the API on http://127.0.0.1:8200 (`--slow` for the simulated server time) |
| `npm run dev` | the page on http://localhost:5173/ while you work |
| `npm test` | the API's checks (node:test) and the page's tests (Vitest) |
| `npm run build` | type check, then the production build in `dist/` |
| `npm run preview` | serves `dist/` on http://localhost:4173/ |
| `npm run size` | the size of each JavaScript file, unpacked and gzip |
| `npm run check:data` | checks the SHA-256 of `data/airports.csv` |
| `npm run measure -- GROUP --label NAME` | measures the page served by `npm run preview` (groups: `open`, `type`, `session`, `click`); writes `results/NAME-GROUP.json` |

Before the first measurement, install Playwright's Chromium once: `npx playwright install chromium` (about 100 MB to download).

## Results

Write your own numbers in `docs/results.md`: the computer, the build, the API's mode, and the medians of the passes. Compare only runs made on the same computer, one after the other.
