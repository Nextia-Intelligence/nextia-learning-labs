import { lazy, startTransition, Suspense, useEffect, useState } from 'react';
import type { Airport, SearchFilter } from './api/types';
import { SearchForm } from './search/SearchForm';
import { ResultList } from './search/ResultList';
import { afterFirstRows } from './search/marks';

// A separate file (code splitting): the details and their world map are about a quarter of the
// JavaScript, and the first rows do not need them. The file is loaded after the first rows.
const loadDetails = () => import('./details/DetailPanel');
const DetailPanel = lazy(() => loadDetails().then((m) => ({ default: m.DetailPanel })));

export function App() {
  const [filter, setFilter] = useState<SearchFilter>({ q: '', type: '' });
  const [selected, setSelected] = useState<Airport | null>(null);

  // Load the details' file while the visitor reads the first rows, not when they click.
  useEffect(() => afterFirstRows(() => void loadDetails()), []);

  // A transition: if the file is not there yet, React keeps the old panel until it is, instead
  // of showing "Loading the map…" and then waiting up to 300 ms more to show the panel.
  const select = (airport: Airport) => startTransition(() => setSelected(airport));

  return (
    <main className="layout">
      <header className="top">
        <h1>Airport search</h1>
        <p className="muted">
          9,051 airports with an IATA code. Data:{' '}
          <a href="https://ourairports.com/data/">OurAirports</a> (public domain).
        </p>
      </header>
      <section className="search" aria-labelledby="results-heading">
        <SearchForm value={filter} onChange={setFilter} />
        <ResultList filter={filter} selected={selected?.iata ?? null} onSelect={select} />
      </section>
      <aside className="details" aria-label="Airport details">
        <Suspense fallback={<p className="muted">Loading the map…</p>}>
          {selected === null ? <p className="muted">Choose an airport to see where it is.</p> : <DetailPanel airport={selected} />}
        </Suspense>
      </aside>
    </main>
  );
}
