import { useInfiniteQuery } from '@tanstack/react-query';
import { searchAirports } from '../api/airports';
import type { SearchFilter } from '../api/types';

/**
 * The pages of a search, from the server. The key holds the whole filter, so each search has its
 * own cache entry, and an old search's answer can never be shown for a new one. TanStack Query
 * gives the request a signal: when the filter changes, the old request is closed (cancelled).
 */
export function useAirportSearch(filter: SearchFilter) {
  const q = filter.q.trim();
  return useInfiniteQuery({
    queryKey: ['airports', { q, type: filter.type }],
    queryFn: ({ pageParam, signal }) => searchAirports({ q, type: filter.type }, pageParam, signal),
    initialPageParam: '',
    getNextPageParam: (last) => last.next ?? undefined,
  });
}
