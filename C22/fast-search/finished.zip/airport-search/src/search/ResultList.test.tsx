import { act, screen } from '@testing-library/react';
import { beforeAll, expect, test } from 'vitest';
import type { SearchFilter } from '../api/types';
import { airport, deferred, installFakeApi, json, renderWithCache } from '../test/fake';
import { ResultList } from './ResultList';

// jsdom does not lay out the page, so every element is 0 px high. The virtual list needs the
// height of its scroll box to know how many rows to draw: give every element 600 × 800 px.
beforeAll(() => {
  Object.defineProperty(HTMLElement.prototype, 'offsetHeight', { configurable: true, get: () => 600 });
  Object.defineProperty(HTMLElement.prototype, 'offsetWidth', { configurable: true, get: () => 800 });
});

const list = (filter: SearchFilter) => <ResultList filter={filter} selected={null} onSelect={() => {}} />;

test('shows the airports of the first page and the total', async () => {
  installFakeApi(() => json(200, { items: [airport(1), airport(2)], next: null, total: 2 }));
  renderWithCache(list({ q: '', type: '' }));
  expect(await screen.findByText('Airport number 1')).toBeInTheDocument();
  expect(screen.getByText('Showing 2 of 2 airports.')).toBeInTheDocument();
});

test('draws only the rows in view, not every loaded airport', async () => {
  const items = Array.from({ length: 50 }, (_, i) => airport(i + 1));
  installFakeApi(() => json(200, { items, next: null, total: 50 }));
  renderWithCache(list({ q: '', type: '' }));
  expect(await screen.findByText('Showing 50 of 50 airports.')).toBeInTheDocument();
  const drawn = screen.getAllByRole('button').length;
  expect(drawn).toBeGreaterThan(5);
  expect(drawn).toBeLessThan(25); // 600 px ÷ 56 px ≈ 11 rows, plus 8 below
});

test('an old answer that arrives late does not replace the new one, and its request is closed', async () => {
  const slow = deferred<Response>();
  const signals: Record<string, AbortSignal | undefined> = {};
  installFakeApi((url, signal) => {
    const q = url.searchParams.get('q') ?? '';
    signals[q] = signal;
    return q === 'p' ? slow.promise : json(200, { items: [airport(1, { name: 'Paris-Orly Airport' })], next: null, total: 1 });
  });
  const { rerender } = renderWithCache(list({ q: 'p', type: '' }));
  rerender(list({ q: 'paris', type: '' }));
  expect(await screen.findByText('Paris-Orly Airport')).toBeInTheDocument();
  expect(signals.p?.aborted).toBe(true);
  await act(async () => slow.resolve(json(200, { items: [airport(2, { name: 'Abruzzo Airport' })], next: null, total: 8741 })));
  expect(screen.queryByText('Abruzzo Airport')).not.toBeInTheDocument();
  expect(screen.getByRole('status')).toHaveAttribute('data-results-for', 'paris');
});

test('an error answer is shown in words', async () => {
  installFakeApi(() => json(400, { error: { code: 'invalid_parameter', message: 'limit must be a whole number from 1 to 100.' } }));
  renderWithCache(list({ q: '', type: '' }));
  expect(await screen.findByRole('alert')).toHaveTextContent('limit must be a whole number');
});
