import { useEffect, useRef } from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import type { Airport, SearchFilter } from '../api/types';
import { AirportRow } from './AirportRow';
import { markFirstRows } from './marks';
import { useAirportSearch } from './useAirportSearch';

const ROW_HEIGHT = 56; // px, the height of .row in styles.css (3.5rem)

interface Props {
  filter: SearchFilter;
  selected: string | null;
  onSelect: (airport: Airport) => void;
}

/** The results: pages from the server, and only the rows in view in the page (a virtual list). */
export function ResultList({ filter, selected, onSelect }: Props) {
  const search = useAirportSearch(filter);
  const airports = search.data?.pages.flatMap((p) => p.items) ?? [];
  const total = search.data?.pages[0]?.total ?? 0;

  const scroller = useRef<HTMLDivElement>(null);
  const rows = useVirtualizer({
    count: airports.length,
    getScrollElement: () => scroller.current,
    estimateSize: () => ROW_HEIGHT,
    overscan: 8,
  });
  const visible = rows.getVirtualItems();

  // Near the end of what is loaded: ask the server for the next page.
  const last = visible.at(-1)?.index ?? 0;
  const { hasNextPage, isFetchingNextPage, fetchNextPage } = search;
  useEffect(() => {
    if (hasNextPage && !isFetchingNextPage && last >= airports.length - 10) void fetchNextPage();
  }, [last, airports.length, hasNextPage, isFetchingNextPage, fetchNextPage]);

  useEffect(() => {
    if (airports.length > 0) markFirstRows();
  }, [airports.length]);

  return (
    <>
      <h2 id="results-heading">Results</h2>
      {search.isError ? (
        <p role="alert" className="error">{search.error.message}</p>
      ) : search.data === undefined ? (
        <p className="muted" role="status">Searching…</p>
      ) : (
        <p className="muted" role="status" data-results-for={filter.q.trim()} data-rows={airports.length}>
          {total === 0 ? 'No airport matches.' : `Showing ${airports.length.toLocaleString('en')} of ${total.toLocaleString('en')} airports.`}
        </p>
      )}
      <div ref={scroller} className="scroller" tabIndex={0} role="region" aria-label="Search results">
        <ul className="rows" style={{ height: rows.getTotalSize(), position: 'relative' }}>
          {visible.map((v) => {
            const a = airports[v.index];
            return (
              <li key={a.iata} style={{ position: 'absolute', top: 0, left: 0, right: 0, transform: `translateY(${v.start}px)` }}>
                <AirportRow airport={a} selected={a.iata === selected} onSelect={onSelect} />
              </li>
            );
          })}
        </ul>
      </div>
      {hasNextPage && (
        <button type="button" className="more" disabled={isFetchingNextPage} onClick={() => void fetchNextPage()}>
          {isFetchingNextPage ? 'Loading…' : 'Load 50 more'}
        </button>
      )}
    </>
  );
}
