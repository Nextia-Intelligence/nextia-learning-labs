import { expect, test } from 'vitest';
import { searchPath } from './airports';

test('a search URL has the words, the type, the page size and the cursor', () => {
  expect(searchPath({ q: ' paris ', type: 'large_airport' }, 'NTA')).toBe('/v1/airports?q=paris&type=large_airport&limit=50&after=NTA');
});

test('empty values are left out', () => {
  expect(searchPath({ q: '', type: '' })).toBe('/v1/airports?limit=50');
});
