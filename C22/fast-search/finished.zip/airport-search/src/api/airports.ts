import { apiGet } from './client';
import type { Airport, AirportPage, SearchFilter } from './types';

export const PAGE_SIZE = 50;

/** The URL of one page of a search. Empty values are left out. */
export function searchPath(filter: SearchFilter, after = '', limit = PAGE_SIZE): string {
  const p = new URLSearchParams();
  if (filter.q.trim()) p.set('q', filter.q.trim());
  if (filter.type) p.set('type', filter.type);
  p.set('limit', String(limit));
  if (after) p.set('after', after);
  return `/v1/airports?${p}`;
}

/** One page of the airports that match, filtered and sorted by the server. */
export function searchAirports(filter: SearchFilter, after = '', signal?: AbortSignal): Promise<AirportPage> {
  return apiGet<AirportPage>(searchPath(filter, after), signal);
}

/** Every airport at once (about 300 kB compressed): the starter's way, kept for the comparison. */
export function allAirports(signal?: AbortSignal): Promise<{ items: Airport[]; total: number }> {
  return apiGet('/v1/airports/all', signal);
}
