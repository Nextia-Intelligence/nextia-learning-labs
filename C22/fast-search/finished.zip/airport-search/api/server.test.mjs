// Checks of the airport API: node --test "api/*.test.mjs" (part of npm test).
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createApi } from './server.mjs';
import { loadAirports, page, parseCsv, search } from './airports.mjs';

const airports = loadAirports();

async function withApi(fn, options = {}) {
  const { server } = createApi({ log: false, airports, ...options });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    await fn(base);
  } finally {
    server.close();
  }
}
const get = async (url, headers = {}) => {
  const res = await fetch(url, { headers });
  return { status: res.status, headers: res.headers, body: await res.json() };
};

test('the CSV reader keeps commas and quotes inside quoted fields', () => {
  assert.deepEqual(parseCsv('a,b\n"x, y","say ""hi"""\n'), [{ a: 'x, y', b: 'say "hi"' }]);
});

test('the data has 9,051 airports, each with a unique IATA code', () => {
  assert.equal(airports.length, 9051);
  assert.equal(new Set(airports.map((a) => a.iata)).size, 9051);
});

test('a search finds the code first, then names and cities that start with it', () => {
  const found = search(airports, { q: 'lhr' });
  assert.equal(found[0].iata, 'LHR');
  const paris = search(airports, { q: 'PARIS' }).map((a) => a.iata);
  assert.ok(paris.includes('CDG') && paris.includes('ORY'));
});

test('the type and country filters must both match', () => {
  const found = search(airports, { q: 'london', type: 'large_airport', country: 'GB' });
  assert.deepEqual(found.map((a) => a.iata).sort(), ['LGW', 'LHR', 'LTN', 'STN']);
});

test('pages follow each other with the cursor, without gaps or repeats', () => {
  const matches = search(airports, { q: 'par' });
  const seen = [];
  let after = '';
  do {
    const p = page(matches, 50, after);
    seen.push(...p.items.map((a) => a.iata));
    after = p.next;
  } while (after);
  assert.equal(seen.length, matches.length);
  assert.equal(new Set(seen).size, matches.length);
});

test('GET /v1/airports answers one page of 50 with the total', async () => {
  await withApi(async (base) => {
    const { status, body } = await get(`${base}/v1/airports?q=par`);
    assert.equal(status, 200);
    assert.equal(body.items.length, 50);
    assert.equal(body.total, 160);
    assert.equal(typeof body.next, 'string');
  });
});

test('bad parameters get 400 with the error shape', async () => {
  await withApi(async (base) => {
    for (const q of ['limit=0', 'limit=500', 'type=airport', 'country=GBR', 'after=xyz']) {
      const { status, body } = await get(`${base}/v1/airports?${q}`);
      assert.equal(status, 400, q);
      assert.equal(body.error.code, 'invalid_parameter');
    }
  });
});

test('one airport by its code, and 404 for an unknown code', async () => {
  await withApi(async (base) => {
    assert.equal((await get(`${base}/v1/airports/lhr`)).body.name, 'London Heathrow Airport');
    const missing = await get(`${base}/v1/airports/QQQ`);
    assert.equal(missing.status, 404);
    assert.equal(missing.body.error.code, 'not_found');
  });
});

test('every airport at once, compressed when the client accepts gzip', async () => {
  await withApi(async (base) => {
    const res = await fetch(`${base}/v1/airports/all`, { headers: { 'Accept-Encoding': 'gzip' } });
    assert.equal(res.headers.get('content-encoding'), 'gzip');
    assert.equal((await res.json()).items.length, 9051);
  });
});

test('only the allowed origins get the CORS header', async () => {
  await withApi(async (base) => {
    const ok = await get(`${base}/health`, { Origin: 'http://localhost:5173' });
    assert.equal(ok.headers.get('access-control-allow-origin'), 'http://localhost:5173');
    const other = await get(`${base}/health`, { Origin: 'http://evil.example' });
    assert.equal(other.headers.get('access-control-allow-origin'), null);
  });
});

test('--slow waits 60 ms plus 0.1 ms per match, and counts a request the client closed', async () => {
  await withApi(async (base) => {
    const start = performance.now();
    await get(`${base}/v1/airports?q=paris`); // 8 matches: about 61 ms
    assert.ok(performance.now() - start >= 60);
    const controller = new AbortController();
    const slow = fetch(`${base}/v1/airports?q=p`, { signal: controller.signal }); // about 934 ms
    setTimeout(() => controller.abort(), 50);
    await assert.rejects(slow);
    await new Promise((r) => setTimeout(r, 50));
    assert.equal((await get(`${base}/admin/stats`)).body.closed_early, 1);
  }, { slow: true });
});
