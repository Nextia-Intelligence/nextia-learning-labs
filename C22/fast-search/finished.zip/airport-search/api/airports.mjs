// The airports and the search rules of the API: read the CSV file, search, sort and page.
// No packages: a small CSV reader is enough for this file (quotes, commas inside quotes).
import { readFileSync } from 'node:fs';

export const TYPES = ['large_airport', 'medium_airport', 'small_airport', 'seaplane_base', 'heliport'];
const TYPE_RANK = Object.fromEntries(TYPES.map((t, i) => [t, i]));

/** Reads CSV text into an array of objects, one per row, keyed by the header. */
export function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const c = text[i];
    if (quoted) {
      if (c === '"' && text[i + 1] === '"') { field += '"'; i += 1; }
      else if (c === '"') quoted = false;
      else field += c;
    } else if (c === '"') quoted = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
    else if (c !== '\r') field += c;
  }
  if (field !== '' || row.length > 0) { row.push(field); rows.push(row); }
  const [header, ...body] = rows;
  return body.map((r) => Object.fromEntries(header.map((h, i) => [h, r[i] ?? ''])));
}

/** The airports of data/airports.csv, with numbers as numbers, in the default order. */
export function loadAirports(file = new URL('../data/airports.csv', import.meta.url)) {
  const airports = parseCsv(readFileSync(file, 'utf8')).map((a) => ({
    ...a,
    latitude: Number(a.latitude),
    longitude: Number(a.longitude),
    elevation_ft: a.elevation_ft === '' ? null : Number(a.elevation_ft),
  }));
  return airports.sort(byDefaultOrder);
}

/** Larger airports first, then by name: the order of an empty search. */
export function byDefaultOrder(a, b) {
  return TYPE_RANK[a.type] - TYPE_RANK[b.type] || a.name.localeCompare(b.name, 'en');
}

// The text a search looks in, made once per airport.
const texts = new WeakMap();
function textOf(a) {
  let t = texts.get(a);
  if (t === undefined) {
    t = `${a.iata} ${a.ident} ${a.name} ${a.municipality} ${a.country}`.toLowerCase();
    texts.set(a, t);
  }
  return t;
}

/**
 * Every airport that matches, best first. `q` is found anywhere in the code, the name, the city
 * or the country (case does not matter); `type` and `country` (a two-letter code) must be equal.
 * Best first: the IATA code itself, then names or cities that start with q, then the rest;
 * larger airports first in each group.
 */
export function search(airports, { q = '', type = '', country = '' } = {}) {
  const query = q.trim().toLowerCase();
  const found = airports.filter(
    (a) => (!type || a.type === type) && (!country || a.country_code === country) && (!query || textOf(a).includes(query)),
  );
  if (!query) return found; // already in the default order
  const group = (a) =>
    a.iata.toLowerCase() === query ? 0
      : a.name.toLowerCase().startsWith(query) || a.municipality.toLowerCase().startsWith(query) ? 1
        : 2;
  return found.sort((a, b) => group(a) - group(b) || byDefaultOrder(a, b));
}

/**
 * One page of the matches. `after` is the cursor of the last page (an opaque text for the client).
 * Here it is the position in the matches: the data never changes while the API runs, so a
 * position is safe. With data that changes, use a key of the last row, as the course's ticket API does.
 */
export function page(matches, limit, after = '') {
  const start = after ? Number.parseInt(Buffer.from(after, 'base64url').toString(), 10) : 0;
  if (!Number.isInteger(start) || start < 0) return null;
  const items = matches.slice(start, start + limit);
  const end = start + items.length;
  return { items, next: end < matches.length ? Buffer.from(String(end)).toString('base64url') : null, total: matches.length };
}
