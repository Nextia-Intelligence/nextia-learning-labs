// The airport search API: a tiny local server for this case study. Node.js only, no packages.
//
//   node api/server.mjs           # http://127.0.0.1:8200
//   node api/server.mjs --slow    # adds a simulated server time (see below)
//
// GET /health                      {"status":"ok","airports":9051}
// GET /v1/airports?q=&type=&country=&limit=50&after=
//                                  one page of the airports that match: {items, next, total}
// GET /v1/airports/all             every airport at once (the starter's way)
// GET /v1/airports/{IATA}          one airport, or 404 with the error shape
// GET /admin/stats, POST /admin/reset   request counters, for the measurements
//
// --slow (or SLOW=1): every answer waits 60 ms plus 0.1 ms per matching airport before it is
// sent, as a real server whose time grows with the work. This time is simulated (constructed):
// on your computer the search itself takes a few milliseconds.
// Settings: PORT / --port (8200), CORS_ORIGINS (http://localhost:5173,http://localhost:4173),
// LOG (1; 0 = quiet).
import { createServer } from 'node:http';
import { gzipSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';
import { TYPES, loadAirports, page, search } from './airports.mjs';

export function createApi(options = {}) {
  const o = {
    slow: options.slow ?? process.env.SLOW === '1',
    origins: (options.origins ?? process.env.CORS_ORIGINS ?? 'http://localhost:5173,http://localhost:4173')
      .split(',').map((s) => s.trim()).filter(Boolean),
    log: options.log ?? process.env.LOG !== '0',
  };
  const airports = options.airports ?? loadAirports();
  const byIata = new Map(airports.map((a) => [a.iata, a]));
  let stats;
  const reset = () => { stats = { requests: 0, by_route: {}, closed_early: 0 }; };
  reset();

  function send(req, res, status, body) {
    let data = Buffer.from(JSON.stringify(body));
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    if (data.length > 1024 && /\bgzip\b/.test(req.headers['accept-encoding'] ?? '')) {
      data = gzipSync(data);
      res.setHeader('Content-Encoding', 'gzip');
    }
    res.writeHead(status).end(data);
  }
  const error = (req, res, status, code, message) => send(req, res, status, { error: { code, message } });

  // Waits like a server whose time grows with the matches (only with --slow). Stops early if the
  // client has gone: the browser closed the request.
  const wait = (matches, res) => new Promise((resolve) => {
    if (!o.slow) return resolve(true);
    const timer = setTimeout(() => resolve(true), 60 + 0.1 * matches);
    res.on('close', () => { clearTimeout(timer); resolve(false); });
  });

  async function route(req, res, url) {
    const path = url.pathname;
    if (req.method === 'GET' && path === '/health') return ['health', () => send(req, res, 200, { status: 'ok', airports: airports.length })];
    if (req.method === 'GET' && path === '/admin/stats') return ['admin', () => send(req, res, 200, stats)];
    if (req.method === 'POST' && path === '/admin/reset') return ['admin', () => { reset(); send(req, res, 200, { status: 'reset' }); }];
    if (req.method === 'GET' && path === '/v1/airports/all') {
      return ['all', async () => {
        if (await wait(airports.length, res)) send(req, res, 200, { items: airports, total: airports.length });
      }];
    }
    if (req.method === 'GET' && path === '/v1/airports') {
      return ['search', async () => {
        const p = url.searchParams;
        const limit = Number(p.get('limit') ?? 50);
        const type = p.get('type') ?? '';
        const country = (p.get('country') ?? '').toUpperCase();
        if (!Number.isInteger(limit) || limit < 1 || limit > 100) return error(req, res, 400, 'invalid_parameter', 'limit must be a whole number from 1 to 100.');
        if (type && !TYPES.includes(type)) return error(req, res, 400, 'invalid_parameter', `type must be one of: ${TYPES.join(', ')}.`);
        if (country && !/^[A-Z]{2}$/.test(country)) return error(req, res, 400, 'invalid_parameter', 'country must be a two-letter code, for example GB.');
        const matches = search(airports, { q: p.get('q') ?? '', type, country });
        const result = page(matches, limit, p.get('after') ?? '');
        if (result === null) return error(req, res, 400, 'invalid_parameter', 'after is not a cursor of this API.');
        if (await wait(matches.length, res)) send(req, res, 200, result);
      }];
    }
    const one = /^\/v1\/airports\/([A-Za-z0-9]{3})$/.exec(path);
    if (req.method === 'GET' && one) {
      return ['one', () => {
        const a = byIata.get(one[1].toUpperCase());
        return a ? send(req, res, 200, a) : error(req, res, 404, 'not_found', `There is no airport with the code ${one[1].toUpperCase()}.`);
      }];
    }
    return ['other', () => error(req, res, 404, 'not_found', `There is nothing at ${req.method} ${path}.`)];
  }

  const server = createServer(async (req, res) => {
    const started = performance.now();
    const url = new URL(req.url, 'http://localhost');
    const origin = req.headers.origin;
    if (origin && o.origins.includes(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Timing-Allow-Origin', origin); // lets the page's measurements see the sizes
      res.setHeader('Vary', 'Origin');
    }
    if (req.method === 'OPTIONS') {
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST');
      return res.writeHead(204).end();
    }
    const [name, handle] = await route(req, res, url);
    stats.requests += 1;
    stats.by_route[name] = (stats.by_route[name] ?? 0) + 1;
    res.on('close', () => {
      const early = !res.writableFinished;
      if (early) stats.closed_early += 1;
      if (o.log && name !== 'admin') {
        const ms = Math.round(performance.now() - started);
        console.log(`${req.method} ${url.pathname}${url.search} ${early ? 'closed by the client' : res.statusCode} ${ms} ms`);
      }
    });
    await handle();
  });
  return { server, stats: () => stats };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const i = args.indexOf('--port');
  const port = Number(i === -1 ? (process.env.PORT ?? 8200) : args[i + 1]);
  const slow = args.includes('--slow') || process.env.SLOW === '1';
  const { server } = createApi({ slow });
  server.listen(port, '127.0.0.1', () => {
    console.log(`Airport search API on http://127.0.0.1:${port} (${slow ? 'slow: 60 ms + 0.1 ms per match, simulated' : 'no added wait'})`);
    console.log('Data: OurAirports (public domain), 9,051 airports with an IATA code.');
  });
}
