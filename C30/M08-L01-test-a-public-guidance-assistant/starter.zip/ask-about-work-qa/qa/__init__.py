"""The QA runner: runs YAML test cases against the assistant, several runs each.

    python -m qa run cases/ --version 1.0

This is the course's QA runner, adapted to a one-message assistant: the same case format (id, title, message,
variants, relation, checks, runs, pass, status, bug), without the order and tool checks. See README.md.
"""

RUNNER_VERSION = "1.0.0-guide"
