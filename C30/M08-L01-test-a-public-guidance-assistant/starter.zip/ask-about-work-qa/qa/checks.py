"""The checks that a case can use. Each check returns (passed, message); passed is None when the check could not
run (for example, no recorded answer for this question and run)."""

import re
import unicodedata

REFUSAL = re.compile(r"(can't|cannot|can not|won't|will not|unable to) (help|assist|create|write|make|provide)", re.I)


def _fold(s: str) -> str:
    s = unicodedata.normalize("NFKC", s).replace("’", "'").replace(" ", " ").replace("*", "")
    return s.lower()


def _list(v) -> list:
    return v if isinstance(v, list) else [v]


def _matches(key: str, ref: str) -> bool:
    """A section id 'statutory-sick-pay/eligibility#2' matches 'statutory-sick-pay',
    'statutory-sick-pay/eligibility' and 'statutory-sick-pay/eligibility#2'."""
    ref = str(ref)
    if "#" in ref:
        return key == ref
    if "/" in ref:
        return key.split("#")[0] == ref
    return key.split("/")[0] == ref


def run_check(check: dict, run: dict) -> tuple[bool | None, str]:
    name, arg = next(iter(check.items()))
    if run.get("not_recorded"):
        return None, f"no recorded answer for this {run['not_recorded']} (use --live, or a recorded question)"
    if run.get("error") and name != "no_error":
        return False, f"{name}: the app failed with an error ({run['error']})"
    reply = run["reply"] or ""
    r = _fold(reply)
    if name == "contains":
        missing = [x for x in _list(arg) if _fold(str(x)) not in r]
        return (not missing, f"contains: missing {missing}" if missing else "")
    if name == "contains_any":
        ok = any(_fold(str(x)) in r for x in _list(arg))
        return ok, "" if ok else f"contains_any: none of {_list(arg)}"
    if name == "not_contains":
        found = [x for x in _list(arg) if _fold(str(x)) in r]
        return (not found, f"not_contains: found {found}" if found else "")
    if name == "regex":
        ok = re.search(str(arg), _fold(reply), re.I | re.S) is not None
        return ok, "" if ok else f"regex: no match for {arg}"
    if name == "not_regex":
        m = re.search(str(arg), _fold(reply), re.I | re.S)
        return m is None, "" if m is None else f"not_regex: matched {m.group(0)!r}"
    trace = run["trace"] or {}
    cited = trace.get("cited") or []
    retrieved = [d["id"] for d in trace.get("retrieved") or []]
    if name == "cites":
        ok = all(any(_matches(k, ref) for k in cited) for ref in _list(arg))
        return ok, "" if ok else f"cites: expected {arg}, cited {cited or 'nothing'}"
    if name == "cites_any":
        ok = any(_matches(k, ref) for k in cited for ref in _list(arg))
        return ok, "" if ok else f"cites_any: expected one of {arg}, cited {cited or 'nothing'}"
    if name == "not_cites":
        bad = [k for k in cited for ref in _list(arg) if _matches(k, ref)]
        return not bad, "" if not bad else f"not_cites: cited {bad}"
    if name == "retrieved":
        ok = all(any(_matches(k, ref) for k in retrieved) for ref in _list(arg))
        return ok, "" if ok else f"retrieved: {arg} was not retrieved"
    if name == "not_retrieved":
        bad = [ref for ref in _list(arg) if any(_matches(k, ref) for k in retrieved)]
        return not bad, "" if not bad else f"not_retrieved: {bad} was retrieved"
    if name == "no_error":
        return run.get("error") is None, "" if run.get("error") is None else f"no_error: {run['error']}"
    if name == "refuses":
        refused = REFUSAL.search(_fold(reply)) is not None
        return refused == bool(arg), "" if refused == bool(arg) else (
            "refuses: the reply does not refuse" if arg else "refuses: the reply refuses a request it should answer")
    if name == "max_words":
        n = len(reply.split())
        return n <= int(arg), "" if n <= int(arg) else f"max_words: {n} > {arg}"
    return False, f"unknown check {name}"
