"""Runs each case N times against the assistant and applies its checks.

Run k of a case is the k-th recorded answer of the model to that message (or a new live answer with --live), so
the same command always gives the same results on the recordings.
"""

import json
from pathlib import Path

from guide import assistant, config

from .checks import run_check


class Runner:
    def __init__(self, version: str, mode: str = "recorded"):
        config.get(version)
        self.version = version
        self.mode = mode

    def versions(self) -> dict:
        cfg = config.get(self.version)
        return {"app": "ask-about-work", "app_version": self.version, "prompt_version": cfg["prompt"],
                "model": config.RECORDED_MODEL if self.mode == "recorded" else "live",
                "settings": {k: cfg[k] for k in ("top_k", "tables", "ignore_numbers")}}

    def run_case(self, case, runs: int, seed_start: int) -> dict:
        results = []
        for i in range(runs):
            run = seed_start + i
            if case.variants:
                outs = [self._one(case, run, v) for v in case.variants]
                results.append(self._relate(case, run, outs))
            else:
                results.append(self._one(case, run, case.steps[-1]))
        passed = sum(r["passed"] is True for r in results)
        not_run = sum(r["passed"] is None for r in results)
        need = case.required(runs)
        if not_run and passed + not_run >= need and passed < need:
            verdict = "not_run"
        else:
            verdict = "pass" if passed >= need else "fail"
        return {"id": case.id, "title": case.title, "file": str(case.file), "status": case.status, "bug": case.bug,
                "runs": runs, "passed_runs": passed, "not_run_runs": not_run, "required": need,
                "rule": case.pass_rule, "result": verdict, "run_results": results}

    def _one(self, case, run: int, message: str) -> dict:
        out = {"error": None}
        try:
            trace = assistant.answer(message, self.version, run=run, mode=self.mode)
        except SystemExit as e:  # the app stopped with a message: a finding, not a runner error
            trace, out["error"] = None, str(e)
        out["trace"] = trace
        out["reply"] = trace["answer"] if trace else None
        out["not_recorded"] = trace.get("not_recorded") if trace else None
        failures, unknown = [], []
        for c in case.checks:
            ok, msg = run_check(c, out)
            if ok is None:
                unknown.append(msg)
            elif not ok:
                failures.append(msg)
        passed = False if failures else (None if unknown else True)
        return {"seed": run, "passed": passed, "failures": failures + sorted(set(unknown)), "reply": out["reply"],
                "error": out["error"], "trace_id": trace.get("trace_id") if trace else None, "export": trace}

    def _relate(self, case, run: int, outs: list[dict]) -> dict:
        """Metamorphic relation: the variants must give the same check results (or all pass)."""
        if case.relation == "all_pass":
            ok = all(o["passed"] is True for o in outs)
            fails = [f"variant {n}: {f}" for n, o in enumerate(outs, 1) for f in o["failures"]]
        else:
            ok = len({o["passed"] for o in outs}) == 1
            fails = [] if ok else [
                "the variants give different results: " + ", ".join(
                    f"variant {n} {'passes' if o['passed'] else 'fails'}" for n, o in enumerate(outs, 1))
            ] + [f"variant {n}: {f}" for n, o in enumerate(outs, 1) for f in o["failures"]]
        if any(o["passed"] is None for o in outs):
            ok = None
        return {"seed": run, "passed": ok, "failures": fails, "reply": " || ".join(str(o["reply"]) for o in outs),
                "error": next((o["error"] for o in outs if o["error"]), None),
                "trace_id": " + ".join(str(o["trace_id"]) for o in outs),
                "export": [o["export"] for o in outs],
                "variants": [{"passed": o["passed"], "reply": o["reply"], "failures": o["failures"]} for o in outs]}


def save_exports(result: dict, folder: Path) -> list[str]:
    """Saves the trace of every failing run, to attach to a bug report."""
    saved = []
    for r in result["run_results"]:
        if r["passed"] is True:
            continue
        folder.mkdir(parents=True, exist_ok=True)
        p = folder / f"{result['id']}-run{r['seed']}.json"
        p.write_text(json.dumps(r["export"], indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        saved.append(p.as_posix())
    return saved
