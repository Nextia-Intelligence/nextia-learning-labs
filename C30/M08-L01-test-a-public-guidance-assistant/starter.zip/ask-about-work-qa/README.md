# Ask about work: a test campaign on a public-guidance assistant

"Ask about work" answers questions about pay and leave at work from a fixed sample of GOV.UK guidance (16 guides).
This folder has the assistant, the real model's recorded answers, a QA runner and the test campaign's files.
It is the project of the case study *Test a public-guidance assistant* of the course *Testing AI Applications:
Manual and AI-Assisted QA* on Nextia Learning.

Thistlecombe Advice Centre, Joanna and Callum are made up. The guidance text is GOV.UK's (see `DATASET.md`).
**This is not legal advice**: the assistant is a test object, and its answers contain known errors.

## What you need

- Python 3.10 or newer, VS Code (or any editor) and a terminal.
- No account, no key and no money: every answer comes from `recordings/`.
- About 5 MB of disk space with the virtual environment.

## Set up

macOS and Linux:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m guide check
```

Windows (PowerShell):

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m guide check
```

`python -m guide check` checks the SHA-256 of the guidance sample and that every recording finds the same sections
in your copy.

## The assistant

| Command | What it does |
|---|---|
| `python -m guide questions` | lists the 45 recorded questions (10 runs each) |
| `python -m guide ask "QUESTION"` | the recorded answer of run 1, with the sections it was given; `--run 3`, `--all-runs`, `--version 1.1` |
| `python -m guide trace q02-v1.0-r3` | what was retrieved (with scores) and cited for one answer, and the versions |
| `python -m guide export q02-v1.0-r3 -o q02.json` | the same as JSON, to attach to a bug report |
| `python -m guide show statutory-sick-pay/eligibility#2` | the text of one section of the guidance |

Two versions are recorded. **1.0** is the first release candidate (prompt `guide/prompts/1.0.md`, 4 sections).
**1.1** has the developer's fixes after the first campaign (prompt `1.1.md`, 6 sections, the search ignores numbers).
`guide/config.py` lists the settings.

A question must be typed as recorded (case and spaces do not matter). Another question answers "No recorded answer".

## The QA runner

The course's QA runner, for a one-message assistant. Cases are YAML files:

```yaml
- id: R1-01
  title: Minimum wage for a 19-year-old
  message: What is the minimum wage for a 19-year-old?
  checks:
    - contains: "£10.85"
    - cites: national-minimum-wage-rates
```

```sh
python -m qa run cases/ --version 1.0          # every case, 10 runs each
python -m qa run cases/rates.yaml --version 1.1 -v
python -m qa check cases/                      # only check the files
```

Checks: `contains`, `contains_any`, `not_contains`, `regex`, `not_regex`, `cites`, `cites_any`, `not_cites`,
`retrieved`, `not_retrieved`, `refuses`, `max_words`, `no_error`. A section reference is a guide
(`statutory-sick-pay`), a part (`statutory-sick-pay/eligibility`) or a section (`statutory-sick-pay/eligibility#2`).
`variants:` with `relation: same_results` or `all_pass` makes a metamorphic relation. `status: known-bug` with
`bug: BUG-03` marks a case that fails because of a known bug (`KNOWN`; `FIXED?` when it passes). Each run writes
`reports/qa-<version>-<time>/report.md` with the failing runs and their traces.

## The campaign's files

| Folder | What is in it |
|---|---|
| `templates/` | the course's templates (CC0) |
| `qa-work/` | risk table, acceptance criteria, rubric and scores, relations, two charters with notes, bug reports, the release sign-off (finished project only) |
| `cases/` | the regression set |
| `pilot/` | eight questions from the pilot week, run once at the end |

## Live mode (optional)

`--live` asks your own model at an OpenAI-compatible endpoint instead of the recordings: set `GUIDE_LIVE_URL` (ends
in `/v1`), `GUIDE_LIVE_MODEL` and, if needed, `GUIDE_LIVE_KEY`. It costs money with a paid provider, and the answers
will differ from the recordings. `python -m qa run ... --live` runs the cases live. The key is never printed or saved.
On Python from python.org on macOS, run "Install Certificates.command" once if HTTPS fails.

## Licences

Code: MIT (`LICENSE`). Guidance sample: Open Government Licence v3.0 (`DATASET.md`). Templates: CC0 1.0.
