# Your QA workspace

Copy a template from `../templates/` into this folder for each step of the case study, then fill it in:

1. `risk-table.md` and `acceptance-criteria.md`
2. `rubric.md` (and your scores of a few answers)
3. `metamorphic-relations.md`
4. `sessions/charter-1-....md` and `sessions/charter-2-....md` (a charter and its session notes in each)
5. `bugs/BUG-01-....md` (one agent-ready, with its failing case `bugs/BUG-01.yaml`), more bug reports
6. `release-sign-off-1.1.md`

Your test cases go in `../cases/`. The finished project has the course author's version of every file.
