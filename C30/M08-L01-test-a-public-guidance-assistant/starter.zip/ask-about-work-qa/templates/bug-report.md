# <ID>: <summary: what goes wrong, where, how often>

<!-- A person who was not in your session must reproduce the bug from this report alone. Keep secrets and
personal data out: made-up people only, no keys, no real names. -->

- **Version:** app <...>, prompt <...>, model <... (simulated / real)>, settings <run numbers>
- **Severity:** <critical / high / medium / low> because <harm> and <frequency>
- **Priority:** <set in triage>

## Steps to reproduce

1. <exact command, for example: `python -m guide ask "..." --version 1.0 --run 3`>

## Actual result

<the reply, word for word, or the part that matters> - trace <q02-v1.0-r1>; what the trace shows (retrieved sections, what was cited)

## Expected result

- Must: <checkable rule>
- Must not: <checkable rule>

## Reproduction rate

<x> of <y> runs (runs <...>), <simulated / recorded>. <What more runs would tell us.>

## Evidence

- Export: <file> (`python -m guide export <trace ID> -o <file>`)
- Trace ID(s): <...>

## Notes

<suspected layer (a guess, with the reason), related bugs, workaround>
