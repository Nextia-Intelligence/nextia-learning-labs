"""The guidance: a fixed sample of GOV.UK guides, cut into short sections for retrieval.

Each guide part (for example "Statutory Sick Pay: Eligibility") is cut at its headings into sections.
How tables become text depends on the version of the app (see config.py):
  "flat"  every table cell on its own line, as a simple HTML-to-text step gives it
  "rows"  one line per table row, with the column headings, like a Markdown table
"""

import hashlib
import json
import re
from dataclasses import dataclass
from html import unescape
from html.parser import HTMLParser
from pathlib import Path

DATA = Path(__file__).resolve().parents[1] / "data"
SAMPLE = DATA / "govuk-sample.jsonl"
SUMS = DATA / "SHA256SUMS"


@dataclass
class Section:
    id: str          # "statutory-sick-pay/eligibility#2"
    page: str        # "statutory-sick-pay"
    part: str        # "eligibility"
    title: str       # "Statutory Sick Pay (SSP) > Eligibility > Telling your employer"
    url: str         # the GOV.UK address of the part
    text: str


class _Text(HTMLParser):
    """HTML to plain lines. Headings start with '## '. Tables follow the table mode."""

    BLOCK = {"p", "li", "div", "br", "tr", "h2", "h3", "h4", "ul", "ol", "table", "caption"}

    def __init__(self, tables: str):
        super().__init__(convert_charrefs=True)
        self.tables = tables
        self.lines: list[str] = []
        self.buf: list[str] = []
        self.heading = False
        self.in_table = 0
        self.row: list[str] | None = None
        self.cell: list[str] | None = None

    def _flush(self):
        line = re.sub(r"\s+", " ", "".join(self.buf)).strip()
        self.buf = []
        if line:
            self.lines.append(("## " + line) if self.heading else line)

    def handle_starttag(self, tag, attrs):
        if tag == "table":
            self._flush()
            self.in_table += 1
        if self.in_table and self.tables == "rows":
            if tag == "tr":
                self.row = []
            elif tag in ("td", "th"):
                self.cell = []
            return
        if tag in ("h2", "h3", "h4"):
            self._flush()
            self.heading = True
        elif tag in self.BLOCK or tag in ("td", "th"):
            self._flush()

    def handle_endtag(self, tag):
        if self.in_table and self.tables == "rows":
            if tag in ("td", "th") and self.cell is not None and self.row is not None:
                self.row.append(re.sub(r"\s+", " ", "".join(self.cell)).strip())
                self.cell = None
            elif tag == "tr" and self.row is not None:
                self.lines.append("| " + " | ".join(c or "-" for c in self.row) + " |")
                self.row = None
            elif tag == "table":
                self.in_table -= 1
            return
        if tag == "table":
            self.in_table -= 1
        if tag in ("h2", "h3", "h4"):
            self._flush()
            self.heading = False
        elif tag in self.BLOCK or tag in ("td", "th"):
            self._flush()

    def handle_data(self, data):
        if self.in_table and self.tables == "rows" and self.cell is not None:
            self.cell.append(data)
        else:
            self.buf.append(data)

    def close(self):
        super().close()
        self._flush()


def html_to_lines(html: str, tables: str = "flat") -> list[str]:
    p = _Text(tables)
    p.feed(unescape(html) if "&lt;" in html else html)
    p.close()
    return p.lines


def check_sample() -> str:
    """Checks the sample against SHA256SUMS. Returns the checksum, or stops with a clear message."""
    want = SUMS.read_text().split()[0]
    got = hashlib.sha256(SAMPLE.read_bytes()).hexdigest()
    if got != want:
        raise SystemExit(f"data/govuk-sample.jsonl has changed: SHA-256 {got[:12]}..., expected {want[:12]}...")
    return got


def records() -> list[dict]:
    return [json.loads(line) for line in SAMPLE.read_text(encoding="utf-8").splitlines() if line.strip()]


def sections(tables: str = "flat", min_words: int = 40) -> list[Section]:
    """All sections of the sample: each guide part cut at its headings; short pieces join the next one."""
    out: list[Section] = []
    for r in records():
        pieces: list[tuple[str, list[str]]] = [("", [])]
        for line in html_to_lines(r["html"], tables):
            if line.startswith("## "):
                pieces.append((line[3:], []))
            else:
                pieces[-1][1].append(line)
        # Join a short piece to the next one, so that every section has enough words to be found.
        merged: list[tuple[str, list[str]]] = []
        head0, acc = None, []
        for head, lines in pieces:
            if acc and head:
                acc.append(head)
            elif not acc:
                head0 = head
            acc += lines
            if sum(len(x.split()) for x in acc) >= min_words:
                merged.append((head0, acc))
                head0, acc = None, []
        if acc:
            if merged:
                merged[-1] = (merged[-1][0], merged[-1][1] + acc)
            else:
                merged.append((head0, acc))
        base = f"{r['page_title']} > {r['part_title']}" if r["part"] != "main" else r["page_title"]
        for i, (head, lines) in enumerate(merged, 1):
            title = f"{base} > {head}" if head else base
            out.append(Section(id=f"{r['page']}/{r['part']}#{i}", page=r["page"], part=r["part"], title=title,
                               url=r["url"], text="\n".join(lines)))
    return out
