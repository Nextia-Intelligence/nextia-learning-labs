"""Live mode: ask a model at an OpenAI-compatible endpoint (your own key, or a local model server).

Set GUIDE_LIVE_URL (ends in /v1), GUIDE_LIVE_MODEL and, if the server needs one, GUIDE_LIVE_KEY.
The key is never printed or saved.
"""

import json
import os
import ssl
import time
import urllib.error
import urllib.request


def _context():
    try:
        import certifi  # not required; it helps on Python installs without system certificates
        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        return ssl.create_default_context()


def settings() -> tuple[str, str]:
    url, model = os.environ.get("GUIDE_LIVE_URL", ""), os.environ.get("GUIDE_LIVE_MODEL", "")
    if not url or not model:
        raise SystemExit("Live mode needs GUIDE_LIVE_URL and GUIDE_LIVE_MODEL (and GUIDE_LIVE_KEY if your server "
                         "needs a key). See README.md, section 'Live mode'.")
    return url, model


def complete(messages: list[dict], max_tokens: int, retries: int = 4) -> dict:
    url, model = settings()
    body = {"model": model, "messages": messages, "max_completion_tokens": max_tokens}
    req = urllib.request.Request(url.rstrip("/") + "/chat/completions", data=json.dumps(body).encode(), method="POST")
    req.add_header("Content-Type", "application/json")
    key = os.environ.get("GUIDE_LIVE_KEY", "")
    if key:
        req.add_header("Authorization", f"Bearer {key}")
        req.add_header("api-key", key)
    for attempt in range(retries + 1):
        try:
            t0 = time.time()
            with urllib.request.urlopen(req, timeout=120, context=_context()) as r:
                data = json.loads(r.read())
            break
        except urllib.error.HTTPError as e:
            if e.code in (429, 500, 502, 503) and attempt < retries:
                time.sleep(int(e.headers.get("Retry-After") or 0) or 5 * (attempt + 1))
                continue
            raise SystemExit(f"The model server answered HTTP {e.code}: {e.read()[:300]!r}") from None
        except (TimeoutError, urllib.error.URLError) as e:
            if attempt < retries:
                time.sleep(5 * (attempt + 1))
                continue
            raise SystemExit(f"Could not reach the model server: {e}") from None
    choice = data["choices"][0]
    usage = data.get("usage") or {}
    details = usage.get("completion_tokens_details") or {}
    return {
        "text": choice["message"].get("content") or "",
        "finish_reason": choice.get("finish_reason"),
        "model_id": data.get("model", model),
        "request_id": data.get("id"),
        "latency_s": round(time.time() - t0, 3),
        "usage": {"input_tokens": usage.get("prompt_tokens"), "output_tokens": usage.get("completion_tokens"),
                  "reasoning_tokens": details.get("reasoning_tokens")},
    }
