"""python -m guide ask "QUESTION" [--version V] [--run N | --all-runs] [--live]
   python -m guide questions [--version V]
   python -m guide trace TRACE_ID
   python -m guide export TRACE_ID [-o FILE]
   python -m guide show SECTION_ID [--version V]
   python -m guide check"""

import argparse
import json
import re
import sys
import textwrap
from pathlib import Path

from . import APP_NAME, assistant, config, corpus

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")  # pound signs and quotes on a Windows terminal


def _wrap(text: str) -> str:
    out = []
    for para in (text or "").splitlines():
        out.append(textwrap.fill(para, 100) if para.strip() else "")
    return "\n".join(out)


def _print_answer(t: dict) -> None:
    if t.get("not_recorded") == "question":
        print("No recorded answer for this question in version " + t["version"] + ".")
        print("List the recorded questions with: python -m guide questions")
        print("Or ask your own model with --live (see README.md).")
        return
    if t.get("not_recorded") == "run":
        print(f"This question has no recorded run {t['run']} in version {t['version']}.")
        return
    print(f"Trace {t['trace_id']} | {APP_NAME} {t['version']} | prompt {t['prompt_version']} | {t['mode']}")
    print()
    print(_wrap(t["answer"]))
    print()
    cited = set(t["cited"])
    for i, r in enumerate(t["retrieved"], 1):
        mark = "cited" if r["id"] in cited else "not cited"
        print(f"[{i}] {r['title']} ({mark})")
        print(f"    {r['url']}")


def _parse_trace(trace_id: str) -> tuple[str, str, int]:
    m = re.fullmatch(r"(\w+)-v([\d.]+)-r(\d+)", trace_id)
    if not m:
        raise SystemExit(f"{trace_id} is not a trace ID like q02-v1.0-r3")
    return m[2], m[1], int(m[3])


def _trace(trace_id: str) -> dict:
    version, qid, run = _parse_trace(trace_id)
    q = next((x for x in assistant.recorded_questions(version) if x["qid"] == qid), None)
    if q is None:
        raise SystemExit(f"No recorded question {qid} in version {version}")
    return assistant.answer(q["question"], version, run=run)


def cmd_ask(a) -> None:
    if a.live:
        _print_answer(assistant.answer(a.question, a.version, mode="live"))
        return
    runs = range(1, 11) if a.all_runs else [a.run]
    for n, run in enumerate(runs):
        if n:
            print("\n" + "-" * 100 + "\n")
        t = assistant.answer(a.question, a.version, run=run)
        _print_answer(t)
        if t.get("not_recorded") == "question":
            break


def cmd_questions(a) -> None:
    qs = assistant.recorded_questions(a.version)
    print(f"{len(qs)} recorded questions in version {a.version} ({config.RECORDED_MODEL}):")
    for q in qs:
        print(f"  {q['qid']:5} {q['runs']:2} runs  {q['question']}")


def cmd_trace(a) -> None:
    t = _trace(a.trace_id)
    print(f"Trace {t['trace_id']}")
    print(f"  App {APP_NAME} {t['version']}, prompt {t['prompt_version']}, model {t['model']}")
    print(f"  Settings: {t['settings']}; prompt SHA-256 {t['prompt_sha256']}")
    print(f"  Question ({t['question_id']}, run {t['run']}): {t['question']}")
    print(f"  Tokens: {t['usage']}")
    print("  Retrieved (score, section):")
    for i, r in enumerate(t["retrieved"], 1):
        print(f"    [{i}] {r['score']:7.3f}  {r['id']}  {'(cited)' if r['id'] in t['cited'] else ''}")
    print("  Answer:")
    print(textwrap.indent(_wrap(t["answer"]), "    "))


def cmd_export(a) -> None:
    t = _trace(a.trace_id)
    data = json.dumps(t, indent=2, ensure_ascii=False) + "\n"
    if a.output:
        Path(a.output).write_text(data, encoding="utf-8")
        print(f"Wrote {a.output}")
    else:
        print(data, end="")


def cmd_show(a) -> None:
    cfg = config.get(a.version)
    for s in corpus.sections(cfg["tables"]):
        if s.id == a.section_id:
            print(f"{s.id}  {s.title}\n{s.url}\n")
            print(s.text)
            return
    raise SystemExit(f"No section {a.section_id}. Section IDs look like statutory-sick-pay/eligibility#2")


def cmd_check(a) -> None:
    digest = corpus.check_sample()
    n = len(corpus.records())
    print(f"data/govuk-sample.jsonl: SHA-256 {digest[:12]}... is correct ({n} guide parts)")
    for v in config.VERSIONS:
        bad = 0
        recs = assistant.recordings(v)
        for (_, run), r in recs.items():
            _, found = assistant.build(r["question"], v)
            bad += r["retrieved"] != [s.id for s, _ in found]
        print(f"Version {v}: {len(recs)} recorded answers, {len(recs) - bad} with the same sections as this copy")


def main(argv=None) -> None:
    p = argparse.ArgumentParser(prog="python -m guide", description="Ask about work: answers from GOV.UK guidance.")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("ask", help="ask a question (recorded answers; --live for your own model)")
    s.add_argument("question")
    s.add_argument("--version", default=config.DEFAULT_VERSION)
    s.add_argument("--run", type=int, default=1, help="which recorded answer (1-10)")
    s.add_argument("--all-runs", action="store_true", help="show all 10 recorded answers")
    s.add_argument("--live", action="store_true")
    s.set_defaults(fn=cmd_ask)
    s = sub.add_parser("questions", help="list the recorded questions")
    s.add_argument("--version", default=config.DEFAULT_VERSION)
    s.set_defaults(fn=cmd_questions)
    s = sub.add_parser("trace", help="show what the assistant retrieved and cited for one answer")
    s.add_argument("trace_id")
    s.set_defaults(fn=cmd_trace)
    s = sub.add_parser("export", help="write one answer with its trace and versions as JSON")
    s.add_argument("trace_id")
    s.add_argument("-o", "--output")
    s.set_defaults(fn=cmd_export)
    s = sub.add_parser("show", help="print one section of the guidance")
    s.add_argument("section_id")
    s.add_argument("--version", default=config.DEFAULT_VERSION)
    s.set_defaults(fn=cmd_show)
    s = sub.add_parser("check", help="check the data and the recordings")
    s.set_defaults(fn=cmd_check)
    a = p.parse_args(argv)
    a.fn(a)


if __name__ == "__main__":
    main()
