"""Keyword search over the sections (BM25, a classic scoring of shared words). Deterministic: the same question
always finds the same sections, so a recorded answer can be replayed with its exact sources."""

import math
import re
from collections import Counter

STOP = set("""a an and are as at be been but by can could do does for from had has have how i i'm if in is it its
me my of on or our so than that the their them then there these they this to under up was we were what when where
which who will with would you your yours get got""".split())


def words(text: str) -> list[str]:
    toks = re.findall(r"[a-z0-9£]+(?:\.[0-9]+)?", text.lower().replace("’", "'"))
    return [t for t in toks if t not in STOP]


class Index:
    def __init__(self, sections, k1: float = 1.2, b: float = 0.75):
        self.sections = sections
        self.docs = [Counter(words(s.title + " " + s.title + " " + s.text)) for s in sections]
        self.lens = [sum(d.values()) for d in self.docs]
        self.avg = sum(self.lens) / len(self.lens)
        df = Counter(w for d in self.docs for w in d)
        n = len(self.docs)
        self.idf = {w: math.log(1 + (n - c + 0.5) / (c + 0.5)) for w, c in df.items()}
        self.k1, self.b = k1, b

    def search(self, question: str, top_k: int) -> list[tuple[object, float]]:
        q = set(words(question))
        scored = []
        for s, d, ln in zip(self.sections, self.docs, self.lens):
            score = 0.0
            for w in q:
                tf = d.get(w, 0)
                if tf:
                    score += self.idf[w] * tf * (self.k1 + 1) / (tf + self.k1 * (1 - self.b + self.b * ln / self.avg))
            if score > 0:
                scored.append((s, round(score, 3)))
        scored.sort(key=lambda x: (-x[1], x[0].id))
        return scored[:top_k]
