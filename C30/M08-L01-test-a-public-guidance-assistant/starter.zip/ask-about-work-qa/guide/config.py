"""The versions of the assistant. A version fixes the prompt, how tables become text and how many sections are sent.

The model's answers for each version are recorded in recordings/answers-<version>.jsonl.
"""

VERSIONS = {
    "1.0": {"prompt": "1.0", "tables": "flat", "top_k": 4, "ignore_numbers": False,
            "note": "first release candidate"},
    "1.1": {"prompt": "1.1", "tables": "flat", "top_k": 6, "ignore_numbers": True,
            "note": "fixes after the first test campaign: search ignores numbers, 6 sections, prompt rules"},
}
DEFAULT_VERSION = "1.0"
RECORDED_MODEL = "chat-small (gpt-6-luna-2026-09-22 on Azure)"
MAX_OUTPUT_TOKENS = 2000


def get(version: str) -> dict:
    if version not in VERSIONS:
        raise SystemExit(f"Unknown version {version}. Versions: {', '.join(VERSIONS)}")
    return VERSIONS[version]
