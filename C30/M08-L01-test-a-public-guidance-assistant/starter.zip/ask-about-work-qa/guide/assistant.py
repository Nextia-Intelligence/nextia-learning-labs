"""The assistant: find sections, build the prompt, get an answer (recorded or live), and keep a trace."""

import hashlib
import json
import re
from functools import lru_cache
from pathlib import Path

from . import APP_NAME, config, corpus, live
from .retrieve import Index

ROOT = Path(__file__).resolve().parents[1]
PROMPTS = Path(__file__).resolve().parent / "prompts"
RECORDINGS = ROOT / "recordings"


@lru_cache(maxsize=None)
def index(tables: str) -> Index:
    return Index(corpus.sections(tables))


def prompt_text(version: str) -> str:
    return (PROMPTS / f"{config.get(version)['prompt']}.md").read_text(encoding="utf-8").strip()


def normalise(question: str) -> str:
    q = question.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    return re.sub(r"\s+", " ", q).strip().lower()


def build(question: str, version: str) -> tuple[list[dict], list[tuple]]:
    cfg = config.get(version)
    query = question
    if cfg["ignore_numbers"]:  # ages and amounts describe the person, not the topic: "25" matched "25 and over"
        query = " ".join(w for w in question.split() if not any(c.isdigit() for c in w))
    found = index(cfg["tables"]).search(query, cfg["top_k"])
    blocks = [f"[{i}] {s.title} ({s.url})\n{s.text}" for i, (s, _) in enumerate(found, 1)]
    user = "GOV.UK guidance:\n\n" + "\n\n".join(blocks) + f"\n\nQuestion: {question}"
    return [{"role": "system", "content": prompt_text(version)}, {"role": "user", "content": user}], found


def cited(answer: str, found: list[tuple]) -> list[str]:
    nums = []
    for group in re.findall(r"\[(\d+(?:\s*[,;]\s*\d+)*)\]", answer):
        nums += [int(n) for n in re.split(r"[,;]", group)]
    out = []
    for n in nums:
        if 1 <= n <= len(found) and found[n - 1][0].id not in out:
            out.append(found[n - 1][0].id)
    return out


@lru_cache(maxsize=None)
def recordings(version: str) -> dict:
    path = RECORDINGS / f"answers-{version}.jsonl"
    out: dict = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                r = json.loads(line)
                out[(normalise(r["question"]), r["run"])] = r
    return out


def recorded_questions(version: str) -> list[dict]:
    seen = {}
    for (_, run), r in recordings(version).items():
        q = seen.setdefault(r["qid"], {"qid": r["qid"], "question": r["question"], "runs": 0})
        q["runs"] += 1
    return sorted(seen.values(), key=lambda q: (q["qid"][0] != "q", q["qid"]))  # campaign first, pilot (n..) last


def trace_id(version: str, qid: str, run: int) -> str:
    return f"{qid}-v{version}-r{run}"


def answer(question: str, version: str = config.DEFAULT_VERSION, run: int = 1, mode: str = "recorded") -> dict:
    """One answer with its trace. In recorded mode, run N is the N-th recorded answer to this question."""
    cfg = config.get(version)
    messages, found = build(question, version)
    trace = {
        "app": APP_NAME, "version": version, "prompt_version": cfg["prompt"], "mode": mode, "run": run,
        "question": question,
        "settings": {"top_k": cfg["top_k"], "tables": cfg["tables"], "ignore_numbers": cfg["ignore_numbers"],
                     "max_output_tokens": config.MAX_OUTPUT_TOKENS},
        "prompt_sha256": hashlib.sha256(json.dumps(messages, ensure_ascii=False).encode()).hexdigest()[:16],
        "retrieved": [{"id": s.id, "title": s.title, "url": s.url, "score": score} for s, score in found],
    }
    if mode == "live":
        out = live.complete(messages, config.MAX_OUTPUT_TOKENS)
        h = hashlib.sha256(f"{version}|{normalise(question)}|{out['request_id']}".encode()).hexdigest()[:8]
        trace.update(question_id=None, trace_id=f"live-{h}", model=out["model_id"], answer=out["text"],
                     usage=out["usage"], finish_reason=out["finish_reason"], request_id=out["request_id"],
                     latency_s=out["latency_s"])
    else:
        rec = recordings(version).get((normalise(question), run))
        if rec is None:
            known = any(q == normalise(question) for q, _ in recordings(version))
            trace.update(question_id=None, trace_id=None, model=config.RECORDED_MODEL, answer=None,
                         not_recorded=("run" if known else "question"))
            return trace
        if rec["retrieved"] != [s.id for s, _ in found]:
            raise SystemExit(f"The recording of {rec['qid']} used other sections than this copy finds. "
                             "Is data/govuk-sample.jsonl or guide/ changed? Run: python -m guide check")
        trace.update(question_id=rec["qid"], trace_id=trace_id(version, rec["qid"], run), model=rec["model_id"],
                     answer=rec["answer"], usage=rec["usage"], finish_reason=rec.get("finish_reason"))
    trace["cited"] = cited(trace["answer"] or "", found)
    return trace
