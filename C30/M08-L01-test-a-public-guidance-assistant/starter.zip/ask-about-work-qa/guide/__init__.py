"""Ask about work: a small assistant that answers questions about pay and leave from a fixed sample of GOV.UK
guidance. Built for a testing case study: its answers come from recordings of a real model (no key needed), or
from your own model with --live."""

APP_NAME = "ask-about-work"
