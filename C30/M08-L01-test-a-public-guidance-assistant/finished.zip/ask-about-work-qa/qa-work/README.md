# QA workspace: Ask about work

The test campaign for Thistlecombe Advice Centre's assistant "Ask about work", versions 1.0 and 1.1.
All answers are **recorded (real model)**: chat-small (gpt-6-luna-2026-09-22 on Azure), 10 runs per question.
Thistlecombe, Joanna and Callum are made up; the guidance is GOV.UK's.

| File | What it is |
|---|---|
| `risk-table.md` | where testing time goes, agreed with Joanna |
| `acceptance-criteria.md` | what "good enough" means, as checkable rules |
| `rubric.md` | how a person scores one answer; `rubric-scores.md` has 13 scored answers |
| `metamorphic-relations.md` | three changes to a question that must not change the answer |
| `sessions/` | two charters with their session notes |
| `bugs/` | ten bug reports; BUG-01 is agent-ready, with its failing case and its fix verification |
| `../cases/` | the regression set (36 cases); `../pilot/` the pilot week's 8 questions |
| `release-sign-off-1.1.md` | the release recommendation |
