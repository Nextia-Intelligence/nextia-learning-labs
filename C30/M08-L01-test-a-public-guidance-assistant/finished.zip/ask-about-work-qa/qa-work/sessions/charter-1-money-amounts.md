# Test charter: money amounts

**Explore** the answers about money (wage rates, sick pay, maternity pay)
**with** people of different ages and situations, `python -m guide ask ... --all-runs`, the trace and `guide show`
**to discover** whether an amount is ever old, invented or wrong for the person

- Tester: you    Time box: 45 minutes    App version: 1.0 (prompt 1.0, chat-small, recorded)    Runs: all 10
- Risks from the risk table: R1, R2 (money conditions)
- Out of scope: totals that need a calculator (redundancy pay), Northern Ireland

Ideas to try:

- one age in each wage band (19, 25), an apprentice after the first year
- a past date ("in 2022"), a future date ("next year")
- low earnings (£100 and £110 a week) with sick pay

# Session notes: money amounts

- Tester: you    Start: 0:00    End: 0:45    App version: 1.0    Runs used: 1-10 of each question
- Time spent: setup 10%, testing 55%, investigating and reporting bugs 35%

## Notes

| Time | What I did (question, version, run) | What I saw | Trace | Bug? Question? Idea? |
|---|---|---|---|---|
| 0:03 | q01 minimum wage at 19, all runs | £10.85 in 10 of 10, cites the rates page | q01-v1.0-r1 | OK |
| 0:08 | q02 National Living Wage at 25, all runs | £12.21 "from April 2025 to March 2026" in 9 runs; run 3 gives £8.72 (2020 to 2021). Never £12.71 | q02-v1.0-r1, q02-v1.0-r3 | Bug: BUG-01 |
| 0:12 | trace of q02 run 1 | retrieved "Rates before 1 April 2021" first (score 21.7) and "Previous rates"; the "Current rates" section is not in the 4 | q02-v1.0-r1 | Layer: retrieval ("25" matches "25 and over"?) |
| 0:16 | q04 apprentice aged 20, second year | £8 in 9 runs; run 3 says £8 and then £10.85 | q04-v1.0-r1, q04-v1.0-r3 | Bug: BUG-02 |
| 0:19 | `guide show national-minimum-wage-rates/main#2` | the section says: age rate after the first year if aged 19 or over; it was retrieved first | | Layer: generation |
| 0:24 | q06 a past rate (2022), q07 next year | q06 £9.18 10/10. q07: 8 runs say the guidance has no 2027 rate; runs 5 and 9 say "From 1 April 2026, the National Living Wage will be £12.71" | q07-v1.0-r5 | Minor (2/10): sounds like next year's rate |
| 0:30 | q03, q05 sick and maternity pay | q03 £123.25 or 80%, 10/10. q05: 9 runs give 90% and £194.32; run 1 talks about form SMP1 first and gives the amounts through Shared Parental Pay | q05-v1.0-r1 | rubric 3 |
| 0:36 | q09 £100 a week; q31a/b £110 (Mohammed, Oliver) | £80 and £88 in every run, no earnings limit. Same for both names | | OK; MR2, MR3 |

## Bugs found

- BUG-01: old National Living Wage given for a 25-year-old, 10 of 10 runs (q02-v1.0-r1)
- BUG-02: apprentice aged 20 in the second year told £8, 10 of 10 runs fail the check (q04-v1.0-r1)

## Questions for the team

- Joanna: next year's rate (q07) - is "the guidance does not say yet" the answer we want? (yes, agreed)

## Debrief summary

- Covered: wage bands, apprentices, past and future dates, sick pay, maternity pay. Not covered: redundancy totals, holiday pay amounts.
- The most important finding: the assistant gives an old wage rate as the current one in every run.
- What to test next: whether the search misses the right section for other everyday questions.
