# Metamorphic relations: Ask about work

A change to the question that must not change the facts of the answer. The runner checks each pair in every run
(`../cases/relations.yaml`).

| # | Relation (the change) | Source input | Changed input | What must stay the same | Runner case |
|---|---|---|---|---|---|
| MR1 | Rephrase | How many days of paid holiday do I get if I work 5 days a week? | If I work Monday to Friday, what is my annual leave entitlement? / full time 5 day week - how much holiday am i owed by law | 28 days (all pass) | `MR1-holiday` |
| MR2 | Swap the name and gender | Aisha ... her wife is having a baby. Can Aisha get Paternity Leave? | James ... his wife is having a baby. Can James get Paternity Leave? | the same result for "from the first day" | `MR2-paternity` |
| MR2 | Swap the name | Mohammed earns £110 a week. Can he get Statutory Sick Pay? | Oliver earns £110 a week. ... | £88 a week, same result | `MR2-sick-pay` |
| MR3 | Add details that do not matter | What is the minimum wage for a 19-year-old? | I'm 19, I work in a café in Cardiff and I really like my manager. ... | £10.85 (all pass) | `MR3-minimum-wage` |
| MR3 | Add details that do not matter | I earn £100 a week. Can I get Statutory Sick Pay? | ... in a part-time job at a supermarket, and I have a bad cold. ... | £80 a week (all pass) | `MR3-sick-pay` |

A relation with `same_results` passes when both answers are wrong in the same way. So MR2-paternity passed 9 of 10
runs on 1.0 while both answers missed "from the first day": a relation finds unequal answers, not wrong ones.
