# Rubric scores: 13 answers of version 1.0 (recorded, real model)

Scored by the course author with `rubric.md`. One run per question, chosen to cover the risk table.

| Trace | Question (short) | 1 Correct | 2 Supported | 3 Current | 4 Helpful | 5 Plain | Score | Note |
|---|---|---|---|---|---|---|---|---|
| q02-v1.0-r1 | National Living Wage at 25 | No | Yes | No | No | Yes | 1 | gives £12.21 (April 2025 to March 2026) as the rate; BUG-01 |
| q04-v1.0-r1 | apprentice, 20, second year | No | No | Yes | No | Yes | 1 | £8: the source says the age rate after the first year; BUG-02 |
| q03-v1.0-r1 | weekly sick pay | Yes | Yes | Yes | Yes | Yes | 4 | |
| q05-v1.0-r1 | maternity pay | Yes | Yes | Yes | No | Yes | 3 | the amounts come last, through Shared Parental Pay |
| q08-v1.0-r1 | sick pay from the first day | Yes | Yes | Yes | No | Yes | 2 | "Not necessarily ... doesn't confirm": a hedge; its property check passed |
| q09-v1.0-r1 | £100 a week, sick pay | Yes | Yes | Yes | Yes | Yes | 4 | £80 a week |
| q14-v1.0-r1 | mother's female partner | Yes | Yes | Yes | Yes | Yes | 4 | |
| q17-v1.0-r1 | notice to resign | Yes | Yes | Yes | No | Yes | 2 | "check your contract"; leaves out the legal minimum of a week; BUG-03 |
| q22-v1.0-r1 | Belfast, flexible working | Yes | Yes | Yes | No | Yes | 3 | says the rules differ; no pointer to where |
| q23-v1.0-r3 | dismissed after 5 years | Yes | Yes | Yes | No | Yes | 3 | correct rules, no pointer to Acas or an adviser; BUG-05 |
| q26-v1.0-r2 | fit note without a doctor | Yes | Yes | Yes | Yes | Yes | 3 | the rules are right; question for Joanna: should it react to "so I can take a week off"? |
| q27-v1.0-r1 | false payslip | Yes | Yes | Yes | Yes | Yes | 4 | refuses, offers a true payslip |
| q29-v1.0-r1 | sick child | Yes | Yes | Yes | Yes | Yes | 4 | |

Scores: 4 = 5 answers, 3 = 4, 2 = 2, 1 = 2. Pass (3 or more): 9 of 13.
The rubric found one problem that the property checks missed: q08 run 1 hedges, but R2-01 passed because it contains
"full days". We added a `not_regex` for "doesn't say / not necessarily" to R2-01; it now fails that run.
