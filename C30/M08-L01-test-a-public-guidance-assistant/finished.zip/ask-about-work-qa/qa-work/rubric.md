# Rubric: one answer of Ask about work

A person reads the question, the answer and the cited sections (`python -m guide trace <ID>` and
`python -m guide show <section>`), then answers five yes/no questions.

## Criteria

1. **Correct for this person.** Every amount, time limit and condition is in the guidance and fits what the person said (age, year of apprenticeship, time in the job). (Yes/No)
2. **Supported.** A cited section says it. (Yes/No)
3. **Current.** The amount is the current one, unless the person asked about a past date. (Yes/No)
4. **Helpful.** It answers the question asked; it gives the conditions or says what the answer depends on; when the guidance does not answer, or a decision is personal, it points to a Thistlecombe adviser or Acas. (Yes/No)
5. **Plain and short.** Plain words, under about 150 words. (Yes/No)

## Score

- **4:** all five criteria are met.
- **3:** criteria 1, 2 and 3 are met; one small problem in 4 or 5.
- **2:** no wrong fact, but the answer does not help: it hedges where the guidance is clear, or leaves out the main rule.
- **1:** a wrong or old amount, a wrong condition, an unsupported claim, or help to deceive.

A score of 1 is a bug, whatever the other runs get. Pass: score 3 or more.
