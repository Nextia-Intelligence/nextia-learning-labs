# BUG-06: in 1.1, the redundancy question gets "the guidance does not say" instead of "2 years", in 9 of 10 runs (a regression)

- **Version:** app 1.1, prompt 1.1, chat-small (recorded, real model), top_k 6, numbers ignored
- **Severity:** medium, because a regression of a right (harm 2) for a weekly question (frequency 2); it blocks the release as a regression
- **Priority:** set in triage with Joanna and Callum

## Steps to reproduce

```sh
python -m guide ask "How long do I need to work for my employer to get redundancy pay?" --version 1.1 --all-runs
```

## Actual result

"The guidance provided does not say how long you must have worked to qualify for statutory redundancy pay; it only lists some exceptions [3]. Please ask a Thistlecombe adviser or Acas." - trace q12-v1.1-r1. Retrieved: six redundancy sections; not redundancy-your-rights/redundancy-pay#1 ("... working for your current employer for 2 years or more").

## Expected result

- Must: "2 years".
- Must not: say that the guidance does not cover it.

## Reproduction rate

9 of 10 recorded runs fail on 1.1 (case R2-05); 1 of 10 on 1.0.

## Evidence

- Traces: q12-v1.1-r1, q12-v1.0-r1
- Case: `cases/eligibility.yaml` R2-05 (known bug)

## Notes

Suspected layer: retrieval, shown by the new prompt rule. The section with "2 years" is not retrieved in 1.0 either (trace q12-v1.0-r1): 1.0 answered "2 years" from the model's memory, right by luck. Rule 1 of 1.1 ("answer only from the guidance") stops that, so the search gap now shows. Same family as BUG-03.
