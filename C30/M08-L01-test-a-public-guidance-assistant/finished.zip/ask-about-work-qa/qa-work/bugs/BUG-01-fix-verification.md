# Fix verification: BUG-01

Fix: version 1.1 (search ignores numbers, 6 sections, prompt 1.1)    Verified by: you    App version: 1.1

1. [x] **Before:** the failing case fails on 1.0: 0/10 passed.
2. [x] **After:** the failing case passes 10/10 on 1.1 (all recorded runs).
3. [x] **Neighbours:** R1-01 (19-year-old) 10/10, R1-06 (a past rate when asked) 10/10, R1-07 (next year) 10/10, MR3-minimum-wage 10/10.
4. [ ] **Suite:** new failures: R2-05 (redundancy pay needs 2 years) passes 1/10 on 1.1, 9/10 on 1.0 (opened as BUG-06); R2-01 (sick pay from the first day) 4/10, 9/10 on 1.0 (BUG-09).
5. [x] **Read the change.** `git diff`: no amount or question in the code; the cases are unchanged; the previous rates are still in the data. Rule 1 of the prompt is new ("Answer only from the GOV.UK guidance").
6. [x] **Side effects:** about 1,160 input tokens per answer instead of about 670 (6 sections instead of 4); answers are not longer.
7. [x] **Evidence:** `reports/qa-1.1-.../report.md`

Decision: [x] close BUG-01. The release stays blocked by BUG-06 and BUG-09 (regressions) until they are triaged; see the sign-off.
