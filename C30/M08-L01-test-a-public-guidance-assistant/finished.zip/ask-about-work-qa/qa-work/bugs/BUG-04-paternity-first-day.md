# BUG-04: after 2 months in a job, the answer does not say that Paternity Leave starts from the first day, in 10 of 10 runs

- **Version:** app 1.0, prompt 1.0, chat-small (recorded, real model)
- **Severity:** medium, because a person may think they have no right (harm 2), for a weekly question (frequency 2)
- **Priority:** set in triage with Joanna and Callum

## Steps to reproduce

```sh
python -m guide ask "I started my job 2 months ago. Can I take Paternity Leave?" --version 1.0 --all-runs
```

## Actual result

Version 1.0: "Starting your job 2 months ago doesn't, by itself, tell us whether you qualify. The guidance provided doesn't state a minimum length of employment for Paternity Leave ..." - trace q10-v1.0-r1. Retrieved: holiday-entitlement-rights/calculate-leave-entitlement#2 first, then three paternity "Leave" sections; not paternity-pay-leave/eligibility#2 ("You're eligible for Paternity Leave from the first day of employment").

## Expected result

- Must: say that Paternity Leave is available from the first day of employment.
- Must not: say that the guidance does not state it.

## Reproduction rate

10 of 10 recorded runs on 1.0 and 10 of 10 on 1.1 (case R2-03). On 1.1 the case first passed 9 of 10: a false pass, see the notes.

## Evidence

- Traces: q10-v1.0-r1, q10-v1.1-r1
- Cases: `cases/eligibility.yaml` R2-03 (known bug), `cases/relations.yaml` MR2-paternity

## Notes

Suspected layer: retrieval ("months" pulls in the holiday calculation; the eligibility section is not among the 6 sections of 1.1 either). On 1.1 the check `regex: first day ... employment` first passed 9 of 10 runs, but every answer says "the guidance doesn't say whether 2 months is enough": the "first day of employment" it matched is the surrogacy rule (trace q10-v1.1-r1, section paternity-pay-leave/adoption#5). We added a `not_regex` for "doesn't say" to R2-03, and the case fails 10 of 10 on 1.1. Open.
