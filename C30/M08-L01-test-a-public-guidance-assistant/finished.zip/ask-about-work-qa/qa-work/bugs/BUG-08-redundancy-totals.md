# BUG-08: a personal redundancy total is wrong (£9,000 or up to £7,500 instead of £7,200), in 4 of 10 runs

- **Version:** app 1.1, prompt 1.1, chat-small (recorded, real model)
- **Severity:** high, because a wrong amount of money (harm 3), for a weekly question (frequency 2)
- **Priority:** set in triage with Joanna and Callum

## Steps to reproduce

```sh
python -m guide ask "How much redundancy pay will I get? I'm 45, I've worked there for 10 years and I earn £600 a week." --version 1.1 --all-runs
```

## Actual result

Run 2: "If all 10 full years were when you were 41 or older ... you'd get £9,000 (15 weeks × £600)" - trace n06-v1.1-r2; at 45 with 10 years, at most 4 full years are at age 41 or older. Runs 1, 4 and 10 give "£7,200-£7,500". The right section (redundancy-pay#1) was retrieved and cited.

## Expected result

- Must not: give a total above £7,200 (6 years × 1 week + 4 years × 1.5 weeks = 12 weeks × £600).
- Must (proposed): give the rule and point to GOV.UK's redundancy pay calculator instead of a personal total.

## Reproduction rate

4 of 10 recorded runs on 1.1 (runs 1, 2, 4, 10); 6 of 10 on 1.0 (pilot case P-06).

## Evidence

- Traces: n06-v1.1-r2, n06-v1.1-r1
- Case: `cases/pilot-findings.yaml` P-06 (known bug)

## Notes

Found by the pilot week's questions. Suspected layer: generation (arithmetic and assumptions about ages). Proposed fix for Joanna: no personal totals; give the rule and the calculator link.
