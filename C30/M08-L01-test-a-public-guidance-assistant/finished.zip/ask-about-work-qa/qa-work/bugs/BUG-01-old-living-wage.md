# BUG-01: a 25-year-old is told last year's National Living Wage (£12.21) as the rate, in 10 of 10 runs

## Summary

Asked for the National Living Wage at 25, version 1.0 gives £12.21 ("April 2025 to March 2026") in 9 of 10
recorded runs and the 2020-21 rate (£8.72) in 1. It never gives the current rate, £12.71 (from April 2026).
A person who believes it may accept pay below the legal minimum.

## Environment

- App build: ask-about-work 1.0 (`guide/config.py`: top_k 4, tables flat)
- Model: chat-small (gpt-6-luna-2026-09-22 on Azure), recorded (real model)
- Prompt / config version: prompt 1.0 (`guide/prompts/1.0.md`, SHA-256 of the messages db145392891b9095)
- Flags and settings: recorded runs 1-10, no live mode
- Data: `data/govuk-sample.jsonl`, SHA-256 1b14208649e3...

## Steps

1. `python -m guide ask "I'm 25. What is the National Living Wage per hour?" --version 1.0 --all-runs`
2. Attached export: `q02-v1.0-r1.json` (`python -m guide export q02-v1.0-r1 -o q02-v1.0-r1.json`)

## Actual

- Output (run 1): "If you're 25, the National Living Wage rate depends on the date: £12.21 an hour from April 2025
  to March 2026. £11.44 an hour from April 2024 to March 2025. [4] Rates for earlier years were different. [1]"
- Trace ID: q02-v1.0-r1 (run 3, q02-v1.0-r3: "it was £8.72 an hour from April 2020 to March 2021")
- Retrieved and cited sections (run 1): [1] national-minimum-wage-rates/main#5 "Rates before 1 April 2021"
  (score 21.662, cited), [2] main#6, [3] main#1, [4] main#3 "Previous rates" (cited). The section with the
  current rates, main#2, is not retrieved.

## Expected (checkable)

- Must: give £12.71 an hour (the "Current rates" row "April 2026", 21 and over) and cite national-minimum-wage-rates.
- Must not: present an earlier rate as the rate today.
- Must keep: a past rate when the person asks about a past date (case R1-06, "in 2022" gives £9.18).

## Reproduction rate

10 of 10 recorded runs fail (runs 1-10). 95% interval for the failure rate: 72% to 100%.

## Suspected layer

Retrieval, then generation - a guess, because the trace shows that the search puts "Rates before 1 April 2021"
first: the question's "25" matches the table heading "25 and over" of the old rates, and the current-rates section
is not among the 4 sections. With no current rate in front of it, the model gives the newest rate it was shown.

## Acceptance criteria

- [ ] The attached failing case passes 10/10 runs: `python -m qa run qa-work/bugs/BUG-01.yaml --version <new version>`
- [ ] The existing suite passes: `python -m qa run cases/ --version <new version>` (only known bugs fail)
- [ ] R1-06 (a past rate when asked) still passes 10/10
- [ ] No change to the guidance data, the recordings or the rules of the prompt that are not part of the fix

## Constraints for the fixer

- Touch only: `guide/retrieve.py`, `guide/assistant.py`, `guide/config.py`, `guide/prompts/` (as a new version)
- Do not: change or delete cases or checks, hard-code £12.71 or this question, remove the previous rates from the
  data, change `data/` or `recordings/`, add a dependency

## Attached failing case

```yaml
id: BUG-01-current-living-wage
title: A 25-year-old gets the current National Living Wage, £12.71
bug: BUG-01
message: I'm 25. What is the National Living Wage per hour?
checks:
  - contains: "£12.71"                    # fails today: 0 of 10 runs pass
  - cites: national-minimum-wage-rates    # neighbour rule: keep citing the rates page
runs: 10
pass: all
```
