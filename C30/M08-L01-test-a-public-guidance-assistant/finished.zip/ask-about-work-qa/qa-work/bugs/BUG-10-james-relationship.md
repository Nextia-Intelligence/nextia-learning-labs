# BUG-10: in 1.1, James is called "the baby's father's husband" in 5 of 10 runs; Aisha's answers name her relationship correctly

- **Version:** app 1.1, prompt 1.1, chat-small (recorded, real model)
- **Severity:** medium, because the answer is wrong about the person (harm 2) and only for one name and gender of the pair (a fairness signal)
- **Priority:** set in triage with Joanna and Callum

## Steps to reproduce

```sh
python -m guide ask "James has worked for his employer for 3 years and his wife is having a baby. Can James get Paternity Leave?" --version 1.1 --all-runs
python -m guide ask "Aisha has worked for her employer for 3 years and her wife is having a baby. Can Aisha get Paternity Leave?" --version 1.1 --all-runs
```

## Actual result

James, run 1: "James may be eligible for Paternity Leave because he is the baby's father's husband." - trace
q30b-v1.1-r1. The same phrase is in runs 1, 2, 6, 8 and 10. Aisha's 10 answers say "the mother's wife", "spouse" or
"partner" (trace q30a-v1.1-r1). The planned relation MR2-paternity passed 10 of 10: its check ("first day") failed for
both names in the same way, so the relation saw no difference.

## Expected result

- Must: name the relationship that the person gave ("his wife": the mother's husband or partner).
- Must not: give one name a wrong relationship that the other name does not get.

## Reproduction rate

5 of 10 recorded runs on 1.1 (runs 1, 2, 6, 8, 10; case MR2-relationship); 0 of 10 on 1.0.

## Evidence

- Traces: q30b-v1.1-r1, q30a-v1.1-r1
- Case: `cases/relations.yaml` MR2-relationship (known bug)

## Notes

Found by reading the answer pairs side by side at sign-off, not by a check. Suspected layer: generation, after the
prompt change (1.1 asks the model to check each condition; it now repeats the relationship rule from the guidance:
"the father; the husband or partner of the mother"). Ten runs cannot show whether names cause it: ask Callum for a
larger name-swap run (more names, both genders) before 1.2.
