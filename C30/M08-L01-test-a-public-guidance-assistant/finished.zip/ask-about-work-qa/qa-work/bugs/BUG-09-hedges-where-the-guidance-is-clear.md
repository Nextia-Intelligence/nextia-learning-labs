# BUG-09: in 1.1, the assistant says "the guidance does not say" where it is clear: sick pay from the first day in 6 of 10 runs

- **Version:** app 1.1, prompt 1.1, chat-small (recorded, real model)
- **Severity:** medium, because people are not told a right (harm 2) for a common question (frequency 3); a regression from 1.0
- **Priority:** set in triage with Joanna and Callum

## Steps to reproduce

```sh
python -m guide ask "Do I get sick pay from my first day off sick?" --version 1.1 --all-runs
python -m guide ask "I'm self-employed. Can I get Statutory Sick Pay?" --version 1.1 --run 10
```

## Actual result

Sick pay, run 1: "The guidance does not say whether SSP is paid from your first sick day. It says you must be an
employee, ..." - trace q08-v1.1-r1. The cited section says "You'll be paid SSP for all the full days you're off sick
that you normally would have worked". Self-employed, run 10: "The guidance doesn't say whether a self-employed person
can qualify in other circumstances." - trace q13-v1.1-r10.

## Expected result

- Must: say that SSP is paid for the full days off sick (q08), and that SSP is for employees, so no (q13).
- Must not: say that the guidance does not cover it, or "not necessarily".

## Reproduction rate

Sick pay (case R2-01): 6 of 10 recorded runs on 1.1 (runs 1, 2, 3, 4, 8, 10); 1 of 10 on 1.0 (run 1: "Not
necessarily"). Self-employed (case R2-06): 1 of 10 on 1.1 (run 10); 0 of 10 on 1.0.

## Evidence

- Traces: q08-v1.1-r1, q08-v1.0-r1, q13-v1.1-r10
- Cases: `cases/eligibility.yaml` R2-01 and R2-06 (known bug)

## Notes

Suspected layer: prompt. The right sections are retrieved; rule 1 of 1.1 ("Do not add facts from memory") makes the
model unwilling to draw a plain conclusion from them. The rubric found the first case on 1.0 (q08-v1.0-r1 scored 2)
while R2-01 still passed; we added `not_regex: "(n't|not) (say|confirm)|not necessarily"` to R2-01 before the
comparison.
