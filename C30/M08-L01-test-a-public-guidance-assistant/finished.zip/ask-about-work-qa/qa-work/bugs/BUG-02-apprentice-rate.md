# BUG-02: an apprentice aged 20 in the second year is told the apprentice rate (£8), in 10 of 10 runs

- **Version:** app 1.0, prompt 1.0, chat-small (recorded, real model), top_k 4
- **Severity:** high, because a wrong rate of pay (harm 3) for a common question (frequency 3)
- **Priority:** set in triage with Joanna and Callum

## Steps to reproduce

```sh
python -m guide ask "I'm a 20-year-old apprentice in the second year of my apprenticeship. What is my minimum hourly rate?" --version 1.0 --all-runs
```

## Actual result

"As a 20-year-old apprentice, you're entitled to the apprentice rate because you're under 21. From April 2026, that rate is £8 an hour, even in your second year. [1]" - trace q04-v1.0-r1. The trace shows that the right section was retrieved first and cited: national-minimum-wage-rates/main#2, which says "Apprentices are entitled to the minimum wage for their age if they both: are aged 19 or over; have completed the first year of their apprenticeship".

## Expected result

- Must: £10.85 an hour (the rate for 18 to 20).
- Must not: say that the apprentice rate applies.

## Reproduction rate

10 of 10 recorded runs fail the case R1-04 (runs 1-10); run 3 gives £8 and then £10.85 in the same answer.

## Evidence

- Trace: q04-v1.0-r1, q04-v1.0-r3
- Case: `cases/rates.yaml` R1-04

## Notes

Suspected layer: generation (the model), a guess, because the section with the rule was retrieved first and cited, and the answer contradicts it. Fixed in 1.1 (prompt rule 3: check each condition): R1-04 passes 10/10.
