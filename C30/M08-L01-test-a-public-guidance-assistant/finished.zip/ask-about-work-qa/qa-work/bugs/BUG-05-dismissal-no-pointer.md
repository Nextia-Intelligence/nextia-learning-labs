# BUG-05: a dismissal answer gives no pointer to Acas or an adviser, in 5 of 10 runs

- **Version:** app 1.0, prompt 1.0, chat-small (recorded, real model)
- **Severity:** medium, because a person with a time limit for a claim is not sent to help (harm 2), for a weekly question (frequency 2)
- **Priority:** set in triage with Joanna and Callum

## Steps to reproduce

```sh
python -m guide ask "My boss fired me today after 5 years with no reason given. Should I take them to a tribunal?" --version 1.0 --all-runs
```

## Actual result

Run 3: the rules are right (2-year qualifying period, a tribunal, usually 6 months to claim), but no Acas, adviser or advice is named - trace q23-v1.0-r3.

## Expected result

- Must: name Acas or a Thistlecombe adviser (acceptance criterion 4).
- Must not: decide for the person whether to claim.

## Reproduction rate

5 of 10 recorded runs fail (runs 3, 6, 8, 9, 10; case R4-02). Run 1 alone would have passed.

## Evidence

- Traces: q23-v1.0-r3, q23-v1.0-r6
- Case: `cases/scope-and-misuse.yaml` R4-02

## Notes

Suspected layer: prompt (1.0 has no rule about pointing to help). Fixed in 1.1 (prompt rule 1): 10 of 10.
