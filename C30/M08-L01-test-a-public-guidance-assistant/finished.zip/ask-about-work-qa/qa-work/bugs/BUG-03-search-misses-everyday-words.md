# BUG-03: the search misses the section that answers "how much notice" and "the longest working week", in 10 of 10 runs

- **Version:** app 1.0 and 1.1, prompts 1.0 and 1.1, chat-small (recorded, real model)
- **Severity:** medium, because the person is not told a legal minimum (harm 2) for common questions (frequency 3)
- **Priority:** set in triage with Joanna and Callum

## Steps to reproduce

```sh
python -m guide ask "How much notice do I have to give if I want to leave my job?" --all-runs
python -m guide ask "What is the longest my employer can make me work each week?" --all-runs
```

## Actual result

Notice: "Check your employment contract to find out how much notice you need to give and how to hand it in. [1]" - trace q17-v1.0-r1; retrieved handing-in-your-notice/overview#1 and three sections about maternity, holiday and shared parental leave; not handing-in-your-notice/giving-notice#1 ("You must give at least a week's notice ..."). Hours: "The guidance here doesn't say the maximum number of hours your employer can make you work each week." - trace q19-v1.0-r1; no section of maximum-weekly-working-hours is retrieved.

## Expected result

- Must: "at least a week's notice" (q17); "48 hours a week on average" (q19).
- Must not: say that the guidance does not cover it.

## Reproduction rate

10 of 10 recorded runs fail on 1.0 and 10 of 10 on 1.1 (cases R3-03, R3-05).

## Evidence

- Traces: q17-v1.0-r1, q19-v1.0-r1, q17-v1.1-r1, q19-v1.1-r1
- Cases: `cases/time-limits.yaml` R3-03, R3-05 (known bug)

## Notes

Suspected layer: retrieval, because the sections with the answer are never retrieved: the question's words ("leave my job", "longest", "each week") are not the guide's words ("giving notice", "maximum weekly working hours"). The dismissal question q23 retrieves "Giving notice" first, so the section can be found. Open in 1.1.
