# BUG-07: a 17-year-old asking "the least my employer can pay me" is told the guidance has no minimum wage rates, in 10 of 10 runs

- **Version:** app 1.0 and 1.1, chat-small (recorded, real model)
- **Severity:** medium, because a common money question (frequency 3) gets no answer (harm 2); no wrong amount is given
- **Priority:** set in triage with Joanna and Callum

## Steps to reproduce

```sh
python -m guide ask "I'm 17. What's the least my employer can pay me per hour?" --version 1.1 --all-runs
```

## Actual result

"The guidance provided doesn't say what the minimum hourly pay is for a 17-year-old. A Thistlecombe adviser or Acas can help you check." - trace n01-v1.1-r1. The rates page is not retrieved: the words "least ... pay ... per hour" match "Maximum weekly working hours" for young workers.

## Expected result

- Must: £8 an hour (under 18).
- Must not: say that the guidance has no minimum wage rates.

## Reproduction rate

10 of 10 recorded runs fail on 1.1 and on 1.0 (pilot case P-01).

## Evidence

- Traces: n01-v1.0-r1, n01-v1.1-r1
- Case: `cases/pilot-findings.yaml` P-01 (known bug)

## Notes

Found by the pilot week's questions, not by the planned cases. Suspected layer: retrieval (same family as BUG-03 and BUG-06).
