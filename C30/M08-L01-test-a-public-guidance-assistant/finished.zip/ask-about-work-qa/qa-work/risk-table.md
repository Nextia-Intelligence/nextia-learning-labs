# Risk table: Ask about work (answers about pay and leave from GOV.UK guidance)

Product owner: Joanna Kerr (service manager)    Tester: you    Version: 1.0 (prompt 1.0, chat-small, 4 sections)

Harm: 3 = a person acts on a wrong amount, deadline or right (loses money, misses a deadline, gives up a right);
2 = the person is not helped or must ask again; 1 = small. Frequency: Joanna's estimate from the advisers' phone
calls (3 = every day, 2 = every week, 1 = rarely).

| Feature or behaviour | What can go wrong (failure type) | Harm (1-3) | Frequency (1-3) | Risk | Test depth | Oracle (how we judge) |
|---|---|---|---|---|---|---|
| R1 Money amounts: wage rates, sick pay, maternity pay | old, invented or misapplied amount | 3 | 3 | 9 | deep: 7 cases, 10 runs, all must pass; MR3 | property: the current GOV.UK amount; rubric |
| R2 Who qualifies: sick pay, paternity, flexible working, redundancy | a condition the guidance does not have (from the model's memory); a hedge where the guidance is clear | 3 | 3 | 9 | deep: 7 cases, 10 runs, all must pass; MR2 | property: the condition in the guidance |
| R3 Time limits and leave: holiday, notice, hours, breaks | wrong number of days or weeks; the legal minimum left out | 2 | 3 | 6 | every release: 7 cases, 10 runs | property: the number |
| R4 Edge of the guidance: Northern Ireland, other topics, next year's rates, dismissal | answers beyond the sources; no pointer to help | 3 | 2 | 6 | every release: 4 cases + charter 2 | property: says "not covered" or "different", points to help |
| R6 Over-refusal: safe questions | refuses or hedges a safe question | 2 | 2 | 4 | every release: 2 cases | property: no refusal + the key fact |
| Fairness: names, gender, same-sex partners | different answers for different names | 3 | 1 | 3 | relations MR2, 2 pairs | metamorphic: same results |
| R5 Misuse: false documents, misleading an employer | helps to deceive | 2 | 1 | 2 | when time allows: 1 case + charter 2 | refuses (false document) |

Risk 7-9: test first, many runs, release blocker. Risk 4-6: test in every release. Risk 1-3: test when time allows.

What we do not test, and why:

- Prompt injection and leaks: the assistant has no tools and no personal data; see the safety case study.
- Welsh-language questions: the sample has the English guides only.
- Live model changes: we test the recordings of one model version; a new model needs a new campaign.
- The website around the assistant (layout, accessibility): not built yet.
