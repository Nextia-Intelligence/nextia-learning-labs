# Release sign-off: Ask about work 1.1

- Candidate: app 1.1, prompt 1.1, chat-small (gpt-6-luna-2026-09-22), 6 sections, numbers ignored in the search
- Compared with: 1.0 (prompt 1.0, 4 sections)
- Tester: you    Evidence: recorded (real model), 10 runs per question

## Recommendation

**Block the public release of 1.1.** It fixes both wrong-amount bugs of the campaign (BUG-01, BUG-02), but it brings
two regressions (BUG-06, BUG-09), and the pilot week found a wrong redundancy total in 4 of 10 runs (BUG-08): a wrong amount of
money at any rate is a blocker. **Use 1.1 instead of 1.0 for the advisers' internal trial**, where an adviser reads
every answer before it goes to a client: no 1.1 answer in our runs gives an old rate, and its failures are mostly
"the guidance does not say" with a pointer to an adviser.

## Evidence

| Area (from the risk table) | Cases | Runs per case | 1.0: cases passing all runs | 1.1: cases passing all runs | Change |
|---|---|---|---|---|---|
| R1 Money amounts | 7 | 10 | 4 | 7 | BUG-01, BUG-02 fixed |
| R2 Who qualifies | 7 | 10 | 4 | 3 | BUG-06 and BUG-09 regressions; BUG-04 still open |
| R3 Time limits | 7 | 10 | 5 | 5 | BUG-03 still open |
| R4 Edge of the guidance | 4 | 10 | 3 | 4 | BUG-05 fixed |
| R5, R6 Misuse and over-refusal | 3 | 10 | 3 | 3 | no change |
| Relations MR1-MR3 | 5 | 10 | 4 | 5 | MR2: see BUG-10 |
| **All planned cases** | **33** | **10** | **23 (270 of 330 runs)** | **27 (284 of 330 runs)** | |

- Regression set (36 cases, 1.1): 27 passed, 0 failed, 9 known bugs still failing, 0 known bugs now passing. Report: `reports/qa-1.1-<time>/report.md`
- Pilot week (8 new questions, run once at the end): 1.1 passes 6, 1.0 passes 5. Failures: BUG-07 (10/10), BUG-08 (4/10 on 1.1).
- New bugs found in 1.1: BUG-06 (medium, 9/10, regression), BUG-09 (medium, 6/10, regression), BUG-10 (medium, 5/10), and from the pilot BUG-07 (medium, 10/10) and BUG-08 (high, 4/10).
- Not tested, and the risk that remains: questions outside the 16 guides; Welsh; other models; changes on GOV.UK after the sample was taken (rates change every April).

## Blockers (any one blocks the release)

- [x] A critical bug (wrong money) at any reproduction rate: BUG-08, 4 of 10 runs
- [x] A rule that worked in the previous version fails now (a regression): BUG-06 (R2-05: 9/10 on 1.0, 1/10 on 1.1), BUG-09 (R2-01: 9/10 on 1.0, 4/10 on 1.1)
- [x] An acceptance criterion that is not met: criteria 1 (BUG-08), 2 (BUG-04, BUG-06, BUG-09), 4 (BUG-03, BUG-07)

## Conditions and follow-up

- 1.2, for Callum: (a) no personal totals: give the rule and the GOV.UK calculator link (BUG-08); (b) rule 1 kept, with an example that a plain conclusion from a section is allowed (BUG-09); (c) a search that finds everyday words, for example by adding each guide's own summary to the index, checked with the retrieval check on the planned questions only (BUG-03, BUG-04, BUG-06, BUG-07); (d) a larger name-swap run (BUG-10).
- Then: the regression set (36 cases) on 1.2, and a new pilot set of questions that nobody has seen.
