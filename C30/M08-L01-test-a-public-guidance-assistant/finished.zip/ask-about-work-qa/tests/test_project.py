"""Tests of the project (for the course team; learners do not need them): python -m pytest"""

import subprocess
import sys
from pathlib import Path

from guide import assistant, config, corpus
from qa.cases import load
from qa.runner import Runner

ROOT = Path(__file__).resolve().parents[1]


def test_sample_checksum():
    assert corpus.check_sample().startswith("1b14208649e3")
    assert len(corpus.records()) == 75


def test_every_recording_replays_with_its_sections():
    for v in config.VERSIONS:
        recs = assistant.recordings(v)
        assert len(recs) == 450
        for (_, run), r in recs.items():
            _, found = assistant.build(r["question"], v)
            assert [s.id for s, _ in found] == r["retrieved"], (v, r["qid"], run)


def test_unknown_question_is_not_recorded():
    t = assistant.answer("What is the capital of France?", "1.0")
    assert t["not_recorded"] == "question" and t["answer"] is None


def test_citations_map_to_sections():
    t = assistant.answer("I'm 25. What is the National Living Wage per hour?", "1.0", run=1)
    assert t["trace_id"] == "q02-v1.0-r1"
    assert t["cited"] == ["national-minimum-wage-rates/main#3", "national-minimum-wage-rates/main#5"]


def _results(folder, version):
    r = Runner(version)
    return {c.id: r.run_case(c, 10, 1)["passed_runs"] for c in load([str(ROOT / folder)])}


def test_campaign_results_match_the_case_study():
    v10, v11 = _results("cases", "1.0"), _results("cases", "1.1")
    assert v10["R1-02"] == 0 and v11["R1-02"] == 10      # BUG-01 fixed
    assert v10["R1-04"] == 0 and v11["R1-04"] == 10      # BUG-02 fixed
    assert v10["R2-05"] == 9 and v11["R2-05"] == 1       # BUG-06 regression
    assert v10["R3-03"] == 0 and v11["R3-03"] == 0       # BUG-03 open
    assert v11["MR2-relationship"] == 5                  # BUG-10
    assert v10["R2-01"] == 9 and v11["R2-01"] == 4       # BUG-09 hedges
    assert sum(v == 10 for v in v11.values()) == 27


def test_runs_beyond_the_recordings_are_not_run():
    case = load([str(ROOT / "cases" / "rates.yaml")])[0]
    res = Runner("1.0").run_case(case, 2, 10)
    assert res["passed_runs"] == 1 and res["not_run_runs"] == 1


def test_cli_commands():
    for args in (["guide", "check"], ["guide", "questions"], ["guide", "trace", "q02-v1.0-r3"],
                 ["guide", "show", "statutory-sick-pay/eligibility#1"], ["qa", "check", "cases/"]):
        out = subprocess.run([sys.executable, "-m", *args], cwd=ROOT, capture_output=True, text=True)
        assert out.returncode == 0, out.stderr
