from pathlib import Path

import pytest

from delivery_slots.zones import UnknownPostcode, load_zones, zone_for

DATA = Path(__file__).resolve().parents[1] / "data"


@pytest.fixture
def zones():
    return load_zones(DATA / "zones.csv")


def test_every_area_has_one_of_the_three_zones(zones):
    assert len(zones) == 9
    assert set(zones.values()) == {"city", "north", "west"}


@pytest.mark.parametrize(
    "postcode, zone",
    [("H3A 0G4", "city"), ("H2W 1Y6", "north"), ("H4A 1B2", "west")],
)
def test_zone_of_a_postcode(zones, postcode, zone):
    assert zone_for(postcode, zones) == zone


def test_postcode_as_customers_type_it(zones):
    assert zone_for(" h2w  1y6 ", zones) == "north"


def test_postcode_without_a_space(zones):
    """Issue 3: a customer typed "H4A1B2" and was told that we do not deliver."""
    assert zone_for("h4a1b2", zones) == "west"


def test_unknown_postcode(zones):
    with pytest.raises(UnknownPostcode, match="We do not deliver to K1A 0B1."):
        zone_for("k1a 0b1", zones)


@pytest.mark.parametrize(
    "postcode, zone",
    [
        ("H3Z 2Y7", "west"),
        ("H3Y 1K5", "west"),
        ("H3T 1J4", "west"),
        ("H3N 2L8", "north"),
    ],
)
def test_fsa_rows_win(zones, postcode, zone):
    """Issue 12: "H3Z 2Y7" got the city zone's slots."""
    assert zone_for(postcode, zones) == zone


def test_an_fsa_row_without_a_space(zones):
    assert zone_for("h3z2y7", zones) == "west"


def test_the_order_of_the_rows_does_not_matter():
    """An FSA row wins over the row of its first two characters, in any order."""
    for rows in ({"H3": "city", "H3Z": "west"}, {"H3Z": "west", "H3": "city"}):
        assert zone_for("H3Z 2Y7", rows) == "west"
        assert zone_for("H3A 0G4", rows) == "city"
