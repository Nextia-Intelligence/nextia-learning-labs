from delivery_slots.postcodes import normalise


def test_capital_letters_and_single_spaces():
    assert normalise(" h2w  1y6 ") == "H2W 1Y6"


def test_a_tidy_postcode_stays_the_same():
    assert normalise("H3A 0G4") == "H3A 0G4"


def test_a_postcode_without_a_space_keeps_no_space():
    assert normalise("h4a1b2") == "H4A1B2"
