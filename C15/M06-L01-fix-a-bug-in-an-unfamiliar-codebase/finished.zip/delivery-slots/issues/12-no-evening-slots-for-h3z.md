# Issue 12: no evening slots for H3Z, although the delivery page promises them

Status: open
Reported by: Grace, help-desk lead

A customer wrote to us on Monday morning. Her email, as she sent it:

> Hello,
>
> Your delivery page says that the west zone gets evening deliveries on Tuesdays
> and Thursdays, 6 to 8 pm. I live in Westmount, H3Z 2Y7, and I work during the
> day. This morning (Monday, about 10 o'clock) I ordered a garden bench, order
> L-40213. For Tuesday the checkout offered me only 8-10, 10-12 and 12-2. No
> evening slot at all. My sister in Notre-Dame-de-Grâce, H4A, has an evening
> delivery booked for tomorrow, so the evening slots do exist.
>
> Can you deliver my bench on Tuesday evening, please?
>
> Solange

What I checked: on the checkout page, `H3Z 2Y7` and Tuesday 20 October show the
same three daytime slots. Monday 10:00 is long before the 20:00 cut-off. The
order L-40213 is paid, and it has no delivery slot yet. I told Solange that we
will come back to her today.

Delphine and Luis are at the trade fair until Friday. Amira (help-desk tools)
said that she can look at it.
