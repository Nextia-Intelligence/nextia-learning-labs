# Issue 3: "We do not deliver to H4A1B2"

Status: closed (fixed in "Accept postcodes typed without a space")
Reported by: Grace, help-desk lead

A customer in Notre-Dame-de-Grâce typed her postal code without the space,
`H4A1B2`, and the checkout said "We do not deliver to H4A1B2." With the space,
`H4A 1B2`, it works. Many customers type postal codes without the space, on
phones most of all.

To reproduce:

    python -m delivery_slots slots H4A1B2 --day 2026-09-29

Expected: the west zone's slots. Observed: `Error: We do not deliver to H4A1B2.`
