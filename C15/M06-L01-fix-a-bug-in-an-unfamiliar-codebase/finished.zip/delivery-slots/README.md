# delivery-slots

Larkfield's delivery time slots, per postcode zone. Larkfield's vans leave the
Montréal depot for three zones: city, north and west. Each zone has its own slots,
and each slot has a capacity: the number of deliveries that fit in it.
The shop's checkout page uses this package to show the slots to a customer and to book one.

Maintainers: Delphine (delivery team) and Luis (delivery team).

## Set up

Python 3.12 or newer. The program needs only the standard library; the tests
need pytest.

```sh
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
python -m pytest
```

## Commands

Run every command in the project folder. `--now` replaces the clock, so that
you can see the slots as a customer saw them at a given time.

```sh
python -m delivery_slots --now 2026-10-19T10:00 slots "H2W 1Y6" --day 2026-10-21
python -m delivery_slots --now 2026-10-19T10:00 book L-40001 "H2W 1Y6" --day 2026-10-21 --start 08:00
python -m delivery_slots manifest --day 2026-10-21 --zone north
```

| Command | What it does |
|---|---|
| `slots POSTCODE --day DAY` | prints the postal code's zone and the zone's slots that day, with the places left |
| `book ORDER POSTCODE --day DAY --start HH:MM` | books the slot for an order and adds it to `data/bookings.csv` |
| `manifest --day DAY --zone ZONE` | prints the driver's list: the zone's bookings that day, in slot order |

Exit codes: 0 done, 1 refused (the message says why), 2 wrong arguments.

## Data

| File | What one row is |
|---|---|
| `data/zones.csv` | an area and its zone. An area is a whole FSA (the first three characters of a postal code, such as `H3Z`) or the first two characters of many FSAs (such as `H3`) |
| `data/slot-plan.csv` | a slot in a normal week: zone, weekdays, start, end, capacity |
| `data/bookings.csv` | a booked delivery: order, postcode, zone, day, start (this week's export from the shop) |

## Rules

- Orders for a day close at 20:00 the evening before (the cut-off), so that the
  depot can load the vans at night.
- A slot with no places left is full.
- The row of a whole FSA wins over the row of its first two characters, wherever
  the rows are in `data/zones.csv`.
- Customers may type a postal code with or without the space: `H4A 1B2` or `h4a1b2`.
- The west zone has evening slots, 18:00 to 20:00, on Tuesdays and Thursdays.

## Issues

The help desk writes each problem as a file in `issues/`, with a number.

## About this project

Nextia Learning wrote this project for a case study of the course
AI-Assisted Software Development. Larkfield, its people, its customers and the
bookings are invented; the FSAs are real forward sortation areas of Montréal,
but their zones are invented.

## Licence

MIT. See `LICENSE`.
