"""Postal codes as customers type them, made tidy."""


def normalise(postcode: str) -> str:
    """Capital letters and single spaces, as on an envelope.

    " h3z  2y7 " -> "H3Z 2Y7". A postal code typed without a space keeps no space:
    "h4a1b2" -> "H4A1B2".
    """
    return " ".join(postcode.upper().split())
