"""Which delivery zone a postal code belongs to.

Larkfield's vans leave the Montréal depot for three zones: city, north and west.
data/zones.csv maps each area to its zone. An area is a whole FSA, the first three
characters of a postal code (H3Z in "H3Z 2Y7"), or the first two characters of
many FSAs (H3).
"""

import csv
from pathlib import Path

from delivery_slots.postcodes import normalise


class UnknownPostcode(ValueError):
    """Larkfield does not deliver to this postal code."""


def load_zones(path: Path) -> dict[str, str]:
    """Read data/zones.csv: area -> zone, in the order of the file."""
    with open(path, newline="", encoding="utf-8") as f:
        return {
            row["area"].strip().upper(): row["zone"].strip()
            for row in csv.DictReader(f)
        }


def zone_for(postcode: str, zones: dict[str, str]) -> str:
    """The zone of a postal code, for example "west" for "H4A 1B2".

    Customers type postal codes with or without the space ("H4A 1B2", "h4a1b2"),
    so the area is matched at the start of the postal code.
    """
    code = normalise(postcode).replace(" ", "")
    for area in sorted(zones, key=len, reverse=True):
        if code.startswith(area):
            return zones[area]
    raise UnknownPostcode(f"We do not deliver to {normalise(postcode)}.")
