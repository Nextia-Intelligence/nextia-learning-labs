from pathlib import Path

import pytest

from delivery_slots.zones import UnknownPostcode, load_zones, zone_for

DATA = Path(__file__).resolve().parents[1] / "data"


@pytest.fixture
def zones():
    return load_zones(DATA / "zones.csv")


def test_every_area_has_one_of_the_three_zones(zones):
    assert len(zones) == 9
    assert set(zones.values()) == {"city", "north", "west"}


@pytest.mark.parametrize(
    "postcode, zone",
    [("H3A 0G4", "city"), ("H2W 1Y6", "north"), ("H4A 1B2", "west")],
)
def test_zone_of_a_postcode(zones, postcode, zone):
    assert zone_for(postcode, zones) == zone


def test_postcode_as_customers_type_it(zones):
    assert zone_for(" h2w  1y6 ", zones) == "north"


def test_postcode_without_a_space(zones):
    """Issue 3: a customer typed "H4A1B2" and was told that we do not deliver."""
    assert zone_for("h4a1b2", zones) == "west"


def test_unknown_postcode(zones):
    with pytest.raises(UnknownPostcode, match="We do not deliver to K1A 0B1."):
        zone_for("k1a 0b1", zones)
