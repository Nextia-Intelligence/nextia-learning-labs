"""Make the case study's fixed sample from tau2-bench's published trajectories (how the fixed sample was made).

    python -I tools/make_sample.py RAW.json OUT.jsonl.gz

RAW.json is one results file of sierra-research/tau2-bench (MIT), folder data/tau2/results/final, release v1.0.0
(commit 17e07b1da2bbc0cadfddeea36412686e0604127b; the same files are in every later release). Download it into its
own empty folder, run this, then delete it. The four raw files and their SHA-256 are in DATASET-RESEARCH.md.

We keep, for each simulation: its ID, task, trial, why it ended, its reward, the agent's and the user
simulator's recorded cost, and for each of the agent's model calls: the recorded token counts and cost, and the
tool calls it asked for (name and arguments), with whether the tool answered with an error. We drop every text
(the messages, the tool results, the policy): the controls need counts, names and arguments, not words.
"""

import gzip
import json
import sys


def compact(sim: dict) -> dict:
    steps, waiting_user = [], False
    msgs = sim["messages"]
    for i, m in enumerate(msgs):
        if m["role"] == "user":
            waiting_user = True
            continue
        if m["role"] != "assistant" or not m.get("usage"):
            continue
        calls = []
        for tc in m.get("tool_calls") or []:
            # The tool's answer is the next "tool" message with this call's ID.
            res = next((x for x in msgs[i + 1:] if x["role"] == "tool" and x.get("id") == tc.get("id")), None)
            err = bool(res and (res.get("error") or str(res.get("content", "")).startswith("Error")))
            calls.append({"name": tc["name"], "arguments": tc.get("arguments") or {}, "error": err})
        steps.append({"turn": m.get("turn_idx"), "after_user": waiting_user,
                      "prompt_tokens": m["usage"]["prompt_tokens"], "completion_tokens": m["usage"]["completion_tokens"],
                      "cost_usd": round(m.get("cost") or 0.0, 8), "tools": calls})
        waiting_user = False
    return {"id": sim["id"], "task_id": sim["task_id"], "trial": sim["trial"],
            "termination_reason": sim["termination_reason"], "reward": sim["reward_info"]["reward"],
            "agent_cost_usd": sim["agent_cost"], "user_cost_usd": sim["user_cost"],
            "messages": len(msgs), "steps": steps}


def main(raw: str, out: str) -> None:
    with open(raw, encoding="utf-8") as f:
        d = json.load(f)
    info = {"agent_llm": d["info"]["agent_info"]["llm"], "user_llm": d["info"]["user_info"]["llm"],
            "domain": d["info"]["environment_info"]["domain_name"], "max_steps": d["info"]["max_steps"],
            "max_errors": d["info"]["max_errors"], "num_trials": d["info"]["num_trials"],
            "tau2_git_commit": d["info"].get("git_commit")}
    with gzip.open(out, "wt", encoding="utf-8", compresslevel=9) as f:
        f.write(json.dumps({"info": info}) + "\n")
        for s in d["simulations"]:
            f.write(json.dumps(compact(s), separators=(",", ":")) + "\n")
    print(out, len(d["simulations"]), "simulations", info)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
