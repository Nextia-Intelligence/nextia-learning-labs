# runaway-replay: contain a runaway agent

A case study of the course *Governing AI Agents: Gateways, Registries and Controls* (Nextia Learning). It replays
456 recorded runs of an open AI support agent (τ²-bench's telecom domain, MIT) through the course's model gateway
and tool gateway, and measures what each runaway control stops, what it saves, and which good runs it stops by
mistake.

## What you need

- The course project at the end of the course, in a folder `ai-estate` next to this one (or set `ESTATE_PROJECT`
  to its folder), with its virtual environment. This folder adds no package.
- About 1 MB of disk, and about 30 seconds per full replay through the gateways.

```sh
cd runaway-replay
source ../ai-estate/.venv/bin/activate        # Windows: ..\ai-estate\.venv\Scripts\Activate.ps1
python -m pytest -q                            # 14 passed
```

## Commands

| Command | What it does |
|---|---|
| `python -m replay.compare` | the data checks, the baseline, and each control at its tightest safe setting (seconds) |
| `python -m replay.compare --json results/compare.json` | the same, with every number in a file |
| `python -m replay.gateway --data design --max-calls-per-run 50` | the design day through the real gateways |
| `python -m replay.gateway --data o4-mini --max-calls-per-run 50 --tokens-per-day 270000000` | new input |
| `--repeat-limit N` | add the repeat limit in front of the tool gateway |

`--data` is `design` (gpt-4.1-mini), `gpt-4.1`, `o4-mini` or `claude-3.7-sonnet`.

## Files

| File | What it does |
|---|---|
| `data/trajectories/` | the fixed sample (4 files, their `SHA256SUMS`, the τ²-bench licence) |
| `data/dataset.md` | the dataset card: source, licence, changes, limits |
| `config/phone-tools.yaml` | the agent's 13 tools: arguments, read or write |
| `registrations/phone-support.yaml` | the agent's registration (the replay sets its limits) |
| `replay/data.py` | loads and checks the sample; prices each call at chat-small's price |
| `replay/controls.py` | the arithmetic: what each control does to each run |
| `replay/compare.py` | the comparison under one measure |
| `replay/trace_provider.py` | a stand-in provider that answers with the recorded token counts |
| `replay/repeat_rule.py` | the repeat limit, in front of the tool gateway |
| `replay/gateway.py` | the replay through the course's gateways, checked against the arithmetic |
| `tools/make_sample.py` | how the fixed sample was made from the benchmark's results files |
| `tests/` | 14 tests (2 need the course project) |

## The replay rule

A recorded run can be followed only while the platform gives the agent the same answer as the recording. A model
call that a limit refuses, or a tool call that the platform refuses where the recording had an answer, ends the
run there, and its task goes to a person. A tool call that the recording also answered with an error may be
refused: the agent sees an error both times, so the run goes on as recorded.

## Licences

The code: MIT (`LICENSE`). The data: τ²-bench by Sierra Research, MIT (`data/trajectories/LICENSE-tau2-bench.txt`),
reduced to counts, names and arguments by Nextia Learning (`data/dataset.md`).
