"""The fixed sample: the right files, the right counts."""

import pytest

from replay import data


@pytest.mark.parametrize("name", list(data.FILES))
def test_every_file_has_its_checksum(name):
    assert len(data.check(name)) == 64


def test_the_design_day():
    info, runs = data.load("design")
    assert info["agent_llm"] == "gpt-4.1-mini-2025-04-14"
    assert len(runs) == 456 and len({r.task_id for r in runs}) == 114
    endings = {k: sum(r.ending == k for r in runs) for k in ("success", "failure", "runaway")}
    assert endings == {"success": 200, "failure": 224, "runaway": 32}
    assert sum(len(r.steps) for r in runs) == 13269
    assert round(sum(r.cost_usd for r in runs), 2) == 13.73


def test_the_longest_successful_run():
    _, runs = data.load("design")
    assert max(len(r.steps) for r in runs if r.ending == "success") == 44
    assert min(len(r.steps) for r in runs if r.ending == "runaway") == 77
