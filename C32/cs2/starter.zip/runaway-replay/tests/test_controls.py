"""The controls on a tiny day of three runs, where every number can be checked by hand."""

from replay.controls import Settings, replay, summary
from replay.data import Run, Step


def tool(name, **args):
    return {"name": name, "arguments": args, "error": False}


def tiny_day():
    """A success (3 calls), a runaway (6 calls, the same lookup again and again) and a failure (2 calls).
    Each call: 1,000 tokens in and 100 out, US$0.00015 at chat-small's price."""
    def step(*tools):
        return Step(1000, 100, list(tools))
    ok = Run("ok", "t1", 0, "success", [step(tool("get_customer_by_phone", phone_number="555-0101")),
                                         step(tool("refuel_data", customer_id="C1", line_id="L1", gb_amount=2)),
                                         step()])
    loop = Run("loop", "t2", 0, "runaway", [step(tool("get_details_by_id", id="L7")) for _ in range(6)])
    bad = Run("bad", "t3", 0, "failure", [step(tool("get_details_by_id", id="L9")), step()])
    return [ok, loop, bad]


def test_no_limit_spends_what_was_recorded():
    s = summary(replay(tiny_day(), Settings()))
    assert s["model_calls"] == 11
    assert s["cost_usd"] == round(11 * 0.00015, 4)
    assert s["saved_usd"] == 0 and s["wrong_blocks"] == 0


def test_a_step_limit_of_4_stops_only_the_loop():
    out = replay(tiny_day(), Settings(max_calls_per_run=4))
    assert [o.stopped_at for o in out] == [None, 4, None]     # the 5th call of the loop is refused
    assert out[1].stopped_by == "run_step_limit" and out[1].calls == 4
    assert summary(out)["saved_usd"] == round(2 * 0.00015, 4)


def test_a_step_limit_of_2_also_stops_the_success():
    out = replay(tiny_day(), Settings(max_calls_per_run=2))
    assert [o.stopped_at for o in out] == [2, 2, None]
    assert summary(out)["wrong_blocks"] == 1


def test_a_repeat_limit_of_2_refuses_the_third_identical_call():
    out = replay(tiny_day(), Settings(repeat_limit=2))
    assert out[1].stopped_by == "repeat_limit"
    assert out[1].stopped_at == 2 and out[1].calls == 3      # the model call was answered (and paid), its tool call refused
    assert out[0].stopped_at is None and out[2].stopped_at is None


def test_a_daily_quota_stops_every_later_run_too():
    # 5,000 tokens: the success uses 3,300; the loop's 2nd call brings the day to 5,500, so its 3rd call is refused.
    out = replay(tiny_day(), Settings(tokens_per_day=5000))
    assert [o.stopped_at for o in out] == [None, 2, 0]
    assert out[2].stopped_by == "quota_exhausted"            # the failure's first call: the day is used up


def test_a_wrong_argument_that_the_recording_also_refused_does_not_stop_the_run():
    schema = {"get_details_by_id": {"arguments": {"id": "string"}, "required": ["id"]}}
    run = Run("x", "t4", 0, "success", [Step(10, 1, [{"name": "get_details_by_id", "arguments": {"app_name": "x"},
                                                      "error": True}]), Step(10, 1, [])])
    out = replay([run], Settings(), schema)
    assert out[0].stopped_at is None and len(out[0].refused_tools) == 1
    run.steps[0].tools[0]["error"] = False                    # the recording answered it: the replay must stop there
    assert replay([run], Settings(), schema)[0].stopped_by == "invalid_arguments"
