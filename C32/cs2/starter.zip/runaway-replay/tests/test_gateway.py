"""The course's gateways give the same result as the arithmetic (needs the course project: ESTATE_PROJECT)."""

import os
from pathlib import Path

import pytest

from replay import controls, gateway

PROJECT = Path(os.environ.get("ESTATE_PROJECT", Path(__file__).resolve().parents[2] / "ai-estate"))
pytestmark = pytest.mark.skipif(not (PROJECT / "toolgate" / "app.py").exists(),
                                reason="the course project is not in ESTATE_PROJECT")


def test_a_step_limit_through_the_gateway_matches_the_arithmetic():
    res = gateway.run("design", controls.Settings(max_calls_per_run=50), first=60)
    assert res["matches_the_arithmetic"]
    assert res["summary"]["runs"] == 60


def test_a_repeat_limit_through_the_tool_gateway_matches_the_arithmetic():
    res = gateway.run("o4-mini", controls.Settings(repeat_limit=13), first=120)
    assert res["matches_the_arithmetic"]
