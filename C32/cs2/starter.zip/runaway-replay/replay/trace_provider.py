"""A stand-in provider that answers each replayed model call with the recorded token counts.

The course's provider simulator answers only requests that an earlier course recorded, byte for byte. These
runs were recorded by someone else, with other models, so the simulator has no answer for them. This small
provider has one job: when the gateway forwards call number `step` of run `run`, it answers with the token counts
that the recording has for that call, and an empty message. The gateway prices those tokens and counts them, as
it does for every answer.

The replayer names the call in the request's `metadata` (the gateway passes the body on as it is).
"""

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route


def create_app(calls: dict, model: str) -> Starlette:
    """calls: {(run_id, step): (prompt_tokens, completion_tokens)}; model: the recorded model's name."""

    async def chat(request: Request) -> JSONResponse:
        body = await request.json()
        meta = body.get("metadata") or {}
        key = (meta.get("run"), int(meta.get("step", -1)))
        if key not in calls:
            return JSONResponse({"error": {"code": "no_recording", "message": f"no recorded call {key}"}}, 422)
        prompt, completion = calls[key]
        return JSONResponse({
            "id": f"replay-{key[0][:8]}-{key[1]}", "object": "chat.completion", "model": model,
            "choices": [{"index": 0, "finish_reason": "stop", "message": {"role": "assistant", "content": ""}}],
            "usage": {"prompt_tokens": prompt, "completion_tokens": completion,
                      "total_tokens": prompt + completion}})

    return Starlette(routes=[Route("/trace/v1/chat/completions", chat, methods=["POST"])])
