"""Contain a runaway agent: recorded agent runs, replayed through the course's gateways."""
