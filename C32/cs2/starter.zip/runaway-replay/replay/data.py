"""The recorded trajectories: load them, check them, and price them.

Each file in data/trajectories/ is a fixed sample of tau2-bench's published telecom results (see
data/dataset.md). The first line describes the file; every other line is one RUN: one conversation of an agent
with a simulated customer, with each of the agent's model calls (its recorded token counts) and the tool calls
that the model asked for.
"""

import gzip
import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
TRAJECTORIES = HERE / "data" / "trajectories"

# The samples. "design" is the agent the team runs today; gpt-4.1 and o4-mini are new input for the end.
FILES = {
    "design": "telecom-gpt-4.1-mini.jsonl.gz",
    "gpt-4.1": "telecom-gpt-4.1.jsonl.gz",
    "o4-mini": "telecom-o4-mini.jsonl.gz",
    "claude-3.7-sonnet": "telecom-claude-3.7-sonnet.jsonl.gz",   # for "Go further"
}

# One price for every recorded token: the course's chat-small (US$ per 1M tokens, the course's catalog).
# The controls are compared on how the agents behave, not on the price lists of other providers.
PRICE_IN, PRICE_OUT = 0.10, 0.50


@dataclass
class Step:
    """One model call of the agent, and the tool calls it asked for (name, arguments, recorded error)."""
    prompt_tokens: int
    completion_tokens: int
    tools: list = field(default_factory=list)

    @property
    def tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens

    @property
    def cost_usd(self) -> float:
        return (self.prompt_tokens * PRICE_IN + self.completion_tokens * PRICE_OUT) / 1e6


@dataclass
class Run:
    id: str
    task_id: str
    trial: int
    ending: str          # "success", "failure" or "runaway"
    steps: list

    @property
    def cost_usd(self) -> float:
        return sum(s.cost_usd for s in self.steps)

    @property
    def tokens(self) -> int:
        return sum(s.tokens for s in self.steps)


def ending(row: dict) -> str:
    """runaway: tau2-bench stopped the conversation (200 messages, or 10 tool errors); success: reward 1."""
    if row["termination_reason"] in ("max_steps", "too_many_errors"):
        return "runaway"
    return "success" if row["reward"] == 1 else "failure"


def check(name: str) -> str:
    """The file's SHA-256 must be the one in SHA256SUMS: a changed file would change every number."""
    path = TRAJECTORIES / FILES[name]
    want = dict(reversed(line.split()) for line in (TRAJECTORIES / "SHA256SUMS").read_text().splitlines())
    got = hashlib.sha256(path.read_bytes()).hexdigest()
    if got != want[path.name]:
        raise ValueError(f"{path.name}: SHA-256 {got[:12]}..., expected {want[path.name][:12]}...")
    return got


def load(name: str = "design") -> tuple[dict, list[Run]]:
    check(name)
    with gzip.open(TRAJECTORIES / FILES[name], "rt", encoding="utf-8") as f:
        info = json.loads(f.readline())["info"]
        runs = []
        for line in f:
            r = json.loads(line)
            steps = [Step(s["prompt_tokens"], s["completion_tokens"], s["tools"]) for s in r["steps"]]
            runs.append(Run(r["id"], r["task_id"], r["trial"], ending(r), steps))
    return info, runs
