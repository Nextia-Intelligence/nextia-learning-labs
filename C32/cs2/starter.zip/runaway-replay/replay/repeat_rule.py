"""A repeat limit in front of the tool gateway: the same tool with the same arguments, at most N times per run.

The course's tool gateway already records every call with a digest of its arguments (toolgate/app.py, the
usage store's tool_calls table). So the rule needs no new record: before a call goes on, it counts the calls of
this run with the same tool and the same digest that the gateway answered, and refuses the next one with
429 repeat_limit.

It sits in front of the tool gateway, as one more check after the gateway's own. It reads the agent from the
access token without checking the signature: the tool gateway checks the token right after it, and a forged
token is refused there.
"""

import json

import jwt
from starlette.requests import Request
from starlette.responses import JSONResponse

from replay.controls import digest


class RepeatLimit:
    def __init__(self, app, store, limit: int, server: str = "phone"):
        self.app, self.store, self.limit, self.server = app, store, limit, server

    async def __call__(self, scope, receive, send):
        if not self.limit or scope["type"] != "http" or scope["path"] != "/v1/tools/call":
            return await self.app(scope, receive, send)
        request = Request(scope, receive)
        raw = await request.body()
        body = json.loads(raw or b"{}")
        auth = request.headers.get("authorization", "")[7:]
        agent = jwt.decode(auth, options={"verify_signature": False}).get("sub") if auth else None
        server, _, tool = str(body.get("tool", "")).partition(".")
        done = self.store.rows(
            "select count(*) as n from tool_calls where agent_id = ? and run_id = ? and server = ? and tool = ? "
            "and args_digest = ? and outcome in ('ok', 'tool_error')",
            (agent, body.get("run_id"), server, tool, digest(body.get("arguments") or {})))[0]["n"]
        if done >= self.limit:
            msg = (f"{body.get('tool')} with these arguments was called {done} times in run {body.get('run_id')}: "
                   f"the limit is {self.limit}. Stop the run and hand the task to a person.")
            response = JSONResponse({"error": {"code": "repeat_limit", "message": msg, "check": "repeat_limit"}}, 429)
            return await response(scope, receive, send)

        async def replay_body():   # the body was read: give it to the tool gateway again
            return {"type": "http.request", "body": raw, "more_body": False}

        return await self.app(scope, replay_body, send)
