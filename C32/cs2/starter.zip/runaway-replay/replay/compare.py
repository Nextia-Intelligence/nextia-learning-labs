"""Compare the controls on the design day, under one measure.

    python -m replay.compare              the checks, the baseline, the sweeps and the comparison
    python -m replay.compare --json results/compare.json

The measure: the US$ that a control saves on the replayed day WITHOUT stopping a single run that would have
succeeded. A control that stops a good run sends a satisfied customer to a person for nothing; the team does
not accept that for a runaway control. So each control gets its tightest setting that stops no successful run
of the design day, and we compare what that setting saves.
"""

import argparse
import json
import statistics
from pathlib import Path

import yaml

from replay import data
from replay.controls import Settings, day_order, replay, summary

HERE = Path(__file__).resolve().parent.parent
SCHEMA = yaml.safe_load((HERE / "config" / "phone-tools.yaml").read_text(encoding="utf-8"))["tools"]
WRITES = {n for n, t in SCHEMA.items() if t["kind"] == "write"}


def day(name="design"):
    info, runs = data.load(name)
    return info, day_order(runs)


def run(runs, **kw) -> dict:
    return summary(replay(runs, Settings(**kw), SCHEMA))


def checks(info, runs) -> dict:
    """What the data holds: the endings, the calls per run, the cost of each kind of run."""
    out = {"agent_llm": info["agent_llm"], "user_llm": info["user_llm"], "runs": len(runs),
           "tasks": len({r.task_id for r in runs}), "trials": info["num_trials"], "max_messages": info["max_steps"],
           "model_calls": sum(len(r.steps) for r in runs), "tool_calls": sum(len(s.tools) for r in runs for s in r.steps),
           "tokens": sum(r.tokens for r in runs), "cost_usd": round(sum(r.cost_usd for r in runs), 4), "by_ending": {}}
    for kind in ("success", "failure", "runaway"):
        g = [r for r in runs if r.ending == kind]
        calls = sorted(len(r.steps) for r in g)
        out["by_ending"][kind] = {
            "runs": len(g), "calls_median": statistics.median(calls) if g else 0, "calls_max": calls[-1] if g else 0,
            "calls_min": calls[0] if g else 0, "cost_usd": round(sum(r.cost_usd for r in g), 4),
            "cost_per_run_usd": round(sum(r.cost_usd for r in g) / len(g), 4) if g else 0}
    return out


def repeats(run_) -> int:
    """The most times this run called one tool with the same arguments."""
    c = {}
    for s in run_.steps:
        for t in s.tools:
            k = (t["name"], json.dumps(t["arguments"], sort_keys=True))
            c[k] = c.get(k, 0) + 1
    return max(c.values(), default=0)


def tightest(runs, key: str, values) -> int:
    """The smallest setting with no successful run stopped (a larger setting stops fewer runs)."""
    for v in values:
        if run(runs, **{key: v})["wrong_blocks"] == 0:
            return v
    return 0


def writes(runs) -> dict:
    """A tool policy that asks a person before every write: how many runs would wait, and when."""
    def first_write(r):
        return next((i for i, s in enumerate(r.steps) if any(t["name"] in WRITES for t in s.tools)), None)
    out = {}
    for kind in ("success", "failure", "runaway"):
        g = [r for r in runs if r.ending == kind]
        fw = [first_write(r) for r in g]
        out[kind] = {"runs": len(g), "with_a_write": sum(x is not None for x in fw),
                     "writes": sum(t["name"] in WRITES for r in g for s in r.steps for t in s.tools),
                     "first_write_median_call": statistics.median([x + 1 for x in fw if x is not None]) if any(
                         x is not None for x in fw) else None}
    return out


def compare() -> dict:
    info, runs = day()
    res = {"checks": checks(info, runs), "baseline": run(runs)}
    res["course_settings"] = run(runs, max_calls_per_run=8, tokens_per_day=2_000_000)
    res["course_step_only"] = run(runs, max_calls_per_run=8)
    res["sweep_step"] = [{"limit": n, **run(runs, max_calls_per_run=n)} for n in range(5, 101, 5)]
    res["sweep_repeat"] = [{"limit": n, **run(runs, repeat_limit=n)} for n in range(2, 31)]
    res["sweep_quota"] = [{"limit_m": m, **run(runs, tokens_per_day=m * 1_000_000)} for m in range(40, 141, 10)]
    healthy = sum(r.tokens for r in runs if r.ending != "runaway")
    res["repeats"] = {k: max(repeats(r) for r in runs if r.ending == k) for k in ("success", "failure", "runaway")}
    res["repeats_runaway_min"] = min(repeats(r) for r in runs if r.ending == "runaway")
    step = tightest(runs, "max_calls_per_run", range(1, 201))
    rep = tightest(runs, "repeat_limit", range(1, 201))
    # The quota: search over whole millions of tokens, up to the whole day.
    quota_m = tightest(runs, "tokens_per_day", [m * 1_000_000 for m in range(1, 200)]) // 1_000_000
    res["tightest"] = {
        "step_limit": {"setting": step, **run(runs, max_calls_per_run=step)},
        "repeat_limit": {"setting": rep, **run(runs, repeat_limit=rep)},
        "quota_m_tokens": {"setting": quota_m, **run(runs, tokens_per_day=quota_m * 1_000_000)},
    }
    res["day_tokens_without_runaways"] = healthy
    res["writes_need_a_person"] = writes(runs)
    # The settings chosen (see the lesson), on the design day and on the two new inputs.
    chosen = {"max_calls_per_run": 0}   # TODO (Part 4): your choice of the step limit, with its reason
    res["chosen"] = {"settings": chosen, "design": run(runs, **chosen)}
    for name in ("gpt-4.1", "o4-mini"):
        i2, r2 = day(name)
        res[name] = {"checks": checks(i2, r2), "chosen": run(r2, **chosen),
                     "step_tightest": run(r2, max_calls_per_run=step), "repeat_tightest": run(r2, repeat_limit=rep),
                     "baseline": run(r2),
                     "repeats_success_max": max(repeats(r) for r in r2 if r.ending == "success")}
    return res


def show(res: dict) -> str:
    c = res["checks"]
    lines = [f"Design day: {c['runs']} runs of {c['agent_llm']} ({c['tasks']} tasks x {c['trials']} trials), "
             f"{c['model_calls']:,} model calls, {c['tool_calls']:,} tool calls, {c['tokens']:,} tokens, "
             f"US${c['cost_usd']:.2f} at chat-small's price"]
    for k, v in c["by_ending"].items():
        lines.append(f"  {k:<8} {v['runs']:>4} runs | calls per run: median {v['calls_median']}, max {v['calls_max']} "
                     f"| US${v['cost_usd']:.2f} ({100 * v['cost_usd'] / c['cost_usd']:.0f}% of the day), "
                     f"US${v['cost_per_run_usd']:.4f} a run")
    b = res["course_settings"]
    lines.append(f"Larkfield's workflow limits (8 calls a run, 2,000,000 tokens a day): {b['wrong_blocks']} of "
                 f"{c['by_ending']['success']['runs']} successful runs stopped")
    lines.append("")
    lines.append("Each control at its tightest setting that stops no successful run (the measure: US$ saved):")
    lines.append(f"  {'control':<28} {'setting':>10} {'saved':>8} {'runaways stopped':>17} {'failures stopped':>17}")
    for name, label, unit in (("step_limit", "step limit (model gateway)", "calls"),
                              ("repeat_limit", "repeat limit (tool gateway)", "times"),
                              ("quota_m_tokens", "daily quota (model gateway)", "M tokens")):
        t = res["tightest"][name]
        lines.append(f"  {label:<28} {str(t['setting']) + ' ' + unit:>10} US${t['saved_usd']:>5.2f} "
                     f"{t['runaway']['stopped']:>10} of {t['runaway']['runs']:<4} {t['failure']['stopped']:>10} of "
                     f"{t['failure']['runs']}")
    b0 = res["baseline"]
    lines.append(f"Strict arguments (always on): {b0['tool_calls_refused_as_recorded']} tool calls refused (all of them errors in the recording too); "
                 f"{sum(b0['stopped_by'].values())} runs stopped")
    w = res["writes_need_a_person"]
    lines.append(f"Writes need a person: {w['runaway']['with_a_write']} of {w['runaway']['runs']} runaways ever write "
                 f"(first write at call {w['runaway']['first_write_median_call']}, median); "
                 f"{w['success']['with_a_write']} of {w['success']['runs']} successful runs would wait for a person")
    lines.append("")
    ch = res["chosen"]
    lines.append(f"Chosen: step limit {ch['settings']['max_calls_per_run']} | design day: saved "
                 f"US${ch['design']['saved_usd']:.2f}, {ch['design']['runaway']['stopped']} of "
                 f"{ch['design']['runaway']['runs']} runaways stopped, {ch['design']['wrong_blocks']} wrong blocks")
    for name in ("gpt-4.1", "o4-mini"):
        n = res[name]
        lines.append(f"  new input {name}: longest successful run {n['checks']['by_ending']['success']['calls_max']} "
                     f"calls; step limit {ch['settings']['max_calls_per_run']}: {n['chosen']['wrong_blocks']} wrong "
                     f"blocks, {n['chosen']['runaway']['stopped']} of {n['chosen']['runaway']['runs']} runaways "
                     f"stopped | repeat limit {res['tightest']['repeat_limit']['setting']}: "
                     f"{n['repeat_tightest']['wrong_blocks']} wrong blocks")
    return "\n".join(lines)


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--json", help="also write every number to this file")
    a = ap.parse_args(argv)
    res = compare()
    print(show(res))
    if a.json:
        Path(a.json).parent.mkdir(parents=True, exist_ok=True)
        Path(a.json).write_text(json.dumps(res, indent=1) + "\n")


if __name__ == "__main__":
    main()
