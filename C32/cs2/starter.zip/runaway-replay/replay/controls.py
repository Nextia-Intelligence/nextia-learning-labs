"""What each control would do to the recorded runs: the arithmetic, without the gateway.

The replay rule: a recorded run can be followed only while the platform gives the agent the same answer as the
recording. A model call refused by a limit, or a tool call refused where the recording had an answer, ends the
recording there: we count the run as STOPPED at that call, and its task goes to a person. A tool call that the
recording also answered with an error (for example wrong arguments) may be refused: the agent sees an error in
both cases, so the run goes on as recorded.

python -m replay.gateway sends the same runs through the course's real gateways and must give the same result.
"""

import hashlib
import json
import random
from dataclasses import dataclass, field

from replay.data import Run


@dataclass
class Settings:
    """0 means "no limit", as in a registration."""
    max_calls_per_run: int = 0        # model gateway: the step limit (calls with one X-Run-Id)
    tokens_per_day: int = 0           # model gateway: the agent's daily quota
    repeat_limit: int = 0             # tool gateway: the same tool with the same arguments, at most this often per run
    strict_arguments: bool = True     # tool gateway: refuse arguments that are not in the tool's schema (always on)

    def label(self) -> str:
        parts = []
        if self.max_calls_per_run:
            parts.append(f"step limit {self.max_calls_per_run}")
        if self.tokens_per_day:
            parts.append(f"quota {self.tokens_per_day:,} tokens a day")
        if self.repeat_limit:
            parts.append(f"repeat limit {self.repeat_limit}")
        return ", ".join(parts) or "no limit"


@dataclass
class Outcome:
    run: Run
    stopped_at: int | None = None     # index of the model call where the run stopped (None: it ran to its end)
    stopped_by: str = ""              # run_step_limit, quota_exhausted, repeat_limit, invalid_arguments
    calls: int = 0                    # model calls answered
    cost_usd: float = 0.0             # what the answered calls cost
    tokens: int = 0
    refused_tools: list = field(default_factory=list)   # tool calls refused that the recording also refused

    @property
    def wrong_block(self) -> bool:
        """A run that would have succeeded, stopped by a control."""
        return self.stopped_at is not None and self.run.ending == "success"


def digest(arguments: dict) -> str:
    """The tool gateway's digest of a call's arguments (toolgate/app.py): the usage store keeps this, not the values."""
    return hashlib.sha256(json.dumps(arguments, sort_keys=True).encode()).hexdigest()[:16]


def refusal(tool: dict, schema: dict, strict: bool = True) -> str | None:
    """What the tool gateway says before the call: tool_not_allowed (not a registered tool), invalid_arguments
    (an argument that the schema does not name, or a required one missing), or None."""
    spec = schema.get(tool["name"])
    if spec is None:
        return "tool_not_allowed"
    args = tool["arguments"] or {}
    if strict and (set(args) - set(spec["arguments"]) or any(a not in args for a in spec.get("required", []))):
        return "invalid_arguments"
    return None


def day_order(runs: list[Run], seed: int = 32) -> list[Run]:
    """The runs as one day of work, in a fixed shuffled order (the recordings ran in batches, not as a day)."""
    order = list(runs)
    random.Random(seed).shuffle(order)
    return order


def replay(runs: list[Run], s: Settings, schema: dict | None = None) -> list[Outcome]:
    """Every run, one after another, under the settings. The day's token count is shared by all runs."""
    day_tokens = 0
    out = []
    for run in runs:
        o = Outcome(run)
        seen: dict[tuple, int] = {}
        for i, step in enumerate(run.steps):
            # The model gateway checks the counts before the call, and adds the call after it.
            # TODO (Part 2): the step limit. If the run has already made s.max_calls_per_run model calls
            # (o.calls), the gateway refuses this one: set o.stopped_at = i and o.stopped_by = "run_step_limit",
            # then break. A setting of 0 means no limit.
            if s.tokens_per_day and day_tokens >= s.tokens_per_day:
                o.stopped_at, o.stopped_by = i, "quota_exhausted"
                break
            o.calls += 1
            o.cost_usd += step.cost_usd
            o.tokens += step.tokens
            day_tokens += step.tokens
            for t in step.tools:
                code = refusal(t, schema, s.strict_arguments) if schema is not None else None
                if code:
                    if t["error"]:      # the recording had an error too: the agent sees an error both times
                        o.refused_tools.append((i, t["name"], code))
                        continue
                    o.stopped_at, o.stopped_by = i, code
                    break
                key = (t["name"], digest(t["arguments"] or {}))
                # TODO (Part 2): the repeat limit. If this run already made this same call (seen[key]) as often
                # as s.repeat_limit allows, the tool gateway refuses it: set o.stopped_at = i and
                # o.stopped_by = "repeat_limit", then break. A setting of 0 means no limit.
                seen[key] = seen.get(key, 0) + 1
            if o.stopped_at is not None:
                break
        out.append(o)
    return out


def summary(outcomes: list[Outcome]) -> dict:
    """The day in numbers: what was spent, what each kind of run became."""
    def part(kind):
        g = [o for o in outcomes if o.run.ending == kind]
        return {"runs": len(g), "stopped": sum(o.stopped_at is not None for o in g),
                "cost_usd": round(sum(o.cost_usd for o in g), 4),
                "recorded_cost_usd": round(sum(o.run.cost_usd for o in g), 4)}
    total = sum(o.cost_usd for o in outcomes)
    recorded = sum(o.run.cost_usd for o in outcomes)
    by = {}
    for o in outcomes:
        if o.stopped_by:
            by[o.stopped_by] = by.get(o.stopped_by, 0) + 1
    return {"runs": len(outcomes), "cost_usd": round(total, 4), "recorded_cost_usd": round(recorded, 4),
            "saved_usd": round(recorded - total, 4), "model_calls": sum(o.calls for o in outcomes),
            "runaway": part("runaway"), "success": part("success"), "failure": part("failure"),
            "wrong_blocks": sum(o.wrong_block for o in outcomes), "stopped_by": by,
            "tool_calls_refused_as_recorded": sum(len(o.refused_tools) for o in outcomes)}
