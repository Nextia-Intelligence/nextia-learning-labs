"""Replay the recorded runs through the course's real model gateway and tool gateway.

    python -m replay.gateway --data design --max-calls-per-run 50
    python -m replay.gateway --data o4-mini --max-calls-per-run 50 --repeat-limit 13

Everything runs in this one process, as the course's measurements do: the estate's registry, identity and
configuration store (in a new temporary state folder), one gateway replica, the tool gateway, and the stand-in
provider of replay/trace_provider.py. Only the network is replaced by in-process calls; the checks are the
project's own code. The course project is found in ESTATE_PROJECT (default: the folder ai-estate next to this
one), and must be the project at the end of the course.

For every run: each recorded model call goes to the model gateway with the run's ID in X-Run-Id. If the gateway
answers, each tool call that the model asked for goes to the tool gateway. A refusal that the recording did not
have ends the run (see replay/controls.py). At the end, the result is compared with the arithmetic of
replay/controls.py: they must agree run by run.
"""

import argparse
import atexit
import json
import os
import shutil
import sys
import tempfile
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import yaml

from replay import controls, data

HERE = Path(__file__).resolve().parent.parent
AGENT = "phone-support"
DAY = datetime(2026, 11, 2, 8, 0, tzinfo=timezone.utc)   # the replayed day (the estate's clock): any working day
SECONDS_PER_CALL = 2                                       # the replayed clock moves 2 s per model call


def find_project() -> Path:
    p = Path(os.environ.get("ESTATE_PROJECT", HERE.parent / "ai-estate")).expanduser().resolve()
    if not (p / "gateway" / "app.py").exists() or not (p / "toolgate" / "app.py").exists():
        sys.exit(f"The course project is not in {p}. Set ESTATE_PROJECT to your ai-estate folder (the end of the "
                 "course, with the tool gateway).")
    return p


def make_config(project: Path, folder: Path) -> None:
    """The course's configuration, plus what this agent needs. Nothing in the course project is changed."""
    shutil.copytree(project / "config", folder)

    def edit(name, change):
        path = folder / name
        doc = yaml.safe_load(path.read_text(encoding="utf-8"))
        change(doc)
        path.write_text(yaml.safe_dump(doc, sort_keys=False, allow_unicode=True), encoding="utf-8")

    def providers(d):   # the stand-in provider, at the simulator's address
        d["providers"]["trace"] = {"base_url": "{provsim}/trace/v1", "key": None, "region": "this computer",
                                   "contract": "none: it replays recorded token counts",
                                   "data_classes": ["public", "internal", "personal"]}

    def catalog(d):     # fast-small is served by the replay, priced as the course's chat-small
        d["capabilities"]["fast-small"]["mapping"] = {"primary": {
            "provider": "trace", "deployment": "chat-small", "params_if_tools": {"reasoning_effort": "none"}}}

    def people(d):
        d["people"]["usr-ines"] = {"name": "Ines", "team": "care", "title": "platform lead"}
        d["people"]["usr-tariq"] = {"name": "Tariq", "team": "care", "title": "AI engineer"}

    def teams(d):
        d["teams"]["care"] = {"lead": "usr-ines", "budget_usd_month": 0}

    phone = yaml.safe_load((HERE / "config" / "phone-tools.yaml").read_text(encoding="utf-8"))

    def tools(d):
        d["servers"] = {"phone": {"about": phone["about"], "command": ["none"],
                                  "tools": {n: {"kind": t["kind"]} for n, t in phone["tools"].items()}}}

    def policy(d):      # the agent acts on its own (medium risk): its writes need no approval
        writes = [f"phone.{n}" for n, t in phone["tools"].items() if t["kind"] == "write"]
        d["rules"].insert(0, {"id": "phone-writes", "match": {"tool": writes}, "approve_by": "none"})

    edit("providers.yaml", providers)
    edit("catalog.yaml", catalog)
    edit("people.yaml", people)
    edit("teams.yaml", teams)
    edit("tools.yaml", tools)
    edit("policy/approvals.yaml", policy)


def schemas() -> dict:
    """The JSON schemas that the stand-in tool server publishes (config/phone-tools.yaml)."""
    phone = yaml.safe_load((HERE / "config" / "phone-tools.yaml").read_text(encoding="utf-8"))
    return {n: {"type": "object", "properties": {a: {"type": ty} for a, ty in t["arguments"].items()},
                "required": t.get("required", [])} for n, t in phone["tools"].items()}


class ReplayedServer:
    """Stands in for the phone company's tool server behind the tool gateway: it answers each call as the
    recording did (an error where the recording had one), without running anything."""

    def __init__(self, runs):
        self.tools = schemas()
        self.errors = {(r.id, i, k): t["error"] for r in runs for i, s in enumerate(r.steps)
                       for k, t in enumerate(s.tools)}

    async def call(self, tool, arguments, meta):
        ctx = next(iter(meta.values()))
        error = self.errors[(ctx["run"], ctx["step"], ctx["k"])]
        return (not error), {"replayed": True, "error": error}


_CONFIG: list = []


def prepare(project: Path) -> None:
    """Once per process: the configuration folder (the estate reads ESTATE_CONFIG when it is first imported)."""
    if _CONFIG:
        return
    folder = Path(tempfile.mkdtemp(prefix="runaway-replay-config-"))
    atexit.register(shutil.rmtree, folder, True)
    make_config(project, folder / "config")
    os.environ.update(ESTATE_CONFIG=str(folder / "config"), ESTATE_REGISTRATIONS=str(HERE / "registrations"),
                      ESTATE_PUSH="off")
    sys.path.insert(0, str(project))
    _CONFIG.append(folder)


def run(name: str, settings: controls.Settings, first: int = 0) -> dict:
    """Replay the day (or only its first `first` runs) through the gateways."""
    project = find_project()
    prepare(project)
    tmp = Path(tempfile.mkdtemp(prefix="runaway-replay-"))
    os.environ["ESTATE_STATE"] = str(tmp / "state")
    import httpx
    from starlette.testclient import TestClient

    from estate import clock, configstore, identity, registry
    from estate.usage import UsageStore
    from gateway.app import create_app as gateway_app
    from gateway.config import ConfigCache
    from replay.repeat_rule import RepeatLimit
    from replay.trace_provider import create_app as trace_app
    from toolgate.app import create_app as toolgate_app

    info, runs = data.load(name)
    runs = controls.day_order(runs)
    if first:
        runs = runs[:first]
    clock.set_replay_time(DAY - timedelta(hours=1))
    form = registry.read_form(HERE / "registrations" / f"{AGENT}.yaml")
    form["limits"] = {"requests_per_minute": 0, "tokens_per_day": settings.tokens_per_day,
                      "max_calls_per_run": settings.max_calls_per_run}
    registry.register(form, "usr-ines")
    secret = identity.issue_credentials(AGENT, "usr-ines")[1]
    configstore.publish("usr-ines", f"replay {name}: {settings.label()}")

    calls = {(r.id, i): (s.prompt_tokens, s.completion_tokens) for r in runs for i, s in enumerate(r.steps)}
    store = UsageStore()
    model_cache = ConfigCache("a", clock=lambda: 0.0)
    tool_cache = ConfigCache("tools", clock=lambda: 0.0)
    model_cache.set(configstore.snapshot("a"))
    tool_cache.set(configstore.snapshot("tools"))
    provider = trace_app(calls, f"{info['agent_llm']} (replayed)")
    gw = TestClient(gateway_app("a", cache=model_cache, store=store, secrets={},
                                transport=httpx.ASGITransport(app=provider), provsim_url="http://sim"))
    tg_app = toolgate_app(cache=tool_cache, store=store,
                          servers=yaml.safe_load((Path(os.environ["ESTATE_CONFIG"]) / "tools.yaml").read_text())["servers"],
                          start_backends=False)
    tg_app.state.tg.backends["phone"] = ReplayedServer(runs)
    tg = TestClient(RepeatLimit(tg_app, store, settings.repeat_limit))

    tokens = {}

    def token(audience):
        tok, exp = tokens.get(audience, ("", 0))
        if exp < clock.now().timestamp() + 60:
            t = identity.token(AGENT, secret, audience)
            tok, exp = t["access_token"], clock.now().timestamp() + t["expires_in"]
            tokens[audience] = (tok, exp)
        return {"authorization": "Bearer " + tok}

    started = time.monotonic()
    t = DAY
    out, first_seen = [], {}
    with gw, tg:
        for run_ in runs:
            o = controls.Outcome(run_)
            for i, step in enumerate(run_.steps):
                clock.set_replay_time(t)
                t += timedelta(seconds=SECONDS_PER_CALL)
                body = {"model": "fast-small", "messages": [{"role": "user", "content": "(replayed call)"}],
                        "metadata": {"run": run_.id, "step": i}}
                r = gw.post("/v1/chat/completions", json=body,
                            headers={**token("model-gateway"), "x-run-id": run_.id})
                if r.status_code != 200:
                    err = r.json()["error"]
                    o.stopped_at, o.stopped_by = i, err["code"]
                    first_seen.setdefault(err["code"], f"{r.status_code} {err['message']}")
                    break
                o.calls += 1
                o.cost_usd += float(r.headers["x-gateway-cost-usd"])
                o.tokens += step.tokens
                for k, tc in enumerate(step.tools):
                    r = tg.post("/v1/tools/call", headers=token("tool-gateway"), json={
                        "tool": f"phone.{tc['name']}", "arguments": tc["arguments"] or {}, "run_id": run_.id,
                        "context": {"run": run_.id, "step": i, "k": k}})
                    if r.status_code == 200:
                        continue
                    err = r.json()["error"]
                    if tc["error"] and err["code"] in ("invalid_arguments", "tool_not_allowed"):
                        o.refused_tools.append((i, tc["name"], err["code"]))
                        first_seen.setdefault(f"{err['code']} (the recording had an error too)",
                                              f"{r.status_code} {err['message']}")
                        continue
                    o.stopped_at, o.stopped_by = i, err["code"]
                    first_seen.setdefault(err["code"], f"{r.status_code} {err['message']}")
                    break
                if o.stopped_at is not None:
                    break
            out.append(o)
    seconds = time.monotonic() - started
    model_rows = store.rows("select outcome, check_name, count(*) as n, round(sum(cost_usd), 4) as usd "
                            "from model_calls group by outcome, check_name")
    tool_rows = store.rows("select outcome, check_name, count(*) as n from tool_calls group by outcome, check_name")
    shutil.rmtree(tmp, ignore_errors=True)
    s = controls.summary(out)
    expected = controls.replay(runs, settings, schemas_for_controls())
    same = [(a.stopped_at, a.stopped_by, a.calls) for a in out] == [(b.stopped_at, b.stopped_by, b.calls)
                                                                     for b in expected]
    return {"data": name, "agent_llm": info["agent_llm"], "settings": settings.label(), "summary": s,
            "first_refusal": first_seen, "usage_store": {"model_calls": model_rows, "tool_calls": tool_rows},
            "matches_the_arithmetic": same, "seconds": round(seconds, 1)}


def schemas_for_controls() -> dict:
    return yaml.safe_load((HERE / "config" / "phone-tools.yaml").read_text(encoding="utf-8"))["tools"]


def report(res: dict) -> str:
    s = res["summary"]
    lines = [f"{res['data']} ({res['agent_llm']}): {s['runs']} runs through the gateways | {res['settings']}",
             f"model calls answered {s['model_calls']:,} | cost US${s['cost_usd']:.2f} "
             f"(recorded runs to their end: US${s['recorded_cost_usd']:.2f}, saved US${s['saved_usd']:.2f})"]
    for kind in ("runaway", "success", "failure"):
        p = s[kind]
        lines.append(f"  {kind:<8} {p['runs']:>4} runs, {p['stopped']:>3} stopped | US${p['cost_usd']:.2f} "
                     f"of US${p['recorded_cost_usd']:.2f}")
    lines.append(f"successful runs stopped (wrong blocks): {s['wrong_blocks']}")
    for code, msg in res["first_refusal"].items():
        lines.append(f"first {code}: {msg}")
    lines.append(f"same result as the arithmetic (replay/controls.py): {'yes' if res['matches_the_arithmetic'] else 'NO'}"
                 f" | {res['seconds']} s")
    return "\n".join(lines)


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--data", default="design", choices=list(data.FILES))
    ap.add_argument("--max-calls-per-run", type=int, default=0)
    ap.add_argument("--tokens-per-day", type=int, default=0)
    ap.add_argument("--repeat-limit", type=int, default=0)
    ap.add_argument("--json", help="also write the result to this file")
    a = ap.parse_args(argv)
    res = run(a.data, controls.Settings(a.max_calls_per_run, a.tokens_per_day, a.repeat_limit))
    print(report(res))
    if a.json:
        Path(a.json).parent.mkdir(parents=True, exist_ok=True)
        Path(a.json).write_text(json.dumps(res, indent=1, default=str) + "\n")


if __name__ == "__main__":
    main()
