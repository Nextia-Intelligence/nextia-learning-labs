# Recommendation: the catalog after o3 retires

To: Hollin's app owners (Joel, Ada, Lena) and finance (Ben). From: Noor, platform.

## The decision

Serve `fast-small` from **gpt-5.6-luna at reasoning_effort low** on OpenAI, with the same model and setting on Azure OpenAI as the fallback. Serve `strong-reasoning` from **gemini-3.8-flash at reasoning_effort high** on Vertex AI, with gpt-5-2025-08-07 at high on Azure OpenAI as the fallback. Every app asks for a capability from now on, and nobody calls o3 straight again.

## The evidence

`python -m pubcat compare` (public scores from Epoch AI, list prices from LiteLLM's price file):

| Approach | Broken rules | US$ a month |
|---|---|---|
| 1. keep today's model (o3) | 4: it retires on 2026-12-11, inside the 60-day window; it is above the fast-small price band | 174.00 |
| 2. top of a leaderboard (gemini-4-argon, high) | 3: fast-small's price band and setting | 192.00 |
| 3. cheapest that keeps the contract | 1: the research assistant is below its minimum | 16.95 |
| 4. cheapest that passes every consumer | 0 | 34.70 |

The gate decided `strong-reasoning`. The cheapest model that keeps the contract, gpt-5-nano at high, scores 0.117 on SimpleQA Verified against the research assistant's minimum of 0.46. gpt-6-luna at max passes the billing agent (0.989 against 0.75) but not the research assistant (0.414): the average of the two scores, 0.701, is above the average minimum, 0.605, and the gate still blocks. gemini-3.8-flash at high passes both: 0.989 and 0.697.

## What it costs

About US$34.70 a month at list prices for the owners' estimated workloads, against US$174.00 on o3. The estimate counts tokens at a price per token. It does not count the extra output tokens of a higher setting, so the strong-reasoning cost is a floor, not a forecast.

## What the public data cannot tell us

- **Our own tasks.** GPQA Diamond, OTIS Mock AIME and SimpleQA Verified are public screens. None of them is a bill question, a payment plan or an engineer's question. Each owner runs a sample of their own work on the new mapping before it goes live.
- **The features at our settings.** The price file lists function calling for every candidate. It does not say which settings it needs. Ada's billing agent makes one real tool call on each new target before the change.
- **The cost per task.** Public results give no token counts. We measure the tokens of the first week and update the estimate.
- **The prices and dates.** They are LiteLLM's at commit 159b5b2: an assumption. Finance checks them on each provider's page before we sign anything.

## The next review

- The strong-reasoning fallback, gpt-5-2025-08-07 on Azure, retires on 2027-02-09 by the price file: replace it before 2026-12-11 (60 days before).
- If gpt-5.6-luna retired, fast-small would move to gemini-3.1-flash-lite at low, with no fallback and a margin of 0.002 over the minimum, inside one standard error. That is not enough evidence: before that day, Joel runs his own evaluation on two or three candidates.
- Run `python data/fetch.py` and `choose` again every month, and when a provider announces a retirement.
