"""The command line: python -m pubcat <command>. Run `python -m pubcat --help` for the list."""

import argparse
import copy
import difflib
import sys
from pathlib import Path

import yaml

from pubcat import catalog, choose, gate, public

FROZEN = public.DATA


def cmd_data(a) -> int:
    problems = public.check_files(a.data)
    if problems:
        print("\n".join(problems))
        print("Some data files are missing or changed. Download the project again, or run python data/fetch.py.")
        return 1
    print(f"Checksums: {len(public.read_sums(a.data))} files match SHA256SUMS")
    scores, _ = public.load_epoch(a.data / "epoch")
    for bench, table in scores.items():
        rows = sum(len(t) for t in table.values())
        print(f"  {bench:<26} {rows:>4} results, {len(table):>4} models")
    _, summary = public.load_models(a.data / "epoch", a.data / "litellm" / "model_prices_and_context_window.json",
                                    catalog.load_providers())
    print(f"Models with a public score: {summary['models_with_scores']}; with an offer at one of our providers: "
          f"{summary['with_an_offer']}; without: {summary['without_an_offer']}")
    if summary["free_offers"]:
        print(f"Offers with a price of 0 (check them): {', '.join(summary['free_offers'])}")
    return 0


def cmd_models(a) -> int:
    content, summary = catalog.build_models_yaml(a.data / "epoch",
                                                 a.data / "litellm" / "model_prices_and_context_window.json")
    path = catalog.write_models_yaml(content, a.models)
    offers = sum(len(m["offers"]) for m in content["models"].values())
    print(f"Wrote {path.relative_to(public.PROJECT) if path.is_relative_to(public.PROJECT) else path}: "
          f"{len(content['models'])} models, {offers} offers")
    print(f"Left out: {summary['without_an_offer']} models with a public score but no offer at our providers")
    return 0


def cmd_show(a) -> int:
    models = catalog.load_models(a.models)
    m = models.get(a.model)
    if m is None:
        print(f"No model {a.model} in config/models.yaml")
        return 1
    print(f"Model: {a.model} ({m['organization']})")
    for bench, table in m["scores"].items():
        se = m.get("stderr", {}).get(bench, {})
        order = sorted(table, key=lambda s: (public.EFFORTS.index(s) if s in public.EFFORTS else len(public.EFFORTS), s))
        cells = ", ".join(f"{s} {table[s]:.3f}" + (f" ±{se[s]:.3f}" if s in se else "") for s in order)
        print(f"  {bench:<26} {cells}")
    for p, o in m["offers"].items():
        print(f"  offer {p:<9} US${o['price']['input']} in / US${o['price']['output']} out per 1M tokens; "
              f"{', '.join(o['features'])}; retires {o['retires'] or 'no date in the price file'}")
    return 0


def context(a):
    return (catalog.load_catalog(a.file), catalog.load_models(a.models), catalog.load_providers(),
            catalog.load_consumers(), a.today, set(a.retire or []))


def cmd_check(a) -> int:
    cat, models, providers, _, today, retired = context(a)
    problems = catalog.check(cat, models, providers, today, retired)
    if problems:
        print("\n".join(problems))
        return 1
    print("The catalog is consistent: every mapping keeps its contract.")
    return 0


def cmd_candidates(a) -> int:
    cat, models, providers, consumers, today, retired = context(a)
    all_rows = choose.rows(a.capability, models, providers, consumers, cat, today, retired)
    kept = sum(r.keeps_contract for r in all_rows)
    print(f"{a.capability}: {len(all_rows)} targets, {kept} keep the contract, "
          f"{sum(r.passes for r in all_rows)} also pass every consumer. Cheapest first:")
    print(choose.table(all_rows, a.limit, only_contract=not a.all))
    return 0


def parse_to(text: str, params: list[str]) -> catalog.Target:
    provider, _, model = text.partition("/")
    p = {}
    for kv in params or []:
        k, _, v = kv.partition("=")
        p[k] = int(v) if v.isdigit() else v
    return catalog.Target(provider, model, tuple(sorted(p.items())))


def cmd_gate(a) -> int:
    cat, models, _, consumers, _, _ = context(a)
    r = gate.gate(a.capability, parse_to(a.to, a.param), models, consumers, cat)
    print(gate.render(r))
    return 0 if r["decision"] == "pass" else 1


def cmd_choose(a) -> int:
    cat, models, providers, consumers, today, retired = context(a)
    new = copy.deepcopy(cat)
    if retired:
        print(f"What-if: {', '.join(sorted(retired))} retired today ({today}).\n")
    for name in cat["capabilities"]:
        res = choose.choose(name, models, providers, consumers, cat, today, retired)
        print(choose.render_choice(res))
        print()
        proposed = choose.mapping_of(res)
        if proposed != cat["capabilities"][name].get("mapping"):
            new["capabilities"][name]["previous_mapping"] = cat["capabilities"][name].get("mapping")
        new["capabilities"][name]["mapping"] = proposed
    before = yaml.safe_dump({n: c.get("mapping") for n, c in cat["capabilities"].items()}, sort_keys=False)
    after = yaml.safe_dump({n: c.get("mapping") for n, c in new["capabilities"].items()}, sort_keys=False)
    diff = list(difflib.unified_diff(before.splitlines(), after.splitlines(), "mapping today", "proposed", lineterm=""))
    print("\n".join(diff) if diff else "The proposed mapping is the same as today's.")
    if a.write:
        path = Path(a.file) if a.file else catalog.CONFIG / "catalog.yaml"
        text = path.read_text(encoding="utf-8")
        head = text[: text.index("version:")] if "version:" in text else ""
        head = "".join(line for line in head.splitlines(keepends=True) if "TODAY" not in line)
        head += ("# The mapping below was proposed by `python -m pubcat choose` from the public data;\n"
                 "# previous_mapping is the one it replaced (the record of the change).\n")
        path.write_text(head + yaml.safe_dump(new, sort_keys=False, width=130, default_flow_style=None),
                        encoding="utf-8")
        print(f"\nWrote the proposed mapping to {path.name}. Run python -m pubcat check.")
    return 0


def leaderboard_pick(capability: str, models: dict, providers: dict) -> catalog.Target | None:
    """'Take the top of a leaderboard': the highest average of the three public scores at one setting,
    at any of our providers, whatever the price, the setting or the contract."""
    best, best_avg = None, -1.0
    for t in choose.all_targets(models):
        if t.provider not in providers:
            continue
        s = [catalog.score(models, t, b) for b in public.BENCHMARKS]
        if None in s:
            continue
        avg = sum(s) / len(s)
        cost = catalog.offer(models, t)["price"]["input"]
        if avg > best_avg or (avg == best_avg and best is not None and cost < catalog.offer(models, best)["price"]["input"]):
            best, best_avg = t, avg
    return best


def cmd_compare(a) -> int:
    cat, models, providers, consumers, today, retired = context(a)
    names = list(cat["capabilities"])
    def before(n):   # the mapping before `choose --write` changed it, if it did
        cap = cat["capabilities"][n]
        return catalog.Target.of((cap.get("previous_mapping") or cap["mapping"])["primary"])

    approaches = {"1. keep today's model": {n: before(n) for n in names},
                  "2. top of a leaderboard": {n: leaderboard_pick(n, models, providers) for n in names}}
    cheapest, gated = {}, {}
    for n in names:
        res = choose.choose(n, models, providers, consumers, cat, today, retired)
        cheapest[n] = res["cheapest_keeping_contract"].target if res["cheapest_keeping_contract"] else None
        gated[n] = res["primary"].target if res["primary"] else None
    approaches["3. cheapest that keeps the contract"] = cheapest
    approaches["4. cheapest that passes every consumer"] = gated
    print(f"{'approach':<40} {'broken rules':>12} {'US$/month':>10}")
    for label, mapping in approaches.items():
        broken, cost, notes = 0, 0.0, []
        for n, t in mapping.items():
            if t is None:
                broken += 1
                notes.append(f"{n}: nothing")
                continue
            contract = cat["capabilities"][n]["contract"]
            chk = catalog.check_target(n, contract, t, models, providers, today, retired)
            g = gate.gate(n, t, models, gate.consumers_of(n, consumers), cat)
            fails = [c["consumer"] for c in g["consumers"] if c["verdict"] != "pass"]
            broken += len(chk.problems) + len(fails)
            cost += catalog.monthly_cost(models, t, gate.consumers_of(n, consumers)) or 0
            why = sorted(set(chk.kinds)) + [f"{f} below its minimum" for f in fails]
            notes.append(f"{n}: {t.label()}" + (f" - {'; '.join(why)}" if why else " - keeps every rule"))
        print(f"{label:<40} {broken:>12} {cost:>10.2f}")
        for note in notes:
            print(f"    {note}")
    print("\nUS$/month: the consumers' assumed workloads at list prices per token (more output tokens at a "
          "higher setting are not counted).")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m pubcat", description="A capability catalog from public evaluation results.")
    ap.add_argument("--data", type=Path, default=FROZEN, help="the data folder (default: data/, the frozen copy)")
    ap.add_argument("--models", type=Path, default=None, help="another models file (default: config/models.yaml)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("data", help="check the data files and count what they hold").set_defaults(fn=cmd_data)
    sub.add_parser("models", help="build config/models.yaml from the public data").set_defaults(fn=cmd_models)
    p = sub.add_parser("show", help="the public evidence for one model")
    p.add_argument("model")
    p.set_defaults(fn=cmd_show)

    def common(p):
        p.add_argument("--file", help="another catalog file (default: config/catalog.yaml)")
        p.add_argument("--today", default=catalog.today_default(), help="the day to check retirement dates against")
        p.add_argument("--retire", action="append", metavar="MODEL", help="what-if: this model is retired today")

    p = sub.add_parser("check", help="check every mapping against its contract")
    common(p)
    p.set_defaults(fn=cmd_check)
    p = sub.add_parser("candidates", help="every target for one capability, cheapest first")
    p.add_argument("capability")
    p.add_argument("--limit", type=int, default=12)
    p.add_argument("--all", action="store_true", help="also targets that break the contract")
    common(p)
    p.set_defaults(fn=cmd_candidates)
    p = sub.add_parser("gate", help="the remap gate: does every consumer pass on this candidate?")
    p.add_argument("capability")
    p.add_argument("--to", required=True, help="provider/model, for example openai/gpt-6-luna")
    p.add_argument("--param", action="append", help="a setting, for example reasoning_effort=max")
    common(p)
    p.set_defaults(fn=cmd_gate)
    p = sub.add_parser("choose", help="propose a mapping for every capability")
    p.add_argument("--write", action="store_true", help="write the proposed mapping into the catalog file")
    common(p)
    p.set_defaults(fn=cmd_choose)
    p = sub.add_parser("compare", help="four ways to choose, under one measure")
    common(p)
    p.set_defaults(fn=cmd_compare)
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
