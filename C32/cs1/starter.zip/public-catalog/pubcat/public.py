"""Read the two public sources and join them: who scored what, and what it costs where.

- Epoch AI's benchmark results (CC BY 4.0): one CSV per benchmark, one row per model version and setting.
  A model version such as "gpt-5.6-luna_low" is the model "gpt-5.6-luna" run with the setting "low".
- LiteLLM's price file (MIT): one entry per model and provider, with the price per token, the features
  the provider lists, and sometimes a deprecation date (the day the provider retires the model).

Both are data that other people publish. The functions here read them and check them; they never change
the files.
"""

import csv
import hashlib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT / "data"

# The benchmarks this project reads, by file name (Epoch AI's names).
BENCHMARKS = {
    "gpqa_diamond": "GPQA Diamond",
    "otis_mock_aime_2024_2025": "OTIS Mock AIME 2024-2025",
    "simpleqa_verified": "SimpleQA Verified",
}

# The settings that Epoch AI writes after the model name. An effort ("low", "max" ...) is a reasoning_effort;
# a number of thousands ("32K") is a thinking budget in tokens. No suffix: the provider's default.
EFFORTS = ["none", "minimal", "low", "medium", "high", "xhigh", "max"]
SUFFIX = re.compile(r"^(?P<model>.+?)_(?P<setting>none|minimal|low|medium|high|xhigh|max|unknown|\d+K)$")


@dataclass(frozen=True)
class Score:
    value: float
    stderr: float | None


@dataclass
class Offer:
    """One provider's offer of one model: its price per 1M tokens, its features and its retirement date."""
    provider: str
    key: str                  # the entry's name in the price file
    price_in: float
    price_out: float
    features: list[str]
    retires: str | None       # YYYY-MM-DD, or None when the price file gives no date


@dataclass
class Model:
    name: str
    organization: str = ""
    scores: dict = field(default_factory=dict)      # benchmark -> setting -> Score
    offers: dict = field(default_factory=dict)      # provider -> Offer


def split_version(version: str) -> tuple[str, str]:
    """'gpt-5.6-luna_low' -> ('gpt-5.6-luna', 'low'); 'o3-2025-04-16' -> ('o3-2025-04-16', 'default')."""
    m = SUFFIX.match(version)
    return (m["model"], m["setting"]) if m else (version, "default")


def params_for(setting: str) -> dict:
    """The request settings that a mapping must send to get the scores of this setting."""
    if setting in EFFORTS:
        return {"reasoning_effort": setting}
    if setting.endswith("K"):
        return {"thinking_budget_tokens": int(setting[:-1]) * 1000}
    return {}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_sums(folder: Path) -> dict:
    out = {}
    for line in (folder / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        if line.strip():
            digest, name = line.split(maxsplit=1)
            out[name.strip()] = digest
    return out


def check_files(folder: Path = DATA) -> list[str]:
    """Every file in SHA256SUMS must be there with the same checksum. Returns the problems (empty: all good)."""
    problems = []
    for name, digest in read_sums(folder).items():
        path = folder / name
        if not path.exists():
            problems.append(f"{name}: missing")
        elif sha256(path) != digest:
            problems.append(f"{name}: wrong checksum (the file changed)")
    return problems


def load_epoch(folder: Path) -> tuple[dict, dict]:
    """Benchmark -> model -> setting -> Score, and model -> organization. Rows without a score are skipped."""
    scores, orgs = {}, {}
    for bench in BENCHMARKS:
        table = {}
        with open(folder / f"{bench}.csv", newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if not row["mean_score"]:
                    continue
                model, setting = split_version(row["Model version"])
                se = float(row["stderr"]) if row.get("stderr") else None
                table.setdefault(model, {})[setting] = Score(float(row["mean_score"]), se)
                orgs.setdefault(model, row["Organization"])
        scores[bench] = table
    return scores, orgs


def provider_of(key: str, entry: dict, providers: dict) -> str | None:
    """Which of OUR providers (config/providers.yaml) this price-file entry belongs to, or None.
    Entries for a region or data zone ('azure/eu/...') are left out: the global entry counts."""
    for name, p in providers.items():
        if entry.get("litellm_provider") in p["price_file_names"]:
            parts = key.split("/")
            if len(parts) > 2 or (len(parts) == 2 and parts[0] not in p.get("prefixes", [])):
                return None
            return name
    return None


def features_of(entry: dict) -> list[str]:
    feats = ["chat"] if entry.get("mode") == "chat" else []
    for flag, feature in [("supports_response_schema", "structured_output"),
                          ("supports_function_calling", "tools"), ("supports_vision", "images")]:
        if entry.get(flag):
            feats.append(feature)
    return feats


def load_offers(path: Path, providers: dict) -> dict:
    """Model name -> provider -> Offer, for chat models of our providers that have a price.
    When one provider has several entries for one model (for example two Vertex AI names), the earliest
    retirement date and the highest price count: the cautious choice."""
    raw = json.loads(path.read_text(encoding="utf-8"))
    out: dict = {}
    for key, entry in raw.items():
        if not isinstance(entry, dict) or entry.get("mode") != "chat" or entry.get("input_cost_per_token") is None:
            continue
        prov = provider_of(key, entry, providers)
        if prov is None:
            continue
        model = key.split("/")[-1].removesuffix("@default")
        offer = Offer(prov, key, round(entry["input_cost_per_token"] * 1e6, 4),
                      round((entry.get("output_cost_per_token") or 0) * 1e6, 4), features_of(entry),
                      entry.get("deprecation_date"))
        old = out.setdefault(model, {}).get(prov)
        if old:
            dates = [d for d in (old.retires, offer.retires) if d]
            offer = Offer(prov, old.key, max(old.price_in, offer.price_in), max(old.price_out, offer.price_out),
                          [f for f in old.features if f in offer.features], min(dates) if dates else None)
        out[model][prov] = offer
    return out


def load_models(epoch: Path, prices: Path, providers: dict) -> tuple[dict, dict]:
    """Join the two sources by model name. Returns the joined models and a summary of the join."""
    scores, orgs = load_epoch(epoch)
    offers = load_offers(prices, providers)
    names = set().union(*(t.keys() for t in scores.values()))
    models = {}
    for name in sorted(names):
        m = Model(name, orgs.get(name, ""))
        for bench, table in scores.items():
            if name in table:
                m.scores[bench] = table[name]
        m.offers = offers.get(name, {})
        models[name] = m
    joined = {n: m for n, m in models.items() if m.offers}
    summary = {"models_with_scores": len(models), "with_an_offer": len(joined),
               "without_an_offer": len(models) - len(joined),
               "free_offers": sorted(n for n, m in joined.items()
                                     if any(o.price_in == 0 and o.price_out == 0 for o in m.offers.values()))}
    return joined, summary
