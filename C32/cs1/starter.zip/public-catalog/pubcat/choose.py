"""Choose a mapping for a capability from public evidence, with the same rules every time.

    python -m pubcat candidates strong-reasoning      every target, with each rule's result
    python -m pubcat choose                           the proposed mapping of every capability
    python -m pubcat choose --retire gpt-5.6-luna     the same, if that model were retired today (what-if)

A TARGET is a model at a provider with a setting: openai/gpt-5.6-luna with reasoning_effort low. For each
capability, the chooser keeps the targets that keep the contract (check_target) AND pass every consumer's
gate, and picks the cheapest for the consumers' assumed workloads. Ties go to the target with the largest
smallest margin over the consumers' minimums (the one furthest from failing), then to the provider that the
capability uses today (the smallest change), then to the name.

The fallback is the same model and setting at another of our providers, if one passes too. Otherwise it is
the next target at another provider that passes every rule and every consumer: a different model, so a
fallback to it is a remap, allowed only because every consumer's gate passed (the course's rule).
"""

from dataclasses import dataclass

from pubcat import catalog, gate, public

# The order of the funnel: each step keeps the targets that passed every step before it.
FUNNEL = [("stable", "is not a preview model"), ("features", "has the contract's features"), ("settings", "uses an allowed setting"),
          ("price", "inside the price band"), ("data", "the provider may receive the data"),
          ("retire", "does not retire inside the review window"), ("floor", "reaches the contract's floor"),
          ("consumers", "every consumer passes its own minimum")]


@dataclass
class Row:
    target: catalog.Target
    check: catalog.TargetCheck
    gate: dict
    cost: float | None

    @property
    def keeps_contract(self) -> bool:
        return not self.check.problems

    @property
    def passes(self) -> bool:
        return self.keeps_contract and self.gate["decision"] == "pass"

    @property
    def margin(self) -> float:
        """The smallest score minus minimum over the consumers; -inf if one has no evidence."""
        rows = self.gate["consumers"]
        if not rows or any(c.get("score") is None for c in rows):
            return float("-inf")
        return min(c["score"] - c["minimum"] for c in rows)

    def sort_key(self, provider_today: str = ""):
        return (self.cost if self.cost is not None else float("inf"), -self.margin,
                self.target.provider != provider_today, self.target.label())


def all_targets(models: dict) -> list[catalog.Target]:
    """Every model at every provider that offers it, with every setting that has at least one public score."""
    out = []
    for name, m in models.items():
        settings = sorted({s for table in (m.get("scores") or {}).values() for s in table})
        for provider in m.get("offers") or {}:
            for s in settings:
                out.append(catalog.Target(provider, name, tuple(sorted(public.params_for(s).items()))))
    return out


def rows(capability: str, models: dict, providers: dict, consumers: list[dict], cat: dict, today: str,
         retired: set | None = None) -> list[Row]:
    contract = cat["capabilities"][capability]["contract"]
    users = gate.consumers_of(capability, consumers)
    out = []
    for t in all_targets(models):
        chk = catalog.check_target(capability, contract, t, models, providers, today, retired)
        g = gate.gate(capability, t, models, users, cat)
        out.append(Row(t, chk, g, catalog.monthly_cost(models, t, users)))
    mapping = cat["capabilities"][capability].get("mapping")
    today_provider = mapping["primary"]["provider"] if mapping else ""
    return sorted(out, key=lambda r: r.sort_key(today_provider))


def funnel(all_rows: list[Row]) -> list[tuple[str, int]]:
    """How many targets are left after each rule, in the order of FUNNEL."""
    left = list(all_rows)
    out = [("all targets (model x provider x setting)", len(left))]
    for kind, text in FUNNEL:
        if kind == "consumers":
            left = [r for r in left if r.gate["decision"] == "pass"]
        else:
            left = [r for r in left if kind not in r.check.kinds]
        out.append((text, len(left)))
    return out


def choose(capability: str, models: dict, providers: dict, consumers: list[dict], cat: dict, today: str,
           retired: set | None = None) -> dict:
    all_rows = rows(capability, models, providers, consumers, cat, today, retired)
    passing = [r for r in all_rows if r.passes]
    result = {"capability": capability, "funnel": funnel(all_rows), "primary": None, "fallback": None,
              "fallback_kind": None, "cheapest_keeping_contract": next((r for r in all_rows if r.keeps_contract), None),
              "passing": passing}
    if not passing:
        return result
    primary = passing[0]
    result["primary"] = primary
    same = [r for r in passing if r.target.deployment == primary.target.deployment
            and r.target.params == primary.target.params and r.target.provider != primary.target.provider]
    other = [r for r in passing if r.target.provider != primary.target.provider]
    if same:
        result.update(fallback=same[0], fallback_kind="the same model and setting at another provider")
    elif other:
        result.update(fallback=other[0], fallback_kind="a different model: every consumer passed its gate")
    return result


def mapping_of(result: dict) -> dict | None:
    if not result["primary"]:
        return None
    return {"primary": result["primary"].target.entry(),
            "fallbacks": [result["fallback"].target.entry()] if result["fallback"] else []}


def render_choice(result: dict) -> str:
    name = result["capability"]
    lines = [f"{name}:"]
    width = max(len(t) for t, _ in result["funnel"])
    for text, n in result["funnel"]:
        lines.append(f"  {text:<{width}}  {n:>4}")
    c = result["cheapest_keeping_contract"]
    if c is not None and not c.passes:
        bad = [x["consumer"] for x in c.gate["consumers"] if x["verdict"] != "pass"]
        lines.append(f"  cheapest that keeps the contract: {c.target.label()}, US${c.cost:.2f} a month"
                     f" - blocked by the gate ({', '.join(bad)})")
    p = result["primary"]
    if p is None:
        lines.append("  proposed mapping: NOTHING - no target keeps the contract and passes every consumer")
        return "\n".join(lines)
    lines.append(f"  proposed primary:  {p.target.label()}, US${p.cost:.2f} a month, smallest margin {p.margin:+.3f}")
    f = result["fallback"]
    lines.append(f"  proposed fallback: {f.target.label()} ({result['fallback_kind']})" if f
                 else "  proposed fallback: none - no other provider passes")
    return "\n".join(lines)


def table(all_rows: list[Row], limit: int = 12, only_contract: bool = True) -> str:
    """The candidates as a table: cost, the contract's floor score, each consumer's verdict."""
    shown = [r for r in all_rows if r.keeps_contract or not only_contract][:limit]
    if not shown:
        return "  (no target keeps the contract)"
    users = [c["consumer"] for c in shown[0].gate["consumers"]]
    head = f"  {'target':<62} {'US$/month':>9}  " + "  ".join(f"{u:<20}" for u in users)
    lines = [head]
    for r in shown:
        cells = []
        for c in r.gate["consumers"]:
            cells.append(f"{c['verdict']:<4} {c['score']:.3f}".ljust(20) if c.get("score") is not None
                         else "no evidence".ljust(20))
        lines.append(f"  {r.target.label():<62} {r.cost:>9.2f}  " + "  ".join(cells))
    return "\n".join(lines)
