"""The capability catalog, the models file and the consumers, in the format of the course's catalog.

config/catalog.yaml     capability -> contract (what it promises) and mapping (what serves it)
config/models.yaml      what each model can do and what it costs where: built from public data by
                        `python -m pubcat models`, so a person can read and review the evidence
config/providers.yaml   the providers Hollin may call, with the data classes each contract allows
config/consumers/*.yaml the apps that ask for each capability, with their own evaluation and minimum

`check()` finds every way a mapping breaks its contract, as `estate catalog check` does in the course,
with two more rules that public data makes possible: the score at the mapped setting must reach the
contract's floor, and the model must not retire inside the review window.
"""

import datetime as dt
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from pubcat import public

CONFIG = public.PROJECT / "config"
REVIEW_WINDOW_DAYS = 60     # the course's review window: a model that retires within 60 days needs a plan now
PRICE_LABEL = ("assumption: LiteLLM's price file at commit 159b5b2 (2026-10-21), list prices in US$ per 1M "
               "tokens; prices change: check the provider's current price page")


def load_yaml(path: Path) -> dict:
    return yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}


def load_catalog(path: Path | None = None) -> dict:
    return load_yaml(path or CONFIG / "catalog.yaml")


def load_providers() -> dict:
    return load_yaml(CONFIG / "providers.yaml")["providers"]


def load_models(path: Path | None = None) -> dict:
    return load_yaml(path or CONFIG / "models.yaml")["models"]


def load_consumers(folder: Path | None = None) -> list[dict]:
    return [load_yaml(p) for p in sorted((folder or CONFIG / "consumers").glob("*.yaml"))]


def today_default() -> str:
    """The day of the frozen data. Pass --today to check another day."""
    return "2026-10-22"


# ----- models.yaml from the public data -----

def build_models_yaml(epoch: Path, prices: Path) -> tuple[dict, dict]:
    """The content of config/models.yaml: one entry per model that has a public score AND an offer at one of
    our providers. Scores are by benchmark and setting; offers are by provider."""
    joined, summary = public.load_models(epoch, prices, load_providers())
    models = {}
    for name, m in joined.items():
        models[name] = {
            "organization": m.organization,
            "scores": {b: {s: round(sc.value, 4) for s, sc in sorted(t.items())} for b, t in m.scores.items()},
            "stderr": {b: {s: round(sc.stderr, 4) for s, sc in sorted(t.items()) if sc.stderr is not None}
                       for b, t in m.scores.items()},
            "offers": {p: {"price": {"input": o.price_in, "output": o.price_out}, "features": o.features,
                           "retires": o.retires, "price_file_entry": o.key} for p, o in sorted(m.offers.items())},
        }
    label = PRICE_LABEL if Path(prices).resolve() == (public.DATA / "litellm" / prices.name).resolve() else (
        f"assumption: LiteLLM's price file as downloaded into {Path(prices).parent.parent.name}/ (see its SHA256SUMS); "
        "prices change: check the provider's current price page")
    return {"source": {"scores": "Epoch AI, Capabilities & benchmarking (CC BY 4.0), mean_score by setting",
                       "prices": label}, "models": models}, summary


def write_models_yaml(content: dict, path: Path | None = None) -> Path:
    path = path or CONFIG / "models.yaml"
    head = ("# Built by `python -m pubcat models` from the public data in data/. Do not edit by hand: change the data\n"
            "# or the providers, and build again. Scores: Epoch AI (CC BY 4.0). Prices, features and retirement\n"
            "# dates: LiteLLM's price file (MIT), an assumption at its date - check each provider's own pages.\n")
    path.write_text(head + yaml.safe_dump(content, sort_keys=False, width=120), encoding="utf-8")
    return path


# ----- one target: a model at a provider with a setting -----

@dataclass(frozen=True)
class Target:
    provider: str
    deployment: str
    params: tuple = ()      # sorted (key, value) pairs, so a Target can be compared and hashed

    @staticmethod
    def of(entry: dict) -> "Target":
        return Target(entry["provider"], entry["deployment"], tuple(sorted((entry.get("params") or {}).items())))

    @property
    def setting(self) -> str:
        p = dict(self.params)
        if "reasoning_effort" in p:
            return p["reasoning_effort"]
        if "thinking_budget_tokens" in p:
            return f"{p['thinking_budget_tokens'] // 1000}K"
        return "default"

    def label(self) -> str:
        return f"{self.provider}/{self.deployment}" + (f" {dict(self.params)}" if self.params else "")

    def entry(self) -> dict:
        out = {"provider": self.provider, "deployment": self.deployment}
        if self.params:
            out["params"] = dict(self.params)
        return out


def score(models: dict, target: Target, benchmark: str) -> float | None:
    """The public score of this model at this setting, or None: no evidence."""
    return ((models.get(target.deployment) or {}).get("scores", {}).get(benchmark) or {}).get(target.setting)


def offer(models: dict, target: Target) -> dict | None:
    return ((models.get(target.deployment) or {}).get("offers") or {}).get(target.provider)


def days_until(date: str | None, today: str) -> int | None:
    if not date:
        return None
    return (dt.date.fromisoformat(str(date)) - dt.date.fromisoformat(today)).days


def monthly_cost(models: dict, target: Target, consumers: list[dict]) -> float | None:
    """US$ a month for these consumers' assumed workloads at this provider's list price.
    Per-token prices only: a higher setting uses more output tokens, which this does not count."""
    o = offer(models, target)
    if o is None:
        return None
    total = 0.0
    for c in consumers:
        w = c.get("workload") or {}
        total += w.get("input_m_tokens_month", 0) * o["price"]["input"] + w.get("output_m_tokens_month", 0) * o["price"]["output"]
    return round(total, 2)


@dataclass
class TargetCheck:
    target: Target
    problems: list[str] = field(default_factory=list)
    kinds: list[str] = field(default_factory=list)      # the rule behind each problem, for the funnel
    floor_score: float | None = None

    def add(self, kind: str, text: str) -> None:
        self.kinds.append(kind)
        self.problems.append(text)


def check_target(name: str, contract: dict, target: Target, models: dict, providers: dict, today: str,
                 retired: set | None = None) -> TargetCheck:
    """Every way one target breaks the contract of capability `name`."""
    out = TargetCheck(target)
    where = f"{name} -> {target.provider}/{target.deployment}"
    if target.provider not in providers:
        out.add("provider", f"{where}: no provider {target.provider} in config/providers.yaml")
    m = models.get(target.deployment)
    if m is None:
        out.add("model", f"{where}: no model {target.deployment} in config/models.yaml")
        return out
    if "preview" in target.deployment or target.deployment.endswith("-exp"):
        out.add("stable", f"{where}: a preview model: providers change or remove previews at short notice")
    o = offer(models, target)
    if o is None:
        out.add("offer", f"{where}: {target.provider} does not offer {target.deployment} in the price file")
        return out
    missing = set(contract.get("features") or []) - set(o["features"])
    if missing:
        out.add("features", f"{where}: the contract promises {', '.join(sorted(missing))}, "
                            f"the price file does not list it for {target.provider}")
    allowed = (contract.get("settings") or {}).get("reasoning_effort")
    if allowed is not None and target.setting not in allowed:
        out.add("settings", f"{where}: the setting {target.setting} is not allowed (the contract allows "
                            f"{', '.join(allowed)})")
    band = contract.get("price_band_usd_per_1m") or {}
    for side in ("input", "output"):
        if side in band and band[side] is None:
            out.add("price", f"{where}: the contract has no {side} price band yet")
        elif side in band and o["price"][side] > band[side]:
            out.add("price", f"{where}: the {side} price {o['price'][side]} is above the contract's band {band[side]}")
    ok_classes = set((providers.get(target.provider) or {}).get("data_classes") or [])
    for dc in contract.get("data_classes") or []:
        if dc not in ok_classes:
            out.add("data", f"{where}: {target.provider}'s contract does not allow {dc} data")
    qf = contract.get("quality_floor") or {}
    if qf.get("benchmark") and qf.get("minimum") is None:
        out.add("floor", f"{where}: the contract's quality floor has no minimum yet")
    elif qf.get("benchmark"):
        s = score(models, target, qf["benchmark"])
        out.floor_score = s
        if s is None:
            out.add("floor", f"{where}: no public {qf['benchmark']} score at the setting {target.setting}: no evidence")
        elif s < qf["minimum"]:
            out.add("floor", f"{where}: {qf['benchmark']} {s:.3f} at {target.setting} is below the contract's "
                                f"floor {qf['minimum']}")
    if retired and target.deployment in retired:
        out.add("retire", f"{where}: retired (what-if: --retire {target.deployment})")
    else:
        left = days_until(o.get("retires"), today)
        if left is not None and left <= 0:
            out.add("retire", f"{where}: retired on {o['retires']}")
        elif left is not None and left <= REVIEW_WINDOW_DAYS:
            out.add("retire", f"{where}: retires on {o['retires']} ({left} days), inside the "
                                f"{REVIEW_WINDOW_DAYS}-day review window")
    return out


def check(catalog: dict | None = None, models: dict | None = None, providers: dict | None = None,
          today: str | None = None, retired: set | None = None) -> list[str]:
    """Every way the mappings break their contracts (empty: the catalog is consistent)."""
    catalog = catalog or load_catalog()
    models = models if models is not None else load_models()
    providers = providers or load_providers()
    today = today or today_default()
    problems = []
    for name, cap in catalog["capabilities"].items():
        mapping = cap.get("mapping")
        if not mapping:
            continue
        for e in [mapping["primary"], *(mapping.get("fallbacks") or [])]:
            problems += check_target(name, cap["contract"], Target.of(e), models, providers, today, retired).problems
    return problems
