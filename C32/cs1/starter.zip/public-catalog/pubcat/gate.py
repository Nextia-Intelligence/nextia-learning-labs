"""The remap gate on public evidence: before a capability moves to another model, every consumer must pass.

    python -m pubcat gate strong-reasoning --to openai/gpt-6-luna --param reasoning_effort=max

The course's gate replays each consumer's own evaluation. Hollin has no evaluations of its own yet, so each
consumer names a PUBLIC benchmark and a minimum in its file (config/consumers/). The gate looks up the
candidate's public score at the candidate's setting and compares it with that consumer's minimum:

    pass         every consumer reaches its own minimum
    block        at least one consumer does not, or has no evidence: no public score for the candidate at
                 that setting (nobody published one), or no evaluation named for this capability

It also prints the average of the consumers' scores, because that is the number a leaderboard shows.
"""

from pubcat import catalog


def consumers_of(capability: str, consumers: list[dict]) -> list[dict]:
    return [c for c in consumers if capability in (c.get("capabilities") or [])]


def evaluate(consumer: dict, capability: str, candidate: catalog.Target, current: catalog.Target | None,
             models: dict) -> dict:
    """One consumer's row: its benchmark, its minimum, the candidate's score, today's score and the verdict."""
    ev = (consumer.get("evaluations") or {}).get(capability)
    row = {"consumer": consumer["id"], "owner": consumer.get("owner")}
    if not ev or ev.get("minimum") is None:
        row.update(verdict="no evidence", reason="no evaluation with a minimum for this capability")
        return row
    s = catalog.score(models, candidate, ev["benchmark"])
    now = catalog.score(models, current, ev["benchmark"]) if current else None
    row.update(benchmark=ev["benchmark"], minimum=ev["minimum"], score=s, today=now,
               cost=catalog.monthly_cost(models, candidate, [consumer]),
               cost_today=catalog.monthly_cost(models, current, [consumer]) if current else None)
    if s is None:
        row.update(verdict="no evidence", reason=f"no public {ev['benchmark']} score for {candidate.deployment} "
                                                 f"at {candidate.setting}")
    else:
        row["verdict"] = "pass" if s >= ev["minimum"] else "fail"
    return row


def decide(rows: list[dict]) -> str:
    """The gate's decision: 'pass' only if there is at least one consumer and EVERY consumer passes its own
    minimum. A failed consumer or a consumer without evidence blocks the remap. The average does not count."""
    # Task 3: return "pass" only if there is at least one row and every row's "verdict" is "pass".
    # Otherwise return "block". Then run: python -m pytest -q -k every_consumer
    raise NotImplementedError("Task 3: write the gate's decision in pubcat/gate.py")


def gate(capability: str, candidate: catalog.Target, models: dict, consumers: list[dict],
         cat: dict | None = None) -> dict:
    cat = cat or catalog.load_catalog()
    mapping = cat["capabilities"][capability].get("mapping")
    current = catalog.Target.of(mapping["primary"]) if mapping else None
    rows = [evaluate(c, capability, candidate, current, models) for c in consumers_of(capability, consumers)]
    scored = [r for r in rows if r.get("score") is not None]
    floors = [r["minimum"] for r in scored]
    return {"capability": capability, "current": current.label() if current else "nothing",
            "candidate": candidate.label(), "consumers": rows,
            "average_score": round(sum(r["score"] for r in scored) / len(scored), 3) if scored else None,
            "average_minimum": round(sum(floors) / len(floors), 3) if floors else None,
            "decision": decide(rows)}


def render(r: dict) -> str:
    lines = [f"Remap gate: {r['capability']} from {r['current']} to {r['candidate']}", ""]
    for c in r["consumers"]:
        if c.get("score") is None:
            lines.append(f"  {c['consumer']:<19} NO EVIDENCE  {c['reason']}: no evidence, no remap")
            continue
        today = f"{c['today']:.3f}" if c.get("today") is not None else "no score"
        cost = (f"; US${c['cost']:.2f} vs US${c['cost_today']:.2f} a month today"
                if c.get("cost") is not None and c.get("cost_today") is not None else "")
        lines.append(f"  {c['consumer']:<19} {c['verdict'].upper():<5} {c['benchmark']} {c['score']:.3f} "
                     f"(minimum {c['minimum']}); today {today}{cost}")
    if r["average_score"] is not None:
        lines += ["", f"Average of the consumers' scores: {r['average_score']:.3f} "
                      f"(average of their minimums: {r['average_minimum']:.3f})"]
    lines.append(f"Decision: {r['decision'].upper()}" + ("" if r["decision"] == "pass"
                                                         else " - every consumer must pass its own evaluation"))
    return "\n".join(lines)
