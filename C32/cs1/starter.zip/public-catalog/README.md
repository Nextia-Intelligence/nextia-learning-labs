# public-catalog

A capability catalog and a remap gate built from **public evaluation results** and **published prices**. It is the project of the case study [A capability catalog from public evaluation results](https://learning.nextia-ai.com/courses/agent-governance/m08/capability-catalog-from-public-evaluations/) in the Nextia Learning course *Governing AI Agents: Gateways, Registries and Controls*. The page explains every step and every output.

Hollin Energy, a made-up electricity and gas supplier, has three AI apps that call one model straight. The provider retires that model soon. The project builds Hollin's first catalog from public data: contracts, a mapping chosen by rules, and a gate in which every app must pass its own minimum.

## Set up

Python 3.12 or newer. No account, no key and no money: everything runs on your computer from the files in `data/`.

macOS and Linux:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Windows (PowerShell):

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

The project needs only PyYAML and pytest, at the versions of the course project. If you did the course, its virtual environment works too.

## Commands

| Command | What it does |
|---|---|
| `python -m pubcat data` | Check the data files against `data/SHA256SUMS` and count what they hold |
| `python -m pubcat models` | Build `config/models.yaml` from the public data |
| `python -m pubcat show <model>` | The public scores (by setting) and the offers (by provider) of one model |
| `python -m pubcat check` | Check every mapping against its contract |
| `python -m pubcat candidates <capability>` | Every target that keeps the contract, cheapest first, with each consumer's verdict |
| `python -m pubcat gate <capability> --to <provider/model> --param reasoning_effort=<setting>` | The remap gate for one candidate |
| `python -m pubcat choose [--write]` | Propose a mapping for every capability (and write it) |
| `python -m pubcat compare` | Four ways to choose, under one measure |
| `python -m pytest -q` | The tests |

`check`, `candidates`, `choose` and `compare` take `--today YYYY-MM-DD` (the day to check retirement dates against; the default is the day of the frozen data) and `--retire <model>` (what if that model were retired today).

## The data

`data/` holds a frozen copy of two public sources, with their licences and `SHA256SUMS`:

- **Epoch AI, Capabilities & benchmarking**: three benchmark files (GPQA Diamond, OTIS Mock AIME 2024-2025, SimpleQA Verified), unchanged, from <https://epoch.ai/data/benchmark_data.zip>. Licence: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Credit: Epoch AI, 'Capabilities & benchmarking'. Published online at epoch.ai. Retrieved from 'https://epoch.ai/benchmarks'.
- **LiteLLM's model price file**, `model_prices_and_context_window.json`, unchanged, from commit `159b5b2f7243bba757c08e4ddc45a2514e4cd037` of <https://github.com/BerriAI/litellm>. Licence: MIT (`data/litellm/LICENSE`). Its prices, features and retirement dates are **assumptions at that commit**: check each provider's own price and deprecation pages before you rely on them.

`python data/fetch.py` downloads the **latest** versions into `data/latest/`. Run the commands with `--data data/latest` (and `--models config/models-latest.yaml`) to see whether the mapping changes. Your results will differ from the page when the sources change.

The scores are a public screen, not Hollin's own evaluation: no public benchmark measures Hollin's bill questions. See the case-study page, "Responsible use".

## Licence

The project's code and configuration: MIT (`LICENSE`). The data keeps its own licences (above).
