# Recommendation: the catalog after o3 retires

To: Hollin's app owners (Joel, Ada, Lena) and finance (Ben). From: Noor, platform.

## The decision

<!-- Task 4: one or two sentences. Which model and setting serve each capability, and its fallback. -->

## The evidence

<!-- The output of python -m pubcat compare, and the two gate results that decided it. -->

## What it costs

<!-- US$ a month today and with the new mapping, and what the estimate does not count. -->

## What the public data cannot tell us

<!-- At least three limits, and what each app owner must check before the change goes live. -->

## The next review

<!-- The dates in the review window, and what happens if the fast-small model retires. -->
