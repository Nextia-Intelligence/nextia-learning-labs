"""Download the LATEST public data into data/latest/, to run the catalog on new input.

    python data/fetch.py

The project works without this: data/ holds a frozen copy of both sources with SHA256SUMS. This script gets
today's versions from the original publishers, so you can see whether the mapping changes:

- Epoch AI's benchmark data (CC BY 4.0): https://epoch.ai/data/benchmark_data.zip (it changes every day);
  only the three CSV files that the project reads are kept.
- LiteLLM's price file (MIT): the newest version on the main branch of github.com/BerriAI/litellm.

Downloaded files are data from the internet: the script only reads them as CSV and JSON, never runs them,
and keeps them in their own folder. It writes data/latest/SHA256SUMS for what it got, so
`python -m pubcat --data data/latest data` can check that nothing changed afterwards. Standard library only.
"""

import hashlib
import io
import shutil
import sys
import urllib.request
import zipfile
from pathlib import Path

EPOCH = "https://epoch.ai/data/benchmark_data.zip"
PRICES = "https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json"
LICENSE = "https://raw.githubusercontent.com/BerriAI/litellm/main/LICENSE"
KEEP = ["gpqa_diamond.csv", "otis_mock_aime_2024_2025.csv", "simpleqa_verified.csv", "README.md"]
OUT = Path(__file__).resolve().parent / "latest"


def get(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "nextia-learning-public-catalog"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()


def main() -> int:
    if OUT.exists():
        shutil.rmtree(OUT)
    (OUT / "epoch").mkdir(parents=True)
    (OUT / "litellm").mkdir()
    try:
        archive = zipfile.ZipFile(io.BytesIO(get(EPOCH)))
        for name in KEEP:
            (OUT / "epoch" / name).write_bytes(archive.read(name))   # read by name: no path from the archive is used
        (OUT / "litellm" / "model_prices_and_context_window.json").write_bytes(get(PRICES))
        (OUT / "litellm" / "LICENSE").write_bytes(get(LICENSE))
    except (OSError, KeyError, zipfile.BadZipFile) as e:
        print(f"Could not download the latest data: {e}. Check your internet connection, or keep using data/.")
        return 1
    lines = []
    for path in sorted(p for p in OUT.rglob("*") if p.is_file()):
        rel = path.relative_to(OUT).as_posix()
        lines.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {rel}")
    (OUT / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {len(lines)} files to data/latest/. Next: python -m pubcat --data data/latest data")
    return 0


if __name__ == "__main__":
    sys.exit(main())
