"""Tests of the public catalog: the data, the join, the contract check, the gate and the chooser."""

import shutil

import pytest

from pubcat import catalog, choose, gate, public

PRICES = public.DATA / "litellm" / "model_prices_and_context_window.json"
TODAY = "2026-10-22"


@pytest.fixture(scope="module")
def models():
    content, _ = catalog.build_models_yaml(public.DATA / "epoch", PRICES)
    return content["models"]


@pytest.fixture(scope="module")
def world(models):
    return catalog.load_catalog(), models, catalog.load_providers(), catalog.load_consumers()


def target(provider, model, effort=None):
    return catalog.Target(provider, model, (("reasoning_effort", effort),) if effort else ())


# ----- the data -----

def test_the_frozen_data_matches_its_checksums():
    assert public.check_files() == []


def test_a_changed_file_is_found(tmp_path):
    shutil.copytree(public.DATA, tmp_path / "data")
    path = tmp_path / "data" / "epoch" / "simpleqa_verified.csv"
    path.write_text(path.read_text(encoding="utf-8").replace("0.494", "0.594"), encoding="utf-8")
    assert public.check_files(tmp_path / "data") == ["epoch/simpleqa_verified.csv: wrong checksum (the file changed)"]


@pytest.mark.parametrize("version, expected", [
    ("gpt-5.6-luna_low", ("gpt-5.6-luna", "low")),
    ("claude-opus-4-5-20251101_32K", ("claude-opus-4-5-20251101", "32K")),
    ("o3-2025-04-16", ("o3-2025-04-16", "default")),
])
def test_a_model_version_is_a_model_and_a_setting(version, expected):
    assert public.split_version(version) == expected


def test_the_setting_becomes_the_mappings_params():
    assert public.params_for("low") == {"reasoning_effort": "low"}
    assert public.params_for("32K") == {"thinking_budget_tokens": 32000}
    assert public.params_for("default") == {}


def test_regional_entries_are_left_out_and_the_earliest_date_counts():
    offers = public.load_offers(PRICES, catalog.load_providers())
    assert offers["o3-2025-04-16"]["azure"].key == "azure/o3-2025-04-16"     # not azure/eu/... or azure/us/...
    assert offers["o3-2025-04-16"]["openai"].retires == "2026-12-11"
    assert offers["o3-2025-04-16"]["azure"].retires == "2026-11-19"           # the same model, another day
    assert offers["gemini-3.7-flash"]["vertex"].retires == "2027-01-28"


def test_a_provider_without_a_contract_has_no_offer(models):
    assert "mistral-large-4-0" not in models          # scores, but no offer at Hollin's providers


def test_the_models_file_is_up_to_date(models):
    assert (catalog.CONFIG / "models.yaml").exists(), "no config/models.yaml yet: run python -m pubcat models"
    assert catalog.load_models() == models, "config/models.yaml is old: run python -m pubcat models"


# ----- the contract check -----

def test_todays_mapping_breaks_the_retirement_rule_and_the_price_band(world):
    cat, models, providers, _ = world
    today = yaml_copy(cat)
    today["capabilities"]["fast-small"]["mapping"] = {"primary": target("openai", "o3-2025-04-16", "low").entry()}
    today["capabilities"]["strong-reasoning"]["mapping"] = {"primary": target("openai", "o3-2025-04-16", "high").entry()}
    assert catalog.check(today, models, providers, TODAY) == [   # after Task 1: the contract is complete
        "fast-small -> openai/o3-2025-04-16: the input price 2.0 is above the contract's band 0.5",
        "fast-small -> openai/o3-2025-04-16: the output price 8.0 is above the contract's band 2.0",
        "fast-small -> openai/o3-2025-04-16: retires on 2026-12-11 (50 days), inside the 60-day review window",
        "strong-reasoning -> openai/o3-2025-04-16: retires on 2026-12-11 (50 days), inside the 60-day review window",
    ]


def test_a_score_counts_only_at_the_setting_it_was_measured_at(world):
    cat, models, providers, _ = world
    contract = cat["capabilities"]["fast-small"]["contract"]
    low = catalog.check_target("fast-small", contract, target("openai", "gpt-5.6-luna", "low"), models, providers, TODAY)
    none = catalog.check_target("fast-small", contract, target("openai", "gpt-5.6-luna", "none"), models, providers, TODAY)
    minimal = catalog.check_target("fast-small", contract, target("openai", "gpt-5.6-luna", "minimal"), models, providers, TODAY)
    assert low.problems == []
    assert none.problems == ["fast-small -> openai/gpt-5.6-luna: gpqa_diamond 0.636 at none is below the contract's floor 0.74"]
    assert minimal.problems == ["fast-small -> openai/gpt-5.6-luna: no public gpqa_diamond score at the setting minimal: no evidence"]


def test_the_review_window_is_60_days(world):
    cat, models, providers, _ = world
    contract = cat["capabilities"]["strong-reasoning"]["contract"]
    t = target("vertex", "gemini-3.7-flash", "high")       # retires on 2027-01-28
    assert "retire" in catalog.check_target("strong-reasoning", contract, t, models, providers, "2026-11-29").kinds
    assert "retire" not in catalog.check_target("strong-reasoning", contract, t, models, providers, "2026-11-28").kinds


def test_a_preview_model_is_refused(world):
    cat, models, providers, _ = world
    contract = cat["capabilities"]["strong-reasoning"]["contract"]
    chk = catalog.check_target("strong-reasoning", contract, target("vertex", "gemini-3-flash-preview", "high"),
                               models, providers, TODAY)
    assert "stable" in chk.kinds


def test_the_strong_reasoning_contract():
    contract = catalog.load_catalog()["capabilities"]["strong-reasoning"]["contract"]
    assert contract["quality_floor"]["benchmark"] == "otis_mock_aime_2024_2025", "Task 1: the floor's benchmark"
    assert contract["quality_floor"]["minimum"] == 0.75, "Task 1: the floor's minimum"
    assert contract["price_band_usd_per_1m"] == {"input": 2.5, "output": 12.0}, "Task 1: the price band"


def test_the_research_assistants_minimum():
    research = next(c for c in catalog.load_consumers() if c["id"] == "research-assistant")
    assert research["evaluations"]["strong-reasoning"]["minimum"] == 0.46, \
        "Task 2: today's score minus two standard errors, rounded down to two decimals"


# ----- the gate -----

@pytest.mark.parametrize("verdicts, decision", [
    (["pass", "pass"], "pass"),
    (["pass", "fail"], "block"),
    (["pass", "no evidence"], "block"),
    ([], "block"),
])
def test_every_consumer_must_pass(verdicts, decision):
    assert gate.decide([{"verdict": v} for v in verdicts]) == decision


def test_the_average_passes_but_one_consumer_fails(world):
    cat, models, _, consumers = world
    r = gate.gate("strong-reasoning", target("openai", "gpt-6-luna", "max"), models, consumers, cat)
    assert [(c["consumer"], c["verdict"]) for c in r["consumers"]] == [("billing-agent", "pass"),
                                                                       ("research-assistant", "fail")]
    assert r["average_score"] > r["average_minimum"]
    assert r["decision"] == "block"


def test_no_public_score_is_no_evidence(world):
    cat, models, _, consumers = world
    r = gate.gate("strong-reasoning", target("anthropic", "claude-haiku-5-5", "high"), models, consumers, cat)
    assert [c["verdict"] for c in r["consumers"]] == ["pass", "no evidence"]
    assert r["decision"] == "block"


# ----- the chooser -----

def test_the_proposed_mapping(world):
    cat, models, providers, consumers = world
    fast = choose.choose("fast-small", models, providers, consumers, cat, TODAY)
    strong = choose.choose("strong-reasoning", models, providers, consumers, cat, TODAY)
    assert fast["primary"].target == target("openai", "gpt-5.6-luna", "low")
    assert fast["fallback"].target == target("azure", "gpt-5.6-luna", "low")
    assert strong["cheapest_keeping_contract"].target == target("azure", "gpt-5-nano-2025-08-07", "high")
    assert strong["primary"].target == target("vertex", "gemini-3.8-flash", "high")
    assert strong["fallback"].target.provider != "vertex"


def test_when_the_fast_model_is_retired(world):
    cat, models, providers, consumers = world
    res = choose.choose("fast-small", models, providers, consumers, cat, TODAY, {"gpt-5.6-luna"})
    assert res["primary"].target == target("vertex", "gemini-3.1-flash-lite", "low")
    assert res["fallback"] is None
    assert res["primary"].margin < 0.01          # inside one standard error: weak evidence
    nothing = choose.choose("fast-small", models, providers, consumers, cat, TODAY, {"gpt-5.6-luna", "gemini-3.1-flash-lite"})
    assert nothing["primary"] is None


def test_the_funnel_only_goes_down(world):
    cat, models, providers, consumers = world
    counts = [n for _, n in choose.choose("strong-reasoning", models, providers, consumers, cat, TODAY)["funnel"]]
    assert counts == sorted(counts, reverse=True)


def yaml_copy(d):
    import yaml
    return yaml.safe_load(yaml.safe_dump(d))
