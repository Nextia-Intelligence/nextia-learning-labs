# Registrations

Your reviewed forms go here, one per request: `registrations/<request-id>.yaml`.
Start each one with `python -m intake draft <request-id> --out registrations/<request-id>.yaml`,
then review it, change it and sign it (`review: by, notes`). Check every form with `python -m intake check`.
