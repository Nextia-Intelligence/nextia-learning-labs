# Your vendor notes

Write a note here when you read a vendor's own pages: `notes/<request-id>.yaml`, in the same shape as
`data/vendor/stripe-mcp.yaml` (`sources`, `answers` with a `status` of yes, partly or no for each of the twelve
questions, and optional `tools` and `flags`). A note here wins over the one in `data/vendor/`.
Summarise in your own words and link each answer to its page.
