# mcp-intake: review public MCP servers for registration

Teams at Larkfield (a made-up online shop) ask to connect public MCP servers to the platform's tool gateway. This
project reviews each request **from published information only**, without running any server:

1. It reads a fixed copy of the official MCP Registry (CC0), a second catalog (Docker's, MIT) and notes that a person
   wrote from each vendor's own pages.
2. It answers twelve questions that a registration needs, and says which source answered each one.
3. It lists the published tools, marks each one read, write, run-any or unknown, and proposes which tools to allow.
4. It drafts a registration in the course's form, with a risk tier, a decision (`refuse`, `wait` or `register reads
   only`) and the list of what is still unknown.
5. A person reviews the draft, changes it and signs it. `python -m intake check` runs the course's registry checks and
   this project's own checks on every form.

## Set up

macOS or Linux:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-dev.txt
python -m intake verify
python -m pytest -q
```

Windows (PowerShell):

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements-dev.txt
python -m intake verify
python -m pytest -q
```

Python 3.12 or newer. The only package the code needs is PyYAML; pytest and ruff are for the tests.

## Commands

| Command | What it shows |
|---|---|
| `python -m intake verify` | every data file matches `data/SHA256SUMS` |
| `python -m intake coverage` | what the registry's 48,606 entries publish, and what no entry can say |
| `python -m intake search stripe` | every entry that mentions a word, by namespace |
| `python -m intake show stripe-mcp` | one entry, and the catalog entries that match it (by address or repository, not by name) |
| `python -m intake answer stripe-mcp --sources registry` | the twelve questions, from one or more sources |
| `python -m intake compare` | the four reviewed servers, answered from one, two and three sources |
| `python -m intake tools notion-mcp` | each published tool with its kind and the reason |
| `python -m intake lists stripe-mcp` | the catalog's tool list against the vendor's |
| `python -m intake draft sentry-mcp --out registrations/sentry-mcp.yaml` | a draft registration |
| `python -m intake check` | the course's registry checks and this project's checks on `registrations/*.yaml` |
| `python -m intake gateway` | the tool gateway's list of reads and writes for the registered servers |
| `python -m intake review com.aftership.mcp/tracking-public` | everything above for one server, end to end |
| `python -m intake fetch com.stripe/mcp` | the live registry's version against the fixed copy (needs the network) |

`ID` is a request in `requests.yaml` or any server name in the registry copy. Notes that you write from a vendor's
pages go in `notes/<id>.yaml` (the same shape as `data/vendor/*.yaml`); they win over ours.

## Files

```text
requests.yaml         the five requests (constructed: the people and requests are made up)
data/                 the fixed copy (see DATASET.md), checked by data/SHA256SUMS
  registry/           servers.jsonl.gz (every latest entry, slim), entries/ (five full entries), FETCHED
  catalog/            index.jsonl (328 entries), servers/ (seven entries), LICENSE (MIT, Docker)
  vendor/             our notes from the vendors' pages, with links, and the tool names they publish
intake/               questions.py (the twelve questions), decide.py (tools, tier, decision, checks), __main__.py
estate/, config/      the course project's registry checks (estate/registry.py) and the config they read, unchanged
registrations/        the reviewed forms (finished project); empty in the starter
docs/review.md        the review report (finished project)
tests/                pytest
```

## Licence and data

Code: MIT (Nextia Learning). `estate/` and `config/` are copied unchanged from the course project `ai-estate` (MIT).
Data: see `DATASET.md`. Registry data: CC0 1.0 (the registry's Terms of Service, section 10). Docker catalog entries:
MIT (`data/catalog/LICENSE`). This project is not affiliated with the Official MCP Registry or with any vendor named.

Tested on macOS (Apple silicon) with Python 3.12.13. The Windows and Linux commands are written, not tested.
