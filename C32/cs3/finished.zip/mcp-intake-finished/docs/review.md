# Review of four public MCP servers for registration

Reviewer: Kwame (platform). Requests: `requests.yaml` (constructed). Evidence: the official MCP Registry's entries
(fixed copy, CC0), the Docker MCP catalog (MIT) and the vendors' own pages (`data/vendor/`). No server was run.

## Decisions

| Request | Server | Decision | Risk | Tools allowed | Why |
|---|---|---|---|---|---|
| stripe-mcp (Amira) | com.stripe/mcp 0.2.4, hosted | **refuse** | high | 0 of 15 | Its tools return payment data to the agent, and the agent sends its context to a model. Two tools run any API method. Refunds stay in orders-mcp, behind approval grants. |
| shippo-mcp (Amira) | com.shippo/shippo-mcp 1.0.0, hosted | **wait** | high | 0 (no list) | No published source names its tools. Ask Shippo; then list the tools in an onboarding test against a test account. |
| sentry-mcp (Tomás) | io.github.getsentry/sentry-mcp 0.42.0, npm package | **register reads only** | medium | 10 of 63 | The source lists every tool with its scopes. Run the pinned package locally with `--skills=inspect`, a read-only token and no LLM provider. |
| notion-mcp (Mei) | com.notion/mcp 1.0.1, hosted | **register reads only** | medium | 2 of 65 | `notion-search` and `notion-fetch`, through a workspace-owned connection that lists only those, with an account that reads one teamspace. |

## How much the published information answered

Twelve questions per server (`python -m intake compare`), answered from one, two and three sources:

| Server | Registry | + catalog | + vendor pages |
|---|---|---|---|
| stripe-mcp | 3 | 6 | 7 |
| shippo-mcp | 3 | 3 | 4 |
| sentry-mcp | 4 | 4 | 10 |
| notion-mcp | 3 | 6 | 8 |
| All four (of 48) | 13 | 19 | 29 |

More answers are not more truth: the catalog's and the vendors' tool lists share 2 of 15 names (Stripe) and none of
65 (Notion). The vendor's list wins; a `tools/list` in an onboarding test is the final word.

## What no published source told us

- What each vendor keeps, and for how long (all four).
- Whether a hosted server's tools change between our review and tomorrow (Stripe, Shippo, Notion: nothing to pin).
- Per-tool read or write labels for Stripe and Notion (we propose them from the names; the platform decides).
- Shippo's tools, and the data each one returns.

## Gaps found in our own controls

- The course's registry checks accepted a tool server with data class `payment` and tools, because the rule "payment
  never goes to a model" checked only forms with capabilities. Reported to the platform owner; the course project's
  `check_form` now applies it to tool servers too (fixed, with a test).
- Tool IDs must match `server.tool` without hyphens, but MCP tool names may have them (`notion-search`): the tool
  gateway needs a map from the platform's ID to the server's name.
- The course's tool gateway starts stdio servers only: a hosted server (Notion) needs a remote transport in the gateway first.

## Next review

Sentry and Notion by 2027-04-15 (medium risk: 6 months), and before any change of version or tool list.
