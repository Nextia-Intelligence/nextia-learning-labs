import shutil

import pytest

from intake import data


def test_the_fixed_data_matches_its_checksums():
    assert len(data.verify()) >= 20


def test_a_changed_file_is_found(tmp_path, monkeypatch):
    copy = tmp_path / "data"
    shutil.copytree(data.DATA, copy)
    (copy / "requests-note.txt").write_text("not listed, so not checked")
    with open(copy / "catalog" / "index.jsonl", "a") as f:
        f.write("\n")
    monkeypatch.setattr(data, "DATA", copy)
    with pytest.raises(data.DataError, match="catalog/index.jsonl changed"):
        data.verify()


def test_sizes_of_the_fixed_copy():
    assert len(data.registry()) == 48_606
    assert len(data.catalog()) == 328
    assert data.fetched().startswith("2026-10-23")


def test_find_takes_a_request_or_a_registry_name():
    assert data.find("stripe-mcp")[1]["name"] == "com.stripe/mcp"
    assert data.find("com.stripe/mcp")[0] == "stripe-mcp"
    assert data.find("io.github.github/github-mcp-server")[0] is None
    with pytest.raises(KeyError):
        data.find("no.such/server")
