from intake import data
from intake.questions import answers, catalog_matches, namespace, score


def test_namespace_says_what_the_registry_checked():
    assert namespace("com.stripe/mcp") == "domain stripe.com"
    assert namespace("io.github.getsentry/sentry-mcp") == "GitHub account getsentry"


def test_a_package_can_be_pinned_a_hosted_server_cannot():
    _, sentry = data.find("sentry-mcp")
    _, notion = data.find("notion-mcp")
    assert "@sentry/mcp-server 0.42.0" in answers(sentry, "sentry-mcp", ("registry",))["pin"].answer
    assert answers(notion, "notion-mcp", ("registry",))["pin"].answer.startswith("no: hosted only")


def test_catalog_matches_by_address_or_repository_not_by_name():
    _, stripe = data.find("stripe-mcp")
    _, sentry = data.find("sentry-mcp")
    assert [(c["name"], how) for c, how in catalog_matches(stripe)] == [
        ("stripe-remote", "the same address"), ("stripe", "the same repository")]
    # The catalog's "sentry" is another server (an archived reference server) with the same word in its name.
    assert [c["name"] for c, _ in catalog_matches(sentry)] == ["sentry-remote"]


def test_each_source_adds_answers():
    totals = []
    for sources in [("registry",), ("registry", "catalog"), ("registry", "catalog", "vendor")]:
        totals.append(sum(score(answers(*reversed(data.find(r)), sources))[0]
                          for r in ["stripe-mcp", "shippo-mcp", "sentry-mcp", "notion-mcp"]))
    assert totals == [13, 19, 29]


def test_what_still_blocks_shippo():
    _, rec = data.find("shippo-mcp")
    assert score(answers(rec, "shippo-mcp"))[2] == ["tools", "data"]
