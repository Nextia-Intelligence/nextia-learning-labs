"""The finished registrations: each one passes the course's registry checks and this case study's checks."""
import pytest

from estate.registry import check_form, read_form
from intake import data
from intake.decide import intake_problems

FORMS = sorted(data.REGISTRATIONS.glob("*.yaml"))


@pytest.mark.parametrize("path", FORMS, ids=[p.stem for p in FORMS])
def test_form_is_complete(path):
    form = read_form(path)
    assert check_form(form, today=data.TODAY) == []
    assert intake_problems(form) == []


def test_the_reviewed_decisions():
    got = {p.stem: read_form(p)["intake"]["decision"] for p in FORMS}
    assert got == {"notion-mcp": "register reads only", "sentry-mcp": "register reads only",
                   "shippo-mcp": "wait", "stripe-mcp": "refuse"}
