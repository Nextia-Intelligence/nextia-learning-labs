"""The finished registrations: each one passes this case study's checks, and the course's registry checks
(a refused form: the registry refuses it too)."""
import pytest

from estate.registry import check_form, read_form
from intake import data
from intake.decide import intake_problems

FORMS = sorted(data.REGISTRATIONS.glob("*.yaml"))


@pytest.mark.parametrize("path", FORMS, ids=[p.stem for p in FORMS])
def test_form_is_complete(path):
    form = read_form(path)
    registry = check_form(form, today=data.TODAY)
    if form["intake"]["decision"] == "refuse":     # the course's registry refuses it too, for the same reason
        assert registry and all("never sent to a model" in p for p in registry)
    else:
        assert registry == []
    assert intake_problems(form) == []


def test_the_reviewed_decisions():
    got = {p.stem: read_form(p)["intake"]["decision"] for p in FORMS}
    assert got == {"notion-mcp": "register reads only", "sentry-mcp": "register reads only",
                   "shippo-mcp": "wait", "stripe-mcp": "refuse"}
