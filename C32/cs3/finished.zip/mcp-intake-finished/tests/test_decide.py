import copy

from intake import data
from intake.decide import classify, intake_problems, propose, tool_id


def test_tool_ids_follow_the_registry_pattern():
    assert tool_id("notion-mcp", "notion-search") == "notion.notion_search"
    assert tool_id("sentry-mcp", "get_issue_details") == "sentry.get_issue_details"


def test_decisions_for_the_five_requests():
    assert {r: propose(r)["decision"] for r in data.requests()} == {
        "stripe-mcp": "refuse", "shippo-mcp": "wait", "sentry-mcp": "register reads only",
        "notion-mcp": "register reads only", "aftership-mcp": "wait"}


def test_run_any_tools_are_never_proposed():
    tools, where = classify("stripe-mcp", data.find("stripe-mcp")[1])
    assert where == "vendor"
    assert {t["name"] for t in tools if t["kind"] == "run-any"} == {"stripe_api_read", "stripe_api_write"}
    sentry = propose("sentry-mcp")["form"]["tools"]
    assert "sentry.execute_sentry_tool" not in sentry and "sentry.search_events" not in sentry


def test_no_tool_list_means_high_risk_and_no_tools():
    p = propose("shippo-mcp")
    assert p["tier"] == "high" and p["form"]["tools"] == [] and "long_form" in p["form"]


def test_the_drafts_pass_the_course_registry_checks():
    from estate.registry import check_form
    for r in data.requests():
        assert check_form(propose(r)["form"], today=data.TODAY) == [], r


def _signed(form):
    f = copy.deepcopy(form)
    f["review"] = {"by": "usr-kwame", "notes": "checked"}
    return f


def test_intake_checks_what_the_course_form_does_not():
    form = _signed(propose("stripe-mcp")["form"])
    form["long_form"].update(impact="refunds", human_oversight="Stripe's confirmation")
    assert intake_problems(form) == []
    form["tools"] = ["stripe.stripe_api_read", "stripe.list_refunds"]
    problems = "\n".join(intake_problems(form))
    assert "runs any operation by name" in problems
    assert "stripe.list_refunds: not in any published tool list" in problems
    assert "payment data never goes to a model" in problems


def test_a_draft_must_be_signed_and_have_no_todo():
    problems = intake_problems(propose("shippo-mcp")["form"])
    assert any(p.startswith("still TODO: impact, human_oversight") for p in problems)
    assert any(p.startswith("review: a person signs") for p in problems)


def test_flagged_tools_need_a_reason():
    form = _signed(propose("notion-mcp")["form"])
    form["tools"] = ["notion.notion_ai_search"]
    assert any("flagged (hidden)" in p for p in intake_problems(form))
