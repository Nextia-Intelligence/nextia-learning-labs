"""The case study's fixed data: the official MCP Registry's entries, the Docker catalog's entries and our vendor notes.

Everything is read from data/ (a fixed copy, checked with data/SHA256SUMS), so the results are the same on every
computer. `python -m intake fetch NAME` can get one entry from the live registry for comparison; nothing else uses
the network.
"""

import gzip
import hashlib
import json
import os
from datetime import date
from functools import cache
from pathlib import Path

import yaml

PROJECT = Path(__file__).resolve().parent.parent
DATA = PROJECT / "data"
REGISTRATIONS = PROJECT / "registrations"
# The day of the review. Fixed, so that review dates in the drafts are the same for everyone.
TODAY = date.fromisoformat(os.environ.get("INTAKE_TODAY", "2026-10-22"))


class DataError(RuntimeError):
    """A data file is missing or changed."""


def verify() -> list[str]:
    """Check every file of data/ against data/SHA256SUMS. Returns the files checked; raises DataError on a change."""
    sums = DATA / "SHA256SUMS"
    if not sums.exists():
        raise DataError(f"{sums} is missing: download the project again")
    checked = []
    for line in sums.read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        path = DATA / name
        if not path.exists():
            raise DataError(f"data/{name} is missing")
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise DataError(f"data/{name} changed: its SHA-256 is not the one in data/SHA256SUMS")
        checked.append(name)
    return checked


@cache
def registry() -> list[dict]:
    """One slim record per latest entry of the official MCP Registry (48,606 at the fixed copy)."""
    with gzip.open(DATA / "registry" / "servers.jsonl.gz", "rt", encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


@cache
def registry_by_name() -> dict[str, dict]:
    return {s["name"]: s for s in registry()}


def fetched() -> str:
    return (DATA / "registry" / "FETCHED").read_text(encoding="utf-8").split()[0]


@cache
def catalog() -> list[dict]:
    """One slim record per entry of the Docker MCP catalog (328 at the fixed copy)."""
    lines = (DATA / "catalog" / "index.jsonl").read_text(encoding="utf-8").splitlines()
    return [json.loads(line) for line in lines if line.strip()]


def catalog_tools(name: str) -> list[dict] | None:
    """The catalog's own tool list (tools.json) for one entry, if we kept it."""
    path = DATA / "catalog" / "servers" / name / "tools.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None


@cache
def requests() -> dict[str, dict]:
    return yaml.safe_load((PROJECT / "requests.yaml").read_text(encoding="utf-8"))["requests"]


def vendor(rid: str) -> dict | None:
    """Notes from the vendor's own pages (people's work, with links): ours in data/vendor/, yours in notes/.
    None if nobody wrote them."""
    for path in (PROJECT / "notes" / f"{rid}.yaml", DATA / "vendor" / f"{rid}.yaml"):
        if path.exists():
            return yaml.safe_load(path.read_text(encoding="utf-8"))
    return None


def find(key: str) -> tuple[str | None, dict]:
    """A request ID (stripe-mcp) or a registry name (com.stripe/mcp) -> (request ID or None, the registry record)."""
    if key in requests():
        return key, registry_by_name()[requests()[key]["server"]]
    rec = registry_by_name().get(key)
    if rec is None:
        raise KeyError(f"{key}: not a request in requests.yaml and not a server name in the registry copy")
    rid = next((r for r, q in requests().items() if q["server"] == key), None)
    return rid, rec
