"""From the answers to a draft registration: the tool list with each tool's kind, a risk tier, the tools to allow,
and a decision. Every rule is written here in plain code, so a person can read why the draft says what it says.
The draft is a proposal: a person reviews it, changes it and signs it (the `review` block of the form).
"""

import re
from datetime import timedelta

from estate.registry import REVIEW_MONTHS
from intake import data
from intake.questions import QUESTIONS, SHORT, answers, score

READ_VERBS = {"get", "list", "search", "find", "fetch", "read", "query", "retrieve", "download", "whoami", "wait",
              "track", "validate", "check"}
WRITE_VERBS = {"create", "update", "delete", "add", "remove", "set", "send", "transfer", "convert", "move", "restore",
               "duplicate", "upload", "cancel", "finalize", "spawn", "stop", "link", "unlink", "buy", "purchase",
               "refund", "void"}
PAYMENT_WORDS = ("payment", "card", "charge", "refund", "payout")
PERSONAL_WORDS = ("customer", "address", "user", "recipient", "people", "personal", "member")


def server_key(rid: str) -> str:
    """stripe-mcp -> stripe: the first part of each tool ID in the registration (stripe.stripe_api_read)."""
    return rid.removesuffix("-mcp").replace("-", "_")


def tool_id(rid: str, name: str) -> str:
    """The platform's ID for a tool: server.tool, in lower case with underscores (the registry's TOOL pattern)."""
    return f"{server_key(rid)}.{re.sub(r'[^a-z0-9_]', '_', name.lower())}"


def verb(name: str, rid: str) -> str:
    prefix = server_key(rid)
    words = [w for w in re.split(r"[-_]", name.lower()) if w and w not in (prefix, "stripe", "notion", "sentry")]
    return words[0] if words else ""


def published_tools(rid: str | None, rec: dict) -> tuple[list[dict], str]:
    """The tool list from the best published source: the vendor's own list, else the catalog's, else none."""
    note = data.vendor(rid) if rid else None
    if note and note.get("tools"):
        return note["tools"], "vendor"
    from intake.questions import catalog_matches
    for c, how in catalog_matches(rec):
        if how != "the same host, another address":
            tools = data.catalog_tools(c["name"])
            if tools:
                return [{"name": t["name"], "kind": None} for t in tools], f"catalog {c['name']}"
    return [], "none"


def classify(rid: str | None, rec: dict) -> tuple[list[dict], str]:
    """Each published tool with its kind and why: published (the server's own label), or proposed from its verb."""
    tools, where = published_tools(rid, rec)
    flags = ((data.vendor(rid) or {}).get("flags") or {}) if rid else {}
    out = []
    for t in tools:
        name, v = t["name"], verb(t["name"], rid or "x")
        if name in flags.get("run_any", []):
            kind, why = "run-any", "runs any operation by name: an allowlist cannot narrow it"
        elif t.get("kind"):
            kind, why = t["kind"], "the server's own annotation (a hint)"
        elif v in WRITE_VERBS:
            kind, why = "write", f"proposed from the verb '{v}'"
        elif v in READ_VERBS:
            kind, why = "read", f"proposed from the verb '{v}'"
        else:
            kind, why = "unknown", f"the verb '{v}' is not in either list"
        notes = [f for f in ("hidden", "calls_a_model", "other_systems", "moves_money") if name in flags.get(f, [])]
        out.append({"name": name, "id": tool_id(rid or "x", name), "kind": kind, "why": why, "flags": notes,
                    **({"skills": t["skills"]} if "skills" in t else {})})
    return out, where


def data_class(ans) -> str:
    text = ans["data"].answer.lower()
    if ans["data"].status == "no":
        return "unknown"
    if any(w in text for w in PAYMENT_WORDS):
        return "payment"
    if any(w in text for w in PERSONAL_WORDS) or "customer data" in text:
        return "personal"
    return "internal"


def propose(key: str) -> dict:
    """The draft for one request: answers, tools, risk tier, decision and the registration form."""
    rid, rec = data.find(key)
    req = data.requests().get(rid) if rid else None
    ans = answers(rec, rid)
    yes, partly, blocking = score(ans)
    tools, where = classify(rid, rec)
    dc = data_class(ans)
    moves = [t for t in tools if "moves_money" in t["flags"] or verb(t["name"], rid or "x") in ("buy", "purchase", "refund")]
    writes = [t for t in tools if t["kind"] == "write"]
    reasons = []
    if not tools:
        tier = "high"
        reasons.append("no published tool list: treat it as the worst case")
    elif dc == "payment" or moves:
        tier = "high"
        reasons.append("payment data" if dc == "payment" else f"{len(moves)} tool(s) can move money or goods")
    elif dc in ("personal", "unknown") or writes:
        tier = "medium"
        reasons.append(f"data class {dc}" + (f", {len(writes)} write tool(s)" if writes else ""))
    else:
        tier = "low"
        reasons.append("internal data, reads only")
    allowed = [t for t in tools if t["kind"] == "read" and not t["flags"]]
    held = [t for t in tools if t not in allowed]

    if dc == "payment":
        decision = "refuse"
        why = ("its tools return payment data to the agent, and the agent sends its context to a model; "
               "Larkfield's rule: payment data never goes to a model")
    elif not tools or "publisher" in blocking or "runs" in blocking:
        decision = "wait"
        why = "the published information does not say " + ", ".join(SHORT[k] for k in blocking)
    else:
        decision = "register reads only"
        why = f"{len(allowed)} read tool(s) allowed; {len(held)} held back (writes, run-any or flagged tools)"

    owner = req["requested_by"] if req else "TODO"
    form = {
        "id": rid or "TODO",
        "name": (rec.get("title") or rec["name"]) + " (third-party MCP server)",
        "kind": "tool-server",
        "owner": owner,
        "team": req["team"] if req else "TODO",
        "purpose": req["purpose"] if req else "TODO",
        "users": req["users"] if req else "TODO",
        "from": f"official MCP Registry: {rec['name']} {rec['version']}",
        "risk_tier": tier,
        "data_classes": ["personal" if dc == "unknown" else dc],
        "capabilities": [],
        "tools": [t["id"] for t in allowed] if decision == "register reads only" else [],
        "autonomy": "suggests",
        "budget_usd_month": 0,
        "limits": {"requests_per_minute": 0, "tokens_per_day": 0, "max_calls_per_run": 0},
        "review_date": (data.TODAY + timedelta(days=30 * REVIEW_MONTHS[tier])).isoformat(),
    }
    if tier == "high":
        form["long_form"] = {
            "impact": "TODO: what a wrong call can do (money, goods, customer data)",
            "human_oversight": "TODO: who approves each write",
            "failure_mode": "fail_closed",
            "incident_contact": owner,
            "data_retention": ans["kept"].answer if ans["kept"].status != "no" else "unknown: not published",
            "kill_switch_tested": None,
        }
    form["intake"] = {
        "decision": decision,
        "why": why,
        "tool_list_from": where,
        "held_back": [t["id"] for t in tools if t["id"] not in form["tools"]],
        "unknowns": [q for k, q, _ in QUESTIONS if ans[k].status != "yes"],
    }
    form["review"] = {"by": None, "notes": None}
    return {"rid": rid, "record": rec, "request": req, "answers": ans, "score": (yes, partly, blocking),
            "tools": tools, "tier": tier, "tier_reasons": reasons, "data_class": dc, "decision": decision,
            "why": why, "form": form}


def intake_problems(form: dict, rid: str | None = None) -> list[str]:
    """The case study's own checks of a finished form, on top of the course's registry checks."""
    p = []
    rid = rid or form.get("id")
    rec = data.registry_by_name().get(str(form.get("from", "")).split(": ", 1)[-1].rsplit(" ", 1)[0])
    if rec is None:
        return ["from: name the registry entry and its version, as the draft does "
                "(official MCP Registry: com.stripe/mcp 0.2.4)"]
    tools, _ = classify(rid, rec)
    by_id = {t["id"]: t for t in tools}
    for t in form.get("tools") or []:
        if t not in by_id:
            p.append(f"tool {t}: not in any published tool list, so nobody has reviewed it")
        elif by_id[t]["kind"] == "run-any":
            p.append(f"tool {t}: runs any operation by name, so the allowlist means nothing")
        elif by_id[t]["kind"] == "write" and form.get("autonomy") == "suggests":
            p.append(f"tool {t}: a write tool, but the autonomy is 'suggests'")
        elif by_id[t]["flags"]:
            p.append(f"tool {t}: flagged ({', '.join(by_id[t]['flags'])}); hold it back or say why in review.notes")
    if (form.get("intake") or {}).get("decision") not in ("refuse", "wait", "register reads only", "register"):
        p.append("intake.decision: refuse, wait, register reads only, or register")
    todo = [k for k, v in {**form, **(form.get("long_form") or {})}.items() if isinstance(v, str) and "TODO" in v]
    if todo:
        p.append(f"still TODO: {', '.join(todo)}")
    review = form.get("review") or {}
    if not review.get("by") or not review.get("notes"):
        p.append("review: a person signs the decision (review.by) and writes why (review.notes)")
    return p
