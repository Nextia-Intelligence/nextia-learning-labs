"""python -m intake COMMAND: review public MCP servers for registration, from published information only.

    verify                      check the fixed data against data/SHA256SUMS
    coverage                    what the registry's entries publish, over all of them
    search WORD                 every entry whose name, title or description has WORD, by namespace
    show ID                     one server: the registry entry and the catalog entries that match it
    answer ID [--sources S,..]  the twelve questions, answered from registry, catalog and/or vendor
    compare                     the four reviewed servers, answered from one, two and three sources
    tools ID                    the published tools, each with its kind and why
    lists ID                    the catalog's tool list against the vendor's: how many names they share
    draft ID [--out FILE]       a draft registration (YAML) with the decision and the unknowns
    check [FILE ...]            the course's registry checks and this case study's checks (default: registrations/);
                                --course-only: the course's registry checks alone
    gateway                     the tool gateway's list of tools (reads and writes) for the registered servers
    review NAME                 end to end for one server: answers, tools, decision, draft, checks
    fetch NAME                  the live registry's entry for NAME, compared with the fixed copy (needs the network)

ID is a request in requests.yaml (stripe-mcp) or a server name of the registry (com.stripe/mcp).
"""

import argparse
import collections
import json
import sys
import urllib.parse
import urllib.request
from pathlib import Path

import yaml

from estate.registry import check_form, read_form
from intake import data
from intake.decide import classify, intake_problems, propose
from intake.questions import QUESTIONS, SOURCES, answers, catalog_matches, namespace, score

REVIEWED = ["stripe-mcp", "shippo-mcp", "sentry-mcp", "notion-mcp"]


def pct(n: int, total: int) -> str:
    return f"{n:,} ({100 * n / total:.1f}%)"


def cmd_verify(_):
    files = data.verify()
    print(f"{len(files)} data files match data/SHA256SUMS. When the registry copy was made: data/registry/FETCHED.")


def cmd_coverage(_):
    reg = data.registry()
    n = len(reg)
    c = collections.Counter()
    for s in reg:
        c["repository"] += bool(s["repository"])
        c["packages"] += bool(s["packages"])
        c["remotes"] += bool(s["remotes"])
        c["remote only"] += bool(s["remotes"]) and not s["packages"]
        c["pinned package"] += any(p.get("version") for p in s["packages"])
        c["secret setting"] += any(e["secret"] for p in s["packages"] for e in p["env"])
        c["tools"] += bool(s["publisher_tools"])
        c["github"] += s["name"].startswith("io.github.")
        c["deprecated"] += s["status"] == "deprecated"
    print(f"Official MCP Registry, latest entries: {n:,} (the fixed copy in data/registry/)")
    print(f"  names a code repository          {pct(c['repository'], n)}")
    print(f"  a package to run on our machine  {pct(c['packages'], n)}")
    print(f"    with an exact version          {pct(c['pinned package'], n)}")
    print(f"    with a setting marked secret   {pct(c['secret setting'], n)}")
    print(f"  a hosted address                 {pct(c['remotes'], n)}")
    print(f"    hosted only (nothing to pin)   {pct(c['remote only'], n)}")
    print(f"  a list of tools (publisher's)    {pct(c['tools'], n)}")
    print(f"  namespace is a GitHub account    {pct(c['github'], n)}")
    print(f"  status deprecated                {pct(c['deprecated'], n)}")
    print("No entry has a field for: the licence, the data returned, read or write per tool, the data kept.")


def cmd_search(a):
    word = a.word.lower()
    hits = [s for s in data.registry()
            if word in s["name"].lower() or word in (s["title"] or "").lower() or word in (s["description"] or "").lower()]
    by_ns = collections.Counter(namespace(s["name"]) for s in hits)
    print(f"{len(hits)} entries mention '{a.word}', in {len(by_ns)} namespaces.")
    domain_hits = [ns for ns in by_ns if ns.startswith("domain ") and (ns.endswith(f"{word}.com") or
                                                                        ns.endswith(f"{word}.io"))]
    for ns, k in by_ns.most_common(a.top):
        print(f"  {k:>4}  {ns}")
    if len(by_ns) > a.top:
        print(f"  ...   {len(by_ns) - a.top} more namespaces")
    print("Namespaces on a domain with that word: " + (", ".join(domain_hits) if domain_hits else "none"))


def cmd_show(a):
    rid, rec = data.find(a.id)
    print(json.dumps(rec, indent=2, ensure_ascii=False))
    matches = catalog_matches(rec)
    print(f"Catalog entries that match: {len(matches)}")
    for c, how in matches:
        print(f"  {c['name']}: {how} ({c['remote'] or c['image']}){' - tool list kept' if c['tools_json'] else ''}")
    req = data.requests().get(rid) if rid else None
    word = req["vendor_domain"].split(".")[0] if req else rec["name"].split("/")[0].split(".")[-1]
    same_word = [c["name"] for c in data.catalog() if word in c["name"] and c not in [m for m, _ in matches]]
    if same_word:
        print(f"  with '{word}' in the name but not this server: {', '.join(same_word)}")


def print_answers(ans):
    for k, q, block in QUESTIONS:
        a = ans[k]
        mark = {"yes": "yes   ", "partly": "partly", "no": "-     "}[a.status]
        print(f"{mark}  {q}{' *' if block else ''}")
        if a.status != "no":
            print(f"        {a.answer}")
    yes, partly, blocking = score(ans)
    print(f"Answered {yes} of 12 ({partly} partly). Unanswered questions that block a decision (*): "
          f"{', '.join(blocking) if blocking else 'none'}")


def cmd_answer(a):
    rid, rec = data.find(a.id)
    sources = tuple(a.sources.split(","))
    print(f"{rec['name']} {rec['version']}, from: {', '.join(sources)}")
    print_answers(answers(rec, rid, sources))


def cmd_compare(_):
    levels = [("registry",), ("registry", "catalog"), ("registry", "catalog", "vendor")]
    print(f"{'server':<14}{'registry':>10}{'+catalog':>10}{'+vendor':>10}   still blocking with all three")
    totals = [0, 0, 0]
    for rid in REVIEWED:
        _, rec = data.find(rid)
        row = []
        for i, lv in enumerate(levels):
            yes, _, blocking = score(answers(rec, rid, lv))
            row.append(yes)
            totals[i] += yes
        print(f"{rid:<14}{row[0]:>10}{row[1]:>10}{row[2]:>10}   {', '.join(blocking) or 'none'}")
    print(f"{'all four':<14}{totals[0]:>10}{totals[1]:>10}{totals[2]:>10}   (of 48 answers)")


def cmd_tools(a):
    rid, rec = data.find(a.id)
    tools, where = classify(rid, rec)
    if not tools:
        print(f"{rec['name']}: no published tool list (registry, catalog and vendor notes checked).")
        return
    kinds = collections.Counter(t["kind"] for t in tools)
    print(f"{rec['name']}: {len(tools)} tools, from the {where} list | " +
          ", ".join(f"{k} {v}" for k, v in sorted(kinds.items())))
    for t in tools:
        flags = f"  [{', '.join(t['flags'])}]" if t["flags"] else ""
        print(f"  {t['kind']:<8} {t['id']:<44} {t['why']}{flags}")


def cmd_lists(a):
    rid, rec = data.find(a.id)
    note = data.vendor(rid) if rid else None
    vendor_names = {t["name"] for t in (note or {}).get("tools") or []}
    found = False
    for c, how in catalog_matches(rec):
        cat = data.catalog_tools(c["name"])
        if cat is None:
            continue
        found = True
        names = {t["name"] for t in cat}
        both = sorted(names & vendor_names)
        print(f"catalog {c['name']} ({how}): {len(names)} tools | vendor: {len(vendor_names)} tools | "
              f"in both: {len(both)}{' (' + ', '.join(both) + ')' if both else ''}")
    if not found:
        print(f"{rec['name']}: no catalog tool list to compare with.")


def cmd_draft(a):
    p = propose(a.id)
    text = yaml.safe_dump(p["form"], sort_keys=False, allow_unicode=True, width=110)
    header = (f"# Draft registration from published information only ({p['form']['from']}).\n"
              f"# Proposed by python -m intake draft: a person reviews it, changes it and signs it (review: by, notes).\n")
    if a.out:
        Path(a.out).write_text(header + text, encoding="utf-8")
        print(f"Wrote {a.out}: decision '{p['decision']}' ({p['why']})")
    else:
        print(header + text, end="")


def cmd_check(a):
    files = [Path(f) for f in a.files] or sorted(data.REGISTRATIONS.glob("*.yaml"))
    if not files:
        print("No forms in registrations/ yet. Write one with: python -m intake draft ID --out registrations/ID.yaml")
        return 1
    bad = 0
    for f in files:
        form = read_form(f)
        decision = (form.get("intake") or {}).get("decision", "?")
        registry = check_form(form, today=data.TODAY)
        agrees = decision == "refuse" and bool(registry)   # a refused form: the registry refuses it too
        problems = [] if agrees else [f"[registry] {x}" for x in registry]
        if not a.course_only:
            problems += [f"[intake] {x}" for x in intake_problems(form)]
        if problems:
            bad += 1
            print(f"{f.name}: {len(problems)} problem(s)")
            for x in problems:
                print(f"  - {x}")
        else:
            also = "; the course's registry refuses it too" if agrees else ""
            print(f"{f.name}: complete ({form['risk_tier']} risk, {len(form['tools'])} tool(s), "
                  f"decision: {decision}{also})")
    return 1 if bad else 0


def cmd_gateway(_):
    """The tool gateway's list (config/tools.yaml in the course project) for the registered servers."""
    servers = {}
    for f in sorted(data.REGISTRATIONS.glob("*.yaml")):
        form = read_form(f)
        if not str((form.get("intake") or {}).get("decision", "")).startswith("register"):
            continue
        rec = data.registry_by_name()[form["from"].split(": ", 1)[1].rsplit(" ", 1)[0]]
        by_id = {t["id"]: t for t in classify(form["id"], rec)[0]}
        tools = {}
        for t in form["tools"]:
            name = by_id[t]["name"]
            entry = {"kind": "read" if by_id[t]["kind"] == "read" else "write"}
            if t.split(".", 1)[1] != name:
                entry["name"] = name   # the server's own name, when the platform's ID differs
            tools[t.split(".", 1)[1]] = entry
        srv = {"about": f"{form['name']}, registered as {form['id']} ({form['from']})"}
        npm = [p for p in rec["packages"] if p["type"] == "npm" and p.get("version")]
        if npm and "npm package" in form["name"]:
            srv["command"] = ["npx", "-y", f"{npm[0]['identifier']}@{npm[0]['version']}",
                              *form["intake"].get("run_args", [])]
        else:
            srv["url"] = rec["remotes"][0]["url"]   # hosted: the course's tool gateway starts stdio servers only
        srv["tools"] = tools
        servers[form["tools"][0].split(".", 1)[0]] = srv
    print("# For config/tools.yaml of the course project: the platform's own list of reads and writes.")
    print("# 'name' is the server's own tool name where the platform's ID differs; 'url' marks a hosted server.")
    print("# The course's tool gateway reads neither yet: it starts stdio servers and calls tools by their ID.")
    print(yaml.safe_dump({"servers": servers}, sort_keys=False, width=110, default_flow_style=None), end="")


def cmd_review(a):
    p = propose(a.name)
    rec = p["record"]
    print(f"== {rec['name']} {rec['version']} ({rec.get('title') or ''})")
    print(f"Request: {p['request']['purpose'] if p['request'] else 'none in requests.yaml'}")
    print("-- The twelve questions, from the registry, the catalog and the vendor notes")
    print_answers(p["answers"])
    print(f"-- Tools: {len(p['tools'])} published" + (f"; allowed: {len(p['form']['tools'])}" if p["tools"] else ""))
    print(f"-- Risk tier: {p['tier']} ({'; '.join(p['tier_reasons'])}); data class {p['data_class']}")
    print(f"-- Decision: {p['decision']}: {p['why']}")
    problems = check_form(p["form"], today=data.TODAY)
    print("-- The course's registry checks on the draft: " + ("complete" if not problems else "; ".join(problems)))
    if not p["request"]:
        print("   (no request in requests.yaml: add one to fill in the owner, the team, the purpose and the users)")
    print("-- Still unknown after the sources we read: " + "; ".join(p["form"]["intake"]["unknowns"]))


def cmd_fetch(a):
    url = "https://registry.modelcontextprotocol.io/v0/servers/" + urllib.parse.quote(a.name, safe="") + \
          "/versions/latest"
    req = urllib.request.Request(url, headers={"User-Agent": "mcp-intake (Nextia Learning case study)"})
    with urllib.request.urlopen(req, timeout=30) as r:
        live = json.load(r)
    s = live.get("server", live)
    fixed = data.registry_by_name().get(a.name)
    print(f"live: {s['name']} {s.get('version')} | fixed copy: {fixed['version'] if fixed else 'not in the copy'}")
    if fixed and s.get("version") != fixed["version"]:
        print("The live entry has another version: review the new one before you change the registration.")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m intake", description=__doc__.splitlines()[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("verify")
    sub.add_parser("coverage")
    s = sub.add_parser("search")
    s.add_argument("word")
    s.add_argument("--top", type=int, default=8)
    sub.add_parser("show").add_argument("id")
    s = sub.add_parser("answer")
    s.add_argument("id")
    s.add_argument("--sources", default=",".join(SOURCES))
    sub.add_parser("compare")
    sub.add_parser("tools").add_argument("id")
    sub.add_parser("lists").add_argument("id")
    s = sub.add_parser("draft")
    s.add_argument("id")
    s.add_argument("--out")
    s = sub.add_parser("check")
    s.add_argument("files", nargs="*")
    s.add_argument("--course-only", action="store_true", help="only the course project's registry checks")
    sub.add_parser("gateway")
    sub.add_parser("review").add_argument("name")
    sub.add_parser("fetch").add_argument("name")
    a = ap.parse_args(argv)
    try:
        return globals()[f"cmd_{a.cmd}"](a) or 0
    except (KeyError, data.DataError) as e:
        print(f"error: {e.args[0] if e.args else e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
