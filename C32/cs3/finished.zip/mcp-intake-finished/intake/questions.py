"""The twelve questions a registration of someone else's MCP server needs answered, and what each source answers.

A source answers a question with a status: `yes` (published, and enough to act on), `partly` (published, but not
enough to act on) or `no` (not published there). Three sources, from the cheapest to the most work:

    registry   the official MCP Registry's entry (computed from data/registry/)
    catalog    a second catalog, Docker's MCP catalog, matched by address or repository (computed from data/catalog/)
    vendor     the vendor's own documentation and source code (data/vendor/<id>.yaml: notes that a person wrote)
"""

from dataclasses import dataclass
from urllib.parse import urlparse

from intake import data

QUESTIONS = [  # key, question, blocks a decision when unknown
    ("publisher", "Who publishes it, and is that checked?", True),
    ("code", "Where is its code, at which version?", False),
    ("licence", "Under which licence or terms?", False),
    ("pin", "Can we pin the exact version we reviewed?", False),
    ("runs", "Where does it run: our machine or the vendor's?", True),
    ("credential", "Which credential does it need?", True),
    ("tools", "Which tools does it have?", True),
    ("kinds", "Which tools read and which write?", False),
    ("data", "Which data do its tools return?", True),
    ("other_services", "Which other services or models does it contact?", False),
    ("stable", "Can its tools change without a new version?", False),
    ("kept", "What does the vendor keep, and for how long?", False),
]
KEYS = [k for k, _, _ in QUESTIONS]
SHORT = {"publisher": "who publishes it", "code": "where its code is", "licence": "its licence",
         "pin": "whether we can pin it", "runs": "where it runs", "credential": "which credential it needs",
         "tools": "which tools it has", "kinds": "which tools write", "data": "which data its tools return",
         "other_services": "what else it contacts", "stable": "whether its tools change",
         "kept": "what the vendor keeps"}
SOURCES = ("registry", "catalog", "vendor")


@dataclass
class Answer:
    status: str          # yes | partly | no
    answer: str
    source: str = ""     # where it is written


def namespace(name: str) -> str:
    """com.stripe/mcp -> 'domain stripe.com'; io.github.getsentry/sentry-mcp -> 'GitHub account getsentry'."""
    ns = name.split("/", 1)[0]
    if ns.startswith("io.github."):
        return f"GitHub account {ns.removeprefix('io.github.')}"
    return "domain " + ".".join(reversed(ns.split(".")))


def _norm(url: str | None) -> str:
    if not url:
        return ""
    u = urlparse(url if "://" in url else "https://" + url)
    return (u.netloc.lower() + u.path.rstrip("/")).removesuffix(".git")


def catalog_matches(rec: dict) -> list[tuple[dict, str]]:
    """The catalog entries that are the same server: the same address, the same repository, or the same host only."""
    remotes = {_norm(r["url"]) for r in rec.get("remotes") or []}
    hosts = {r.split("/", 1)[0] for r in remotes}
    repo = _norm(rec.get("repository"))
    out = []
    for c in data.catalog():
        if c["remote"] and _norm(c["remote"]) in remotes:
            out.append((c, "the same address"))
        elif repo and c["source"] and _norm(c["source"]) == repo:
            out.append((c, "the same repository"))
        elif c["remote"] and _norm(c["remote"]).split("/", 1)[0] in hosts:
            out.append((c, "the same host, another address"))
    order = ["the same address", "the same repository", "the same host, another address"]
    return sorted(out, key=lambda m: order.index(m[1]))


def from_registry(rec: dict) -> dict[str, Answer]:
    src = "registry entry " + rec["name"]
    a = {k: Answer("no", "not in the registry entry", src) for k in KEYS}
    a["publisher"] = Answer("yes", f"{namespace(rec['name'])}: the registry checks that the publisher controls it", src)
    if rec.get("repository"):
        a["code"] = Answer("partly", f"{rec['repository']} (no commit or tag in the entry)", src)
    pinned = [f"{p['type']} {p['identifier']} {p['version']}" for p in rec["packages"] if p.get("version")]
    pinned += [f"{p['type']} {p['identifier']} (an image tag; a digest pins it exactly)" for p in rec["packages"]
               if not p.get("version") and p["type"] == "oci" and ":" in p["identifier"].rsplit("/", 1)[-1]]
    if pinned:
        a["pin"] = Answer("yes", ", ".join(pinned), src)
    elif rec["remotes"] and not rec["packages"]:
        a["pin"] = Answer("yes", f"no: hosted only; the entry's version {rec['version']} is a label, not something we "
                                 "can pin", src)
    where = []
    if rec["packages"]:
        where.append("on our machine: " + ", ".join(f"{p['type']} {p['identifier']} ({p['transport']})"
                                                    for p in rec["packages"]))
    if rec["remotes"]:
        where.append("hosted: " + ", ".join(f"{r['url']} ({r['type']})" for r in rec["remotes"]))
    if where:
        a["runs"] = Answer("yes", "; ".join(where), src)
    secrets = [e["name"] for p in rec["packages"] for e in p["env"] if e["secret"]]
    headers = [h for r in rec["remotes"] for h in r["headers"]]
    if secrets:
        a["credential"] = Answer("yes", "secret settings: " + ", ".join(secrets) + " (hosted: not stated)"
                                 if rec["remotes"] else "secret settings: " + ", ".join(secrets), src)
    elif headers:
        a["credential"] = Answer("partly", "request headers: " + ", ".join(headers), src)
    if rec.get("publisher_tools"):
        a["tools"] = Answer("partly", f"{rec['publisher_tools']} tools in the publisher's own notes; the registry "
                                      "does not check them", src)
    return a


def from_catalog(rec: dict) -> dict[str, Answer]:
    a = {k: Answer("no", "no matching catalog entry") for k in KEYS}
    matches = [(c, how) for c, how in catalog_matches(rec) if how != "the same host, another address"]
    if not matches:
        return a
    a = {k: Answer("no", "not in the catalog entry") for k in KEYS}
    c, how = matches[0]
    src = f"catalog entry {c['name']} ({how})"
    if c["source"] and c["commit"]:
        a["code"] = Answer("yes", f"{c['source']} at commit {c['commit'][:12]}", src)
    if c["image"] and c["commit"]:
        a["pin"] = Answer("partly", f"image {c['image']}, built from commit {c['commit'][:12]}", src)
    a["runs"] = Answer("yes", f"hosted: {c['remote']}" if c["remote"] else f"on our machine: image {c['image']}", src)
    if c["secrets"] or c["oauth"]:
        parts = (["secrets: " + ", ".join(c["secrets"])] if c["secrets"] else []) + (["OAuth"] if c["oauth"] else [])
        a["credential"] = Answer("yes", "; ".join(parts), src)
    tools = data.catalog_tools(c["name"])
    if tools:
        a["tools"] = Answer("yes", f"{len(tools)} tools in the catalog's list", src)
    if c["allow_hosts"]:
        a["other_services"] = Answer("yes", "network: " + ", ".join(c["allow_hosts"]), src)
    if c["dynamic_tools"]:
        a["stable"] = Answer("yes", "yes: the catalog marks the tool list as dynamic", src)
    return a


def from_vendor(rid: str | None) -> dict[str, Answer]:
    note = data.vendor(rid) if rid else None
    if not note:
        return {k: Answer("no", "nobody has read the vendor's pages yet") for k in KEYS}
    out = {}
    for k in KEYS:
        v = note["answers"][k]
        s = note["sources"].get(v["source"]) if v.get("source") else None
        out[k] = Answer(v["status"], v["answer"], s["url"] if s else "")
    return out


def answers(rec: dict, rid: str | None, sources=SOURCES) -> dict[str, Answer]:
    """For each question, the best answer of the chosen sources (yes beats partly beats no; the first source wins)."""
    got = {"registry": from_registry(rec), "catalog": from_catalog(rec), "vendor": from_vendor(rid)}
    rank = {"yes": 2, "partly": 1, "no": 0}
    best = {}
    for k in KEYS:
        best[k] = max((got[s][k] for s in sources), key=lambda x: rank[x.status])
    return best


def score(ans: dict[str, Answer]) -> tuple[int, int, list[str]]:
    """(answered, partly, blocking questions still unanswered)."""
    yes = sum(a.status == "yes" for a in ans.values())
    partly = sum(a.status == "partly" for a in ans.values())
    blocking = [k for k, _, b in QUESTIONS if b and ans[k].status != "yes"]
    return yes, partly, blocking
