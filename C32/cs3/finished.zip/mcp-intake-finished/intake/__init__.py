"""Review public MCP servers for registration: published information in, a draft registration out."""
