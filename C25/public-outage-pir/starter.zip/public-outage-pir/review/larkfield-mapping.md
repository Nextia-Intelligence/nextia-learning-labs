# What PIR-EXT-001 means for Larkfield's ticket service

Owner: <name>. Sources: `PIR-EXT-001`, the course project at the end of Module 6
(`operations/alerts.toml`, `operations/runbooks/provider-outage.md`, `operations/slos.toml`) and
the course's saved practice outage (`outage.jsonl.gz`).

## 1. The dependency we share in kind

<Which part of the outage is like Larkfield's dependency on its hosted model provider? Which two
facts of the report matter most for us, and why?>

## 2. Which of our alerts and runbooks would fire

| Alert | Fires? | When | Runbook |
|---|---|---|---|
| | | | |

<Which alerts would not fire, and why? Where is the gap?>

## 3. Our runbook against an outage of the same length

| | Value | How |
|---|---|---|
| Tickets during the outage | | |
| Tickets that wait more than 10 minutes | | |
| Of those, tickets that need a person | | |
| The draft SLO's budget for a week | | |
| One outage uses | | |

## 4. Options, one measure

Measure: <one number that you compare for every option>.

| Option | <the measure> | <a second number> | What it costs |
|---|---|---|---|
| A. The runbook as written (baseline) | | | |
| B. | | | |
| C. | | | |

## 5. The one change we make

<The option, why, and what it does not fix.>

| Action | Owner | Done when |
|---|---|---|
| | | |
