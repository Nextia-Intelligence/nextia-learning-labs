# PIR-EXT-001: <what failed, and what customers saw, in one line>

A post-incident review of a **published** incident, in the format of our own reviews
(`operations/reviews/PIR-001-prompt-v3.md` in the course project). It blames no person. We did
not see this incident ourselves: every fact and number comes from the reports below, and each
row of `data/<name>.csv` cites its report. Where we infer something that no report says, we
write "our reading".

| | |
|---|---|
| Reports | <publisher, title, link> |
| Their severity | <the severity or priority the report gives> |
| Our severity | <SEV-1 to SEV-4 on our scale (operations/slos.toml), and why> |
| Owner of this review | <name> |
| People | <who read it with you, and their part> |
| Status | <read; actions open or done> |

## Summary

<Three to five sentences: what changed, what failed, who was affected, for how long, what fixed it.>

## What the reports show

<The impact in numbers, each with the report's own measure (for example "90.22% of requests
failed" or "error rate peaked at 97%"). Say what each number counts.>

## Timeline (UTC)

| When | Who | What |
|---|---|---|
| | | |

<Durations: say which two events each duration counts between.>

## The response, section by section of a runbook

| Runbook section | What the reports show |
|---|---|
| Detection | |
| Triage | |
| Mitigation | |
| Escalation | |
| Recovery checks | |

## Causes and contributing conditions

1. **The cause:** <the change or failure that started it>
2. <a condition that made it worse or longer>

## Actions (each with an owner)

| Action | Owner | Status in the report |
|---|---|---|
| | | |

## How we know it is fixed

<What evidence of recovery the reports give, and what evidence is missing.>
