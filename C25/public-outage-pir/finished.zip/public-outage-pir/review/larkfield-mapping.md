# What PIR-EXT-001 means for Larkfield's ticket service

Owner: Kwame. Read with Amira, Grace, Priya and Mei. Sources: `PIR-EXT-001` (the reports'
facts), the course project at the end of Module 6 (`operations/alerts.toml`,
`operations/runbooks/provider-outage.md`, `operations/slos.toml`) and the course's saved practice
outage (`outage.jsonl.gz`: a 5-minute provider outage that we caused on purpose).

## 1. The dependency we share in kind

Cloudflare's products read their configuration from one store, and that store depended on an
outside cloud provider. Larkfield's triage step depends on **one hosted model provider**: every
ticket needs one call to it before a team, a needs-a-person decision and a draft exist.

Two facts of the report matter most for us:

- **Workers AI failed every inference request**, because it reads its routing configuration
  from Workers KV. A model service can fail even when its models are fine.
- **AI Gateway failed up to 97% of requests.** A gateway sits in front of model providers, and
  people use it to switch between them. It failed because of its own configuration store. A
  fallback that shares a dependency with the thing it protects fails with it.

We cannot see our provider's own dependencies, as Cloudflare's customers could not see the cloud
provider behind Workers KV. So we plan for a long outage of the provider, whatever its cause.

## 2. Which of our alerts and runbooks would fire

From the practice outage (Grafana rules; the `ops alerts` rules on the saved file agree within a
fraction of a minute):

| Alert | Fires? | When | Runbook |
|---|---|---|---|
| `provider-circuit-open` (SEV-2, Kwame) | yes | 0.85 min after the outage began | provider-outage.md |
| `drafts-late` (SEV-2, Amira) | yes | 3.28 min | provider-outage.md |
| `draft-fast-burn` | **no** | it counts finished tickets, and none finish | (bad-release.md) |
| `accept-fast-burn` | no | the API accepts every ticket (0 refused) | (tickets-refused.md) |
| `no-answer`, `cost-over-budget`, `triage-slow` | no | no answers, no cost | |

So detection is fast: under a minute, against Cloudflare's 13 minutes to the first alert. That
is easier for us, because we have one dependency and a breaker that watches it.

**The gap is in the SLOs, not in the alerts.** The draft SLO (a valid draft within 10 minutes,
99% of tickets) breaks for every ticket that waits more than 10 minutes. No alert counts those
tickets during the outage: `drafts-late` says "late", and `ops slo` shows the damage afterwards.

## 3. Our runbook against a Cloudflare-length outage

The runbook was written for, and tested on, a 5-minute outage: the queue peaked at 315 tickets,
the oldest waited 354 s, and the draft SLO held. A 2 h 36 min outage is different. At
Larkfield's average of 822 tickets a day (0.571 a minute; an average, so real peaks are higher):

| | Value | How |
|---|---|---|
| Tickets during the outage | about 89 | 0.571 × 156 |
| Tickets that wait more than 10 minutes | about 83 | 0.571 × (156 − 10) |
| Of those, tickets that need a person | about 21 | 83 × 25.13% (the normal week's share) |
| The draft SLO's budget for a week | 57.5 | 1% of 5,754 |
| One outage uses | 145% of the week's budget | 83 ÷ 57.5 |

The runbook's mitigation is "do nothing to the workers" and "agents read the queue for words such
as fire, smoke, burn, child". The first is right: the breaker gives jobs back without spending
attempts, and the tickets are safe in the queue. The second is the only protection for the
**about 21 tickets that need a person**, and it finds only the tickets with those words. A
needs-a-person ticket that reaches nobody is SEV-1 on our scale.

## 4. Three options, one measure

Measure: **needs-a-person tickets that wait more than 10 minutes before they reach the agents'
queue** (a person is told), in
a provider outage of 2 h 36 min at the average rate. We also show what each option costs.

| Option | Needs-a-person tickets that wait > 10 min | Tickets without a draft | What it costs |
|---|---|---|---|
| A. The runbook as written (baseline) | about 21, unless the hand scan finds them | about 83 | nothing new |
| B. A second model provider, switched automatically | 0 if it is truly independent; about 21 if it shares a dependency | 0, or about 83 | a second contract; the other model must pass our release gate first (our evidence is for one model); we cannot check its hidden dependencies |
| C. **Person mode:** when the breaker has been open for 5 minutes, every waiting and new ticket goes to a person, until the breaker closes | 0 (each waits at most about 5 minutes for the switch) | about 89 (no drafts at all) | agents sort about 89 tickets by hand, about 67 more than usual; every ticket gets priority 1, so the hand scan for safety words stays |

A second model at the **same** provider is not option B: it shares every dependency of the first
one.

## 5. The one change we make

**Option C, person mode after 5 minutes of an open breaker.** It needs nothing outside our own
service, it uses the fallback that the service already has (`TRIAGE_FALLBACK=person`), and it
protects the journey with no error budget: safety. It does not save the draft SLO; nothing that
we control can, while the provider is down.

| Action | Owner | Done when |
|---|---|---|
| The worker sends every waiting and new ticket to a person once the breaker has been open for 5 minutes, and stops when it closes | Amira | a practice outage of 20 minutes shows 0 needs-a-person tickets waiting more than 10 minutes |
| The runbook says so, with what agents see and how long it may last | Amira, Grace | `provider-outage.md` updated (see `provider-outage-runbook-change.md`) |
| Grace's team plans for about 90 extra tickets sorted by hand in a long outage | Grace | a staffing note in the service brief |
| Option B, later: a second provider only after the gate passes for its model and its dependencies are asked for in the contract | Kwame | an experiment record, not a change now |

Open question for the next review: should the runbook raise an outage to SEV-1 after a fixed time
(Cloudflare raised P1 to P0 at +29 minutes), or only when a needs-a-person ticket waits?
