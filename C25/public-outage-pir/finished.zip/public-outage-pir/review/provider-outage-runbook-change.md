# Runbook: the AI provider fails (proposed change after PIR-EXT-001)

The course project's `operations/runbooks/provider-outage.md`, with the one change of
`larkfield-mapping.md`. Lines marked **(new)** are the change; the rest is unchanged. The change
is proposed, not built: the worker does not have person mode yet (owner: Amira).

**Alerts:** `provider-circuit-open` (SEV-2), `drafts-late` (SEV-2), `triage-slow` (SEV-3).
**Owner:** Kwame (the provider contract) with Amira (the service). **Customer message:** Grace.

## Detection

- The circuit breaker is open: the provider failed 5 calls in a row (5xx or timeout).
- The oldest queued ticket waits more than 2 minutes.
- Dashboard *Ticket service: overview*: "Provider circuit" shows OPEN; the queue grows.

## Triage (5 minutes)

1. Is it the provider or us? `curl http://127.0.0.1:8300/admin/stats` (practice) or the
   provider's status page. Look at the error types in "Provider calls per minute, by error".
   **(new)** The provider's status page can be late or down with the provider: Google's first
   post came about 1 hour after its outage began. Trust our breaker first.
2. Are tickets lost? No: the API still accepts tickets (202); they wait in the queue. Check
   `GET /v1/queue` and the "Tickets accepted" SLI.
3. How long until the draft SLO breaks? A ticket must get its draft within 10 minutes.

## Mitigation

- Do nothing to the workers: the breaker stops the calls, jobs go back to the queue without
  losing an attempt, and they continue when the provider answers again.
- **(new) Person mode.** When the breaker has been open for 5 minutes, the worker sends every
  waiting and new ticket to a person (`needs_human` true, priority 1, outcome `sent_to_person`),
  with no team and no draft. It stops when the breaker closes. Agents now sort these tickets by
  hand; in an outage of 2.5 hours, expect about 90 tickets at our average rate.
- Tell customers: `GET /v1/status` shows the delayed message on the website automatically
  ("Your ticket is saved, and nothing is lost. Our replies take longer than usual ...").
- Safety tickets do not wait for the assistant: agents read the queue for words such as
  *fire*, *smoke*, *burn*, *child* (Grace's team, by hand) while the provider is down.
  **(new)** In person mode every ticket has priority 1, so this scan is how safety tickets come
  first.
- Do not raise retries or timeouts during an outage: that sends more calls to a provider
  that cannot answer.
- **(new)** Do not switch to another model or provider during the outage. A model that has not
  passed the release gate is an unreviewed release, and a router or a second model at the same
  provider can share the failure (Cloudflare's AI Gateway failed up to 97%).

## Escalation

- After 15 minutes: Kwame opens a ticket with the provider and asks for a time to recovery.
- After 30 minutes: Grace puts a message on the help page and the support phone line.
- **(new)** Any needs-a-person ticket that waited more than 10 minutes before person mode: SEV-1.
  Grace's team reads it first.

## Recovery checks (the evidence)

- [ ] The breaker is closed: `python -m ops incident FILE` shows "circuit closed".
- [ ] **(new)** Person mode has stopped: new tickets get a team and a draft again.
- [ ] The queue drains: `GET /v1/queue` shows `oldest_queued_seconds` under 120.
- [ ] Drafts are valid again: the draft SLI is back above 99% in the last 5 minutes.
- [ ] No dead letters were created, or each one is retried: `POST /v1/jobs/{id}/retry`.
- [ ] `GET /v1/status` says "ok".
- [ ] **(new)** The tickets of person mode are counted in the post-incident review: how many, how
  long the first waited, and how many needed a person.
