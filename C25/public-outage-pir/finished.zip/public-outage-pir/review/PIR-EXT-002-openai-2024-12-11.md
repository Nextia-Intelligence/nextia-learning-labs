# PIR-EXT-002: a telemetry rollout took down a model provider's clusters (11 December 2024)

The same method on new input: a short review of a published incident, in our format. It blames no
person. Every fact comes from the report below; each row of `data/openai-2024-12-11.csv` cites it.
Times are UTC (the report writes PST, UTC−8).

| | |
|---|---|
| Report | OpenAI, [API, ChatGPT & Sora Facing Issues: write-up](https://status.openai.com/incidents/ctrsv3lwd797/write-up) |
| Their severity | "Full outage" on the status page |
| Our severity | SEV-1 on our scale, if it were our service: no request could be served |
| Owner of this review | Kwame |
| Status | read; mapped onto Larkfield below |

## Summary

A new telemetry service was rolled out to every Kubernetes cluster. In large clusters, it made
every node call the Kubernetes API, and the API servers were overwhelmed. DNS for service
discovery depends on them, so services could not find each other once their DNS caches expired.
All products degraded from 23:16. The fix needed the API servers that were down, so recovery took
until 03:38: **4 h 22 min**.

## Timeline (UTC)

| When | What |
|---|---|
| 10 Dec | The new telemetry service works in a staging cluster. |
| 22:23 | The change is merged; the deployment pipeline starts. |
| 22:51 | The change starts to reach the clusters (to 23:20). |
| 23:13 | Alerts fire: 3 minutes **before** customers are affected. |
| 23:16 | **Impact starts.** Root cause identified. |
| 23:27 | Engineers move traffic away from the affected clusters. |
| 23:40 | Maximum customer impact. |
| 00:36 | The first cluster recovers. |
| 01:36 | API: substantial recovery. |
| 03:38 | **Impact ends:** all clusters recovered, the API across all models. |

## The response, section by section of a runbook

| Runbook section | What the report shows |
|---|---|
| Detection | Alerts at −3 min; the cause was known at +0. |
| Triage | Fast: the change was known. |
| Mitigation | Removing the service needed the Kubernetes API, which was overloaded: three steps in parallel (smaller clusters, blocked admin API access, larger API servers). |
| Escalation | Not described. |
| Recovery checks | Cluster by cluster; some clusters stayed degraded as services downloaded resources at the same time. |

## Causes and contributing conditions

1. **The cause:** a configuration whose API load grew with the size of the cluster.
2. Staging was small, so the test could not show it; DNS caches hid the failure for about 20
   minutes, so the rollout went on.
3. The fix needed the system that had failed (the report calls it a "locked out effect").

## Actions (each with an owner)

All five are OpenAI's: phased rollouts with cluster-health monitoring, fault-injection tests,
emergency access to the API servers, decoupling the data plane from the control plane, and faster
cluster start-up.

## What it means for Larkfield

- The same alerts as PIR-EXT-001 would fire: `provider-circuit-open` and `drafts-late`.
- At our average rate, 4 h 22 min is about **150 tickets**, about **144** of them waiting more
  than 10 minutes, about **36** of them needing a person; the draft SLO would use **250%** of a
  week's budget.
- With person mode (the change of `larkfield-mapping.md`), 0 needs-a-person tickets wait more than
  10 minutes before they reach the agents' queue; agents sort about 150 tickets by hand.
- Recovery: the report's last clusters were slow because many services started at once. Our
  workers are bounded (2 workers with 8 jobs each in the practice runs), and the breaker sends one
  trial call first; in the practice outage, the queue drained in about 2 minutes after the breaker closed.
