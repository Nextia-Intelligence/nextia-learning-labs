# PIR-EXT-001: a storage service failed, and many Cloudflare products failed with it (12 June 2025)

A post-incident review of a **published** incident, in the format of our own reviews
(`operations/reviews/PIR-001-prompt-v3.md` in the course project). It blames no person. We did
not see this incident ourselves: every fact and number comes from the two reports below, and each
row of `data/cloudflare-2025-06-12.csv` cites its report and section. Where we infer something
that no report says, we write "our reading". Times are UTC; "≈" marks a time that the report
gives as "~" or "within".

| | |
|---|---|
| Reports | Cloudflare, [Cloudflare service outage June 12, 2025](https://blog.cloudflare.com/cloudflare-service-outage-june-12-2025/); Google Cloud, [incident ow5i3PPK96RduMcb1SsW](https://status.cloud.google.com/incidents/ow5i3PPK96RduMcb1SsW) (status updates, mini report, full report) |
| Their severity | Cloudflare: P1 at +14 min, P0 at +29 min |
| Our severity | SEV-1 on our scale: many customers could not be served (for example, every identity login to Access failed) |
| Owner of this review | Kwame (provider contracts) |
| People | Amira (the ticket service), Grace (customers and agents), Priya (the assistant), Mei (the database) |
| Status | read; our actions are in `larkfield-mapping.md` |

## Summary

On 12 June 2025, a quota policy with blank fields reached every region of Google Cloud within
seconds. Google's Service Control crashed in a loop, and API requests to many Google Cloud
products failed with 503 errors from 17:49. Cloudflare's Workers KV keeps its central store
partly on "a third-party cloud provider"; from 17:52, reads that missed KV's cache and every
write failed. Many Cloudflare products read their configuration from Workers KV, so they failed
too: Access, Gateway, WARP, Workers AI, AI Gateway and others. Google turned off the failing
code path (the "red button") within about 40 minutes, but its largest region took hours to
recover. Cloudflare's impact ended at 20:28, when the storage came back.

**Our reading:** Cloudflare's report does not name the third-party provider. We link the two
reports because the times match (Google's impact starts 3 minutes before Cloudflare's, and
Cloudflare recovers as Google's last region recovers) and because the press reported the link.
Neither report says it.

## What the reports show

Cloudflare, each product with its own measure (the report's words in brackets):

| Product | Impact | What the number counts |
|---|---|---|
| Workers KV | 90.22% of requests failing | requests in the incident window; the rest came from KV's cache |
| Access | 100% of identity-based logins failed | logins; service-token and IP-based logins were not affected |
| Workers AI | every inference request failed | requests, "for the duration of the incident" |
| AI Gateway | error rates peaked at 97% | requests, at the peak |
| Pages | error rate peaked at about 100% | requests, at the peak |
| Stream | error rate over 90% | requests in the window |
| D1, Durable Objects (SQLite) | error rate peaked at 22%, fell to 2% as services recovered | average error rate |
| Workers for Platforms | peak about 10% | requests |
| Workers | peak about 2% | requests |
| Images | delivery success dipped to about 97% | image deliveries |

- No data was lost, and it was not an attack (Cloudflare).
- DNS, Cache, the proxy and the WAF were not directly affected (Cloudflare).
- Google: 503 errors on external API requests of many Google Cloud and Workspace products; the
  mini report lists 76 Google Cloud products and 10 Workspace products, among them the Vertex Gemini API, Vertex AI Search and
  Document AI. Vertex AI Online Prediction (some Model Garden models) was the last to recover,
  at 18:18 PDT (01:18 UTC the next day).

## Timeline (UTC)

| When | Who | What |
|---|---|---|
| 29 May | Google | A new quota check is shipped region by region. Its failing path is not exercised and has no feature flag. |
| ≈17:45 | Google | A quota policy with blank fields is written and copied to every region within seconds. |
| 17:49 | Google | **Impact starts:** API requests fail with 503 (Service Control crashes in a loop). |
| ≈17:51 | Google | Site Reliability Engineering is triaging. |
| 17:52 | Cloudflare | **Impact starts:** new WARP device registrations fail. The WARP team declares an incident. |
| ≈17:59 | Google | Root cause identified; the red button is being prepared. |
| 18:05 | Cloudflare | Access gets an alert for a fast rise in errors; SLOs of several services alert their teams. |
| 18:06 | Cloudflare | The incidents are joined into one, with a shared cause (Workers KV). **P1.** |
| ≈18:14 | Google | The red button is ready. |
| 18:21 | Cloudflare | **P0**, as the size of the impact becomes clear. |
| ≈18:29 | Google | The red button is rolled out; small regions recover first. |
| 18:43 | Cloudflare | Access explores a move to another datastore. |
| 18:46 | Google | First post on the status page (about 1 hour after the start: the status page was down too). |
| 19:09 | Cloudflare | Gateway degrades rules that need identity or device posture. |
| 19:32 | Cloudflare | Access and Device Posture drop requests to shed load on Workers KV. |
| 19:45 | Cloudflare | Teams work on Workers KV on another datastore. |
| 19:48 | Google | All regions except us-central1 mitigated. |
| 20:23 | Cloudflare | Services start to recover; caches fill again, with errors and rate limits. |
| 20:28 | Cloudflare | **Impact ends:** SLOs are back at their level before the incident. |
| 20:49 | Google | **Impact ends** (mini report); residual impact on some products. |
| 22:00 | Cloudflare | The report is published. |
| 01:18 (13 June) | Google | Vertex AI Online Prediction fully recovered: the last product. |

**Durations.** Cloudflare's table runs from 17:52 to 20:28: **2 h 36 min**. Its text says
"2 hours and 28 minutes"; the report does not say which two events that counts between. Google's
mini report says 3 hours (17:49 to 20:49); its status page says 10:51 to 18:18 PDT (7 h 27 min,
with the residual errors). In this review, a duration is always "from impact start to impact
end", as in the table.

## The response, section by section of a runbook

| Runbook section | What the reports show |
|---|---|
| Detection | Cloudflare: a team saw its own product fail at +0 and declared an incident; the first alert came at +13, then SLO alerts in several teams. Google: triage within 2 minutes. |
| Triage | Cloudflare joined the service incidents into one at +14, once it saw the shared cause. Google found the root cause within about 10 minutes. |
| Mitigation | Google: a prepared red button turned the failing path off (ready ≈+25, rolled out ≈+40). Cloudflare could not fix the store; it reduced harm in each product: kill switches for Challenges and Turnstile (fail open), degraded Gateway rules, shed load on KV, and prepared a move to another store. |
| Escalation | Cloudflare: P1 at +14, P0 at +29. Google's first public status post at +57, late because the status page ran on the failing infrastructure. |
| Recovery checks | Cloudflare: SLOs back at their earlier level at 20:28, then monitoring "as dependent systems recover". Google: recovery region by region; us-central1 overloaded by its own restarts. |

## Causes and contributing conditions

1. **The cause (Google):** a quota policy with blank fields hit a code path without error
   handling, and the binary crashed in every region. The change "did not have appropriate error
   handling nor was it feature flag protected" (Google).
2. **Global at once (Google):** the policy data was copied to every region within seconds, so
   there was no region in which to see the failure first.
3. **A slow recovery (Google):** as tasks restarted, they overloaded the database they read (a
   "herd effect"), because Service Control had no randomized exponential backoff.
4. **One store for many products (Cloudflare):** Workers KV is a building block of many products.
   Its central store depended on one outside provider during a migration ("a gap in coverage").
5. **Fail closed (Cloudflare):** Access and Gateway refuse when they cannot read policy or
   identity. That protects customers' rules, but it turns a storage outage into failed logins.
6. **The status page shared the failure (Google):** the first public post came about 1 hour after
   the start, and customers whose monitoring ran on Google Cloud lost that signal too.

## Actions (each with an owner)

| Action | Owner | Status in the report |
|---|---|---|
| Remove the dependency of Workers KV's storage on any single provider | Cloudflare | in progress |
| Make each affected product resilient to the loss of a single dependency | Cloudflare | in progress |
| Tools to turn namespaces back on step by step after a storage incident, so caches do not overload it | Cloudflare | in progress |
| Make Service Control fail open when a check fails | Google | planned |
| Copy globally replicated data step by step, with time to detect problems | Google | planned |
| Feature flags, off by default, for every change to critical binaries | Google | planned |
| Randomized exponential backoff in all systems | Google | planned |
| Keep monitoring and status communication working when Google Cloud is down | Google | planned |

## How we know it is fixed

Cloudflare gives one number for recovery: its SLOs returned to the level before the incident.
Google gives the order of recovery by region and product. Neither report shows the evidence after
recovery (for example, error rates for the following day), and neither gives a date for its
actions. **Our reading:** a reader cannot check from outside whether the actions are done; we can
only change how much our own service depends on them.
