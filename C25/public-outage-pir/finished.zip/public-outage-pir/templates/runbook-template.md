# Runbook: <the failure, in plain words>

**Alerts:** `<alert-uid>` (SEV-n), ...
**Owner:** <name> (<what they own>). **Customer message:** <name>.

## Detection

- <How you know: the alert, the dashboard panel, what a customer sees.>

## Triage (5 minutes)

1. <The first check, with its command or link.>
2. <Are tickets lost? How long until an SLO breaks?>

## Mitigation

- <What protects customers now. What you must NOT do.>

## Escalation

- After <n> minutes: <who does what>.

## Recovery checks (the evidence)

- [ ] <A check with its command and the value that proves recovery.>
