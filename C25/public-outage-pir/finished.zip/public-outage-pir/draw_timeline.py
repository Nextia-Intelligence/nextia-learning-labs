"""Check an incident timeline (a CSV that you typed from the published reports) and draw it.

    python draw_timeline.py data/cloudflare-2025-06-12.csv
    python draw_timeline.py data/openai-2024-12-11.csv --out out

It prints three things: the checks of the CSV, the timeline in minutes from each
organization's impact start, and the phase summary (how long until detection, escalation,
mitigation, recovery and the end of the impact). Then it writes two SVG charts into the
output folder: <name>.svg (wide, one lane per organization) and <name>-narrow.svg (a list
for a phone screen).

The CSV has one row per event, with these columns:

    time_utc  the time in UTC, for example 2025-06-12T17:52Z (your conversion)
    stated    the time as the report wrote it, for example "10:49 PDT" or "within 2 minutes"
    approx    yes (the report says "~" or "within"), no, or day (only the day is known)
    org       the organization, one lane of the chart
    kind      change, trigger, impact-start, detection, diagnosis, escalation, mitigation,
              communication, impact, recovery or impact-end
    label     a short label for the chart (at most 24 characters)
    event     the event in your own words
    source    the report's URL and section

Only the Python standard library is needed (Python 3.10 or newer).
"""

import argparse
import csv
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from xml.sax.saxutils import escape

COLUMNS = ["time_utc", "stated", "approx", "org", "kind", "label", "event", "source"]
KINDS = {
    # kind: (colour, shape, legend text)
    "change": ("#4A5A76", "diamond", "change"),
    "trigger": ("#0B1A3F", "diamond", "trigger"),
    "impact-start": ("#B42318", "bar", "impact starts / ends"),
    "impact": ("#B42318", "circle", "impact"),
    "detection": ("#0054D8", "circle", "detection"),
    "diagnosis": ("#6D3FC0", "circle", "diagnosis"),
    "escalation": ("#B54708", "triangle", "escalation"),
    "mitigation": ("#0E7490", "square", "mitigation"),
    "communication": ("#4A5A76", "ring", "communication"),
    "recovery": ("#067647", "circle", "recovery"),
    "impact-end": ("#B42318", "bar", "impact starts / ends"),
}
PHASES = ["detection", "diagnosis", "escalation", "mitigation", "recovery", "impact-end"]
ZONES = {"UTC": 0, "GMT": 0, "PDT": -7, "PST": -8, "EDT": -4, "EST": -5, "CEST": 2, "CET": 1}
CLOCK = re.compile(r"(\d{1,2}):(\d{2})\s*(am|pm)?\s*(UTC|GMT|PDT|PST|EDT|EST|CEST|CET)\b", re.I)
FONT = "Inter, system-ui, -apple-system, Segoe UI, sans-serif"
INK, MUTED, GRID, BAND = "#0B1A3F", "#4A5A76", "#D5DCE8", "#FDECEA"


def parse_time(text):
    return datetime.strptime(text.strip(), "%Y-%m-%dT%H:%MZ").replace(tzinfo=timezone.utc)


def stated_utc_clock(stated):
    """The UTC clock time (hour, minute) of a stated time, or None if it cannot be checked."""
    m = CLOCK.search(stated)
    if not m:
        return None
    hour, minute = int(m.group(1)), int(m.group(2))
    ampm, zone = (m.group(3) or "").lower(), m.group(4).upper()
    if ampm == "pm" and hour != 12:
        hour += 12
    if ampm == "am" and hour == 12:
        hour = 0
    total = (hour * 60 + minute - ZONES[zone] * 60) % (24 * 60)
    return divmod(total, 60)


def load(path):
    """Read the CSV and check it. Returns (rows, problems, notes)."""
    problems, notes = [], []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        missing = [c for c in COLUMNS if c not in (reader.fieldnames or [])]
        if missing:
            return [], [f"missing columns: {', '.join(missing)}"], notes
        rows = []
        for n, row in enumerate(reader, start=2):  # line 1 is the header
            where = f"line {n}"
            try:
                row["t"] = parse_time(row["time_utc"])
            except ValueError:
                problems.append(f"{where}: time_utc {row['time_utc']!r} is not like 2025-06-12T17:52Z")
                continue
            if row["kind"] not in KINDS:
                problems.append(f"{where}: unknown kind {row['kind']!r}")
            if row["approx"] not in ("yes", "no", "day"):
                problems.append(f"{where}: approx must be yes, no or day")
            if not row["source"].startswith("https://"):
                problems.append(f"{where}: no source (a URL of the report)")
            if len(row["label"]) > 24:
                notes.append(f"{where}: label longer than 24 characters ({len(row['label'])})")
            clock = stated_utc_clock(row["stated"])
            row["checked"] = clock is not None
            if clock and clock != (row["t"].hour, row["t"].minute):
                problems.append(
                    f"{where}: stated {row['stated']!r} is {clock[0]:02d}:{clock[1]:02d} UTC, "
                    f"but time_utc says {row['t']:%H:%M}"
                )
            if row["approx"] == "no" and not clock and row["kind"] != "change":
                notes.append(f"{where}: approx is 'no', but {row['stated']!r} has no clock time to check")
            row["line"] = n
            rows.append(row)
    rows.sort(key=lambda r: (r["t"], r["line"]))
    for org in orgs_of(rows):
        starts = [r for r in rows if r["org"] == org and r["kind"] == "impact-start"]
        ends = [r for r in rows if r["org"] == org and r["kind"] == "impact-end"]
        if len(starts) != 1:
            problems.append(f"{org}: needs exactly one impact-start row (found {len(starts)})")
        if len(ends) > 1:
            problems.append(f"{org}: has {len(ends)} impact-end rows (at most one)")
        if starts and ends and ends[0]["t"] < starts[0]["t"]:
            problems.append(f"{org}: the impact ends before it starts")
    return rows, problems, notes


def orgs_of(rows):
    seen = []
    for r in rows:
        if r["org"] not in seen:
            seen.append(r["org"])
    return seen


def start_of(rows, org):
    return next((r["t"] for r in rows if r["org"] == org and r["kind"] == "impact-start"), None)


def minutes(a, b):
    return round((a - b).total_seconds() / 60)


def signed(m):
    return f"+{m}" if m >= 0 else str(m)


def signed_svg(m):
    return f"+{m}" if m >= 0 else f"\u2212{-m}"  # a true minus sign in the charts


def hm(m):
    m = abs(m)
    return f"{m // 60} h {m % 60:02d} min" if m >= 60 else f"{m} min"


def print_report(rows, problems, notes, path):
    checked = sum(r["checked"] for r in rows)
    print(f"Checks of {path}")
    n_orgs = len(orgs_of(rows))
    print(f"  {len(rows)} events, {n_orgs} organization{'s' if n_orgs > 1 else ''}: {', '.join(orgs_of(rows))}")
    print(f"  stated times converted and checked: {checked} of {len(rows)}"
          f" (the others are relative, like 'within 10 minutes', or a day)")
    print(f"  approximate times: {sum(r['approx'] == 'yes' for r in rows)}")
    for p in problems:
        print(f"  PROBLEM {p}")
    for n in notes:
        print(f"  note    {n}")
    if not problems:
        print("  no problem found")
    print()
    print("Timeline (UTC; minutes from the organization's impact start; ~ = approximate):")
    width = max(len(o) for o in orgs_of(rows))
    for r in rows:
        s = start_of(rows, r["org"])
        if not s:
            rel = "?"
        elif r["approx"] == "day":
            rel = f"{signed((r['t'].date() - s.date()).days)} d"
        else:
            rel = signed(minutes(r["t"], s))
        when = f"{r['t']:%Y-%m-%d}" if r["approx"] == "day" else f"{r['t']:%m-%d %H:%M}"
        mark = "~" if r["approx"] == "yes" else " "
        print(f"  {when:<11} {mark}{rel:>6}  {r['org']:<{width}}  {r['kind']:<13} {r['label']}")
    print()
    print("Phases (minutes from the impact start to the first event of each kind):")
    for org in orgs_of(rows):
        s = start_of(rows, org)
        if not s:
            continue
        parts = []
        for kind in PHASES:
            first = next((r for r in rows if r["org"] == org and r["kind"] == kind), None)
            if first:
                parts.append(f"{kind} {'~' if first['approx'] == 'yes' else ''}{signed(minutes(first['t'], s))}")
        print(f"  {org}: impact starts {s:%H:%M} UTC" + ("; " + ", ".join(parts) if parts else ""))
        end = next((r["t"] for r in rows if r["org"] == org and r["kind"] == "impact-end"), None)
        if end:
            print(f"  {org}: impact lasted {hm(minutes(end, s))} ({minutes(end, s)} min) by this timeline")
        last = max((r["t"] for r in rows if r["org"] == org and r["kind"] == "recovery"), default=None)
        if end and last and last > end:
            print(f"  {org}: the last recovery is {hm(minutes(last, s))} after the impact start")


# ---------- SVG ----------

def text_width(s, size=12):
    return len(s) * size * 0.56


def el(tag, attrs, body=""):
    a = " ".join(f'{k}="{escape(str(v))}"' for k, v in attrs.items())
    return f"<{tag} {a}>{body}</{tag}>" if body else f"<{tag} {a}/>"


def txt(x, y, s, size=12, color=INK, anchor="start", weight=400):
    # A white outline under the letters keeps a label readable where a line passes behind it.
    return el("text", {"x": f"{x:.1f}", "y": f"{y:.1f}", "font-size": size, "fill": color,
                       "text-anchor": anchor, "font-weight": weight, "stroke": "#FFFFFF",
                       "stroke-width": 3, "stroke-linejoin": "round", "paint-order": "stroke"}, escape(s))


def marker(x, y, kind, r=5.5):
    color, shape, _ = KINDS[kind]
    if shape == "circle":
        return el("circle", {"cx": f"{x:.1f}", "cy": f"{y:.1f}", "r": r, "fill": color})
    if shape == "ring":
        return el("circle", {"cx": f"{x:.1f}", "cy": f"{y:.1f}", "r": r - 1, "fill": "#FFFFFF",
                             "stroke": color, "stroke-width": 2})
    if shape == "square":
        return el("rect", {"x": f"{x - r + 0.5:.1f}", "y": f"{y - r + 0.5:.1f}", "width": 2 * r - 1,
                           "height": 2 * r - 1, "fill": color})
    if shape == "diamond":
        pts = f"{x:.1f},{y - r - 1:.1f} {x + r + 1:.1f},{y:.1f} {x:.1f},{y + r + 1:.1f} {x - r - 1:.1f},{y:.1f}"
        return el("polygon", {"points": pts, "fill": color})
    if shape == "triangle":
        pts = f"{x:.1f},{y - r - 1:.1f} {x + r + 1:.1f},{y + r:.1f} {x - r - 1:.1f},{y + r:.1f}"
        return el("polygon", {"points": pts, "fill": color})
    return el("rect", {"x": f"{x - 1.5:.1f}", "y": f"{y - r - 3:.1f}", "width": 3, "height": 2 * r + 6,
                       "fill": color})


def svg_doc(width, height, body):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height:.0f}" '
            f'viewBox="0 0 {width} {height:.0f}" font-family="{FONT}">'
            f'<rect width="100%" height="100%" fill="#FFFFFF"/>{body}</svg>\n')


def legend(kinds, x0, y, width):
    out, x, seen = "", x0, []
    for k in kinds:
        name = KINDS[k][2]
        if name in seen:
            continue
        seen.append(name)
        w = text_width(name) + 30
        if x + w > width - 8:
            x, y = x0, y + 22
        out += marker(x + 6, y - 4, k) + txt(x + 16, y, name, 12, MUTED)
        x += w
    return out, y


def window(rows, until):
    # The chart starts before the first impact start or trigger (the change that started it).
    starts = [r["t"] for r in rows if r["kind"] in ("impact-start", "trigger")]
    ends = [r["t"] for r in rows if r["kind"] == "impact-end"]
    lo = min(starts) - timedelta(minutes=15)
    lo = lo.replace(minute=0 if lo.minute < 30 else 30)
    hi = until or (max(ends) if ends else max(r["t"] for r in rows)) + timedelta(minutes=20)
    if hi.minute not in (0, 30):
        hi = hi.replace(minute=0) + timedelta(minutes=30 if hi.minute < 30 else 60)
    return lo, hi


def wide_svg(rows, until=None, width=960):
    lo, hi = window(rows, until)
    left, right = 118, width - 24
    span = (hi - lo).total_seconds()

    def X(t):
        return left + (t - lo).total_seconds() / span * (right - left)

    body, y = "", 18
    inside = [r for r in rows if lo <= r["t"] <= hi]
    later = [r for r in rows if r["t"] > hi and r["kind"] in ("recovery", "impact-end")]
    for org in orgs_of(rows):
        s = start_of(rows, org)
        evs = [r for r in inside if r["org"] == org]
        # Greedy rows for the labels, so that no two labels overlap.
        placed, levels = [], []
        for r in evs:
            rel = minutes(r["t"], s) if s else 0
            label = f"{r['label']} ({'≈' if r['approx'] == 'yes' else ''}{signed_svg(rel)})"
            w = text_width(label, 11.5)
            x = X(r["t"])
            x0 = min(max(x - 4, left), right - w)
            level = 0
            while level < len(levels) and any(not (x0 > b + 10 or x0 + w < a - 10) for a, b in levels[level]):
                level += 1
            if level == len(levels):
                levels.append([])
            levels[level].append((x0, x0 + w))
            placed.append((r, x, x0, level, label))
        n = max(1, len(levels))
        axis_y = y + 22 + n * 18 + 8
        end = next((r["t"] for r in rows if r["org"] == org and r["kind"] == "impact-end"), None)
        if s:
            x_end = X(min(end, hi)) if end else right
            body += el("rect", {"x": f"{X(max(s, lo)):.1f}", "y": f"{y + 18:.1f}",
                                "width": f"{max(x_end - X(max(s, lo)), 1):.1f}",
                                "height": f"{axis_y - y - 6:.1f}", "fill": BAND})
        body += txt(left - 12, axis_y + 4, org, 13, INK, "end", 600)
        body += el("line", {"x1": left, "y1": f"{axis_y:.1f}", "x2": right, "y2": f"{axis_y:.1f}",
                            "stroke": MUTED, "stroke-width": 1})
        for r, x, x0, level, label in placed:  # the lines first, so the labels lie on top
            body += el("line", {"x1": f"{x:.1f}", "y1": f"{y + 37 + level * 18:.1f}", "x2": f"{x:.1f}",
                                "y2": f"{axis_y - 6:.1f}", "stroke": GRID, "stroke-width": 1})
        for r, x, x0, level, label in placed:
            body += txt(x0, y + 34 + level * 18, label, 11.5, INK)
        for r, x, *_ in placed:
            body += marker(x, axis_y, r["kind"])
        for r in reversed(later):  # the last recovery after the chart
            if r["org"] == org:
                rel = minutes(r["t"], s) if s else 0
                note = f"later: {r['label']} {r['t']:%H:%M} UTC ({signed_svg(rel)}) \u2192"
                body += txt(right, axis_y + 18, note, 11.5, MUTED, "end")
                break
        y = axis_y + 30
    # The time axis.
    t = lo
    body += el("line", {"x1": left, "y1": f"{y:.1f}", "x2": right, "y2": f"{y:.1f}", "stroke": MUTED})
    step = 30 if span <= 6 * 3600 else 60
    while t <= hi:
        x = X(t)
        body += el("line", {"x1": f"{x:.1f}", "y1": f"{y:.1f}", "x2": f"{x:.1f}", "y2": f"{y + 5:.1f}",
                            "stroke": MUTED})
        body += txt(x, y + 19, f"{t:%H:%M}", 11.5, MUTED, "middle")
        t += timedelta(minutes=step)
    body += txt(right, y + 36, f"UTC, {lo:%d %b %Y}" + (f" to {hi:%d %b}" if hi.date() != lo.date() else ""),
                11.5, MUTED, "end")
    kinds = [k for k in KINDS if any(r["kind"] == k for r in inside)]
    leg, ly = legend(kinds, left, y + 60, width)
    return svg_doc(width, ly + 14, body + leg)


def narrow_svg(rows, until=None, width=360):
    lo, hi = window(rows, until)
    evs = [r for r in rows if lo <= r["t"] <= hi or (r["t"] > hi and r["kind"] in ("recovery", "impact-end"))]
    body, y, line_x = "", 26, 62
    multi = len(orgs_of(rows)) > 1
    body += el("line", {"x1": line_x, "y1": 18, "x2": line_x, "y2": 26 + len(evs) * 36 - 18,
                        "stroke": GRID, "stroke-width": 2})
    for r in evs:
        s = start_of(rows, r["org"])
        rel = minutes(r["t"], s) if s else 0
        day = "" if r["t"].date() == lo.date() else f" {r['t']:%d %b}"
        body += txt(line_x - 14, y + 4, f"{r['t']:%H:%M}", 12, MUTED, "end")
        if day:
            body += txt(line_x - 14, y + 17, day.strip(), 10, MUTED, "end")
        body += marker(line_x, y, r["kind"])
        body += txt(line_x + 14, y + 4, r["label"], 12.5, INK, weight=600)
        sub = f"{r['org']} · " if multi else ""
        body += txt(line_x + 14, y + 19, f"{sub}{'about ' if r['approx'] == 'yes' else ''}{signed_svg(rel)} min", 11, MUTED)
        y += 36
    body += txt(8, y + 4, "UTC; minutes from the organization's impact start", 10.5, MUTED)
    kinds = [k for k in KINDS if any(r["kind"] == k for r in evs)]
    leg, ly = legend(kinds, 8, y + 30, width)
    return svg_doc(width, ly + 14, body + leg)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("csv", type=Path)
    ap.add_argument("--out", type=Path, default=Path("out"), help="folder for the two SVG files (default: out)")
    ap.add_argument("--until", help="end of the chart, for example 2025-06-12T21:00Z (default: after the last impact end)")
    a = ap.parse_args(argv)
    rows, problems, notes = load(a.csv)
    if not rows:
        print("\n".join(problems) or f"{a.csv}: no events yet. Add one row per event of the report.")
        return 1
    print_report(rows, problems, notes, a.csv)
    if problems:
        print("\nFix the problems first; no chart was written.")
        return 1
    until = parse_time(a.until) if a.until else None
    a.out.mkdir(parents=True, exist_ok=True)
    wide, narrow = a.out / f"{a.csv.stem}.svg", a.out / f"{a.csv.stem}-narrow.svg"
    wide.write_text(wide_svg(rows, until), encoding="utf-8")
    narrow.write_text(narrow_svg(rows, until), encoding="utf-8")
    print(f"\nWrote {wide.as_posix()} and {narrow.as_posix()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
