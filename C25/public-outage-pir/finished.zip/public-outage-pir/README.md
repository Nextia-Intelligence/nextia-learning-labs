# Post-incident review of a public outage

A post-incident review (PIR) of a real, published outage, written in the format of the MLOps and
LLMOps course, and mapped onto Larkfield's ticket service. The outage: Cloudflare, 12 June 2025,
with the Google Cloud incident of the same day as the upstream cause. New input at the end: the
OpenAI outage of 11 December 2024.

## What is in the folder

| File | What it holds |
|---|---|
| `data/cloudflare-2025-06-12.csv` | the timeline of both organizations, typed from the two reports, one row per event, each row with its source |
| `data/openai-2024-12-11.csv` | the timeline of the new input |
| `draw_timeline.py` | checks a timeline CSV, prints it with the minutes from the impact start and the phase summary, and draws two SVG charts |
| `templates/` | the course's review (PIR) and runbook formats, empty |
| `review/PIR-EXT-001-cloudflare-2025-06-12.md` | the review of the outage |
| `review/larkfield-mapping.md` | which of Larkfield's alerts and runbooks would fire, the shared dependency, three options under one measure, and the one change |
| `review/provider-outage-runbook-change.md` | Larkfield's provider-outage runbook with that change |
| `review/PIR-EXT-002-openai-2024-12-11.md` | the same method on new input |
| `out/` | the two charts of each timeline (made by the script) |
| `SHA256SUMS` | the checksums of the two finished CSVs |
| `dataset.md` | where the facts come from, the licences and the limits |

In the **starter**, the CSVs have only their first rows and `review/` holds the empty templates.
You fill them in. The **finished** folder is one complete answer, for when you are stuck or want
to compare.

## Run it

Python 3.10 or newer, nothing to install (the script uses only the standard library).

macOS or Linux:

```sh
cd public-outage-pir
python3 draw_timeline.py data/cloudflare-2025-06-12.csv
python3 draw_timeline.py data/openai-2024-12-11.csv
```

Windows (PowerShell):

```powershell
cd public-outage-pir
python draw_timeline.py data\cloudflare-2025-06-12.csv
python draw_timeline.py data\openai-2024-12-11.csv
```

Open `out/cloudflare-2025-06-12.svg` in a browser to see the chart. The script stops with
`PROBLEM` lines, and writes no chart, when a row has no source, an unknown kind, a time that does
not match its stated time, or an organization without exactly one `impact-start`.

## Licence

The script: MIT (`LICENSE`). The CSVs and the review documents: CC0 1.0. The reports are not
included: they are copyright of Cloudflare, Google and OpenAI. Read them at their links, and
quote only short passages, with credit.
